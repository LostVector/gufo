from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';out=Path(__file__).resolve().parent;repo=p/'tp2-upstream-8ab834a5-adoption-worktree'
assert(out/'runtime-complete').exists();ci={}
for name,run in [('repository',41485872231),('Windows',41485876452)]:
 d=json.loads(subprocess.check_output(['/home/rkuo/.local/bin/gh','run','view',str(run),'--repo','LostVector/gufo','--json','status,conclusion,headSha,url'],text=True));assert d['status']=='completed'and d['conclusion']=='success'and d['headSha']=='5e7663534afd17f7d4d18162285d3d81f1acf42d',(name,d);ci[name]=d
(out/'CI.json').write_text(json.dumps(ci,indent=2)+'\n')
dest=repo/'docs/patches/tp2-adoption/upstream-8ab834a5-data';dest.mkdir(parents=True,exist_ok=False);files={};allowed={'.py','.sh','.md','.json','.jsonl','.txt','.log','.xml','.stdout','.stderr','.pid'}
for name in ['upstream-8ab834a5-intake-v1','upstream-8ab834a5-http-smoke-v1','upstream-8ab834a5-http-lifecycle-v1']:
 for f in(p/name).rglob('*'):
  if f.is_file()and f.suffix in allowed and '__pycache__'not in f.parts:files[str(f.relative_to(r))]=f
 for base in [r/'results/model-scaling',r/'results/model-scaling/corsair']:
  for f in base.glob(name+'-*'):
   if f.is_file()and f.suffix in allowed:files[str(f.relative_to(r))]=f
reference=json.loads((p/'upstream-8ab834a5-http-smoke-v1/reference.json').read_text())
for d in reference.values():
 f=Path(d['path']);assert hashlib.sha256(f.read_bytes()).hexdigest()==d['sha256'];files[str(f.relative_to(r))]=f
secret=re.compile(rb'(?:--tp-control-token[\s\"\x27,:]+[a-f0-9]{64}|gh[opsu]_[A-Za-z0-9]{30,})')
for name,f in files.items():assert not secret.search(f.read_bytes()),'Possiblecredentialin '+name
manifest={n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for n,f in sorted(files.items())}
with zipfile.ZipFile(dest/'acquisition.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,f in sorted(files.items()):z.write(f,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
meta={'entries':len(files),'zip_bytes':(dest/'acquisition.zip').stat().st_size,'zip_sha256':hashlib.sha256((dest/'acquisition.zip').read_bytes()).hexdigest(),'source':'5e7663534afd17f7d4d18162285d3d81f1acf42d','canonical':'8ab834a5902bf19341750daecf27516a57840dd1','scope':'3commitcanonicalintake,5CPU/2realHIPcachebacking/12parser/fullrelease/source336/smoke12/cache4/cancel9/exactheadCI. No new32K/modelkernelquality/performancequalification; noHC/Q8draftadoption. No models/binaries/controltokens. Offlineauditcannotrerunhardware/livePIDkernelchecks.'};(dest/'archive.json').write_text(json.dumps(meta,indent=2)+'\n');(out/'adoption-record-package.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copy2(out/'offline-check.py',dest/'check.py');print(json.dumps(meta,indent=2))
