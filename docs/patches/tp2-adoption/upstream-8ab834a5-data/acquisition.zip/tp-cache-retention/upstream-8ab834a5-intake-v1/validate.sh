#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
out=$root/tp-cache-retention/upstream-8ab834a5-intake-v1
source_tree=$root/tp-cache-retention/tp2-upstream-8ab834a5-worktree
cpu_build=$root/tp-cache-retention/tp2-upstream-8ab834a5-cpu-build
gpu_build=$root/tp-cache-retention/tp2-upstream-8ab834a5-gpu-build
rocm_root=/home/rkuo/.local/opt/rocm-7.14.1
deps_root=$root/dependencies/gufo-dev
exec 9>"$root/overnight/results/model-matrix.lock"
flock -n 9
export PATH="$root/mtp-snapshot-priority/format-tool/bin:$PATH"
export CPLUS_INCLUDE_PATH="$deps_root/usr/include/x86_64-linux-gnu${CPLUS_INCLUDE_PATH:+:$CPLUS_INCLUDE_PATH}"
export LD_LIBRARY_PATH="$deps_root/usr/lib/x86_64-linux-gnu:$rocm_root/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PKG_CONFIG_SYSROOT_DIR="$deps_root"
export PKG_CONFIG_LIBDIR="$deps_root/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig"
export OPENSSL_ROOT_DIR="$deps_root/usr"
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
cd "$source_tree"
[[ -z $(git diff --name-only --diff-filter=U) ]]
git diff --cached --check
python3 tools/ci/check-format.py > "$out/format.log" 2>&1
python3 tools/ci/check-extension-api.py --base d038b2e84ce7659608cfb239b944086690baa849 --labels '[]' > "$out/api.log" 2>&1
python3 tools/ci/check-docs.py > "$out/docs.log" 2>&1
python3 tools/ci/generate-infrastructure.py --check > "$out/generated.log" 2>&1
python3 -m unittest discover -s tests/functional -p test_cache_workloads.py > "$out/cache-functional-parser.log" 2>&1
cmake --preset cpu-test -B "$cpu_build" -DGUFO_BUILD_TOOLS=OFF -DGUFO_ENABLE_TP2_RDMA=OFF \
 -DCMAKE_C_COMPILER="$rocm_root/bin/amdclang" -DCMAKE_CXX_COMPILER="$rocm_root/bin/amdclang++" \
 -DPKG_CONFIG_EXECUTABLE="$deps_root/usr/bin/pkgconf" -DCMAKE_PREFIX_PATH="$rocm_root;$deps_root/usr" > "$out/cpu.log" 2>&1
cmake --build "$cpu_build" --target text_model_runner_test qwen38_flash_next_runner_options_test qwen38_flash_next_config_test qwen38_flash_next_tp_partition_test qwen38_flash_next_rdma_gid_test --parallel 4 >> "$out/cpu.log" 2>&1
ctest --test-dir "$cpu_build" -R '^(text_model_runner_test|qwen38_flash_next\.(runner_options|config|tp_partition|rdma_gid))$' --output-on-failure --no-tests=error --output-junit "$out/cpu-tests.xml" >> "$out/cpu.log" 2>&1
cmake --preset gpu-test -B "$gpu_build" -DGUFO_BUILD_TOOLS=OFF -DGUFO_ENABLE_TP2_RDMA=ON \
 -DCMAKE_HIP_ARCHITECTURES=gfx1151 -DCMAKE_HIP_COMPILER="$rocm_root/lib/llvm/bin/clang++" \
 -DCMAKE_C_COMPILER="$rocm_root/bin/amdclang" -DCMAKE_CXX_COMPILER="$rocm_root/bin/amdclang++" \
 -DPKG_CONFIG_EXECUTABLE="$deps_root/usr/bin/pkgconf" -DCMAKE_PREFIX_PATH="$rocm_root;$deps_root/usr" > "$out/gpu.log" 2>&1
cmake --build "$gpu_build" --target cache_backing_test --parallel 4 >> "$out/gpu.log" 2>&1
ctest --test-dir "$gpu_build" -R '^cache_backing(_restricted)?_test$' --output-on-failure --no-tests=error --output-junit "$out/gpu-tests.xml" >> "$out/gpu.log" 2>&1
python3 - "$out" <<'PY'
from pathlib import Path
import json,sys,xml.etree.ElementTree as E
p=Path(sys.argv[1]);counts={}
for filename,count in [('cpu-tests.xml',5),('gpu-tests.xml',2)]:
 xs=E.parse(p/filename).findall('.//testcase');assert len(xs)==count and all(x.find('skipped')is None and x.find('failure')is None and x.find('error')is None for x in xs);counts[filename]=len(xs)
(p/'validation.json').write_text(json.dumps({'focused_tests':counts,'format_API_docs_generated':True,'cache_workload_parser':True,'scope':'Uncommitted clean automaticmerge ofcanonical8ab onto maintainedd038; no mergeconflicts/manualresolution.5focusedCPU + realHIP normal/restrictedpin cachebacking fixtures; fakeheap/noncharging/charging/reserve/queryfailure paths. No modelperformance or adoption qualification yet.'},indent=2)+'\n')
PY
touch "$out/validation-complete"
