from pathlib import Path
import hashlib,json,py_compile,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';out=Path(__file__).resolve().parent;src=p/'tp2-upstream-8ab834a5-worktree';build=p/'tp2-upstream-8ab834a5-release-build'
assert(out/'release-build-complete').exists();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();assert head=='5e7663534afd17f7d4d18162285d3d81f1acf42d';assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True).strip()
cache=(build/'CMakeCache.txt').read_text();assert all(s in cache for s in ['BUILD_TESTING:BOOL=OFF','GUFO_ENABLE_TP2_RDMA:BOOL=ON','CMAKE_BUILD_TYPE:STRING=RelWithDebInfo']);binary=r/'instrumentation/bin/gufo-tp2-upstream-5e766353';assert not binary.exists();shutil.copy2(build/'gufo',binary);sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
meta={'path':str(binary),'sha256':sha(binary),'source_commit':head,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip(),'canonical_head':'8ab834a5902bf19341750daecf27516a57840dd1','build_testing':False,'full_fresh_release':True,'scope':'Canonical3commit intake into maintainedd038, automaticmerge5e; HC/Q8drafts excluded. New RAMregistration admission policy/capacityerror/parserrecognition only, no modelkernel/scheduling/transport change.'};(out/'binary.json').write_text(json.dumps(meta,indent=2)+'\n')
source={'candidate':{'path':str(src),'source_commit':head,'source_sha256':{str(f.relative_to(src)):sha(f)for folder in ['src','include','cmake']for f in(src/folder).rglob('*')if f.is_file()and '__pycache__'not in f.parts}}}
for kind in ['smoke','lifecycle']:
 old=p/f'upstream-773a1641-http-{kind}-v1';lab=p/f'upstream-8ab834a5-http-{kind}-v1';lab.mkdir(exist_ok=False)
 names=['run.py','engine.py','server-rank.sh','requests.py']+(['analyze.py','reference.json','design.json']if kind=='smoke'else['validate.py','cache-requests.py','cancel-requests.py'])
 for n in names:
  s=(old/n).read_text().replace(str(old),str(lab)).replace(old.name,lab.name).replace('tp2-upstream-9c715720','tp2-upstream-5e766353').replace('Canonical773a1641Combined9c715720','Canonical8ab834a5Combined5e766353').replace('Canonical773a1641 combined9c715720','Canonical8ab834a5 combined5e766353').replace('Combined PLE/earlyEnd9c715720/canonical773a1641','Canonical8ab/cacheadmission+capacityfix5e766353')
  (lab/n).write_text(s)
 if kind=='smoke':
  (lab/'reference.json').write_bytes((old/'validated-reference.json').read_bytes());design=json.loads((lab/'design.json').read_text());design['scope']='Onefresh full5e production TP2 provider startup and12standard requests, identities/cachework vs archivedqualified9c. NewRAMcacheadmission/capacityerror/parser3commit canonical8abintake. Actualsource/binary/MTP/options/boot/driver/rails/kernel/errors/PIDexit/idle guards. No new speed/equivalence/defaultclaim; no systemchanges/tablewarm. GC snapshots/heap pressure covered separately byrealHIPwrapperfixtures.';(lab/'design.json').write_text(json.dumps(design,indent=2)+'\n')
 (lab/'binaries.json').write_text(json.dumps({'candidate':{'name':binary.name,'sha256':meta['sha256']}},indent=2)+'\n');(lab/'source-preflight.json').write_text(json.dumps(source,indent=2)+'\n');(lab/'release-build-provenance.json').write_text(json.dumps(meta,indent=2)+'\n');(lab/'server-rank.sh').chmod(0o755)
 for f in lab.glob('*.py'):py_compile.compile(str(f),doraise=True)
print('Prepared fresh full5e production smoke/cachecancel qualification')
