#!/bin/bash
set -euo pipefail
cd /home/rkuo/strix-dispatch-investigation
out=tp-cache-retention/upstream-8ab834a5-intake-v1
python3 "$out/prepare-runtime.py" > "$out/runtime-prepare.log" 2>&1
python3 -u tp-cache-retention/upstream-8ab834a5-http-smoke-v1/run.py > tp-cache-retention/upstream-8ab834a5-http-smoke-v1/controller.log 2>&1
python3 tp-cache-retention/upstream-8ab834a5-http-smoke-v1/analyze.py > tp-cache-retention/upstream-8ab834a5-http-smoke-v1/analyze.log 2>&1
python3 -u tp-cache-retention/upstream-8ab834a5-http-lifecycle-v1/run.py > tp-cache-retention/upstream-8ab834a5-http-lifecycle-v1/controller.log 2>&1
python3 tp-cache-retention/upstream-8ab834a5-http-lifecycle-v1/validate.py > tp-cache-retention/upstream-8ab834a5-http-lifecycle-v1/validate.log 2>&1
touch "$out/runtime-complete"
