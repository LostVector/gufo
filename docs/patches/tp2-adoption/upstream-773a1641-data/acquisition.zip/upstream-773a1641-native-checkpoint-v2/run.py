from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess,time
lab=Path(__file__).resolve().parent;r=lab.parents[1];lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(lab/'protocol.json').exists()
def command(rank,args):return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','rk-corsair-ai',shlex.join(args)]if rank else args
def call(rank,args):return subprocess.check_output(command(rank,args),text=True,stderr=subprocess.STDOUT,timeout=60)
def inventory(rank):return json.loads(call(rank,['python3',str(r/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']))
def snapshot(rank,tag):
 text=call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']);(lab/f'{tag}-r{rank}.txt').write_text(text)
 return {s.split(': ',1)[0]:int(s.split(': ',1)[1]) for s in text.splitlines()if ': 'in s and s.split(': ',1)[1].isdigit()}
source=r/'tp-cache-retention/tp2-upstream-773a1641-worktree';head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert head=='9c7157201e8aa30cbfc51ddf3595a3dea13b196a';assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
probe=lab/'probe';meta=json.loads((lab/'binary.json').read_text());assert hashlib.sha256(probe.read_bytes()).hexdigest()==meta['sha256']
call(1,['mkdir','-p',str(lab)]);subprocess.run(['rsync','-rt',str(probe),'rk-corsair-ai:'+str(probe)],check=True);assert call(1,['sha256sum',str(probe)]).split()[0]==meta['sha256']
initial=[];before=[]
for rank in(0,1):
 inv=inventory(rank);assert inv['module']=='81C6FF2FBAC473C7AB21844'and inv['refcnt']==0;initial.append(inv);(lab/f'initial-r{rank}.json').write_text(json.dumps(inv,indent=2)+'\n');before.append(snapshot(rank,'before'))
(lab/'protocol.json').write_text(json.dumps(dict(source_commit=head,binary=meta,initial=initial,cases=8,scope='Actual supported TP2 mirrored separate captures, derived repository payload/score/sampled-continuation assertions retained. In-pass claim0 checked; actual boundary SnapshotBytes used. AR/MTP, short/resumed crossing4K, normal/asymmetric reported headroom. Not distributed in-pass capture coverage. Existing per-process free-byte test interposer only. No performance claim or system power/memory change.'),indent=2)+'\n')
jobs=[];started=time.monotonic();success=False
try:
 for rank in(0,1):
  args=[str(probe),str(rank),'192.168.64.125','usb4_rdma0','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf']
  script='cd '+shlex.quote(str(r))+'\nsource native-rdma/env.sh\nexport LD_LIBRARY_PATH='+shlex.quote(str(r/'tp-cache-retention/fork-integration-v1/runtime/lib'))+':"$LD_LIBRARY_PATH"\nunset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX\necho $$ > '+shlex.quote(str(lab/f'rank{rank}.pid'))+'\nexec '+shlex.join(args)+' > '+shlex.quote(str(lab/f'rank{rank}.stdout'))+' 2> '+shlex.quote(str(lab/f'rank{rank}.stderr'))
  jobs.append(subprocess.Popen(command(rank,['bash','-c',script])))
 while any(p.poll()is None for p in jobs):
  assert not[p.returncode for p in jobs if p.returncode not in(None,0)],'Probe failed; preserve both logs'
  assert time.monotonic()-started<900,'Probe deadline'
  time.sleep(.25)
 assert all(p.returncode==0 for p in jobs);success=True
finally:
 for rank,p in enumerate(jobs):
  if p.poll()is None:
   pid=call(rank,['cat',str(lab/f'rank{rank}.pid')]).strip();assert call(rank,['readlink','-f','/proc/'+pid+'/exe']).strip()==str(probe);call(rank,['kill','-INT',pid])
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:call(rank,['kill','-TERM',pid]);p.wait(timeout=10)
 for suffix in('pid','stdout','stderr'):subprocess.run(['rsync','-rt','rk-corsair-ai:'+str(lab/f'rank1.{suffix}'),str(lab)+'/'],check=True)
 final=[];deltas=[]
 for rank in(0,1):
  inv=inventory(rank);final.append(inv);(lab/f'final-r{rank}.json').write_text(json.dumps(inv,indent=2)+'\n');after=snapshot(rank,'after');deltas.append({k:after[k]-before[rank][k]for k in before[rank]if k in after and after[k]!=before[rank][k]})
 (lab/'result.json').write_text(json.dumps(dict(success=success,exits=[p.returncode for p in jobs],elapsed_seconds=time.monotonic()-started,final=final,counter_deltas=deltas),indent=2)+'\n')
assert success
for rank in(0,1):
 text=(lab/f'rank{rank}.stdout').read_text();assert 'PASS native_checkpoint_cases=8 asymmetric_headroom=true repository_snapshot_assertions=true supported_mirrored_capture=true'in text
 assert text.count('restore exact')==8
 assert final[rank]['module']==initial[rank]['module']and final[rank]['refcnt']==0
 for key in('boot_id','kernel','cmdline','mask','routers','selected_device'):
  assert key in initial[rank]and final[rank][key]==initial[rank][key],(rank,key)
 for key in('data_wr_retransmit','data_wr_rnr_retransmit','data_wr_timeout','data_tx_errors','data_read_resp_retransmit','data_rx_active_timeout','data_rx_reorder_timeout'):
  assert key in before[rank]and deltas[rank].get(key,0)==0,(rank,key,deltas[rank].get(key))
(lab/'complete').write_text('8native checkpoint cases per rank; source/current production GPU objects; normal/asymmetric headroom; no speed claim\n')
print('PASS native TP2 checkpoint oracle eight cases per rank; runtime guards clean',flush=True)
