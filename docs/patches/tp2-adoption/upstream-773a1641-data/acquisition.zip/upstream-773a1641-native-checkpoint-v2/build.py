from pathlib import Path
import hashlib,json,os,shlex,subprocess
lab=Path(__file__).resolve().parent;r=lab.parents[1];build=r/'tp-cache-retention/tp2-upstream-773a1641-gpu-build'
assert(r/'tp-cache-retention/fork-integration-v1/upstream-773a1641-builds-complete').exists()
assert not(lab/'commands.json').exists()
entries=json.loads((build/'compile_commands.json').read_text());e=next(e for e in entries if e['file'].endswith('/tests/models/qwen38_flash_next/snapshot_test.cpp'));c=shlex.split(e['command']);c[c.index('-o')+1]=str(lab/'probe.o');c[-1]=str(lab/'probe.cpp');assert '-DENGINE_ENABLE_HIP=1'in c and '-UNDEBUG'in c
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','qwen38_flash_next_snapshot_test'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2];i=next(i for i,x in enumerate(link)if x.endswith('/snapshot_test.cpp.o'));link[i]=str(lab/'probe.o');link[link.index('-o')+1]=str(lab/'probe')
if '-Xlinker'in link:
 i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
env=os.environ.copy();deps=r/'dependencies/gufo-dev/usr';env['CPLUS_INCLUDE_PATH']=str(deps/'include/x86_64-linux-gnu');env['LD_LIBRARY_PATH']=str(deps/'lib/x86_64-linux-gnu')+':/home/rkuo/.local/opt/rocm-7.14.1/lib'
(lab/'commands.json').write_text(json.dumps(dict(compile=c,link=link,cwd=str(build),scope='External native TP2 main derives repository checkpoint assertions but stages supported Sync(boundary)/SaveSnapshot/Sync(tail), checks unsupported in-pass claim0, and uses the actual boundary SnapshotBytes claim; current canonical-merged assertions-enabled GPU test libraries and existing reported-free interposer. All original production/GPU/archive members unchanged. No timing claim.'),indent=2)+'\n')
with(lab/'build.log').open('w')as f:
 for command in(c,link):subprocess.run(command,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
(lab/'binary.json').write_text(json.dumps(dict(path=str(lab/'probe'),sha256=hashlib.sha256((lab/'probe').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((lab/'probe.cpp').read_bytes()).hexdigest()),indent=2)+'\n')
