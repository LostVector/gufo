// Run the repository's exact checkpoint oracle on both native TP ranks.
#define main RepositorySnapshotTestMain
#include "/home/rkuo/strix-dispatch-investigation/tp-cache-retention/tp2-upstream-773a1641-worktree/tests/models/qwen38_flash_next/snapshot_test.cpp"
#undef main
#include "src/models/qwen38_flash_next/kernels/rocm/verbs.hpp"
void CheckMirroredCheckpoint(const std::shared_ptr<qfn::Model>& model,
                            std::span<const std::int32_t> prompt,
                            gufo::core::SessionMode mode, std::size_t warm = 0,
                            std::uint32_t suffix = 7) {
  std::string error;
  auto source = model->CreateSession(mode, 8192, &error);
  auto whole = model->CreateSession(mode, 8192, &error);
  auto split = model->CreateSession(mode, 8192, &error);
  Require(source && whole && split, error);
  if (warm)
    Require(source->Sync(prompt.first(warm), &error) &&
                whole->Sync(prompt.first(warm), &error) &&
                split->Sync(prompt.first(warm), &error),
            error);
  const auto boundary = static_cast<std::uint32_t>(prompt.size() - suffix);
  Require(source->PrefillCheckpointBytes(boundary) == 0,
          "distributed in-pass checkpoint remains unadvertised");
  Require(source->Sync(prompt.first(boundary), &error), error);
  const auto claim = source->SnapshotBytes();
  const auto started = std::chrono::steady_clock::now();
  auto checkpoint = source->SaveSnapshot(&error);
  const double capture_ms = Millis(started);
  Require(checkpoint != nullptr && source->Sync(prompt, &error), error);
  Require(std::isfinite(capture_ms) && capture_ms > 0,
          "in-pass checkpoint capture time was not reported");
  Require(checkpoint != nullptr, "in-pass checkpoint was not returned");
  Require(checkpoint->SizeBytes() == claim,
          "in-pass checkpoint differs from its admission claim");
  Require(whole->Sync(prompt.first(boundary), &error) &&
              whole->Sync(prompt, &error),
          error);
  Require(source->Logits().size() == whole->Logits().size() &&
              std::memcmp(source->Logits().data(), whole->Logits().data(),
                          source->Logits().size_bytes()) == 0,
          "in-pass checkpoint changed split-pass logits");
  const auto continued =
      Decode(*source, 8,
             {.temperature = 0.8F, .top_k = 20, .top_p = 0.95F, .seed = 73}, 8);
  RequireSame(
      continued,
      Decode(*whole, 8,
             {.temperature = 0.8F, .top_k = 20, .top_p = 0.95F, .seed = 73}, 8),
      "in-pass sampled continuation");
  Require(std::memcmp(source->Logits().data(), whole->Logits().data(),
                      source->Logits().size_bytes()) == 0,
          "in-pass sampled continuation changed logits");
  Require(split->Sync(prompt.first(boundary), &error), error);
  const auto expected = Payload(*split);
  source->Reset();
  const auto actual = Payload(*checkpoint);
  Require(source->RestoreSnapshot(*checkpoint, &error), error);
  Require(Payload(*source) == actual,
          "in-pass checkpoint did not survive source reset");
  Require(actual == expected,
          "in-pass boundary differs from a pass ending there");
  auto raw = model->CreateSession(mode, 8192, &error);
  Require(raw && raw->RestoreSnapshot(actual, &error), error);
  Require(source->Sync(prompt, &error), error);
  Require(raw->Sync(prompt, &error), error);
  Require(Payload(*source) == Payload(*raw),
          "borrowed and serialized boundaries resumed differently");
  Require(split->Sync(prompt, &error), error);
  Require(Payload(*source) == Payload(*split),
          "restored boundary did not resume exactly");
  std::cout << "in-pass checkpoint mode=" << static_cast<int>(mode)
            << " tokens=" << prompt.size() << " boundary=" << boundary
            << " warm=" << warm << " restore exact\n";
}

void CheckBorrowedSnapshots(const std::shared_ptr<qfn::Model>& model,
                            std::span<const std::int32_t> prompt,
                            gufo::core::SessionMode mode) {
  std::string error;
  auto source = model->CreateSession(mode, 8192, &error);
  Require(source != nullptr, error);
  Require(source->Sync(prompt, &error), error);
  const auto frontier_bytes = Payload(*source);
  auto eager =
      source->SaveSnapshot(&error, qfn::Session::SnapshotMode::kMaterialized);
  Require(eager != nullptr, error);
  Require(Payload(*eager) == frontier_bytes,
          "export capture differs from borrowed checkpoint bytes");
  auto frontier = source->SaveSnapshot(&error);
  Require(frontier != nullptr, error);
  source->Reset();
  Require(source->RestoreSnapshot(*frontier, &error), error);
  Require(Payload(*source) == frontier_bytes,
          "rewind after logical reset changed checkpoint rows");

  std::vector<std::int32_t> extended(prompt.begin(), prompt.end());
  extended.insert(extended.end(), prompt.begin(), prompt.begin() + 9);
  Require(source->Sync(extended, &error), error);
  const auto boundary_bytes = Payload(*source);
  auto boundary = source->SaveSnapshot(&error);
  Require(boundary != nullptr, error);
  extended.insert(extended.end(), prompt.begin() + 9, prompt.begin() + 16);
  Require(source->Sync(extended, &error), error);

  // Rewind without reading either borrowed payload. Preserve B's suffix,
  // overwrite it with a different branch, then restore B over that branch.
  Require(source->RestoreSnapshot(*frontier, &error), error);
  std::vector<std::int32_t> branch(prompt.begin(), prompt.end());
  branch.insert(branch.end(), prompt.begin() + 20, prompt.begin() + 36);
  Require(source->Sync(branch, &error), error);
  auto other_branch = source->SaveSnapshot(&error);
  Require(other_branch != nullptr, error);
  const auto other_bytes = Payload(*source);
  auto fork = model->CreateSession(mode, 8192, &error);
  Require(fork != nullptr, error);
  Require(fork->RestoreSnapshot(*boundary, &error), error);
  Require(Payload(*fork) == boundary_bytes,
          "foreign fork lost its live prefix or detached tail");
  auto fork_boundary = fork->SaveSnapshot(&error);
  Require(fork_boundary != nullptr, error);
  // A fresh checkpoint still has no host KV. Fork from it while the source
  // continues above those rows; neither path may materialize its host prefix.
  auto live_branch = source->SaveSnapshot(&error);
  Require(live_branch != nullptr, error);
  auto fork_reader = std::async(std::launch::async, [&] {
    std::string fork_error;
    Require(fork->RestoreSnapshot(*live_branch, &fork_error), fork_error);
    return Payload(*fork);
  });
  auto appended = branch;
  appended.insert(appended.end(), prompt.begin() + 36, prompt.begin() + 40);
  Require(source->Sync(appended, &error), error);
  Require(fork_reader.get() == other_bytes,
          "concurrent device fork changed committed checkpoint rows");
  // Retained shared rows still belong to the target session: resetting and
  // overwriting that prefix must protect them even without another capture.
  fork->Reset();
  Require(fork->Sync(prompt.subspan(20, 32), &error), error);
  Require(Payload(*fork_boundary) == boundary_bytes,
          "reset after sibling fork overwrote retained checkpoint rows");
  Require(fork->RestoreSnapshot(*fork_boundary, &error), error);
  Require(Payload(*fork) == boundary_bytes,
          "sibling fork checkpoint did not restore its protected suffix");
  Require(source->RestoreSnapshot(*boundary, &error), error);
  Require(Payload(*source) == boundary_bytes,
          "borrowed restore differs from complete snapshot");
  Require(source->RestoreSnapshot(*other_branch, &error), error);
  Require(Payload(*source) == other_bytes,
          "second branch lost its overwritten rows");

  // Disk/fork readers can copy committed rows while this session appends.
  auto reader =
      std::async(std::launch::async, [&] { return Payload(*frontier); });
  branch.insert(branch.end(), prompt.begin() + 36, prompt.begin() + 52);
  Require(source->Sync(branch, &error), error);
  Require(reader.get() == frontier_bytes,
          "concurrent append changed borrowed snapshot");
  source->Reset();
  Require(Payload(*boundary) == boundary_bytes,
          "reset discarded borrowed checkpoint rows");
  Require(Payload(*other_branch) == other_bytes,
          "reset discarded a detached branch");

  Require(source->Sync(prompt, &error), error);
  auto overwritten = source->SaveSnapshot(&error);
  Require(overwritten != nullptr, error);
  source->Reset();
  Require(source->Sync(prompt.subspan(20, 32), &error), error);
  Require(Payload(*overwritten) == frontier_bytes,
          "first write after reset overwrote a borrowed checkpoint");
  Require(source->RestoreSnapshot(*overwritten, &error), error);
  auto at_decode = source->SaveSnapshot(&error);
  Require(at_decode != nullptr, error);
  const auto decode_bytes = Payload(*source);
  auto decode_reader =
      std::async(std::launch::async, [&] { return Payload(*at_decode); });
  (void)Decode(*source, 16,
               {.temperature = 0.8F, .top_k = 40, .top_p = 0.9F, .seed = 7}, 8);
  Require(decode_reader.get() == decode_bytes,
          "concurrent graph capture/decode changed checkpoint bytes");

  auto survivor = source->SaveSnapshot(&error);
  Require(survivor != nullptr, error);
  const auto survivor_bytes = Payload(*source);
  auto final_reader =
      std::async(std::launch::async, [&] { return Payload(*survivor); });
  source.reset();
  Require(final_reader.get() == survivor_bytes,
          "concurrent source destruction changed borrowed rows");
  Require(Payload(*survivor) == survivor_bytes,
          "source destruction discarded borrowed rows");
  Require(fork->RestoreSnapshot(*survivor, &error), error);
  Require(Payload(*fork) == survivor_bytes,
          "foreign restore after source destruction lost checkpoint rows");
  std::cout << "borrowed checkpoints: rewind, branches, reader, reset, "
               "destruction pass\n";
}

void CheckCheckpointRetention(const std::shared_ptr<qfn::Model>& model,
                              std::span<const std::int32_t> prompt,
                              gufo::core::SessionMode mode) {
  std::string error;
  auto source = model->CreateSession(mode, 8192, &error);
  Require(source && source->Sync(prompt.first(32), &error), error);
  const auto expected = Payload(*source);
  auto small = source->SaveSnapshot(&error);
  Require(small != nullptr, error);
  Require(source->OwnsSnapshot(*small), "checkpoint lost its source identity");
  const auto before = small->DeviceBytes();
  Require(source->Sync(prompt, &error), error);
  auto large = source->SaveSnapshot(&error);
  Require(large != nullptr, error);
  source->Reset();
  Require(source->Sync(prompt.first(16), &error), error);
  Require(large->DeviceBytes() > before + (80ULL << 20),
          "deep checkpoint did not preserve its overwritten rows");
  large.reset();
  // Count owned backing blocks rather than HIP's global heap cache. A short
  // prefix may retain bounded packing slack, but never the deep-only rows.
  const auto after = small->DeviceBytes();
  Require(after <= before + (8ULL << 20),
          "short checkpoint retained the discarded deep allocation");
  Require(source->RestoreSnapshot(*small, &error), error);
  Require(Payload(*source) == expected,
          "discarding a deep checkpoint changed its shared short prefix");
  std::cout << "checkpoint retention mode=" << static_cast<int>(mode)
            << " additional_bytes=" << after - before
            << " short prefix exact\n";
}

int main(int argc, char** argv) {
  std::shared_ptr<qfn::rocm::Communicator> comm;
  try {
    Require(argc == 6, "rank bootstrap device target mtp");
    const auto rank = static_cast<unsigned>(std::stoul(argv[1]));
    Require(rank < 2, "rank");
    qfn::rocm::IbrverbsConfig config;
    config.rank = rank;
    config.bootstrap_host = argv[2];
    config.rdma_device = argv[3];
    config.bootstrap_port = 29669;
    std::string error;
    comm = qfn::rocm::CreateIbrverbsCommunicator(config, &error);
    Require(bool(comm), error);
    qfn::ModelOptions options;
    options.max_context = 8192;
    options.mtp_model_path = argv[5];
    options.max_draft_tokens = 7;
    options.tp_world_size = 2;
    options.tp_rank = rank;
    options.communicator = comm;
    auto model = qfn::Model::Load(argv[4], options, &error);
    Require(bool(model), error);
    const auto pattern = model->Tokenize(
        "Independent rank checkpoint replay retains exact recurrent and KV state. ");
    Require(!pattern.empty(), "token pattern");
    std::vector<std::int32_t> prompt(4100);
    for (std::size_t i = 0; i < prompt.size(); ++i)
      prompt[i] = pattern[i % pattern.size()];
    Require(comm->BeginOperation(773416, &error), error);
    unsigned cases = 0;
    for (bool asymmetric : {false, true}) {
      // This only changes reported free bytes, not real memory or system policy.
      // Rank0 has no reported checkpoint headroom while rank1 retains real free.
      LimitReportedDeviceFree(asymmetric && rank == 0
                                  ? 0
                                  : std::numeric_limits<std::size_t>::max());
      for (const auto mode : {gufo::core::SessionMode::kAutoregressive,
                             gufo::core::SessionMode::kSpeculative}) {
        CheckMirroredCheckpoint(model,
            std::span<const std::int32_t>(prompt).first(2052), mode, 0, 5);
        ++cases;
        CheckMirroredCheckpoint(model, prompt, mode, 1999, 5);
        ++cases;
      }
    }
    LimitReportedDeviceFree(std::numeric_limits<std::size_t>::max());
    Require(comm->EndOperation(773416, &error), error);
    Require(cases == 8, "coverage");
    std::cout << "PASS native_checkpoint_cases=8 asymmetric_headroom=true "
                 "repository_snapshot_assertions=true supported_mirrored_capture=true\n";
    return 0;
  } catch (const std::exception& e) {
    if (comm) comm->Abort(e.what());
    std::cerr << e.what() << '\n';
    return 1;
  }
}
