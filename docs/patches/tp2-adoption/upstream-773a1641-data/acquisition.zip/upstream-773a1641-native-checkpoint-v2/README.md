# Supported native TP=2 checkpoint qualification

Source: integration9c715720, canonical773a1641 merged into maintained94f1232d.
Eight cases per rank pass: AR/MTP, 2,047/4,095 boundaries, fresh and resumed
contexts, normal and asymmetric process-reported free device memory. Both ranks
run the same sequence. The existing device-headroom interposer changes a reported
number only; it does not change system policy or actual memory availability.

The original v1 fixture invoked the repository's single-node in-pass oracle.
It failed because that oracle expects nonzero future admission, whereas the
engine intentionally returns0 and the distributed runner returns nullopt for
in-pass checkpoints. That capability is not mirrored by the current control RPC.
Both original logs and counter/cleanup records are retained. This is an invalid
fixture for an explicitly unsupported capability, not a hidden numerical failure.

V2 derives the same score, payload, sampled continuation, reset, borrowed and
serialized restore assertions from that oracle. Its only scheduling adaptation is
the supported ordinary prefill-to-boundary, separate SaveSnapshot, then remainder.
It asserts future in-pass admission stays0 and checks the returned checkpoint
against the actual boundary SnapshotBytes claim. No production code, golden or
numerical tolerance was changed to accept this test.

The inherited helper's output strings still say "in-pass checkpoint"; these are
legacy assertion labels, not proof of in-pass TP support. The final marker and
protocol explicitly identify supported mirrored separate captures.

This test does not exercise the new local checkpoint-arena reservation path:
that path is qualified separately by the repository's actual single-node snapshot
and adapter --in-pass-only executables, including zero reported headroom and normal
arena capture. Distributed HTTP still uses mirrored separate captures. Kernel,
boot flags, driver, topology and idle state match before/after; no timeout or
retransmission counters increased. This is correctness, not a speed benchmark.
