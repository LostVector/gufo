#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
cd "$root"
test -f tp-cache-retention/fork-integration-v1/upstream-773a1641-release-build-complete
python3 tp-cache-retention/fork-integration-v1/prepare-773a1641-runtime.py
source cable-prep/env.sh
source native-rdma/env.sh
export LD_LIBRARY_PATH="$root/tp-cache-retention/fork-integration-v1/runtime/lib:$LD_LIBRARY_PATH"
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
for phase in smoke lifecycle; do
 out="tp-cache-retention/upstream-773a1641-http-$phase-v1"
 python3 -u "$out/run.py" > "$out/controller.log" 2>&1
 if [[ $phase == smoke ]]; then
  python3 "$out/analyze.py" > "$out/validate.log" 2>&1
 else
  python3 "$out/validate.py" > "$out/validate.log" 2>&1
 fi
 echo "$(date -Is) PASS $phase"
done
touch tp-cache-retention/fork-integration-v1/upstream-773a1641-runtime-complete
