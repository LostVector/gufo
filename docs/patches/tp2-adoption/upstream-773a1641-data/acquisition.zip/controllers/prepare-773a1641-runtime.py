"""Prepare fresh production startup/lifecycle qualification for the upstream sync."""
from pathlib import Path
import hashlib
import json
import py_compile
import shutil
import subprocess

r = Path('/home/rkuo/strix-dispatch-investigation')
f = Path(__file__).resolve().parent
source = r / 'tp-cache-retention/tp2-upstream-773a1641-worktree'
commit = '9c7157201e8aa30cbfc51ddf3595a3dea13b196a'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == commit
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()
assert (f / 'upstream-773a1641-release-build-complete').exists()
build = r / 'tp-cache-retention/tp2-upstream-773a1641-release-build'
cache = (build / 'CMakeCache.txt').read_text()
assert 'BUILD_TESTING:BOOL=OFF' in cache and 'GUFO_ENABLE_TP2_RDMA:BOOL=ON' in cache
assert 'CMAKE_BUILD_TYPE:STRING=RelWithDebInfo' in cache
binary = r / 'instrumentation/bin/gufo-tp2-upstream-9c715720'
assert not binary.exists()
shutil.copy2(build / 'gufo', binary)
sha = hashlib.sha256(binary.read_bytes()).hexdigest()
entry = dict(path=str(binary), sha256=sha, source_commit=commit, build_testing=False,
             source_tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=source, text=True).strip(),
             canonical_head='773a16419282a3b9790d685ce6b4dd980b285943')
(f / 'upstream-773a1641-release-binary.json').write_text(json.dumps(entry, indent=2) + '\n')
paths = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
         for directory in ('src', 'include', 'cmake')
         for p in (source / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
pre = dict(candidate=dict(path=str(source), source_commit=commit, source_sha256=paths))
for suffix in ('smoke', 'lifecycle'):
    old = r / f'tp-cache-retention/platform-http-{suffix}-v1'
    out = r / f'tp-cache-retention/upstream-773a1641-http-{suffix}-v1'
    out.mkdir()
    names = ['run.py', 'engine.py', 'server-rank.sh', 'requests.py']
    names += ['analyze.py', 'reference.json', 'design.json'] if suffix == 'smoke' else ['validate.py', 'cache-requests.py', 'cancel-requests.py']
    for name in names:
        text = (old / name).read_text().replace(str(old), str(out))
        text = text.replace('tp2-platform-373a98cd', binary.name.removeprefix('gufo-'))
        text = text.replace('Portable control/cache373a98cd/canonical05f0a9a0', 'Combined PLE/earlyEnd9c715720/canonical773a1641')
        text = text.replace('Canonical f25f4744 merge4e8a2dc0', 'Canonical773a1641 combined9c715720')
        text = text.replace('CanonicalF25f4744Merge4e8a2dc0ReleaseNativeWire21actualMTP', 'Canonical773a1641Combined9c715720ReleaseNativeWire21actualMTP')
        text = text.replace('Wire21', 'Wire22').replace('wire21', 'wire22')
        (out / name).write_text(text)
    (out / 'server-rank.sh').chmod(0o755)
    (out / 'binaries.json').write_text(json.dumps(dict(candidate=dict(name=binary.name, sha256=sha)), indent=2) + '\n')
    (out / 'source-preflight.json').write_text(json.dumps(pre, indent=2) + '\n')
    (out / 'release-build-provenance.json').write_text(json.dumps(entry, indent=2) + '\n')
    for path in out.glob('*.py'):
        py_compile.compile(str(path), doraise=True)
    print('Prepared', out.name, flush=True)
