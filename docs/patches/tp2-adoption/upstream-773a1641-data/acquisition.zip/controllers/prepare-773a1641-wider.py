"""Matched current94 versus canonical773 integration; no old statistics relabeling."""
from pathlib import Path
import json,py_compile
r=Path('/home/rkuo/strix-dispatch-investigation');lab=r/'tp-cache-retention';f=lab/'fork-integration-v1';old=lab/'early-end-wider-concurrency-v1';out=lab/'upstream-773a1641-wider-v1'
assert(f/'upstream-773a1641-models-complete').exists();out.mkdir(exist_ok=False)
for n in('run.py','requests.py','analyze.py','engine.py','server-rank.sh','design.json','README.md'):
 s=(old/n).read_text().replace(str(old),str(out)).replace(old.name,out.name)
 s=s.replace('Maintained e250a07c vs isolated early-End dd9449e6.','Maintained94f1232d vs canonical773 integration9c715720.')
 s=s.replace('Exact baseline e250a07c / corrected candidate dd9449e6.','Exact baseline94f1232d / candidate9c715720; native wire22 matching peers.')
 s=s.replace('e250a07c / dd9449e6 / e250a07c','94f1232d / 9c715720 / 94f1232d')
 (out/n).write_text(s)
(out/'server-rank.sh').chmod(0o755)
bins={};sources={};provenance={}
for role,name in [('baseline','upstream-c32136f8-http-smoke-v1'),('candidate','upstream-773a1641-http-smoke-v1')]:
 p=lab/name;bins[role]=json.loads((p/'binaries.json').read_text())['candidate'];sources[role]=json.loads((p/'source-preflight.json').read_text())['candidate'];provenance[role]=json.loads((p/'release-build-provenance.json').read_text())
assert provenance['candidate']['canonical_head']=='773a16417c29e83dd55ab66c5e703e895ab8f03e'
provenance['candidate']['canonical_head']='773a16419282a3b9790d685ce6b4dd980b285943'
provenance['candidate']['canonical_label_erratum']=json.loads((f/'upstream-773a1641-canonical-head-erratum.json').read_text())
for name,d in [('binaries.json',bins),('source-preflight.json',sources),('release-build-provenance.json',provenance)]: (out/name).write_text(json.dumps(d,indent=2)+'\n')
d=json.loads((out/'design.json').read_text());d['scope']+=' Matched current94/source9c canonical773 intake, no reuse or pooling of older measurements. Bounded C3/C4/ragged functional/ordering and mandatory phase checks, not throughput significance/equivalence.';(out/'design.json').write_text(json.dumps(d,indent=2)+'\n')
for p in out.glob('*.py'):py_compile.compile(str(p),doraise=True)
print(out)
