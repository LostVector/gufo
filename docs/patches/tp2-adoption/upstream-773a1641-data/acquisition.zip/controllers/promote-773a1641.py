"""Adopt a canonical correctness intake, retaining inconclusive timing explicitly."""
from pathlib import Path
import datetime,fcntl,hashlib,json,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');f=Path(__file__).resolve().parent;repo=r/'reference/gufo-rdma';wt=r/'tp-cache-retention/tp2-windows-macro-worktree';src=r/'tp-cache-retention/tp2-upstream-773a1641-worktree'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
oldmain='c32136f87c29e83dd55ab66c5e703e895ab8f03e';oldtp='94f1232d4b28b2f4cec4ecc4505492283c6e2b54';main='773a16419282a3b9790d685ce6b4dd980b285943';head='9c7157201e8aa30cbfc51ddf3595a3dea13b196a';dest=f/'upstream-773a1641-promoted.json';assert not dest.exists()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def read(path):return json.loads(path.read_text())
checks={}
for run in(41453594920,41453598440):
 d=json.loads(subprocess.check_output(['/home/rkuo/.local/bin/gh','run','view',str(run),'--repo','LostVector/gufo','--json','status,conclusion,headSha,url'],text=True));assert d['headSha']==head and d['status']=='completed'and d['conclusion']=='success',d;checks[str(run)]=d
for a,b in((oldmain,main),(oldtp,head),(main,head)):git('merge-base','--is-ancestor',a,b)
assert git('-C',str(wt),'rev-parse','HEAD')==oldtp and not git('-C',str(wt),'status','--porcelain')
assert git('-C',str(src),'rev-parse','HEAD')==head and not git('-C',str(src),'status','--porcelain')
assert not git('diff',oldtp,head,'--','src/models/qwen38_flash_next/kernels/rocm/batch.cpp'),'Unqualified Q8 patch must remain excluded'
remote={line.split()[1]:line.split()[0]for line in git('ls-remote','fork','refs/heads/main','refs/heads/tp2').splitlines()};assert remote=={'refs/heads/main':oldmain,'refs/heads/tp2':oldtp},remote
for name in('release-build','builds','models','native-qualification'):assert(f/f'upstream-773a1641-{name}-complete').exists()
assert(r/'tp-cache-retention/upstream-773a1641-tp1-headroom-v1/complete').exists()
for name in('upstream-773a1641-native-checkpoint-v2','upstream-773a1641-native-long-checkpoint-v1'):assert(r/'tp-cache-retention'/name/'complete').exists()
assert '100% tests passed, 0 tests failed out of 4'in(f/'upstream-773a1641-validation-v1/cpu.log').read_text()
proof=read(f/'upstream-773a1641-release-binary.json');assert proof['source_commit']==head and proof['canonical_head']==main and not proof['build_testing'];assert hashlib.sha256(Path(proof['path']).read_bytes()).hexdigest()==proof['sha256']
paths=[f/'upstream-773a1641-source.json',f/'upstream-773a1641-release-binary.json',f/'upstream-773a1641-canonical-head-erratum.json',f/'upstream-773a1641-gpu-v1/validation.json',f/'upstream-773a1641-timing-review.json']
paths += [r/'tp-cache-retention'/p for p in('upstream-773a1641-http-smoke-v1/validation.json','upstream-773a1641-http-lifecycle-v1/validation.json','upstream-773a1641-wider-v1/validation.json','upstream-773a1641-native-checkpoint-v2/result.json','upstream-773a1641-native-long-checkpoint-v1/result.json','upstream-773a1641-native-long-checkpoint-v1/design.json','upstream-773a1641-startup-http-v1/validation.json','upstream-773a1641-cycle-http-v1/validation.json','upstream-773a1641-cycle-http-v1/cycles.json')]
evidence={str(p.relative_to(r)):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),data=read(p))for p in paths}
assert read(r/'tp-cache-retention/upstream-773a1641-wider-v1/validation.json')['functional_qualification_pass']
assert read(r/'tp-cache-retention/upstream-773a1641-http-smoke-v1/validation.json')['all_prompt_output_cachework_identities_exact']
assert read(f/'upstream-773a1641-gpu-v1/validation.json')['skips']==0
cycles=read(r/'tp-cache-retention/upstream-773a1641-cycle-http-v1/cycles.json');assert len(cycles['comparisons'])==16 and all(x['exact_ordered_work']for x in cycles['comparisons'])
assert read(f/'upstream-773a1641-timing-review.json')['original']['timing_qualified']is False
policy=(src/'AGENTS.md').read_text();assert 'Devlab keeps' in policy and 'inconclusive timing advisory on both ordinary and release PRs' in policy
for name in('upstream-773a1641-native-checkpoint-v2','upstream-773a1641-native-long-checkpoint-v1'):
 lab=r/'tp-cache-retention'/name;meta=read(lab/'binary.json');assert hashlib.sha256((lab/'probe').read_bytes()).hexdigest()==meta['sha256'];assert hashlib.sha256((lab/'probe.cpp').read_bytes()).hexdigest()==meta['source_sha256']
 data=read(lab/'result.json');assert data['success'] and data['exits']==[0,0]
 assert all(x['refcnt']==0 and x['module']=='81C6FF2FBAC473C7AB21844'for x in data['final'])
long=r/'tp-cache-retention/upstream-773a1641-native-long-checkpoint-v1'
for rank in(0,1):
 log=(long/f'rank{rank}.stdout').read_text();assert log.count('tokens=32773 boundary=32768')==4 and log.count('warm=0 restore exact')==2 and log.count('warm=1999 restore exact')==2
# Policy allows inconclusive timings as advisory; do not relabel them as passed.
# Push without force, atomically, after checking both pinned old heads.
push=git('push','--atomic','fork',main+':refs/heads/main',head+':refs/heads/tp2')
git('-C',str(wt),'merge','--ff-only',head)
assert git('-C',str(wt),'rev-parse','HEAD')==head and not git('-C',str(wt),'status','--porcelain')
after={line.split()[1]:line.split()[0]for line in git('ls-remote','fork','refs/heads/main','refs/heads/tp2').splitlines()};assert after=={'refs/heads/main':main,'refs/heads/tp2':head},after
result=dict(updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),previous=remote,published=after,CI=checks,qualification=evidence,functional_qualified=True,timing_qualified=False,scope='Canonical checkpoint correctness/local scratch sync adopted with retained inconclusive timing under repository advisory policy. No new speed/latency-equivalence claim or Q8 optimization adoption. No transport/driver/kernel/boot/service setting change. Exact pinned source9c production binary remains attributed to9c; all original timing flags and invalid-fixture/provenance errata remain.',push_stdout=push)
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(after,indent=2))
