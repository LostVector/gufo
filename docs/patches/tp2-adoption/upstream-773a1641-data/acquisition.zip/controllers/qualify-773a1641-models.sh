#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
cd "$root"
f=tp-cache-retention/fork-integration-v1
python3 - <<'PY'
from pathlib import Path
import json,time
f=Path('tp-cache-retention/fork-integration-v1');pid,start=json.loads((f/'upstream-773a1641-build-wait.json').read_text())['process'];p=Path('/proc')/str(pid)
while p.exists():
 assert(p/'stat').read_text().rsplit(')',1)[1].split()[19]==start
 time.sleep(.5)
assert(f/'upstream-773a1641-builds-complete').exists(),'Build gate failed; preserve logs, do not launch models'
PY
python3 tp-cache-retention/upstream-773a1641-native-checkpoint-v1/build.py
python3 -u tp-cache-retention/upstream-773a1641-native-checkpoint-v1/run.py > "$f/upstream-773a1641-native-checkpoint-controller.log" 2>&1
source cable-prep/env.sh
source native-rdma/env.sh
export LD_LIBRARY_PATH="$root/tp-cache-retention/fork-integration-v1/runtime/lib:$root/dependencies/gufo-dev/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
model=/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf
mtp=/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf
out="$root/tp-cache-retention/upstream-773a1641-tp1-headroom-v1"
mkdir "$out"
exec 8>"$root/overnight/results/model-matrix.lock"
flock -n 8
build="$root/tp-cache-retention/tp2-upstream-773a1641-gpu-build/tests/models/qwen38_flash_next"
printf '%s\n' "Context8192(snapshot),16384(adapter); UD-Q4_K_XL/sharedQ8MTP; official assertion-enabled test executables, current source. No speed claim." > "$out/scope.txt"
timeout -s INT -k 15 900 "$build/qwen38_flash_next_snapshot_test" --model "$model" --mtp-model "$mtp" > "$out/snapshot.log" 2>&1
timeout -s INT -k 15 900 "$build/qwen38_flash_next_continuation_adapter_test" --model "$model" --mtp-model "$mtp" --in-pass-only > "$out/adapter-inpass.log" 2>&1
touch "$out/complete"
flock -u 8
bash "$f/run-773a1641-runtime.sh" > "$f/upstream-773a1641-runtime-controller.log" 2>&1
touch "$f/upstream-773a1641-models-complete"
