#!/bin/bash
set -euo pipefail
cd /home/rkuo/strix-dispatch-investigation
f=tp-cache-retention/fork-integration-v1
bash "$f/validate-773a1641-sync.sh" > "$f/upstream-773a1641-cpu-controller.log" 2>&1
bash "$f/build-773a1641-release.sh" > "$f/upstream-773a1641-release-controller.log" 2>&1
bash "$f/validate-773a1641-gpu-fixtures.sh" > "$f/upstream-773a1641-gpu-controller.log" 2>&1
touch "$f/upstream-773a1641-builds-complete"
