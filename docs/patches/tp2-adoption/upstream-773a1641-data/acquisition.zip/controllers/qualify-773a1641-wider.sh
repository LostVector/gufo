#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
cd "$root"
f=tp-cache-retention/fork-integration-v1
python3 - <<'PY'
from pathlib import Path
import json,time
f=Path('tp-cache-retention/fork-integration-v1');pid,start=json.loads((f/'upstream-773a1641-model-wait.json').read_text())['process'];p=Path('/proc')/str(pid)
while p.exists():
 assert(p/'stat').read_text().rsplit(')',1)[1].split()[19]==start
 time.sleep(.5)
assert(f/'upstream-773a1641-models-complete').exists(),'Model gates failed; preserve and inspect'
PY
source cable-prep/env.sh
source native-rdma/env.sh
export LD_LIBRARY_PATH="$root/tp-cache-retention/fork-integration-v1/runtime/lib:$LD_LIBRARY_PATH"
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
python3 "$f/prepare-773a1641-wider.py"
out=tp-cache-retention/upstream-773a1641-wider-v1
python3 -u "$out/run.py" > "$out/controller.log" 2>&1
python3 "$out/analyze.py" > "$out/analyze.log" 2>&1
touch "$f/upstream-773a1641-native-qualification-complete"
