#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
out="$root/tp-cache-retention/fork-integration-v1/upstream-773a1641-validation-v1"
source_tree="$root/tp-cache-retention/tp2-upstream-773a1641-worktree"
build_dir="$root/tp-cache-retention/tp2-upstream-773a1641-cpu-build"
rocm_root=/home/rkuo/.local/opt/rocm-7.14.1
deps_root="$root/dependencies/gufo-dev"
mkdir "$out"
exec 9>"$root/overnight/results/model-matrix.lock"
flock -n 9
export PATH="$root/mtp-snapshot-priority/format-tool/bin:$PATH"
export CPLUS_INCLUDE_PATH="$deps_root/usr/include/x86_64-linux-gnu${CPLUS_INCLUDE_PATH:+:$CPLUS_INCLUDE_PATH}"
export LD_LIBRARY_PATH="$deps_root/usr/lib/x86_64-linux-gnu:$rocm_root/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PKG_CONFIG_SYSROOT_DIR="$deps_root"
export PKG_CONFIG_LIBDIR="$deps_root/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig"
export OPENSSL_ROOT_DIR="$deps_root/usr"
export CMAKE_PREFIX_PATH="$deps_root/usr:$rocm_root"
cd "$source_tree"
[[ -z $(git diff --name-only --diff-filter=U) ]]
git diff --cached --check
python3 tools/ci/check-format.py > "$out/format.log" 2>&1
python3 tools/ci/check-extension-api.py --base 94f1232d4b28b2f4cec4ecc4505492283c6e2b54 --labels '[]' > "$out/api.log" 2>&1
python3 tools/ci/generate-infrastructure.py --check > "$out/generated.log" 2>&1
python3 tools/ci/check-docs.py > "$out/docs.log" 2>&1
cmake --preset cpu-test -B "$build_dir" -DGUFO_BUILD_TOOLS=OFF -DGUFO_ENABLE_TP2_RDMA=OFF \
 -DCMAKE_C_COMPILER="$rocm_root/bin/amdclang" -DCMAKE_CXX_COMPILER="$rocm_root/bin/amdclang++" \
 -DPKG_CONFIG_EXECUTABLE="$deps_root/usr/bin/pkgconf" -DCMAKE_PREFIX_PATH="$rocm_root;$deps_root/usr" > "$out/cpu.log" 2>&1
cmake --build "$build_dir" --target qwen38_flash_next_runner_options_test qwen38_flash_next_config_test qwen38_flash_next_tp_partition_test qwen38_flash_next_rdma_gid_test --parallel 4 >> "$out/cpu.log" 2>&1
ctest --test-dir "$build_dir" -R '^qwen38_flash_next\.(runner_options|config|tp_partition|rdma_gid)$' --output-on-failure >> "$out/cpu.log" 2>&1
touch "$out/complete"
