// Run the repository's exact checkpoint oracle on both native TP ranks.
#define main RepositorySnapshotTestMain
#include "/home/rkuo/strix-dispatch-investigation/tp-cache-retention/tp2-upstream-773a1641-worktree/tests/models/qwen38_flash_next/snapshot_test.cpp"
#undef main
#include "src/models/qwen38_flash_next/kernels/rocm/verbs.hpp"
void CheckMirroredCheckpoint(const std::shared_ptr<qfn::Model>& model,
                            std::span<const std::int32_t> prompt,
                            gufo::core::SessionMode mode, std::size_t warm = 0,
                            std::uint32_t suffix = 7) {
  std::string error;
  auto source = model->CreateSession(mode, 65536, &error);
  auto whole = model->CreateSession(mode, 65536, &error);
  auto split = model->CreateSession(mode, 65536, &error);
  Require(source && whole && split, error);
  if (warm)
    Require(source->Sync(prompt.first(warm), &error) &&
                whole->Sync(prompt.first(warm), &error) &&
                split->Sync(prompt.first(warm), &error),
            error);
  const auto boundary = static_cast<std::uint32_t>(prompt.size() - suffix);
  Require(source->PrefillCheckpointBytes(boundary) == 0,
          "distributed in-pass checkpoint remains unadvertised");
  Require(source->Sync(prompt.first(boundary), &error), error);
  const auto claim = source->SnapshotBytes();
  const auto started = std::chrono::steady_clock::now();
  auto checkpoint = source->SaveSnapshot(&error);
  const double capture_ms = Millis(started);
  Require(checkpoint != nullptr && source->Sync(prompt, &error), error);
  Require(std::isfinite(capture_ms) && capture_ms > 0,
          "in-pass checkpoint capture time was not reported");
  Require(checkpoint != nullptr, "in-pass checkpoint was not returned");
  Require(checkpoint->SizeBytes() == claim,
          "in-pass checkpoint differs from its admission claim");
  Require(whole->Sync(prompt.first(boundary), &error) &&
              whole->Sync(prompt, &error),
          error);
  Require(source->Logits().size() == whole->Logits().size() &&
              std::memcmp(source->Logits().data(), whole->Logits().data(),
                          source->Logits().size_bytes()) == 0,
          "in-pass checkpoint changed split-pass logits");
  const auto continued =
      Decode(*source, 8,
             {.temperature = 0.8F, .top_k = 20, .top_p = 0.95F, .seed = 73}, 8);
  RequireSame(
      continued,
      Decode(*whole, 8,
             {.temperature = 0.8F, .top_k = 20, .top_p = 0.95F, .seed = 73}, 8),
      "in-pass sampled continuation");
  Require(std::memcmp(source->Logits().data(), whole->Logits().data(),
                      source->Logits().size_bytes()) == 0,
          "in-pass sampled continuation changed logits");
  Require(split->Sync(prompt.first(boundary), &error), error);
  const auto expected = Payload(*split);
  source->Reset();
  const auto actual = Payload(*checkpoint);
  Require(source->RestoreSnapshot(*checkpoint, &error), error);
  Require(Payload(*source) == actual,
          "in-pass checkpoint did not survive source reset");
  Require(actual == expected,
          "in-pass boundary differs from a pass ending there");
  auto raw = model->CreateSession(mode, 65536, &error);
  Require(raw && raw->RestoreSnapshot(actual, &error), error);
  Require(source->Sync(prompt, &error), error);
  Require(raw->Sync(prompt, &error), error);
  Require(Payload(*source) == Payload(*raw),
          "borrowed and serialized boundaries resumed differently");
  Require(split->Sync(prompt, &error), error);
  Require(Payload(*source) == Payload(*split),
          "restored boundary did not resume exactly");
  std::cout << "in-pass checkpoint mode=" << static_cast<int>(mode)
            << " tokens=" << prompt.size() << " boundary=" << boundary
            << " warm=" << warm << " restore exact\n";
}


int main(int argc, char** argv) {
  std::shared_ptr<qfn::rocm::Communicator> comm;
  try {
    Require(argc == 6, "rank bootstrap device target mtp");
    const auto rank = static_cast<unsigned>(std::stoul(argv[1]));
    Require(rank < 2, "rank");
    qfn::rocm::IbrverbsConfig config;
    config.rank = rank;
    config.bootstrap_host = argv[2];
    config.rdma_device = argv[3];
    config.bootstrap_port = 29669;
    std::string error;
    comm = qfn::rocm::CreateIbrverbsCommunicator(config, &error);
    Require(bool(comm), error);
    qfn::ModelOptions options;
    options.max_context = 65536;
    options.mtp_model_path = argv[5];
    options.max_draft_tokens = 7;
    options.tp_world_size = 2;
    options.tp_rank = rank;
    options.communicator = comm;
    auto model = qfn::Model::Load(argv[4], options, &error);
    Require(bool(model), error);
    const auto pattern = model->Tokenize(
        "Independent rank checkpoint replay retains exact recurrent and KV state. ");
    Require(!pattern.empty(), "token pattern");
    std::vector<std::int32_t> prompt(32773);
    for (std::size_t i = 0; i < prompt.size(); ++i)
      prompt[i] = pattern[i % pattern.size()];
    Require(comm->BeginOperation(773416, &error), error);
    unsigned cases = 0;
    for (bool asymmetric : {false, true}) {
      // This only changes reported free bytes, not real memory or system policy.
      // Rank0 has no reported checkpoint headroom while rank1 retains real free.
      LimitReportedDeviceFree(asymmetric && rank == 0
                                  ? 0
                                  : std::numeric_limits<std::size_t>::max());
      for (const auto mode : {gufo::core::SessionMode::kAutoregressive,
                             gufo::core::SessionMode::kSpeculative}) {
        CheckMirroredCheckpoint(model, prompt, mode, asymmetric ? 1999 : 0, 5);
        ++cases;
      }
    }
    LimitReportedDeviceFree(std::numeric_limits<std::size_t>::max());
    Require(comm->EndOperation(773416, &error), error);
    Require(cases == 4, "coverage");
    std::cout << "PASS native_checkpoint_cases=4 asymmetric_headroom=true "
                 "repository_snapshot_assertions=true supported_mirrored_capture=true\n";
    return 0;
  } catch (const std::exception& e) {
    if (comm) comm->Abort(e.what());
    std::cerr << e.what() << '\n';
    return 1;
  }
}
