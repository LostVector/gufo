from pathlib import Path
import hashlib,json
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;previous=r/'tp-cache-retention/upstream-773a1641-startup-trace-v1'
parents=json.loads((previous/'parent-sources.json').read_text());helper=(out/'helper.hpp').read_text()
for role,meta in parents.items():
 source=Path(meta['path']);text=(source/'src/models/qwen38_flash_next/engine.cpp').read_text();meta['source_sha256']['src/models/qwen38_flash_next/engine.cpp']=hashlib.sha256(text.encode()).hexdigest()
 text=text.replace('#include <algorithm>','#include <algorithm>\n#include <atomic>\n#include <cstdio>',1)
 ns='namespace gufo::models::qwen38_flash_next {\n';assert text.count(ns)==1;text=text.replace(ns,ns+helper+'\n',1)
 a=text.index('bool Session::DecodeBatchImpl(');b=text.index('bool Session::EvaluateBatchImpl(',a);body=text[a:b]
 def replace(old,new):
  global body
  assert body.count(old)==1,(role,old[:90],body.count(old));body=body.replace(old,new,1)
 replace('  auto& exec = *requests.front().session->model_->executor_;', '''  C3CycleTrace trace(requests.size(), requests.front().session->model_->TpRank());
  if (trace.cycle) {
    for (unsigned i = 0; i < 3; ++i) {
      trace.row[i] = {};
      trace.row[i].before = requests[i].session->Position();
      trace.row[i].after = trace.row[i].before;
      trace.row[i].forced = requests[i].drafts ? int(*requests[i].drafts) : -1;
    }
  }
  const auto plan_begin = trace.Start();
  auto& exec = *requests.front().session->model_->executor_;''')
 replace('  const auto cycle_start = std::chrono::steady_clock::now();', '''  if (trace.cycle) trace.plan = batch_drafts ? int(*batch_drafts) : -1;
  trace.Add("plan", plan_begin, requests.size());
  const auto cycle_start = std::chrono::steady_clock::now();
  const auto prepare_begin = trace.Start();''')
 replace('  std::vector<AdvanceRequest> catchup;', '''  trace.Add("prepare", prepare_begin, requests.size());
  if (trace.cycle) for (unsigned i = 0; i < 3; ++i) {
    trace.row[i].prepared_width = pending[i].width;
    trace.row[i].prepared_chain = pending[i].chain.size();
  }
  std::vector<AdvanceRequest> catchup;''')
 replace('  if (!DraftCatchUpBatch(catchup, error_msg, propose))\n    return false;', '''  const auto catchup_begin = trace.Start();
  if (!DraftCatchUpBatch(catchup, error_msg, propose))
    return false;
  trace.Add("draft-catchup", catchup_begin, catchup.size(), catchup.size());''')
 replace('    if (!exec.MtpHeads(heads, error_msg))\n      return false;', '''    const auto heads_begin = trace.Start();
    if (!exec.MtpHeads(heads, error_msg))
      return false;
    trace.Add("draft-heads", heads_begin, heads.size(), heads.size());''')
 replace('    if (!bodies.empty() && !exec.MtpForwardBatch(bodies, error_msg))\n      return false;', '''    const auto bodies_begin = trace.Start();
    if (!bodies.empty() && !exec.MtpForwardBatch(bodies, error_msg))
      return false;
    if (!bodies.empty()) trace.Add("draft-body", bodies_begin, bodies.size(), bodies.size());''')
 replace('  if (!items.empty() && !exec.ForwardBatch(items, error_msg))\n    return false;', '''  unsigned packed_rows = 0;
  if (trace.cycle) {
    for (unsigned i = 0; i < 3; ++i) {
      const auto& p = pending[i]; auto& x = trace.row[i];
      x.chain_size = p.chain.size(); x.lookup = p.lookup;
      x.token_count = std::min<std::size_t>(p.chain.size(), x.tokens.size());
      std::copy_n(p.chain.begin(), x.token_count, x.tokens.begin());
    }
    for (const auto& item : items) packed_rows += item.tokens.size();
  }
  const auto target_begin = trace.Start();
  if (!items.empty() && !exec.ForwardBatch(items, error_msg))
    return false;
  trace.Add("target-forward", target_begin, items.size(), packed_rows);
  const auto finish_begin = trace.Start();''')
 replace('  const bool used_lookup =', '''  trace.Add("finish", finish_begin, requests.size());
  if (trace.cycle) for (unsigned i = 0; i < 3; ++i) {
    trace.row[i].after = requests[i].session->Position();
    trace.row[i].emitted = requests[i].result->tokens.size();
    trace.row[i].completed = requests[i].outcome->completed;
  }
  const bool used_lookup =''')
 text=text[:a]+body+text[b:];(out/f'{role}-engine.cpp').write_text(text)
 for label in('scheduler','pool','batch'):(out/f'{role}-{label}.cpp').write_bytes((previous/f'{role}-{label}.cpp').read_bytes())
(out/'parent-sources.json').write_text(json.dumps(parents,indent=2)+'\n')
print('Prepared equal first-four-C3-cycle stage/actual-work observer; no policy or arithmetic change.')
