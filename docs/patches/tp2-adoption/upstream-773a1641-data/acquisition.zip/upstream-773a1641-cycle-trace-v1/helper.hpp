namespace {
std::atomic<unsigned> c3_cycle_sequence{0};
struct C3CycleTrace {
  struct Event { const char* stage; long long begin, end; unsigned items, rows; };
  struct Row {
    unsigned before, after, prepared_width, prepared_chain, chain_size;
    unsigned lookup, emitted, completed;
    int forced;
    std::array<std::int32_t, 8> tokens;
    unsigned token_count;
  };
  std::array<Event, 64> events;
  std::array<Row, 3> row;
  unsigned cycle = 0, rank, used = 0;
  int plan = -1;
  long long begin = 0;
  static long long Clock() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
  }
  C3CycleTrace(unsigned n, unsigned r) : rank(r) {
    if (n == 3 && c3_cycle_sequence.load(std::memory_order_relaxed) < 4) {
      const auto next = c3_cycle_sequence.fetch_add(1, std::memory_order_relaxed);
      if (next < 4) { cycle = next + 1; begin = Clock(); }
    }
  }
  long long Start() const { return cycle ? Clock() : 0; }
  void Add(const char* name, long long start, unsigned n = 0, unsigned rows = 0) {
    if (cycle && used < events.size())
      events[used++] = {name, start, Clock(), n, rows};
  }
  ~C3CycleTrace() {
    if (!cycle) return;
    const auto end = Clock();
    // Emit after the original policy observation, never inside a timed stage.
    std::fprintf(stderr, "C3_CYCLE rank=%u cycle=%u begin_ns=%lld end_ns=%lld plan=%d events=%u\n",
                 rank, cycle, begin, end, plan, used);
    for (unsigned i = 0; i < used; ++i) {
      const auto& e = events[i];
      std::fprintf(stderr, "C3_STAGE rank=%u cycle=%u stage=%s begin_ns=%lld end_ns=%lld items=%u rows=%u\n",
                   rank, cycle, e.stage, e.begin, e.end, e.items, e.rows);
    }
    for (unsigned i = 0; i < 3; ++i) {
      const auto& x = row[i];
      std::fprintf(stderr, "C3_ROW rank=%u cycle=%u actor=%u before=%u after=%u forced=%d prepared_width=%u prepared_chain=%u chain_size=%u lookup=%u emitted=%u completed=%u tokens=",
                   rank, cycle, i, x.before, x.after, x.forced, x.prepared_width,
                   x.prepared_chain, x.chain_size, x.lookup, x.emitted, x.completed);
      for (unsigned j = 0; j < x.token_count; ++j)
        std::fprintf(stderr, "%s%d", j ? "," : "", x.tokens[j]);
      std::fprintf(stderr, "\n");
    }
  }
};
} // namespace
