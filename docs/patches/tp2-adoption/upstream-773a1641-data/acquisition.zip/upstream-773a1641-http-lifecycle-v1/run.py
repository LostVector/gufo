from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,secrets,shlex,subprocess,time
root=Path(__file__).resolve().parents[2];os.chdir(root);out=Path(__file__).resolve().parent
lock=(root/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'protocol.json').exists()
def call(rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','rk-corsair-ai',shlex.join(args)]if rank else args,text=True,stderr=subprocess.STDOUT,timeout=90)
def inventory(label):
 result=[]
 for rank in(0,1):
  d=json.loads(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']));(out/f'{label}-r{rank}.json').write_text(json.dumps(d,indent=2)+'\n');result.append(d)
 return result
def snapshot(label):
 for rank in(0,1):(out/f'{label}-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
call(1,['mkdir','-p',str(out)]);subprocess.run(['rsync','-a',str(out/'server-rank.sh'),f'rk-corsair-ai:{out}/server-rank.sh'],check=True)
initial=inventory('initial-inventory');manifest=json.loads((out/'binaries.json').read_text());entry=manifest['candidate'];binary=root/'instrumentation/bin'/entry['name'];assert hashlib.sha256(binary.read_bytes()).hexdigest()==entry['sha256']
source=json.loads((out/'source-preflight.json').read_text())
for meta in source.values():
 for n,h in meta['source_sha256'].items():assert hashlib.sha256((Path(meta['path'])/n).read_bytes()).hexdigest()==h,n
subprocess.run(['rsync','-a',str(binary),f'rk-corsair-ai:{binary}'],check=True)
for rank in(0,1):assert call(rank,['sha256sum',str(binary)]).split()[0]==entry['sha256']
spec=importlib.util.spec_from_file_location('engine',out/'engine.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
os.environ.update(SCALING_NATIVE_RDMA='1',STRIX_SESSIONS='2',STRIX_CONTEXT='65536',STRIX_CHUNK='2048',STRIX_SPECULATION='mtp',SCALING_REQUEST_SCRIPT=str(out/'requests.py'))
for key in('LD_PRELOAD','ROCP_TOOL_ATTACH','STRIX_READ_OUTPUT'):os.environ.pop(key,None)
protocol={'binaries':manifest,'initial':initial,'sequence':[['candidate','tp2-upstream-9c715720']],'scope':'Canonical773a1641Combined9c715720ReleaseNativeWire22actualMTP cachedcontinuation+bothC2slotcancellation. Fourgreedy/sampledkeep/discard interruptedassistant cases then9cancellationrecords withsolo controls, live survivorwidth2 andpostcancel replay. Eachcompletedsubstantiverequest requiresactualproposals. Context65536,2slots/chunk2048/backend4224/cache1GiB,UD-Q4_K_XL/sharedQ8_0,approved81C6TX32unchanged/crossed40+20. Candidate-only functional qualification, raw timings retained; no matched performance/control/gain or driver/error/peerloss guarantee. No full table warming/profiler/adminsampler or systemchanges.'}
protocol['harness_sha256']={n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in('run.py','requests.py','cache-requests.py','cancel-requests.py','validate.py','source-preflight.json','binaries.json','engine.py','server-rank.sh')}
protocol['external_harness_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in('link40/engine-runner.py','link40/server-rank.sh','native-rdma/env.sh','cable-prep/env.sh','tp-cache-retention/driver-parent-timing-v1/inventory.py','reference/gufo-rdma/tests/functional/continuation.py','reference/gufo-rdma/tests/functional/metrics.py','reference/gufo-rdma/tests/functional/tool_agent.py')}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');token=root/'model-scaling/control-token';assert not token.exists();start=int(time.time())-2
try:
 token.write_text(secrets.token_hex(32));token.chmod(0o600);subprocess.run(['rsync','-a',str(token),f'{e.peer}:{token}'],check=True)
 snapshot('candidate-before');print(time.strftime('%F %T'),'START candidate',flush=True)
 e.run(out.name+'-candidate',2,e.local,'tp2-upstream-9c715720');snapshot('candidate-after');rows=[json.loads(s)for s in(e.out/f'{out.name}-candidate.jsonl').read_text().splitlines()];assert len(rows)==13
 (out/'complete').touch();print(time.strftime('%F %T'),'COMPLETE',flush=True)
finally:
 snapshot('candidate-after')
 token.unlink(missing_ok=True);subprocess.run(['ssh',e.peer,'rm','-f',str(token)],check=False);errors=[]
 try:inventory('final-inventory')
 except BaseException as ex:errors.append(repr(ex))
 for rank in(0,1):
  try:(out/f'kernel-window-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-driver-lab','run','fork-integration/hardware/kernel-window.py',str(start)]))
  except BaseException as ex:errors.append(repr(ex))
 (out/'cleanup.json').write_text(json.dumps({'errors':errors,'finished':time.time()},indent=2)+'\n');assert not errors,errors
