from pathlib import Path
import ast,hashlib,json
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;old=r/'tp-cache-retention/confidence-startup-path-trace-v1'
text=(old/'prepare.py').read_text();tree=ast.parse(text);helpers={}
for n in tree.body:
 if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id in('helper','snaphelper'):helpers[n.targets[0].id]=ast.literal_eval(n.value)
helper=helpers['helper'].replace('r.token_limit == 128 && before < 8','(r.token_limit == 128 || r.token_limit == 256) && before < 8');snaphelper=helpers['snaphelper']
# Reuse checked source-level stage boundaries; do not execute the old preparation script.
loop=next(n for n in tree.body if isinstance(n,ast.For)and isinstance(n.target,ast.Tuple)and [x.id for x in n.target.elts]==['role','meta'])
index=next(i for i,n in enumerate(loop.body)if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='s'and 'text_generation_scheduler.cpp' in ast.get_source_segment(text,n))
body=ast.fix_missing_locations(ast.Module(body=loop.body[index:],type_ignores=[]))
parents={role:dict(path=str(r/'tp-cache-retention'/dirname))for role,dirname in(('baseline','tp2-upstream-c32136f8-worktree'),('candidate','tp2-upstream-773a1641-worktree'))}
namespace=dict(helper=helper,snaphelper=snaphelper,o=out,hashlib=hashlib,Path=Path)
for role,meta in parents.items():
 w=Path(meta['path']);meta['source_sha256']={n:hashlib.sha256((w/n).read_bytes()).hexdigest()for n in('src/cli/serve/text_generation_scheduler.cpp','src/cli/serve/text_model_runner.cpp','src/models/qwen38_flash_next/kernels/rocm/batch.cpp')}
 # Original transformations are applied in an isolated namespace with explicit role/path.
 exec(compile(body,'retained-startup-boundaries','exec'),dict(namespace,role=role,w=w))
 b=(w/'src/models/qwen38_flash_next/kernels/rocm/batch.cpp').read_text()
 b=b.replace('#include <algorithm>','#include <algorithm>\n#include <atomic>\n#include <cstdio>\n#include <chrono>\n#include <unistd.h>',1)
 ns='namespace gufo::models::qwen38_flash_next::rocm {\n';assert b.count(ns)==1
 marker='''namespace {
std::atomic<long long> hc_epoch_previous{};
struct HcEpochScope {
 long long begin; unsigned rows; const void* executor; bool emit;
 static long long Now(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
 HcEpochScope(unsigned n,const void* e):begin(Now()),rows(n),executor(e){
  const auto previous=hc_epoch_previous.exchange(begin,std::memory_order_relaxed);
  emit=!previous||begin-previous>=100000000;
  if(emit)std::fprintf(stderr,"HC_EPOCH enter pid=%d executor=%p rows=%u time_ns=%lld\\n",int(getpid()),executor,rows,begin);
 }
 ~HcEpochScope(){if(emit)std::fprintf(stderr,"HC_EPOCH leave pid=%d executor=%p rows=%u begin_ns=%lld end_ns=%lld\\n",int(getpid()),executor,rows,begin,Now());}
};
}
'''
 b=b.replace(ns,ns+marker,1)
 needle='''                          std::string* error) const {
  const auto& c = config();''';assert b.count(needle)==1
 b=b.replace(needle,'''                          std::string* error) const {
  HcEpochScope hc_epoch(rows,this);
  const auto& c = config();''',1)
 (out/f'{role}-batch.cpp').write_text(b)
(out/'parent-sources.json').write_text(json.dumps(parents,indent=2)+'\n');print('Prepared unchanged scheduler/pool source-stage logs and first-HC-epoch markers, both roles')
