from pathlib import Path
import fcntl,hashlib,json,os,shlex,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(out/'build.json').exists();os.environ['CPLUS_INCLUDE_PATH']=str(r/'dependencies/gufo-dev/usr/include/x86_64-linux-gnu')
parents=json.loads((out/'parent-sources.json').read_text());allmeta={}
for role,meta in parents.items():
 build=r/'tp-cache-retention'/('tp2-upstream-c32136f8-release-build' if role=='baseline' else 'tp2-upstream-773a1641-release-build')
 entries=json.loads((build/'compile_commands.json').read_text())
 commands=[];objdir=out/role;objdir.mkdir()
 for label,suffix in(('scheduler','/src/cli/serve/text_generation_scheduler.cpp'),('pool','/src/cli/serve/text_model_runner.cpp'),('batch','/src/models/qwen38_flash_next/kernels/rocm/batch.cpp')):
  e=next(e for e in entries if e['file'].endswith(suffix));c=shlex.split(e['command']);c[-1]=str(out/f'{role}-{label}.cpp');c[c.index('-o')+1]=str(objdir/(Path(suffix).name+'.o'));commands.append(c)
 archive=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';copy=out/f'{role}-libgufo_qwen38_flash_next_hip.a';assert not copy.exists();shutil.copy2(archive,copy)
 commands.append(['ar','r',str(copy),str(objdir/'batch.cpp.o')])
 serving=build/'libgufo_serving.a';serving_copy=out/f'{role}-libgufo_serving.a';assert not serving_copy.exists();shutil.copy2(serving,serving_copy)
 commands.append(['ar','r',str(serving_copy),str(objdir/'text_generation_scheduler.cpp.o'),str(objdir/'text_model_runner.cpp.o')])
 link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','gufo'],text=True).splitlines()[-1])[2:-2]
 link=[str(copy)if x==str(archive.relative_to(build))else str(serving_copy)if x==str(serving.relative_to(build))else x for x in link];i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
 binary=r/'instrumentation/bin'/f'gufo-tp2-upstream773-startup-v1-{role}';assert not binary.exists();link[link.index('-o')+1]=str(binary);commands.append(link)
 allmeta[role]=dict(commands=commands,source_path=meta['path'],source_sha256=meta['source_sha256'],diagnostic_source_sha256={str((out/f'{role}-{n}.cpp').relative_to(r)):hashlib.sha256((out/f'{role}-{n}.cpp').read_bytes()).hexdigest()for n in('scheduler','pool','batch')},scope='Logging-only scheduler/pool/first-HC-epoch; no engine/GPU/header/transport/modelsetting changes. Source94baseline/9ccandidate, each its own canonical-merged release build/header/library closure, exactsameobserverboundaryboth. Diagnosticparentbuildmetadata, actualSHA/sourcepin, notperformanceartifact.')
 (out/'build.json').write_text(json.dumps(dict(environment={'CPLUS_INCLUDE_PATH':os.environ['CPLUS_INCLUDE_PATH']},roles=allmeta),indent=2)+'\n')
 with(out/f'{role}-build.log').open('w')as log:
  for cmd in commands:subprocess.run(cmd,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
 proofs={}
 for parent_file,child,expected in((archive,copy,['batch.cpp.o']),(serving,serving_copy,['text_generation_scheduler.cpp.o','text_model_runner.cpp.o'])):
  changes=[]
  for n in subprocess.check_output(['ar','t',str(parent_file)],text=True).splitlines():
   if subprocess.check_output(['ar','p',str(parent_file),n])!=subprocess.check_output(['ar','p',str(child),n]):changes.append(n)
  assert sorted(changes)==sorted(expected),changes;proofs[parent_file.name]=changes
 allmeta[role].update(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),changed_members=proofs)
(out/'build.json').write_text(json.dumps(dict(environment={'CPLUS_INCLUDE_PATH':os.environ['CPLUS_INCLUDE_PATH']},roles=allmeta),indent=2)+'\n');print('Both startup diagnostic binaries built')
