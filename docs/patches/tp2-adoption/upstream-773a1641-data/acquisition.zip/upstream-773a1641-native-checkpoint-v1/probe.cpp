// Run the repository's exact checkpoint oracle on both native TP ranks.
#define main RepositorySnapshotTestMain
#include "/home/rkuo/strix-dispatch-investigation/tp-cache-retention/tp2-upstream-773a1641-worktree/tests/models/qwen38_flash_next/snapshot_test.cpp"
#undef main
#include "src/models/qwen38_flash_next/kernels/rocm/verbs.hpp"
int main(int argc, char** argv) {
  std::shared_ptr<qfn::rocm::Communicator> comm;
  try {
    Require(argc == 6, "rank bootstrap device target mtp");
    const auto rank = static_cast<unsigned>(std::stoul(argv[1]));
    Require(rank < 2, "rank");
    qfn::rocm::IbrverbsConfig config;
    config.rank = rank;
    config.bootstrap_host = argv[2];
    config.rdma_device = argv[3];
    config.bootstrap_port = 29669;
    std::string error;
    comm = qfn::rocm::CreateIbrverbsCommunicator(config, &error);
    Require(bool(comm), error);
    qfn::ModelOptions options;
    options.max_context = 8192;
    options.mtp_model_path = argv[5];
    options.max_draft_tokens = 7;
    options.tp_world_size = 2;
    options.tp_rank = rank;
    options.communicator = comm;
    auto model = qfn::Model::Load(argv[4], options, &error);
    Require(bool(model), error);
    const auto pattern = model->Tokenize(
        "Independent rank checkpoint replay retains exact recurrent and KV state. ");
    Require(!pattern.empty(), "token pattern");
    std::vector<std::int32_t> prompt(4100);
    for (std::size_t i = 0; i < prompt.size(); ++i)
      prompt[i] = pattern[i % pattern.size()];
    Require(comm->BeginOperation(773416, &error), error);
    unsigned cases = 0;
    for (bool asymmetric : {false, true}) {
      // This only changes reported free bytes, not real memory or system policy.
      // Rank0 has no reported checkpoint headroom while rank1 retains real free.
      LimitReportedDeviceFree(asymmetric && rank == 0
                                  ? 0
                                  : std::numeric_limits<std::size_t>::max());
      for (const auto mode : {gufo::core::SessionMode::kAutoregressive,
                             gufo::core::SessionMode::kSpeculative}) {
        CheckPrefillCheckpoint(model,
            std::span<const std::int32_t>(prompt).first(2052), mode, 0, 5);
        ++cases;
        CheckPrefillCheckpoint(model, prompt, mode, 1999, 5);
        ++cases;
      }
    }
    LimitReportedDeviceFree(std::numeric_limits<std::size_t>::max());
    Require(comm->EndOperation(773416, &error), error);
    Require(cases == 8, "coverage");
    std::cout << "PASS native_checkpoint_cases=8 asymmetric_headroom=true "
                 "repository_exact_oracle=true\n";
    return 0;
  } catch (const std::exception& e) {
    if (comm) comm->Abort(e.what());
    std::cerr << e.what() << '\n';
    return 1;
  }
}
