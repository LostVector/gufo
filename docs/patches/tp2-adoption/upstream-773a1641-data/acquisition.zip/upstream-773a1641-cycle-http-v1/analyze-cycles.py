from pathlib import Path
import collections,json,re
out=Path(__file__).resolve().parent;r=out.parents[1]
assert json.loads((out/'validation.json').read_text())['functional_qualification_pass']
def fields(s):
 return {k:int(v)if re.fullmatch(r'-?\d+',v)else v for k,v in re.findall(r'(\w+)=([^ ]+)',s)}
allphases=[]
for phase,role in json.loads((out/'design.json').read_text())['sequence']:
 rankdata=[]
 for rank in(0,1):
  parent=r/'results/model-scaling';parent=parent/'corsair'if rank else parent
  lines=(parent/f'{out.name}-{phase}-rank{rank}.stderr').read_text().splitlines();cycles={};stages=collections.defaultdict(list);rows=collections.defaultdict(list)
  for s in lines:
   if s.startswith('C3_CYCLE '):
    e=fields(s);assert e['rank']==rank and e['cycle']not in cycles;cycles[e['cycle']]=e
   elif s.startswith('C3_STAGE '):
    e=fields(s);assert e['rank']==rank;stages[e['cycle']].append(e)
   elif s.startswith('C3_ROW '):
    e=fields(s);assert e['rank']==rank;e['tokens']=[int(v)for v in s.split(' tokens=',1)[1].split(',')]if s.split(' tokens=',1)[1]else[];rows[e['cycle']].append(e)
  assert set(cycles)=={1,2,3,4}and set(stages)==set(cycles)and set(rows)==set(cycles),(phase,rank,cycles.keys())
  result=[]
  for cid in(1,2,3,4):
   c=cycles[cid];ss=stages[cid];rr=sorted(rows[cid],key=lambda e:e['actor']);assert [e['actor']for e in rr]==[0,1,2];assert len(ss)==c['events']<64
   for e in ss:assert c['begin_ns']<=e['begin_ns']<=e['end_ns']<=c['end_ns']
   assert all(e['completed']==1 and len(e['tokens'])==e['chain_size'] and e['after']-e['before']==e['emitted']for e in rr)
   assert sum(s['stage']=='target-forward'for s in ss)==1
   target=next(s for s in ss if s['stage']=='target-forward');assert target['rows']==sum(x['chain_size']for x in rr)and target['items']==3
   work=dict(plan=c['plan'],stages=[{k:e[k]for k in('stage','items','rows')}for e in ss],span_rows=[{k:v for k,v in e.items()if k not in('rank','cycle')}for e in rr])
   totals=collections.defaultdict(float)
   for e in ss:totals[e['stage']]+=(e['end_ns']-e['begin_ns'])/1e6
   wall=(c['end_ns']-c['begin_ns'])/1e6
   result.append(dict(cycle=cid,rank=rank,wall_ms=wall,stage_wall_ms=dict(totals),unassigned_wall_ms=wall-sum(totals.values()),work=work))
  rankdata.append(result)
 for a,b in zip(*rankdata):assert a['work']==b['work'],(phase,a['cycle'],'rank work mismatch')
 allphases.append(dict(phase=phase,role=role,ranks=rankdata))
comparisons=[]
candidate=next(p for p in allphases if p['role']=='candidate')
for control in(p for p in allphases if p['role']=='baseline'):
 for rank in(0,1):
  for a,b in zip(control['ranks'][rank],candidate['ranks'][rank]):
   differences={k:dict(baseline=a['work'][k],candidate=b['work'][k])for k in a['work']if a['work'][k]!=b['work'][k]}
   comparisons.append(dict(control=control['phase'],rank=rank,cycle=a['cycle'],exact_ordered_work=not differences,work_differences=differences,baseline_wall_ms=a['wall_ms'],candidate_wall_ms=b['wall_ms'],wall_delta_ms=b['wall_ms']-a['wall_ms'],stage_wall_delta_ms={k:b['stage_wall_ms'].get(k,0)-a['stage_wall_ms'].get(k,0)for k in set(a['stage_wall_ms'])|set(b['stage_wall_ms'])}))
report=dict(scope='First4 actual residents3 cycles, nativeTP2 bothhosts. Row actor field is ordered DecodeRequest span index, NOT assumed HTTP actor identity. Entire proposal chains/plans/widths/lookup/emission and stage shapes required equal across ranks. Stage wall includes CPU/GPU/remote wait; no pureCPU/GPU attribution or unprofiled throughput inference. No crosshost clock subtraction. Clock/buffer/dump observer effects remain. Comparisons with unequal actual work must not be called equal-work regressions.',phases=allphases,comparisons=comparisons)
(out/'cycles.json').write_text(json.dumps(report,indent=2)+'\n')
for phase in allphases:
 print(phase['phase'])
 for e in phase['ranks'][0]:print('cycle',e['cycle'],'plan',e['work']['plan'],'packed',next(s['rows']for s in e['work']['stages']if s['stage']=='target-forward'),'wall_ms',round(e['wall_ms'],4),'stages',{k:round(v,4)for k,v in e['stage_wall_ms'].items()})
print('Exact ordered work comparisons',sum(c['exact_ordered_work']for c in comparisons),'of',len(comparisons))
