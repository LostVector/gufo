from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,urllib.request,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'reference/gufo-rdma/tools'))
import shlex
identity_out=Path(__file__).resolve().parent
label=Path(sys.argv[1]).stem
phase=label.removeprefix(identity_out.name+'-');role=next(role for name,role in json.loads((identity_out/'design.json').read_text())['sequence']if name==phase)
entry=json.loads((identity_out/'binaries.json').read_text())[role]
for rank in (0,1):
 code="rank="+str(rank)+";from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank{rank}.pid')+").read_text());proc=Path('/proc')/str(pid);exe=(proc/'exe').resolve();assert str(exe)=="+repr(str(root/'instrumentation/bin'/entry['name']))+";assert hashlib.sha256(exe.read_bytes()).hexdigest()=="+repr(entry['sha256'])+";args=(proc/'cmdline').read_bytes().decode().split(chr(0));selected={k:args[args.index(k)+1]for k in ('--context','--sessions','--prefill-chunk','--cache-ram-bytes','--speculative','--tp-world-size','--tp-rank','--think','--tp-rdma-device')};assert selected['--context']=='65536' and selected['--sessions']=='4' and selected['--prefill-chunk']=='2048' and selected['--speculative']=='mtp' and selected['--think']=='off';assert selected['--tp-world-size']=='2'and selected['--tp-rank']==str(rank)and selected['--tp-rdma-device']=='usb4_rdma0'and selected['--cache-ram-bytes']=='1073741824';maps=(proc/'maps').read_text();assert '/copy-fault.so'not in maps;assert '/read-observer/pread.so'not in maps and 'librocprofiler-sdk.so'not in maps;print(json.dumps({'pid':pid,'binary_sha256':"+repr(entry['sha256'])+",'start_ticks':(proc/'stat').read_text().rsplit(')',1)[1].split()[19],'selected_safe_options':selected,'read_observer_absent':True,'SDK_trace_absent':True}))"
 args=['python3','-c',code];cmd=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args
 raw=subprocess.check_output(cmd,text=True,timeout=60);json.loads(raw)
 (identity_out/f'{label}-identity-r{rank}.json').write_text(raw)

from gufo import serving_bench as bench
import time
base=sys.argv[2];dest=Path(sys.argv[1]);local=threading.local();lock=threading.Lock();original_integer=bench._required_integer;original_sse=bench._sse_data

def integer(metrics,key):
 if key=='prefill_tokens':local.metrics=dict(metrics)
 return original_integer(metrics,key)
bench._required_integer=integer

def sse(response):
 for event in original_sse(response):
  if event!='[DONE]':
   payload=json.loads(event);choices=payload.get('choices')
   if isinstance(choices,list)and choices:
    delta=choices[0].get('delta',{});content=delta.get('content');tools=delta.get('tool_calls')
    if content or tools:local.events.append({'perf_counter_ns':time.perf_counter_ns(),'content_bytes':len(content.encode())if isinstance(content,str)else 0})
  yield event
bench._sse_data=sse
short='Write a detailed numbered list of thirty practical ways to debug a slow distributed inference server. Explain each item.'
prompts=[short+f'\nRequest variant {i}.'for i in range(4)]

class Gate:
 def __init__(self,index,event):self.index=index;self.event=event
 def wait(self):
  if self.index==0:self.event.set()
  else:self.event.wait();time.sleep(.01*self.index)

with dest.open('x')as output:
 def request(case,actor,width,tokens,order,gate=None):
  local.metrics=None;local.events=[];text='Explain tensor parallel inference briefly.'if case=='warmup'else prompts[actor]
  obs=bench.run_request(base_url=base,model='flash-next-tp-test',prompt=text,max_tokens=tokens,temperature=0,timeout_seconds=600,client_id=f'wide-{case}-{actor}',concurrency=width,repetition=1,request_index=actor,start_gate=gate,cache_prompt=False,extra_body={'chat_template_kwargs':{'enable_thinking':False}},endpoint_profile='gufo')
  row={'case':case,'order':order,'max_tokens':tokens,**obs.public(),'started_at':obs.started_at,'finished_at':obs.finished_at,'raw_gufo':local.metrics,'prompt_sha256':hashlib.sha256(text.encode()).hexdigest(),'content_events':local.events,'first_followup_content_gap_ms':(local.events[1]['perf_counter_ns']-local.events[0]['perf_counter_ns'])/1e6 if len(local.events)>1 else None,'maximum_content_gap_ms':max(((b['perf_counter_ns']-a['perf_counter_ns'])/1e6 for a,b in zip(local.events,local.events[1:])),default=None)}
  with lock:
   output.write(json.dumps(row)+'\n');output.flush();print(case,actor,'tokens',obs.completion_tokens,'width',obs.physical_execution_width,'admitted',local.metrics['resident_requests_at_admission'],flush=True)
  return row
 request('warmup',0,1,8,0)
 for i in range(4):request('solo',i,1,128,1+i)
 for i,n in enumerate([17,33,65]):request('solo-ragged',i,1,n,5+i)
 for case,width,limits,start in [('C3',3,[128]*3,8)]:
  event=threading.Event()
  with concurrent.futures.ThreadPoolExecutor(max_workers=width)as pool:
   jobs=[pool.submit(request,case,i,width,n,start+i,Gate(i,event))for i,n in enumerate(limits)]
   for job in jobs:job.result()
