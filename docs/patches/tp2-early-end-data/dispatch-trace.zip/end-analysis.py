"""Separate every recorded EndRequest's pre-send, send and post-send intervals."""
import ast
import hashlib
import json
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
assert (p / 'validation.json').exists()
assert json.loads((p / 'cleanup.json').read_text())['errors'] == []
protocol = json.loads((p / 'protocol.json').read_text())
for name, digest in protocol['harness_sha256'].items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, name
tree = ast.parse((p / 'analyze.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'read_spans')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(p / 'analyze.py'), 'exec'))
report = dict(phases=[], input_sha256={},
              scope='One targeted diagnostic B/C/B on frozen production binaries and original five-request history. Host pre-send interval includes lock acquisition and request bookkeeping, not measured pure CPU dispatch. Send duration is host API execution, not remote receipt or wire latency. Inner Session::DecodeStep overlap can contain GPU/transport work. Every EndRequest is retained without order-only request assignment. Client-tail overlap is same-host temporal association; no flag waiver or new unprofiled performance claim.')
for phase, role in protocol['sequence']:
    app = p / phase / 'trace-r0/app.csv'
    raw = root / 'results/model-scaling' / f'{p.name}-{phase}.jsonl'
    for path in (app, raw):
        report['input_sha256'][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    spans = read_spans(app.parent)
    ends = [s for s in spans if s['id'] == 4]
    assert len(ends) == 5
    records = []
    for end in ends:
        sends = [s for s in spans if s['id'] == 7 and s['tid'] == end['tid']
                 and end['begin'] <= s['begin'] and s['end'] <= end['end']]
        assert len(sends) == 1
        send = sends[0]
        steps = [s for s in spans if s['id'] == 13 and s['begin'] < end['end'] and s['end'] > end['begin']]
        overlap = sum(max(0, min(s['end'], end['end']) - max(s['begin'], end['begin'])) for s in steps)
        records.append(dict(end=end, send=send, pre_send_ms=(send['begin'] - end['begin']) / 1e6,
                            send_ms=(send['end'] - send['begin']) / 1e6,
                            post_send_ms=(end['end'] - send['end']) / 1e6,
                            total_ms=(end['end'] - end['begin']) / 1e6,
                            overlapping_SessionDecodeStep=steps,
                            overlapping_step_ms=overlap / 1e6))
    clients = []
    rows = [json.loads(s) for s in raw.read_text().splitlines()]
    assert len(rows) == 5
    for row in rows:
        lo = row['content_events'][-1]['perf_counter_ns']
        hi = round(row['finished_at'] * 1e9)
        matches = [i for i, end in enumerate(ends) if end['begin'] < hi and end['end'] > lo]
        clients.append(dict(case=row['case'], repetition=row['repetition'], actor=row['request_index'],
                            final_content_to_HTTP_finish_ms=(hi - lo) / 1e6,
                            overlapping_EndRequest_indices=matches))
    report['phases'].append(dict(phase=phase, role=role, EndRequests=records, clients=clients))
(p / 'end-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
for phase in report['phases']:
    print(phase['phase'])
    for record in phase['EndRequests']:
        print({key: record[key] for key in ('total_ms', 'pre_send_ms', 'send_ms', 'post_send_ms', 'overlapping_step_ms')})
