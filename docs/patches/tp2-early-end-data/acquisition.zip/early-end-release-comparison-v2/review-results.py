"""Retain phase-level tradeoffs without filtering pairs or redefining endpoints."""
from pathlib import Path
import collections,json
p=Path(__file__).resolve().parent;d=json.loads((p/'statistical-summary.json').read_text());work=collections.defaultdict(list)
for row in d['adaptive_work_fields']:work[row['pair'],row['case'],row['repetition'],row['actor']].append(row)
groups=collections.defaultdict(list)
for row in d['strict_flags']:groups[row['pair'],row['case'],row['repetition'],row['actor']].append(row)
review=[]
for key,rows in groups.items():
 startup=key[1]=='warmup'
 review.append(dict(pair=key[0],case=key[1],repetition=key[2],actor=key[3],flags=rows,changed_work=work[key],classification='Unresolved startup high-mode, not waived by previous baseline HIP trace.' if startup else 'C2 phase/gap tradeoff; adaptive work differs for this request.' if work[key] else 'C2 phase/gap tradeoff without a detected change in the four recorded work fields.',timing_qualified=False))
r=dict(strict_entries=len(d['strict_flags']),request_comparisons=len(review),startup_entries=sum(len(x['flags'])for x in review if x['case']=='warmup'),C2_entries=sum(len(x['flags'])for x in review if x['case']=='short-c2'),all_work_fields=len(d['adaptive_work_fields']),request_reviews=review,primary_supported=d['primary']['supported'],whole_wave_gain_supported=False,universal_phase_qualification=False,scope='Descriptive grouping of all original flags. Does not establish causal attribution, equivalence, or waive any regression. No acquisition exclusion, optional stopping or new statistical endpoint. The actor1 tail endpoint remains independently supported; broader rates are inconclusive.')
(p/'timing-flag-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='request_reviews'},indent=2))
