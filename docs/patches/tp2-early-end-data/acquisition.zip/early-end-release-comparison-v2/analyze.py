"""Audit all fixed pairs; primary is completion-tail latency, not throughput."""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import statistics
from paired_statistics import summarize

p = Path(__file__).resolve().parent
root = p.parents[1]
protocol = json.loads((p / 'protocol.json').read_text())
design = protocol['design']
assert (p / 'complete').exists() and json.loads((p / 'cleanup.json').read_text())['errors'] == []
for name, digest in protocol['harness_sha256'].items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, name
for name, digest in protocol['external_harness_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for metadata in json.loads((p / 'source-preflight.json').read_text()).values():
    for name, digest in metadata['source_sha256'].items():
        assert hashlib.sha256((Path(metadata['path']) / name).read_bytes()).hexdigest() == digest
identity = ('case', 'repetition', 'request_index', 'concurrency', 'prompt_sha256',
            'prompt_tokens', 'prefill_tokens', 'cached_prompt_tokens',
            'completion_tokens', 'completion_sha256')
canonical = None
pairs, input_hashes = {}, {}
audits = {}
for phase, role in protocol['sequence']:
    path = root / 'results/model-scaling' / f'{p.name}-{phase}.jsonl'
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(rows) == 5
    ids = [{key: row[key] for key in identity} for row in rows]
    if canonical is None:
        canonical = ids
    assert ids == canonical
    assert all(r['cached_prompt_tokens'] == 0 and r['prefill_tokens'] == r['prompt_tokens'] and r['draft_tokens'] > 0 for r in rows)
    input_hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    pairs[phase.split('-')[0], role] = rows
    for rank in (0, 1):
        def counters(tag):
            text = (p / f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ', 1)[0]
            return {k: int(v) for k, v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$', text, re.M)}
        a, b = counters('before'), counters('after')
        assert a and a.keys() == b.keys() and all(b[k] >= a[k] for k in a)
        errors = {k: b[k] - a[k] for k in a if b[k] != a[k] and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun', k)}
        assert not errors
        audits[f'{phase}/r{rank}'] = errors
        for when in ('initial', 'final'):
            inv = json.loads((p / f'{phase}-{when}-inventory-r{rank}.json').read_text())
            assert inv['module'] == '81C6FF2FBAC473C7AB21844' and inv['refcnt'] == 0 and len(inv['devices']) == 4
            assert all(inv[key] == protocol['initial'][rank][key] for key in ('boot_id', 'cmdline', 'routers'))
        observed = json.loads((p / f'{p.name}-{phase}-identity-r{rank}.json').read_text())
        assert observed['binary_sha256'] == protocol['binaries'][role]['sha256']
        assert observed['read_observer_absent'] and observed['SDK_trace_absent']
        for option, value in {'--context': '65536', '--sessions': '2', '--prefill-chunk': '2048', '--cache-ram-bytes': '1073741824', '--speculative': 'mtp', '--tp-world-size': '2', '--tp-rank': str(rank), '--think': 'off', '--tp-rdma-device': 'usb4_rdma0'}.items():
            assert observed['selected_safe_options'][option] == value
for rank in (0, 1):
    assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout|amdgpu.*reset|segfault', (p / f'kernel-window-r{rank}.txt').read_text(), re.I)


def tail(row):
    result = (round(row['finished_at'] * 1e9) - row['content_events'][-1]['perf_counter_ns']) / 1e6
    assert result > 0 and math.isfinite(result)
    return result


def wave(rows):
    selected = [r for r in rows if r['case'] == 'short-c2']
    assert len(selected) == 2
    return sum(r['completion_tokens'] for r in selected) / (max(r['finished_at'] for r in selected) - min(r['started_at'] for r in selected))


primary = {'baseline': [], 'candidate': []}
secondary = {name: {'baseline': [], 'candidate': []} for name in ('C2-client-whole-wave', 'C1-first-server-decode', 'C1-repeat-server-decode')}
flags, work, completion_order = [], [], []
for pair in range(1, 11):
    name = f'pair{pair:02d}'
    a, b = [pairs[name, role] for role in ('baseline', 'candidate')]
    for role, rows in [('baseline', a), ('candidate', b)]:
        c2 = [r for r in rows if r['case'] == 'short-c2']
        actor1 = next(r for r in c2 if r['request_index'] == 1)
        actor0 = next(r for r in c2 if r['request_index'] == 0)
        primary[role].append(tail(actor1))
        completion_order.append(dict(pair=name, role=role, actor1_finishes_first=actor1['finished_at'] < actor0['finished_at']))
        secondary['C2-client-whole-wave'][role].append(wave(rows))
        for rep in (1, 2):
            row = next(r for r in rows if r['case'] == 'pp2048-tg128' and r['repetition'] == rep)
            secondary['C1-first-server-decode' if rep == 1 else 'C1-repeat-server-decode'][role].append(row['decode_tokens_per_second'])
    for before, after in zip(a, b):
        ident = dict(pair=name, case=before['case'], repetition=before['repetition'], actor=before['request_index'])
        for key in ('draft_tokens', 'draft_accepted_tokens', 'physical_execution_width'):
            if before[key] != after[key]:
                work.append(ident | dict(metric=key, baseline=before[key], candidate=after[key]))
        if before['raw_gufo']['draft_rounds'] != after['raw_gufo']['draft_rounds']:
            work.append(ident | dict(metric='raw.draft_rounds', baseline=before['raw_gufo']['draft_rounds'], candidate=after['raw_gufo']['draft_rounds']))
        phases = {k: (v, after[k]) for k, v in before.items() if k.endswith('_ms') and isinstance(v, (int, float)) and isinstance(after.get(k), (int, float))}
        phases.update({'raw.' + k: (v, after['raw_gufo'][k]) for k, v in before['raw_gufo'].items() if k.endswith('_ms') and isinstance(v, (int, float)) and isinstance(after['raw_gufo'].get(k), (int, float))})
        phases['final_content_to_HTTP_finish_ms'] = tail(before), tail(after)
        for metric, (av, bv) in phases.items():
            assert math.isfinite(av) and math.isfinite(bv)
            if bv - av > 3 and bv > 1.05 * av:
                flags.append(ident | dict(metric=metric, baseline_ms=av, candidate_ms=bv, delta_ms=bv - av))
stats = summarize([math.log(a / b) for a, b in zip(primary['baseline'], primary['candidate'])], design['observed_order'], 2026110203)
primary_report = dict(values_ms=primary,
                      geometric_ms={role: math.exp(statistics.mean(map(math.log, values))) for role, values in primary.items()},
                      tail_reduction_pct=stats['duration_reduction_pct'],
                      marginal_bootstrap95_tail_reduction_pct=[100 * value / (100 + value) for value in stats['marginal_bootstrap95_throughput_increase_pct']],
                      balanced_assignment_sensitivity_p=stats['balanced_assignment_sensitivity_p'],
                      signflip_p=stats['signflip_p'], positive_pairs=stats['positive_pairs'],
                      supported=stats['duration_reduction_pct'] > 0 and stats['marginal_bootstrap95_throughput_increase_pct'][0] > 0 and stats['balanced_assignment_sensitivity_p'] <= .05)
secondaries = {}
for index, (name, values) in enumerate(secondary.items()):
    s = summarize([math.log(b / a) for a, b in zip(values['baseline'], values['candidate'])], design['observed_order'], 2026110210 + index)
    secondaries[name] = dict(values=values, paired_rate_change_pct=s['paired_geometric_throughput_increase_pct'],
                             marginal_bootstrap95_rate_change_pct=s['marginal_bootstrap95_throughput_increase_pct'],
                             balanced_assignment_sensitivity_p=s['balanced_assignment_sensitivity_p'], scope='Secondary/exploratory; no equivalence or independent confirmatory gain claim.')
report = dict(records=100, starts=20, pairs=10, primary=primary_report, secondary=secondaries,
              completion_order=completion_order, strict_flags=flags, adaptive_work_fields=work,
              checked_transport_windows=audits, raw_inputs_sha256=input_hashes,
              scope='One predeclared primary completion-tail endpoint. Twenty fresh untraced starts; no diagnostic pooling, exclusions or adaptive stopping. Other rates/phase flags remain visible, not waived by the primary result. Sign-flip assumes pairwise symmetry; balanced assignment p is a sensitivity calculation. No GPU-ready/network-latency claim.')
(p / 'statistical-summary.json').write_text(json.dumps(report, indent=2) + '\n')
for name, rows in [('phase-flags.csv', flags), ('adaptive-work.csv', work)]:
    with (p / name).open('w') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]) if rows else ['no_rows'])
        writer.writeheader()
        writer.writerows(rows)
print(json.dumps(dict(records=100, primary=primary_report, secondary=secondaries,
                      flags=len(flags), work_fields=len(work)), indent=2))
