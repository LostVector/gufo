#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
// Test-only preload. Never modifies data or device settings. Arm explicitly after
// serving starts; fail exactly one aligned O_DIRECT table read in this process.
static _Atomic int injected = 0;
static int fail_read(int fd, size_t bytes, off_t offset) {
 const char *arm = getenv("STRIX_PLE_FAULT_ARM");
 if (!arm || atomic_load_explicit(&injected, memory_order_relaxed) ||
     access(arm, F_OK) != 0 || offset < 0 || offset % 4096 ||
     !bytes || bytes % 4096) return 0;
 int flags = fcntl(fd, F_GETFL);
 if (flags < 0 || !(flags & O_DIRECT)) return 0;
 char name[64], path[4096];snprintf(name,sizeof(name),"/proc/self/fd/%d",fd);
 ssize_t n=readlink(name,path,sizeof(path)-1);if(n<0)return 0;path[n]=0;
 const char *suffix="/Qwen3.8-Flash-Next-UD-Q4_K_XL-00002-of-00004.gguf";
 size_t length=strlen(path),tail=strlen(suffix);
 if(length<tail || strcmp(path+length-tail,suffix))return 0;
 int expected=0;
 if(!atomic_compare_exchange_strong_explicit(&injected,&expected,1,
       memory_order_relaxed,memory_order_relaxed))return 0;
 const char *log=getenv("STRIX_PLE_FAULT_LOG");
 if(log){int out=open(log,O_CREAT|O_EXCL|O_WRONLY|O_CLOEXEC,0600);
  if(out>=0){char row[512];int len=snprintf(row,sizeof(row),
   "{\"pid\":%d,\"tid\":%ld,\"fd\":%d,\"offset\":%lld,\"bytes\":%zu,\"errno\":%d,\"result\":-1,\"o_direct\":true}\n",
   getpid(),syscall(SYS_gettid),fd,(long long)offset,bytes,EIO);
   if(len>0 && len<(int)sizeof(row))(void)write(out,row,(size_t)len);close(out);}}
 errno=EIO;return 1;
}
ssize_t pread(int fd, void *buf, size_t bytes, off_t offset) {
 if(fail_read(fd,bytes,offset))return -1;
 typedef ssize_t (*Read)(int,void*,size_t,off_t);
 Read next=(Read)dlsym(RTLD_NEXT,"pread");
 if(!next){errno=ENOSYS;return -1;}return next(fd,buf,bytes,offset);
}
ssize_t pread64(int fd, void *buf, size_t bytes, off64_t offset) {
 if(fail_read(fd,bytes,(off_t)offset))return -1;
 typedef ssize_t (*Read)(int,void*,size_t,off64_t);
 Read next=(Read)dlsym(RTLD_NEXT,"pread64");
 if(!next){errno=ENOSYS;return -1;}return next(fd,buf,bytes,offset);
}
