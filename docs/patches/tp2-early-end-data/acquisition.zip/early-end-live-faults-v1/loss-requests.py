from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,urllib.request,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'reference/gufo-rdma/tools'))
import shlex
identity_out=Path(__file__).resolve().parent
label=Path(sys.argv[1]).stem
mode='candidate'
entry=json.loads((identity_out/'binaries.json').read_text())[mode]
for rank in (0,1):
 code="from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank{rank}.pid')+").read_text());proc=Path('/proc')/str(pid);exe=(proc/'exe').resolve();assert str(exe)=="+repr(str(root/'instrumentation/bin'/entry['name']))+";assert hashlib.sha256(exe.read_bytes()).hexdigest()=="+repr(entry['sha256'])+";args=(proc/'cmdline').read_bytes().decode().split(chr(0));selected={k:args[args.index(k)+1]for k in ('--context','--sessions','--prefill-chunk','--cache-ram-bytes','--speculative','--tp-world-size','--tp-rank','--think')};assert selected['--context']=='65536' and selected['--sessions']=='2' and selected['--prefill-chunk']=='2048' and selected['--speculative']=='mtp' and selected['--think']=='off';maps=(proc/'maps').read_text();assert '/read-observer/pread.so'not in maps and 'librocprofiler-sdk.so'not in maps;print(json.dumps({'pid':pid,'start_ticks':(proc/'stat').read_text().rsplit(')',1)[1].split()[19],'binary_sha256':"+repr(entry['sha256'])+",'selected_safe_options':selected,'read_observer_absent':True,'SDK_trace_absent':True}))"
 args=['python3','-c',code];cmd=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args
 raw=subprocess.check_output(cmd,text=True,timeout=60);json.loads(raw)
 (identity_out/f'{label}-identity-r{rank}.json').write_text(raw)

from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time,urllib.error,urllib.request
root=Path('/home/rkuo/strix-dispatch-investigation');out=root/'tp-cache-retention/early-end-live-faults-v1';label=Path(sys.argv[1]).stem;base=sys.argv[2];manifest=json.loads((root/'tp-cache-retention/early-end-live-faults-v1/binaries.json').read_text());exe=str(root/'instrumentation/bin/gufo-tp2-early-end-v2-dd9449e69')
def remote(code):return subprocess.check_output(['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(['python3','-c',code])],text=True,stderr=subprocess.STDOUT,timeout=30)
code="from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank1.pid')+").read_text());p=Path('/proc')/str(pid);exe=(p/'exe').resolve();assert str(exe)=="+repr(exe)+";digest=hashlib.sha256(exe.read_bytes()).hexdigest();assert digest=="+repr(manifest['candidate']['sha256'])+";print(json.dumps({'pid':pid,'exe':str(exe),'sha256':digest,'start_ticks':(p/'stat').read_text().rsplit(')',1)[1].split()[19]}))"
identity=json.loads(remote(code));(out/'loss-owner-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
body={'model':'flash-next-tp-test','messages':[{'role':'user','content':'Write a detailed numbered list of one hundred practical Linux performance debugging techniques. Explain each item in multiple sentences.'}],'max_tokens':512,'temperature':0,'seed':1,'cache_prompt':False,'stream':True,'chat_template_kwargs':{'enable_thinking':False}}
req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'});events=[];pieces=0;killed=False;signal_begin=None;normal_finish=False;explicit_error=None;started=time.monotonic()
with urllib.request.urlopen(req,timeout=30) as response:
 assert response.status==200
 for line in response:
  if not line.startswith(b'data:'):continue
  raw=line[5:].strip()
  if raw==b'[DONE]':break
  event=json.loads(raw);events.append(event)
  if event.get('error'):explicit_error=event['error']
  for choice in event.get('choices',[]):
   if choice.get('finish_reason') is not None:normal_finish=True
   pieces+=bool(choice.get('delta',{}).get('content'))
  if pieces>=8 and not killed:
   assert not normal_finish
   pid=identity['pid'];ticks=identity['start_ticks'];code="from pathlib import Path;import os,signal;pid="+str(pid)+";p=Path('/proc')/str(pid);assert str((p/'exe').resolve())=="+repr(exe)+";assert (p/'stat').read_text().rsplit(')',1)[1].split()[19]=="+repr(ticks)+";os.kill(pid,signal.SIGINT);print('signalled exact task-owned owner PID')"
   signal_begin=time.monotonic();confirmation=remote(code);assert confirmation.strip()=='signalled exact task-owned owner PID';killed=True
(out/'loss-stream-events.json').write_text(json.dumps(events,indent=2)+'\n');assert killed and explicit_error and not normal_finish,{'killed':killed,'error':explicit_error,'normal_finish':normal_finish}
failed_at=time.monotonic()
from failure_policy import wait_for_pair_exit
pair_exit=wait_for_pair_exit(out,label,base,body,exe)
(out/('loss-pair-exit.json')).write_text(json.dumps(pair_exit,indent=2))
record={'case':'live-owner-process-loss','owner':identity,'content_pieces_observed_at_least':pieces,'explicit_stream_error':explicit_error,'normal_completion_reported':normal_finish,'signal_to_error_ms':(failed_at-signal_begin)*1000,'whole_test_seconds':time.monotonic()-started,'failed_pair_exited':True,'pair_exit':pair_exit,'scope':'SIGINT exact task-owned owner after8content pieces; actual early-End engine; arithmetic unchanged. Socket deadline not accepted as success. Poisoned pair must exit; a new connection must be refused; fresh process recovery is separate.'}
Path(sys.argv[1]).write_text(json.dumps(record)+'\n');(out/'loss-result.json').write_text(json.dumps(record,indent=2)+'\n');print('Live owner loss rejected explicitly; poisoned engine refused subsequent request',flush=True)
