from pathlib import Path
import hashlib,json,re,shlex,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'complete').exists()and not json.loads((p/'cleanup.json').read_text())['errors']
for n,h in proto['harness_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
for n,h in proto['external_harness_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
ref=json.loads((p/'fresh-reference.json').read_text());assert hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest()==ref['sha256'];keys=('case','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256');errors={};failures={}
for phase,script in proto['sequence']:
 assert(p/f'{phase}-complete').exists();rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()]
 failure=phase.startswith('owner-')
 if failure:
  r=rows[0];assert len(rows)==1 and r['explicit_stream_error']and not r['normal_completion_reported']and r['failed_pair_exited']and all(not x['alive']for x in r['pair_exit']['states']);assert r['owner']['sha256']==proto['binaries']['candidate']['sha256']and r['content_pieces_observed_at_least']>=8
  if phase=='owner-readerror':
   f=r['injected_fault'];assert f['pid']==r['owner']['pid']and f['errno']==5 and f['result']==-1 and f['o_direct']and r['failed_pair_exited'];assert json.loads((p/'injected.jsonl').read_text())==f
  failures[phase]=r
 else:
  assert len(rows)==4 and all(all(a[k]==b[k]for k in keys)for a,b in zip(ref['rows'],rows));assert all(r['draft_tokens']>0 and r['cached_prompt_tokens']==0 for r in rows)
 for rank in(0,1):
  def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());delta={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};errors[f'{phase}/rank{rank}']=delta
  if not failure or phase=='owner-readerror':assert not delta,delta
  ident=json.loads((p/f'{p.name}-{phase}-identity-r{rank}.json').read_text());assert ident['binary_sha256']==proto['binaries']['candidate']['sha256']and ident['read_observer_absent']and ident['SDK_trace_absent']
  for k,v in {'--context':'65536','--sessions':'2','--prefill-chunk':'2048','--cache-ram-bytes':'1073741824','--speculative':'mtp','--tp-world-size':'2','--tp-rank':str(rank),'--think':'off'}.items():assert ident['selected_safe_options'][k]==v
  args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',str(ident['pid'])]
  if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
  subprocess.run(args,check=True,timeout=20)
for rank in(0,1):
 inv=json.loads((p/f'final-inventory-r{rank}.json').read_text());assert inv['module']=='81C6FF2FBAC473C7AB21844'and inv['refcnt']==0 and len(inv['devices'])==4 and all(inv[k]==proto['initial'][rank][k]for k in('boot_id','cmdline','routers'))
 assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout',(p/f'kernel-window-r{rank}.txt').read_text(),re.I)
report={'failures':failures,'initial_fresh_control_requests':4,'independent_fresh_recoveries':2,'exact_recovery_outputs_actual_MTP':8,'checked_transport_error_deltas':errors,'frozen_harness_binary_settings_boot_topology_PIDs_final_idle_audits':True,'scope':'Actual current early-End dd9449e6 production-OFF serving peerprocess loss and one userspace table EIO during live generation, explicit errors and automatic failed-pair exit under current serve.cpp policy and separate fresh recovery. No GPUfault/rank1extraDenseerror injection, exact failure-at-new-AllReduce coverage, transparent reconnect, physical cableloss or matched performance qualification. Previous timing flags remain.'}
(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
