from pathlib import Path
import json,subprocess,shlex,time,urllib.request,urllib.error,http.client

def wait_for_pair_exit(out,label,base,body,binary):
 identities=[json.loads((out/f'{label}-identity-r{rank}.json').read_text())for rank in(0,1)]
 def state(rank):
  i=identities[rank]
  code="from pathlib import Path;import json;p=Path('/proc/"+str(i['pid'])+"');exists=(p/'stat').exists();ticks=(p/'stat').read_text().rsplit(')',1)[1].split()[19]if exists else None;alive=exists and ticks=="+repr(i['start_ticks'])+"and(p/'exe').exists();assert not alive or str((p/'exe').resolve())=="+repr(binary)+";print(json.dumps({'rank':"+str(rank)+",'pid':"+str(i['pid'])+",'alive':alive,'original_start_ticks':"+repr(i['start_ticks'])+",'observed_start_ticks':ticks}))"
  args=['python3','-c',code]
  if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
  return json.loads(subprocess.check_output(args,text=True,stderr=subprocess.STDOUT,timeout=5))
 began=time.monotonic()
 while True:
  states=[state(rank)for rank in(0,1)]
  if not any(s['alive']for s in states):break
  assert time.monotonic()-began<10,('Failed pair did not exit',states)
  time.sleep(.05)
 req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps({**body,'stream':False,'max_tokens':1}).encode(),headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=2)as response:raise AssertionError(('Failed pair still accepts connections',response.status))
 except urllib.error.HTTPError as error:raise AssertionError(('Expected exited pair, received HTTP',error.code))from error
 except urllib.error.URLError as error:
  assert isinstance(error.reason,(ConnectionRefusedError,ConnectionResetError)),repr(error)
  connection_error=repr(error.reason)
 except (ConnectionRefusedError,ConnectionResetError,http.client.RemoteDisconnected)as error:connection_error=repr(error)
 return {'states':states,'exit_observation_ms':(time.monotonic()-began)*1000,'new_connection_rejected':connection_error,'scope':'Current serve.cpp fails closed by exiting the poisoned pair. No timeout or normal completion is accepted; no transparent in-process reconnect claim.'}
