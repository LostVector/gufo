from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,urllib.request,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'reference/gufo-rdma/tools'))
import shlex
identity_out=Path(__file__).resolve().parent
label=Path(sys.argv[1]).stem
mode='candidate'
entry=json.loads((identity_out/'binaries.json').read_text())[mode]
for rank in (0,1):
 code="from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank{rank}.pid')+").read_text());proc=Path('/proc')/str(pid);exe=(proc/'exe').resolve();assert str(exe)=="+repr(str(root/'instrumentation/bin'/entry['name']))+";assert hashlib.sha256(exe.read_bytes()).hexdigest()=="+repr(entry['sha256'])+";args=(proc/'cmdline').read_bytes().decode().split(chr(0));selected={k:args[args.index(k)+1]for k in ('--context','--sessions','--prefill-chunk','--cache-ram-bytes','--speculative','--tp-world-size','--tp-rank','--think')};assert selected['--context']=='65536' and selected['--sessions']=='2' and selected['--prefill-chunk']=='2048' and selected['--speculative']=='mtp' and selected['--think']=='off';maps=(proc/'maps').read_text();assert '/read-observer/pread.so'not in maps and 'librocprofiler-sdk.so'not in maps;print(json.dumps({'pid':pid,'start_ticks':(proc/'stat').read_text().rsplit(')',1)[1].split()[19],'binary_sha256':"+repr(entry['sha256'])+",'selected_safe_options':selected,'read_observer_absent':True,'SDK_trace_absent':True}))"
 args=['python3','-c',code];cmd=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args
 raw=subprocess.check_output(cmd,text=True,timeout=60);json.loads(raw)
 (identity_out/f'{label}-identity-r{rank}.json').write_text(raw)

from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,urllib.request,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'reference/gufo-rdma/tools'))
from gufo import serving_bench as bench
base=sys.argv[2];dest=Path(sys.argv[1]);original=bench._required_integer;local=threading.local()
def integer(metrics,key):
 if key=='prefill_tokens':local.metrics=dict(metrics)
 return original(metrics,key)
bench._required_integer=integer
class Gate:
 def __init__(self,index,event):self.index=index;self.event=event
 def wait(self):
  if self.index==0:self.event.set()
  else:self.event.wait();__import__('time').sleep(.01)
prompts=json.loads((root/'prefill-scaling/results/prompts.json').read_text())
def count(text):
 req=urllib.request.Request(base+'/v1/messages/count_tokens',data=json.dumps({'model':'flash-next-tp-test','messages':[{'role':'user','content':text}]}).encode(),headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=60))['input_tokens']
assert count(prompts['32768'])==32768 and count(prompts['2048'])==2048
short='Write a detailed numbered list of thirty practical ways to debug a slow distributed inference server. Explain each item.'
def request(case,text,index=0,width=1,tokens=128,gate=None,rep=1):
 local.metrics=None;obs=bench.run_request(base_url=base,model='flash-next-tp-test',prompt=text,max_tokens=tokens,temperature=0,timeout_seconds=600,client_id=f'refresh-{case}-{rep}-{index}',concurrency=width,repetition=rep,request_index=index,start_gate=gate,cache_prompt=False,extra_body={'chat_template_kwargs':{'enable_thinking':False}},endpoint_profile='gufo')
 return {'case':case,**obs.public(),'started_at':obs.started_at,'finished_at':obs.finished_at,'raw_gufo':local.metrics,'prompt_sha256':hashlib.sha256(text.encode()).hexdigest()}
with dest.open('x') as out:
 def save(r):
  out.write(json.dumps(r)+'\n');out.flush();print(r['case'],r['repetition'],r['request_index'],'prefill',r['prefill_tokens_per_second'],'decode',r['decode_tokens_per_second'],flush=True)
 save(request('warmup','Explain tensor parallel inference briefly.',tokens=8,rep=0))
 for rep in [1]:save(request('pp2048-tg128',prompts['2048'],rep=rep))
 for rep in [1]:
  event=threading.Event()
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   jobs=[pool.submit(request,'short-c2',short+f'\nRequest variant {i}.',i,2,128,Gate(i,event),rep) for i in range(2)];rs=[j.result() for j in jobs]
   assert [r['raw_gufo']['resident_requests_at_admission'] for r in rs]==[1,2]
   for r in rs:save(r)
