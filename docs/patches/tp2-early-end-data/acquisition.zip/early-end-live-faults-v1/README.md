# Early-End failure and lifetime qualification

Corrected production dd9449e6. Five fresh starts: exact four-request control;
one userspace EIO on rank1 aligned O_DIRECT n-gram-table pread after eight
content pieces; fresh four-request recovery; exact task-owned rank1 SIGINT
after eight pieces; independent fresh four-request recovery. Both poisoned
processes must exit, streams must report explicit error with no normal finish,
and new connections must be refused. Existing caller-side fallback is exercised
when the scheduler model step fails, skipping the new success hook. Healthy
controls and recoveries must retain actual MTP and exact outputs. Normal SIGINT
shutdown after each arm also checks unload/exit of the new ownership path.

The preload and its C source are reused byte-for-byte from the prior validated
fault fixture. It intercepts one userspace read, not drive/controller failure.
Legacy phase/variable names say owner; here both ranks read their local n-gram
tables and only rank1 is injected. There is no cooperative PLE protocol here.
No physical disconnect, driver/system change, full-table warm, hardware fault,
transparent reconnect, or timing claim. Keep failed attempts and all deltas.

Run from project root with the existing cable/native environment and runtime
library path, after any model study has released model-matrix.lock:

```bash
python3 -u tp-cache-retention/early-end-live-faults-v1/run.py
python3 tp-cache-retention/early-end-live-faults-v1/validate.py
```
