# Early-End wider completion qualification

Run from project root after the fixed primary study completes:

```bash
source cable-prep/env.sh
source native-rdma/env.sh
export LD_LIBRARY_PATH="$PWD/tp-cache-retention/fork-integration-v1/runtime/lib:$LD_LIBRARY_PATH"
python3 -u tp-cache-retention/early-end-wider-concurrency-v1/run.py
python3 tp-cache-retention/early-end-wider-concurrency-v1/analyze.py
```

Three fresh starts, fixed B/C/B: e250a07c / dd9449e6 / e250a07c. Twenty requests per start: solo controls, C3, C4, ragged C4, post-wave solo. Four sessions, context65,536, UD-Q4_K_XL plus actual shared-Q8_0 MTP, chunk2048,1GiB cache. No observer, sampler, driver or system changes. Outputs and prompt/cache work must match solo and across arms. Every phase5% AND3ms flag, adaptive work, completion order and last-content-to-HTTP-finish tail is retained. This is bounded functional/ordering coverage and phase investigation, not a new significance claim. Partial/failed attempts are preserved.
