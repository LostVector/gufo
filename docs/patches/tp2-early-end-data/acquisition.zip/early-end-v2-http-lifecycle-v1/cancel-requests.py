from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,sys,threading,time
root=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'reference/gufo-rdma/tests/functional'))
import continuation as c
c.TRACE.path=out/'requests.json';url=sys.argv[2]
prompts=['Write a detailed numbered list of thirty practical ways to debug a slow distributed inference server. Explain every item.','List sixty concrete Linux performance troubleshooting checks. Give one sentence explaining each check.']
def body(i,tokens=128):return {'model':'flash-next-tp-test','messages':[{'role':'user','content':prompts[i]}],'max_tokens':tokens,'temperature':0,'seed':1,'cache_prompt':False,'stream':False,'chat_template_kwargs':{'enable_thinking':False}}
def complete(i,tokens=128):return c.call(url,body(i,tokens))
reports=[]
with Path(sys.argv[1]).open('x') as dest:
 def save(row):reports.append(row);dest.write(json.dumps(row)+'\n');dest.flush()
 warm=complete(0,8);save({'case':'warmup','draft_tokens':warm['usage'].get('draft_tokens',0),'sha256':c.digest(warm)})
 controls=[complete(i) for i in [0,1]]
 for i,r in enumerate(controls):save({'case':'solo-control','index':i,'draft_tokens':r['usage'].get('draft_tokens',0),'sha256':c.digest(r),'usage':r['usage']})
 for survivor,victim in [(0,1),(1,0)]:
  started=threading.Event();done=threading.Event()
  def survive():
   started.set()
   try:return complete(survivor)
   finally:done.set()
  with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
   job=pool.submit(survive);assert started.wait(5);time.sleep(.01)
   partial,elapsed=c.call(url,{**body(victim),'stream':True},'content');concurrent_at_cancel=not done.is_set()
   save({'case':'cancelled-victim','index':victim,'survivor':survivor,'draft_tokens':None,'partial_sha256':hashlib.sha256(partial['content'].encode()).hexdigest(),'content_pieces_at_least':8,'elapsed_seconds':elapsed,'survivor_still_running_at_cancel':concurrent_at_cancel})
   assert concurrent_at_cancel,'Survivor finished before cancellation'
   assert controls[victim]['choices'][0]['message']['content'].startswith(partial['content']),'Partial content differs from solo control'
   result=job.result(timeout=120)
  save({'case':'survivor','index':survivor,'draft_tokens':result['usage'].get('draft_tokens',0),'sha256':c.digest(result),'usage':result['usage']})
  assert c.digest(result)==c.digest(controls[survivor]),'Cancellation changed peer output'
  detail=result['usage']['gufo'];assert detail['physical_execution_width']==2,'Two-row execution not observed'
  replay=complete(victim);save({'case':'after-cancel','index':victim,'draft_tokens':replay['usage'].get('draft_tokens',0),'sha256':c.digest(replay),'usage':replay['usage']})
  assert c.digest(replay)==c.digest(controls[victim]),'Post-cancel replay differs'
 assert all(r['draft_tokens'] > 0 for r in reports if r['case'] in ('solo-control','survivor','after-cancel')), 'MTP proposals not exercised'
print('completed9requestrecords',flush=True)
