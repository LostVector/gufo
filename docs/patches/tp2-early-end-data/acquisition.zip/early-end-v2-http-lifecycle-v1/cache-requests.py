from pathlib import Path
import json,subprocess,sys
root=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
script=root/'reference/gufo-rdma/tests/functional/continuation.py'
with Path(sys.argv[1]).open('x') as dest:
 for sampled in (0,1):
  for discard in (False,True):
   name=('discard' if discard else 'keep')+('-sampled' if sampled else '-greedy')
   case=f'content-preserve{int(discard)}-sampled{sampled}'
   output=out/f'{name}.json'
   args=['python3',str(script),'--url',sys.argv[2],'--model','flash-next-tp-test','--output',str(output),'--case',case]
   if discard:args.append('--discard-assistant')
   with(out/f'{name}.log').open('x')as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
   reports=json.loads(output.read_text());assert len(reports)==1
   r=reports[0];assert r['status']=='passed' and r['exact'] and r['cached']>=128 and r['proposed']>0
   dest.write(json.dumps({'case':name,'draft_tokens':r['proposed'],'command':args,'result':r})+'\n');dest.flush()
print('completed4actualMTPcachedcontinuationcases',flush=True)
