from pathlib import Path
import hashlib,json,re,shlex,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'complete').exists()and not json.loads((p/'cleanup.json').read_text())['errors']
for n,h in proto['harness_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
for n,h in proto['external_harness_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
for meta in json.loads((p/'source-preflight.json').read_text()).values():
 for n,h in meta['source_sha256'].items():assert hashlib.sha256((Path(meta['path'])/n).read_bytes()).hexdigest()==h,n
rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-candidate.jsonl').read_text().splitlines()];assert len(rows)==13
cache=[r for r in rows if r['suite']=='cache'];cancel=[r for r in rows if r['suite']=='cancel'];assert len(cache)==4 and len(cancel)==9
for row in cache:
 r=row['result'];assert r['exact']and r['status']=='passed'and r['proposed']>0 and r['cached']>=128 and r['followup']['cached']>=r['cached']and r['accepted']<=r['proposed'];assert r['request']['temperature']==(.8 if row['case'].endswith('sampled')else 0)and r['request']['seed']==1234;assert r['discard_assistant']==row['case'].startswith('discard')
controls={r['index']:r['sha256']for r in cancel if r['case']=='solo-control'};assert controls.keys()=={0,1}
for row in cancel:
 if row['case']in('solo-control','survivor','after-cancel'):assert row['draft_tokens']>0 and row['sha256']==controls[row['index']]
 if row['case']=='survivor':assert row['usage']['gufo']['physical_execution_width']==2
 if row['case']=='cancelled-victim':assert row['survivor_still_running_at_cancel']and row['draft_tokens']is None
assert {r['index']for r in cancel if r['case']=='cancelled-victim'}=={0,1}
errors={}
for rank in(0,1):
 def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'candidate-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
 a,b=counters('before'),counters('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());errors[rank]={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};assert not errors[rank]
 inv=json.loads((p/f'final-inventory-r{rank}.json').read_text());assert inv['module']=='81C6FF2FBAC473C7AB21844'and inv['refcnt']==0 and len(inv['devices'])==4;assert all(inv[k]==proto['initial'][rank][k]for k in('boot_id','cmdline','routers'))
 assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout',(p/f'kernel-window-r{rank}.txt').read_text(),re.I)
 ident=json.loads((p/f'{p.name}-candidate-identity-r{rank}.json').read_text());assert ident['binary_sha256']==proto['binaries']['candidate']['sha256']and ident['read_observer_absent']and ident['SDK_trace_absent']
 for k,v in {'--context':'65536','--sessions':'2','--prefill-chunk':'2048','--cache-ram-bytes':'1073741824','--speculative':'mtp','--tp-world-size':'2','--tp-rank':str(rank),'--think':'off','--tp-rdma-device':'usb4_rdma0'}.items():assert ident['selected_safe_options'][k]==v
 args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',str(ident['pid'])]
 if rank:args=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','rk-corsair-ai',shlex.join(args)]
 subprocess.run(args,check=True,timeout=20)
report={'cache_cases':[{k:r['result'][k]for k in('case','cached','prefill','proposed','accepted','exact','discard_assistant')}for r in cache],'two_C2_victim_roles_and_live_survivors_width2_exact_solo_and_postcancel_replay':True,'completed_substantive_requests_actual_MTP':True,'13_case_records_not13_HTTPcalls':True,'frozen_harness_binary_settings_boot_topology_PIDs_final_idle_checks':True,'checked_transport_error_deltas':errors,'scope':'Canonical13f64566 earlyenddd9449e69, current release provider-based TP2, wire21 dynamic-host-window batched-target-head greedy/sampled interrupted-assistant cache restore and two-role C2cancellation correctness; all underlying HTTP timings retained in *.requests.json/requests.json. No newpath read-error/peerloss/extraDensefailure, diskrestart, exhaustive acceptance-prefix or matched speed/timing-equivalence qualification. Earlier24pilot and6confidence warmup comparisons remain; no timing waiver. Materialized full-logit/seededRNG snapshot checks are separate; borrowed/serialized/diskrestart and fault-at-newhead/peerloss require their own evidence.'}
(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
