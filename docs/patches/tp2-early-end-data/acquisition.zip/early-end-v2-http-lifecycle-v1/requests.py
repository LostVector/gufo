from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,urllib.request,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'reference/gufo-rdma/tools'))
import shlex
identity_out=Path(__file__).resolve().parent
label=Path(sys.argv[1]).stem
mode=label.rsplit('-',1)[1];assert mode in ('baseline','candidate')
entry=json.loads((identity_out/'binaries.json').read_text())[mode]
for rank in (0,1):
 code="from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank{rank}.pid')+").read_text());proc=Path('/proc')/str(pid);exe=(proc/'exe').resolve();assert str(exe)=="+repr(str(root/'instrumentation/bin'/entry['name']))+";assert hashlib.sha256(exe.read_bytes()).hexdigest()=="+repr(entry['sha256'])+";args=(proc/'cmdline').read_bytes().decode().split(chr(0));selected={k:args[args.index(k)+1]for k in ('--context','--sessions','--prefill-chunk','--cache-ram-bytes','--speculative','--tp-world-size','--tp-rank','--think','--tp-rdma-device')};assert selected['--context']=='65536' and selected['--sessions']=='2' and selected['--prefill-chunk']=='2048' and selected['--speculative']=='mtp' and selected['--think']=='off'and selected['--tp-rdma-device']=='usb4_rdma0';maps=(proc/'maps').read_text();assert '/copy-fault.so'not in maps;assert '/read-observer/pread.so'not in maps and 'librocprofiler-sdk.so'not in maps;print(json.dumps({'pid':pid,'binary_sha256':"+repr(entry['sha256'])+",'selected_safe_options':selected,'read_observer_absent':True,'SDK_trace_absent':True}))"
 args=['python3','-c',code];cmd=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args
 raw=subprocess.check_output(cmd,text=True,timeout=60);json.loads(raw)
 (identity_out/f'{label}-identity-r{rank}.json').write_text(raw)

import runpy
original_argv=list(sys.argv);dest=Path(sys.argv[1]);base=sys.argv[2]
with dest.open('x')as combined:
 for suite,script in [('cache','cache-requests.py'),('cancel','cancel-requests.py')]:
  path=identity_out/(suite+'-records.jsonl');sys.argv=[str(identity_out/script),str(path),base]
  try:runpy.run_path(str(identity_out/script),run_name='__main__')
  finally:sys.argv=original_argv
  rows=[json.loads(line)for line in path.read_text().splitlines()]
  assert len(rows)==(4 if suite=='cache' else 9)
  for row in rows:combined.write(json.dumps({'suite':suite,**row})+'\n');combined.flush()
