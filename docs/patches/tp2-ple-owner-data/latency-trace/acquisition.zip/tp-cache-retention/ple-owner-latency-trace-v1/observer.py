from pathlib import Path
import concurrent.futures,json,shlex,subprocess,time

RPC = '''from pathlib import Path
import json,sys,time
p=Path(sys.argv[1]);action=sys.argv[2];deadline=time.monotonic()+25
if action=='activate':
 with(p/'capture.start').open('x')as f:f.write(str(time.monotonic_ns())+'\\n')
if action=='stop':(p/'capture.stop').touch()
name={'arm':'armed.ready','activate':'trace.ready','stop':'capture.complete'}[action]
while not(p/name).exists():
 if action!='stop'and(p/'status.json').exists():raise RuntimeError((p/'status.json').read_text())
 assert time.monotonic()<deadline,action+' timeout'
 time.sleep(.005)
if action=='stop':
 d=json.loads((p/'status.json').read_text());assert d['returncode']==0,d
else:d={'marker_ns':int((p/name).read_text()),'collector_exists':(p/'collector-process.json').exists()}
print(json.dumps(d))
'''

class Observer:
    def __init__(self,out,phase):self.out=out;self.phase=phase
    def rpc(self,rank,action):
        folder=self.out/self.phase/f'trace-r{rank}'
        args=['python3','-c',RPC,str(folder),action]
        command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','rk-corsair-ai',shlex.join(args)]if rank else args
        return json.loads(subprocess.check_output(command,text=True,timeout=35))
    def both(self,action):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
            jobs=[pool.submit(self.rpc,r,action)for r in(0,1)]
            values=[j.result()for j in jobs]
        (self.out/self.phase/(action+'-statuses.json')).write_text(json.dumps(values,indent=2)+'\n')
        return values
    def start(self):
        values=self.both('arm');assert not any(v['collector_exists']for v in values)
        self.both('activate')
    def stop(self):
        values=self.both('stop')
        assert all(v['returncode']==v['app_collector_exit_code']==0 and v['app_coverage_complete'] for v in values),values
