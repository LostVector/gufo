# PLE latency attribution

Fixed baseline/candidate/baseline replay of the original performance study first
five requests, using its frozen production binaries and unchanged approved native
driver. See design.json for exact scope. Same precompiled application-only v3 BPF
recorder on both hosts; scheduler IDs9/10/11 retain its validated shared_ptr ABI.
New candidate-only callback ID15 is a whole host span, potentially including peer
GPU execution; it is not pure dispatch. IDs4/8 are now EndRequest/StartRead and
record no argument fields. No new recorder or production binary changes.

One observation per arm cannot clear old timing flags or establish throughput
significance. Raw outputs, phase flags, adaptive work, coverage gaps and all failed
attempts must remain. No SDK/GPU/NVMe/admin probes or table warming.

Preparation caught old pre-extension snapshot symbol namespace and an unused
producer string-split before protocol creation/model launch; corrected preparation
passes exact symbol resolution, py_compile and global-name checks.
