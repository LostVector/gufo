#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
rank=${3:?};label=${1:?};phase=${label#ple-owner-latency-trace-v1-};role=${phase##*-}
[[ $rank = 0 || $rank = 1 ]]; [[ $role = baseline || $role = candidate ]]
unset LD_PRELOAD ROCP_TOOL_ATTACH
sudo -n /usr/local/sbin/strix-driver-lab run tp-cache-retention/ple-owner-latency-trace-v1/capture.py "$rank" "$$" "tp-cache-retention/ple-owner-latency-trace-v1/$phase/trace-r$rank" "$role" > "$root/tp-cache-retention/ple-owner-latency-trace-v1/$phase/trace-r$rank/supervisor.log" 2>&1 < /dev/null &
exec bash "$root/tp-cache-retention/ple-owner-latency-trace-v1/server-rank.sh" "$@"
