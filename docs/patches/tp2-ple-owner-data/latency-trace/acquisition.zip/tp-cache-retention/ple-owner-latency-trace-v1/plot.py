from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;d=json.loads((p/'analysis.json').read_text());fig,axes=plt.subplots(3,1,figsize=(10,6),sharex=True)
for ax,a in zip(axes,d['phases']):
 for item in a['C2_schedule']:
  actor=item['actor'];color=['#2878a5','#d67527'][actor]
  ax.broken_barh([(b,e-b)for b,e in item['prefill_intervals_ms']],(actor-.22,.44),facecolors=color,label=f'request {actor} prefill')
  ax.plot(item['publication_ms'],actor,'|',markersize=20,color='black')
  if item['postprefill_gap_ms']>1:
   end=item['prefill_intervals_ms'][-1][1];ax.annotate(f"{item['postprefill_gap_ms']:.2f} ms until publication",xy=((end+item['publication_ms'])/2,actor+.26),ha='center',fontsize=8)
 ax.set_yticks([0,1],['request 0','request 1']);ax.set_ylim(-.5,1.5);ax.set_title(a['phase'],loc='left',fontsize=11);ax.grid(axis='x',alpha=.2)
axes[-1].set_xlabel('Milliseconds from first C2 client arrival (head host only)')
fig.suptitle('Same scheduler interleaving in baseline and PLE candidate\nBars: host StepPrefill spans; black marks: first PublishSelection entry',fontsize=12)
fig.tight_layout(rect=[0,0,1,.91]);fig.savefig(p/'publication-timeline.png',dpi=150);fig.savefig(p/'publication-timeline.pdf')
