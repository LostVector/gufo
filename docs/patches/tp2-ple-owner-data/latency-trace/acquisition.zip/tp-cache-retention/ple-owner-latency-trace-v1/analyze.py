"""Request-identified host spans; outer waits include useful peer/GPU work."""
from pathlib import Path
import json,csv,collections,math
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'validation.json').exists();raw={};phases=[];flags=[];work=[]
def read_spans(folder):
 enters={};ends=[]
 for line in(folder/'app.csv').read_text().splitlines():
  if not line.startswith('APP,'):continue
  x=dict(zip(('kind','end','begin','tid','id','depth','cpu','pid','value'),map(int,line.split(',')[1:])))
  key=tuple(x[k]for k in('tid','id','depth','begin'))
  if x['kind']==1:assert key not in enters;enters[key]=x
  else:
   assert x['kind']==2 and key in enters;x['entry_value']=enters[key]['value'];ends.append(x)
 assert len(enters)==len(ends)==len({tuple(x[k]for k in('tid','id','depth','begin'))for x in ends})
 return sorted(ends,key=lambda x:x['begin'])
for phase,role in proto['sequence']:
 rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()];assert len(rows)==5;raw[phase]=rows
 ss=[read_spans(p/phase/f'trace-r{r}')for r in(0,1)];tags={f['id']:f['tag']for f in json.loads((p/'probes.json').read_text())[role]['functions']};items=[]
 for i,row in enumerate(rows):
  lo=int(row['started_at']*1e9);hi=int(row['finished_at']*1e9);pre=[s for s in ss[0]if s['id']==9 and lo<=s['begin']and s['end']<=hi]
  ptrs=list(dict.fromkeys(s['entry_value']for s in pre));assert all(ptrs)
  if i<3:assert len(ptrs)==1;ptr=ptrs[0]
  else:
   wave_start=int(min(r['started_at']for r in rows[3:])*1e9);wave_end=int(max(r['finished_at']for r in rows[3:])*1e9)
   ptrs=list(dict.fromkeys(s['entry_value']for s in ss[0]if s['id']==9 and wave_start<=s['begin']and s['end']<=wave_end));assert len(ptrs)==2;ptr=ptrs[i-3]
   assert row['raw_gufo']['resident_requests_at_admission']==i-2
  calls=[s for s in pre if s['entry_value']==ptr];pub=[s for s in ss[0]if s['id']==11 and s['entry_value']==ptr and lo<=s['begin']and s['end']<=hi];assert calls and pub
  shapes=[s['entry_value']for s in ss[0]if s['id']==3 and any(c['tid']==s['tid']and c['begin']<=s['begin']and s['end']<=c['end']for c in calls)];assert sum(shapes)==row['prompt_tokens']
  firstpub=pub[0]['begin'];prefill_end=max(s['end']for s in calls);assert prefill_end<=firstpub
  aggregates=[]
  for rank in(0,1):
   ag={}
   for ident,tag in tags.items():
    selected=[s for s in ss[rank]if s['id']==ident and lo<=s['begin']and s['end']<=hi];times=[(s['end']-s['begin'])/1e6 for s in selected]
    ag[tag]={'calls':len(times),'sum_host_span_ms':sum(times),'max_host_span_ms':max(times,default=0)}
   aggregates.append(ag)
  items.append(dict(case=row['case'],repetition=row['repetition'],actor=row['request_index'],request_pointer=ptr,prefill_shapes=shapes,client_ttft_ms=row.get('client_ttft_ms'),server_ttft_ms=row.get('server_ttft_ms'),last_prefill_to_first_publication_ms=(firstpub-prefill_end)/1e6,first_publication_after_client_start_ms=(firstpub-lo)/1e6,first_content_after_client_start_ms=(row['content_events'][0]['perf_counter_ns']-lo)/1e6,per_rank_window_spans=aggregates))
 wave_lo=int(min(r['started_at']for r in rows[3:])*1e9);wave_hi=int(max(r['finished_at']for r in rows[3:])*1e9)
 schedule=[]
 for item in items[3:]:
  ptr=item['request_pointer'];calls=[x for x in ss[0]if x['id']==9 and x['entry_value']==ptr and wave_lo<=x['begin']and x['end']<=wave_hi];done=max(x['end']for x in calls)
  pubs=[x for x in ss[0]if x['id']==11 and x['entry_value']==ptr and wave_lo<=x['begin']and x['end']<=wave_hi];pub=pubs[0]['begin']
  overlap=[(max(done,x['begin']),min(pub,x['end']))for x in ss[0]if x['id']==9 and x['entry_value']!=ptr and done<x['end']and x['begin']<pub]
  assert all(b>=a for a,b in overlap)
  schedule.append(dict(actor=item['actor'],prefill_intervals_ms=[[(x['begin']-wave_lo)/1e6,(x['end']-wave_lo)/1e6]for x in calls],publication_ms=(pub-wave_lo)/1e6,postprefill_gap_ms=(pub-done)/1e6,other_request_prefill_inside_gap_ms=sum(b-a for a,b in overlap)/1e6))
 warm=items[0];warm_lo=int(rows[0]['started_at']*1e9);warm_hi=int(rows[0]['finished_at']*1e9)
 initial=[x for x in ss[0]if x['id']==9 and x['entry_value']==warm['request_pointer']and warm_lo<=x['begin']and x['end']<=warm_hi]
 initial_forwards=[x for x in ss[0]if x['id']==3 and any(a['tid']==x['tid']and a['begin']<=x['begin']and x['end']<=a['end']for a in initial)]
 phases.append(dict(phase=phase,requests=items,C2_schedule=schedule,warmup_prefill_Forward_ms=[(x['end']-x['begin'])/1e6 for x in initial_forwards],span_counts_per_rank=[dict(collections.Counter(s['id']for s in v))for v in ss]))
for control in('before-baseline','after-baseline'):
 for a,b in zip(raw[control],raw['first-candidate']):
  ident=dict(control=control,case=a['case'],repetition=a['repetition'],actor=a['request_index'])
  for k in('draft_tokens','draft_accepted_tokens','physical_execution_width'):
   if a[k]!=b[k]:work.append(ident|dict(metric=k,baseline=a[k],candidate=b[k]))
  for k in('draft_rounds',):
   if a['raw_gufo'].get(k)!=b['raw_gufo'].get(k):work.append(ident|dict(metric='raw.'+k,baseline=a['raw_gufo'].get(k),candidate=b['raw_gufo'].get(k)))
  values={k:(v,b[k])for k,v in a.items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b.get(k),(int,float))}
  values.update({'raw.'+k:(v,b['raw_gufo'][k])for k,v in a['raw_gufo'].items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b['raw_gufo'].get(k),(int,float))})
  for k,(av,bv)in values.items():
   assert math.isfinite(av)and math.isfinite(bv)
   if bv-av>3 and bv>1.05*av:flags.append(ident|dict(metric=k,baseline_ms=av,candidate_ms=bv,delta_ms=bv-av))
report=dict(phases=phases,strict_flags=flags,adaptive_work_differences=work,scope='One fixed observed B/C/B of frozen measured production sources and exact original first-five-request history. Per-request windows overlap in C2; span sums include nested and peer/GPU work, are not additive wall components or pure CPU tax. No crosshost clock alignment; peer spans joined only by its own local request time window are NOT valid across hosts, so per-rank1 aggregates below intentionally omitted. Publication is host attempt, not hardware-ready/delivery. No causal/speed/equivalence claim or prior flag waiver.')
# Host clocks are independent: do not export peer windows selected with head timestamps.
for phase in report['phases']:
 for request in phase['requests']:request['per_rank_window_spans'][1]={'omitted':'No cross-host clock alignment; use full peer trace with ordinal/model boundaries.'}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for n,rows in [('phase-flags.csv',flags),('adaptive-work.csv',work)]:
 with(p/n).open('w')as f:w=csv.DictWriter(f,fieldnames=list(rows[0])if rows else['no_rows']);w.writeheader();w.writerows(rows)
print(json.dumps({'phases':[dict(phase=a['phase'],requests=[{k:v for k,v in r.items()if k!='per_rank_window_spans'}for r in a['requests']])for a in phases],'strict_flag_count':len(flags),'adaptive_work_field_count':len(work)},indent=2))
