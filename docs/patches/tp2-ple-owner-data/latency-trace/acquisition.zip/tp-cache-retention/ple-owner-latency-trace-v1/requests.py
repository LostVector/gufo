from pathlib import Path
import runpy,sys,time,json
from observer import Observer
out=Path(__file__).resolve().parent;label=Path(sys.argv[1]).stem;phase=label.removeprefix(out.name+'-');assert phase in('before-baseline','first-candidate','after-baseline')
observer=Observer(out,phase)
try:
 observer.start()
 (out/(phase+'-activation.json')).write_text(json.dumps({'request_begin_monotonic_ns':time.monotonic_ns(),'request_begin_perf_counter_ns':time.perf_counter_ns(),'scope':'Necessary postHTTP BPFactivation only, no fixedidle/GPUprofiler/adminsampler.'})+'\n')
 runpy.run_path(str(out/'client.py'),run_name='__main__')
finally:observer.stop()
