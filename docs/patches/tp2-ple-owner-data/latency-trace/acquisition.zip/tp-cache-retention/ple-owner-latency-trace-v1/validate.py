from pathlib import Path
import hashlib,json,re,shlex,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'complete').exists()and not json.loads((p/'cleanup.json').read_text())['errors']
for n,h in proto['harness_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
for n,h in proto['external_harness_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
for folder,meta in proto['collector_build_manifests'].items():
 for n,h in meta['files_sha256'].items():assert hashlib.sha256((root/folder/n).read_bytes()).hexdigest()==h,n
identity_keys=('case','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256');reference=[json.loads(s)for s in(root/'results/model-scaling/cooperative-ple-release-comparison-v2-pair01-baseline.jsonl').read_text().splitlines()][:5];errors={}
for phase,binary in proto['sequence']:
 role=phase.rsplit('-',1)[1];rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()];assert len(rows)==5 and all(all(a[k]==b[k]for k in identity_keys)for a,b in zip(reference,rows));assert all(r['draft_tokens']>0 for r in rows)
 for rank in(0,1):
  def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());delta={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};assert not delta;errors[f'{phase}/rank{rank}']=delta
  ident=json.loads((p/f'{p.name}-{phase}-identity-r{rank}.json').read_text());assert ident['binary_sha256']==proto['binaries'][role]['sha256']and ident['SDK_trace_absent']and ident['read_observer_absent']
  for k,v in {'--context':'65536','--sessions':'2','--prefill-chunk':'2048','--cache-ram-bytes':'1073741824','--speculative':'mtp','--tp-world-size':'2','--tp-rank':str(rank),'--think':'off'}.items():assert ident['selected_safe_options'][k]==v
  folder=p/phase/f'trace-r{rank}';status=json.loads((folder/'status.json').read_text());assert status['app_collector_exit_code']==0 and status['app_coverage_complete']
  stats=status['stats'];assert not any(stats['counters'][:5])and not any(stats['program_recursion_misses'])and stats['remaining_span_keys']==stats['remaining_depth_keys']==0
  pids={ident['pid'],json.loads((folder/'collector-process.json').read_text())['pid']}
  for pid in pids:
   args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',str(pid)]
   if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
   subprocess.run(args,check=True,timeout=15)
for rank in(0,1):
 final=json.loads((p/f'final-inventory-r{rank}.json').read_text());assert final['module']=='81C6FF2FBAC473C7AB21844'and final['refcnt']==0 and len(final['devices'])==4 and all(final[k]==proto['initial'][rank][k]for k in('boot_id','cmdline','routers'))
 assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout|amdgpu.*reset|segfault',(p/f'kernel-window-r{rank}.txt').read_text(),re.I)
report={'15canonical_outputs_exact_original_performance_prefix':True,'frozen_harness_and_actual_shared_ptr_ABI_fixture_pins':True,'both_rank_binary_settings_and_approved_final_idle':True,'all_recorded_model_and_app_collector_PIDs_gone':True,'application_loss_balance_recursion_remaining_maps_checks_pass':True,'six_checked_transport_windows':errors,'boot_topology_unchanged_checked_kernel_faults_absent':True,'scope':'Acquisition/correctness/safety only. No independent kernel uprobe misscounter, GPUtimeline or lossfreeclaim. No speed/effect/cause orpreviousphaseflagwaiver.'};(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
