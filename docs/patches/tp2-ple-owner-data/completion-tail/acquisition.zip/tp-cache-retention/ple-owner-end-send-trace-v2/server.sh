#!/bin/bash
set -euo pipefail
root=/home/rkuo/strix-dispatch-investigation
rank=${3:?};label=${1:?};phase=${label#ple-owner-end-send-trace-v2-};role=${phase##*-}
[[ $rank = 0 || $rank = 1 ]]; [[ $role = baseline || $role = candidate ]]
unset LD_PRELOAD ROCP_TOOL_ATTACH
sudo -n /usr/local/sbin/strix-driver-lab run tp-cache-retention/ple-owner-end-send-trace-v2/capture.py "$rank" "$$" "tp-cache-retention/ple-owner-end-send-trace-v2/$phase/trace-r$rank" "$role" > "$root/tp-cache-retention/ple-owner-end-send-trace-v2/$phase/trace-r$rank/supervisor.log" 2>&1 < /dev/null &
exec bash "$root/tp-cache-retention/ple-owner-end-send-trace-v2/server-rank.sh" "$@"
