"""Fixed affected-history CPU span attribution; no causal/effect claim from one B/C/B."""
from pathlib import Path
import collections,csv,json,math
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'complete').exists();data={};timelines=[];flags=[];work=[]
def spans(folder):
 entries={};ends=[]
 for line in(folder/'app.csv').read_text().splitlines():
  if not line.startswith('APP,'):continue
  v=list(map(int,line.split(',')[1:]));s=dict(zip(('kind','end','begin','tid','id','depth','cpu','pid','value'),v));key=s['tid'],s['id'],s['depth'],s['begin']
  if s['kind']==1:assert key not in entries;entries[key]=s
  else:assert s['kind']==2 and key in entries;s['entry_value']=entries[key]['value'];ends.append(s)
 assert len(entries)==len(ends)==len({(s['tid'],s['id'],s['depth'],s['begin'])for s in ends})
 for s in ends:
  if s['id']in(9,10,11):assert s['entry_value']!=0
  if s['id']in(3,5):assert s['value']&255==1
 return sorted(ends,key=lambda s:s['begin'])
def union_duration(xs):
 merged=[]
 for lo,hi in sorted(xs):
  if hi<=lo:continue
  if merged and lo<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],hi)
  else:merged.append([lo,hi])
 return sum(b-a for a,b in merged)
for phase,_ in proto['sequence']:
 rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()];assert len(rows)==5;data[phase]=rows
 ss=spans(p/phase/'trace-r0');peer=spans(p/phase/'trace-r1');base=min(r['started_at']for r in rows[3:])*1e9;end=max(r['finished_at']for r in rows[3:])*1e9
 pre=[s for s in ss if s['id']==9 and base<=s['begin']and s['end']<=end];ptrs=list(dict.fromkeys(s['entry_value']for s in pre));assert len(ptrs)==2 and [r['raw_gufo']['resident_requests_at_admission']for r in rows[3:]]==[1,2]
 heads=[s for s in ss if s['id']==15 and base<=s['begin']and s['end']<=end]
 items=[]
 for idx,ptr in enumerate(ptrs):
  calls=[s for s in pre if s['entry_value']==ptr];published=[s for s in ss if s['id']==11 and s['entry_value']==ptr and base<=s['begin']and s['end']<=end];prepared=[s for s in ss if s['id']==10 and s['entry_value']==ptr and base<=s['begin']and s['end']<=end];assert published and prepared
  forward=[s for s in ss if s['id']==3 and any(c['tid']==s['tid']and c['begin']<=s['begin']and s['end']<=c['end']for c in calls)];tokens=[s['entry_value']for s in forward];assert sum(tokens)==39,tokens
  done=max(s['end']for s in calls);firstpub=published[0]['begin'];assert done<=firstpub
  other=[(max(done,s['begin']),min(firstpub,s['end']))for s in pre if s['entry_value']!=ptr];r=rows[3+idx]
  items.append({'request_index':idx,'opaque_request_pointer':ptr,'prefill_Forward_token_shapes':tokens,'StepPrefill_intervals_ms':[[(s['begin']-base)/1e6,(s['end']-base)/1e6]for s in calls],'last_prefill_return_ms':(done-base)/1e6,'PrepareFirstSnapshot_first_ms':(prepared[0]['begin']-base)/1e6,'PublishSelection_first_entry_ms':(firstpub-base)/1e6,'first_content_ms':(r['content_events'][0]['perf_counter_ns']-base)/1e6,'second_content_ms':(r['content_events'][1]['perf_counter_ns']-base)/1e6,'last_prefill_to_first_publish_ms':(firstpub-done)/1e6,'peer_StepPrefill_overlap_in_that_window_ms':union_duration(other)/1e6,'server_queue_ms':r['raw_gufo'].get('queue_ms'),'prefill_ms':r['prefill_ms'],'server_ttft_ms':r['server_ttft_ms'],'drafts':r['draft_tokens'],'accepted':r['draft_accepted_tokens'],'rounds':r['raw_gufo'].get('draft_rounds')})
 timelines.append({'phase':phase,'C2_requests':items,'C2_first_MtpHead_ms':(min(s['begin']for s in heads)-base)/1e6 if heads else None,'first_contents_before_changed_head_execution':bool(heads)and all(r['content_events'][0]['perf_counter_ns']<min(s['begin']for s in heads)for r in rows[3:]),'capture_intervals_ms':[{'id':s['id'],'begin':(s['begin']-base)/1e6,'end':(s['end']-base)/1e6,'tid':s['tid']}for s in ss if s['id']in(2,7)and base<=s['begin']and s['end']<=end],'span_counts_per_rank':[dict(collections.Counter(s['id']for s in v))for v in(ss,peer)]})
for control in('before-baseline','after-baseline'):
 for a,b in zip(data[control],data['first-candidate']):
  ident={'control':control,'case':a['case'],'repetition':a['repetition'],'index':a['request_index']}
  for k in('draft_tokens','draft_accepted_tokens','physical_execution_width'):
   if a[k]!=b[k]:work.append(ident|{'metric':k,'baseline':a[k],'candidate':b[k]})
  if a['raw_gufo'].get('draft_rounds')!=b['raw_gufo'].get('draft_rounds'):work.append(ident|{'metric':'raw.draft_rounds','baseline':a['raw_gufo'].get('draft_rounds'),'candidate':b['raw_gufo'].get('draft_rounds')})
  vals={k:(v,b[k])for k,v in a.items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b.get(k),(int,float))};vals.update({'raw.'+k:(v,b['raw_gufo'][k])for k,v in a['raw_gufo'].items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b['raw_gufo'].get(k),(int,float))})
  for k,(av,bv)in vals.items():
   assert math.isfinite(av)and math.isfinite(bv)
   if bv-av>3 and bv>av*1.05:flags.append(ident|{'metric':k,'baseline_ms':av,'candidate_ms':bv,'delta_ms':bv-av})
report={'timelines':timelines,'strict_flags':flags,'adaptive_work_differences':work,'scope':'Fixed observedB/C/B withoriginalpilotprefixhistory, noSDK/GPU/NVMe/adminsampler. StepPrefill requestidentity read fromexactlibstdc++shared_ptrrefABI; sameopaqueobjectjoins publication/preparation. C2requestindices follow observedfirst-admissionorder (resident1/2), firstseenprefillpointerorder; no crosshostclockalignment. Lastprefillreturn ismeasured schedulerboundary, nothardwareGPUready timestamp. PublishSelection entry ispublicationattempt, not guaranteed1:1visiblecontent. Peerworkoverlap isnotpurewastedCPUtime. Allflagsretained; no significance/equivalence/cause ororiginalflagwaiver inferred.'}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for name,records in [('phase-flags.csv',flags),('adaptive-work.csv',work)]:
 with(p/name).open('w')as f:w=csv.DictWriter(f,fieldnames=list(records[0])if records else['no_rows']);w.writeheader();w.writerows(records)
print(json.dumps({'timelines':[{k:v for k,v in r.items()if k not in('capture_intervals_ms','span_counts_per_rank')}for r in timelines],'phase_flags':len(flags),'work_comparisons':len(work)},indent=2))
