from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,secrets,shlex,subprocess,time
root=Path(__file__).resolve().parents[2];os.chdir(root);out=Path(__file__).resolve().parent
lock=(root/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'protocol.json').exists()
def call(rank,args,timeout=90):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','rk-corsair-ai',shlex.join(args)]if rank else args,text=True,stderr=subprocess.STDOUT,timeout=timeout)
def admin(rank,mode):return call(rank,['sudo','-n','/usr/local/sbin/strix-driver-lab','run','driver-frame-investigation/module-fork.py',mode])
def inventory(profile,label):
 result=[];deadline=time.monotonic()+150
 for rank in(0,1):
  while True:
   try:d=json.loads(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),profile]));break
   except subprocess.CalledProcessError as ex:
    with(out/'readiness-errors.log').open('a')as f:f.write(ex.output)
    assert time.monotonic()<deadline;time.sleep(1)
  (out/f'{label}-r{rank}.json').write_text(json.dumps(d,indent=2)+'\n');result.append(d)
 return result
def snapshot(label):
 for rank in(0,1):(out/f'{label}-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
for phase in ('before-baseline','first-candidate','after-baseline'):
 for rank in (0,1):
  folder=out/phase/f'trace-r{rank}';folder.mkdir(parents=True,exist_ok=False)
call(1,['mkdir','-p',str(out)])
subprocess.run(['rsync','-a','--no-owner','--no-group',str(out/'capture.py'),str(out/'server.sh'),str(out/'binaries.json'),str(out/'probes.json'),f'rk-corsair-ai:{out}/'],check=True)
for phase in ('before-baseline','first-candidate','after-baseline'):
 for rank in (0,1):call(1,['mkdir','-p',str(out/phase/f'trace-r{rank}')])
initial=inventory('baseline','initial-inventory');manifest=json.loads((out/'binaries.json').read_text());assert(out/'source-preflight.json').exists()
for entry in manifest.values():
 binary=root/'instrumentation/bin'/entry['name'];assert hashlib.sha256(binary.read_bytes()).hexdigest()==entry['sha256'];subprocess.run(['rsync','-a',str(binary),f'rk-corsair-ai:{binary}'],check=True)
 for rank in(0,1):assert call(rank,['sha256sum',str(binary)]).split()[0]==entry['sha256']
spec=importlib.util.spec_from_file_location('engine',root/'link40/engine-runner.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
exec(compile((root/'link40/engine-runner.py').read_text().replace('link40/server-rank.sh','tp-cache-retention/ple-owner-end-send-trace-v1/server.sh'),str(root/'link40/engine-runner.py'),'exec'),e.__dict__)
os.environ.update(SCALING_NATIVE_RDMA='1',STRIX_SESSIONS='2',STRIX_CONTEXT='65536',STRIX_CHUNK='2048',STRIX_SPECULATION='mtp',SCALING_REQUEST_SCRIPT=str(out/'requests.py'))
for key in('LD_PRELOAD','ROCP_TOOL_ATTACH','STRIX_READ_OUTPUT'):os.environ.pop(key,None)
sequence=[('before-baseline','ar-snapshot-turn-v1'),('first-candidate','draft-subset-shard-v1'),('after-baseline','ar-snapshot-turn-v1')]
design={'scope':'Fixed observed B/C/B, exactpilotprefixhistorywarmup8→first2K/max128→repeat2K/max128→two39tokenC2/max128; omit32KAFTERaffectedhistory. Exactd41versus486 withidenticalappspanv3 schedulerrequestidentity/preview/publication/TPcapture/modelspans, noSDK/GPU/NVMe/adminsampler/profiler/extraidle/priming/fulltablewarm orproductionchanges. TargetactualTTFTflags, retainallrequestphase/workdifferences andcoveragefailures. Notunprofiledconfidence/effect/equivalence. Matched65Kcapacity/2slots/chunk2K/backend4K/cache1GiB/heaps124GiB/crossed40+20/common844E/TX32thenrestore81C6.'}
protocol={'sequence':sequence,'binaries':manifest,'initial':initial,'settings':{'quant':'UD-Q4_K_XL','MTP':'enabled/sharedQ8_0','capacity':65536,'sessions':2,'chunk':2048,'cache_RAM_bytes':1073741824,'driver':'common transient844E/TX32; restore81C6afterward','links_per_direction_Gbps':[40,20]},'scope':design['scope'],'design':design}
protocol['harness_sha256']={n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in('run.py','requests.py','source-preflight.json','binaries.json','capture.py','observer.py','server.sh','probes.json','client.py','analyze.py','validate.py')}
protocol['external_harness_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in('link40/engine-runner.py','link40/server-rank.sh','native-rdma/env.sh','cable-prep/env.sh','driver-frame-investigation/module-fork.py','tp-cache-retention/driver-parent-timing-v1/inventory.py')}
protocol['collector_build_manifests']={n:json.loads((root/n/'build-info.json').read_text())for n in ('tp-cache-retention/app-span-recorder-v3',)}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
token=root/'model-scaling/control-token';assert not token.exists();start=int(time.time())-2;reference=None
try:
 for mode in('prepare','load'):
  for rank in(0,1):(out/f'{mode}-r{rank}.json').write_text(admin(rank,mode))
 inventory('candidate','common-driver-ready')
 token.write_text(secrets.token_hex(32));token.chmod(0o600);subprocess.run(['rsync','-a',str(token),f'{e.peer}:{token}'],check=True)
 for phase,binary in sequence:
  inv=inventory('candidate',phase+'-runtime')
  for rank in(0,1):assert inv[rank]['boot_id']==initial[rank]['boot_id']and inv[rank]['cmdline']==initial[rank]['cmdline']
  snapshot(phase+'-before');print(time.strftime('%F %T'),'START',phase,flush=True)
  e.run(out.name+'-'+phase,2,e.local,binary)
  for rank in(0,1):
   if rank:subprocess.run(['rsync','-a','--no-owner','--no-group',f'rk-corsair-ai:{out}/{phase}/trace-r1/',str(out/phase/'trace-r1')+'/'],check=True)
  snapshot(phase+'-after');inventory('candidate',phase+'-final-inventory')
  rows=[json.loads(s)for s in(e.out/f'{out.name}-{phase}.jsonl').read_text().splitlines()];assert len(rows)==5
  assert all(r['draft_tokens']>0 and r['cached_prompt_tokens']==0 and r['prefill_tokens']==r['prompt_tokens']for r in rows)
  assert rows[1]['prompt_tokens']==2048
  assert all(r['prompt_tokens']==39 and r['physical_execution_width']in(1,2)for r in rows[3:])
  assert all(r['prompt_tokens']==2048 and r['completion_tokens']==113 for r in rows[1:3])
  keys=('case','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256');ident=[{k:r[k]for k in keys}for r in rows]
  if reference is None:reference=ident
  assert reference==ident,('canonical identity mismatch',phase)
  for rank in(0,1):
   a,b=[{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(out/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}for tag in('before','after')]
   assert a and a.keys()==b.keys()and all(b[k]>=a[k]for k in a)
   errors={k:b[k]-a[k]for k in a if b[k]!=a[k]and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
   (out/f'{phase}-errors-r{rank}.json').write_text(json.dumps(errors,indent=2)+'\n');assert not errors,(phase,rank,errors)
  (out/f'{phase}-complete').touch();print(time.strftime('%F %T'),'PASS',phase,flush=True)
 (out/'complete').touch()
finally:
 token.unlink(missing_ok=True);subprocess.run(['ssh',e.peer,'rm','-f',str(token)],check=False);errors=[]
 for rank in(0,1):
  try:(out/f'final-before-unload-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
  except BaseException as ex:errors.append('finalcounter rank'+str(rank)+':'+repr(ex))
 for phase in ('before-baseline','first-candidate','after-baseline'):
  for rank in(0,1):
   try:
    folder=out/phase/f'trace-r{rank}'
    code="from pathlib import Path;import sys,time;p=Path(sys.argv[1]);(p/'capture.stop').touch();deadline=time.monotonic()+20\nwhile not(p/'capture.complete').exists():\n assert time.monotonic()<deadline,'capture cleanup timeout'\n time.sleep(.01)"
    # A phase never started has no supervisor log; no worker is expected.
    present=call(rank,['python3','-c',"from pathlib import Path;import sys;print(int((Path(sys.argv[1])/'supervisor.log').exists()))",str(folder)]).strip()
    if present=='1':call(rank,['python3','-c',code,str(folder)],timeout=25)
    if rank:subprocess.run(['rsync','-a','--no-owner','--no-group',f'rk-corsair-ai:{folder}/',str(folder)+'/'],check=True)
   except BaseException as ex:errors.append('collector cleanup '+phase+'/r'+str(rank)+':'+repr(ex))
 for rank in(0,1):
  try:(out/f'restored-r{rank}.json').write_text(admin(rank,'restore'))
  except BaseException as ex:errors.append(repr(ex))
 try:inventory('baseline','final-inventory')
 except BaseException as ex:errors.append(repr(ex))
 for rank in(0,1):
  try:(out/f'kernel-window-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-driver-lab','run','fork-integration/hardware/kernel-window.py',str(start)]))
  except BaseException as ex:errors.append(repr(ex))
 (out/'cleanup.json').write_text(json.dumps({'errors':errors,'finished':time.time()},indent=2)+'\n');assert not errors,errors
