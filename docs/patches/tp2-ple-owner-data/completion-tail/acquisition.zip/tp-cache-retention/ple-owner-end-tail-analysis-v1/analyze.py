"""Read-only completion-tail analysis of the already acquired v1 app trace."""
import ast
import hashlib
import json
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
trace = p.parent / 'ple-owner-latency-trace-v1'
assert not (p / 'analysis.json').exists()
assert json.loads((trace / 'cleanup.json').read_text())['errors'] == []
protocol = json.loads((trace / 'protocol.json').read_text())
for name, digest in protocol['harness_sha256'].items():
    assert hashlib.sha256((trace / name).read_bytes()).hexdigest() == digest, name
tree = ast.parse((trace / 'analyze.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'read_spans')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(trace / 'analyze.py'), 'exec'))
original = json.loads((trace / 'analysis.json').read_text())
records = []
inputs = {}
for phase in original['phases']:
    tag = phase['phase']
    raw = root / 'results/model-scaling' / f'{trace.name}-{tag}.jsonl'
    app = trace / tag / 'trace-r0/app.csv'
    for path in (raw, app):
        inputs[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    spans = read_spans(app.parent)
    c2 = [row for row in rows if row['case'] == 'short-c2']
    assert len(c2) == 2
    by_actor = {r['actor']: r for r in phase['requests'] if r['case'] == 'short-c2'}
    for row in c2:
        actor = row['request_index']
        pointer = by_actor[actor]['request_pointer']
        lo = row['content_events'][-1]['perf_counter_ns']
        hi = round(row['finished_at'] * 1e9)
        others = [r for r in c2 if r['request_index'] != actor and round(r['finished_at'] * 1e9) > lo]
        ends = [s for s in spans if s['id'] == 4 and s['begin'] < hi and s['end'] > lo]
        record = dict(phase=tag, actor=actor, request_pointer=pointer,
                      final_content_to_HTTP_finish_ms=(hi - lo) / 1e6,
                      other_requests_still_live=[r['request_index'] for r in others],
                      overlapping_EndRequest=ends)
        if actor == 1:
            assert len(ends) == 1 and len(others) == 1
            end = ends[0]
            steps = [s for s in spans if s['id'] == 13 and s['begin'] < end['end'] and s['end'] > end['begin']]
            assert len(steps) == 1
            step = steps[0]
            assert step['tid'] != end['tid'] and step['end'] < end['end']
            pubs = [s for s in spans if s['id'] == 11 and s['tid'] == step['tid']
                    and step['end'] <= s['begin'] < end['end']]
            assert pubs and all(s['entry_value'] == by_actor[0]['request_pointer'] for s in pubs)
            nested = [s for s in spans if s['tid'] == step['tid'] and step['begin'] <= s['begin'] and s['end'] <= step['end']]
            record.update(overlapping_decode_step=step,
                          decode_overlap_with_EndRequest_ms=(min(step['end'], end['end']) - max(step['begin'], end['begin'])) / 1e6,
                          EndRequest_after_decode_return_ms=(end['end'] - step['end']) / 1e6,
                          survivor_publication_count=len(pubs),
                          survivor_actor=0,
                          mtp_forward_calls=sum(s['id'] == 5 for s in nested),
                          forward_host_ms=sum((s['end'] - s['begin']) / 1e6 for s in nested if s['id'] == 3))
        records.append(record)
result = dict(records=records, input_sha256=inputs,
              scope='Postprocessing existing B/C/B trace only. Same-host interval overlap and managed-request publication identity are measured. EndRequest call-mutex contention is inferred from source and overlap, not measured lock acquisition. EndRequest Send/API/network components are not separately timed. No timing flag waiver, new performance sample, or candidate-specific regression claim.')
(p / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
for record in records:
    print(record['phase'], record['actor'], record['final_content_to_HTTP_finish_ms'],
          record.get('decode_overlap_with_EndRequest_ms'), record.get('EndRequest_after_decode_return_ms'))
