# Completion tails in the existing PLE trace

This is offline analysis of `ple-owner-latency-trace-v1`, not a new acquisition
or performance sample. The original trace, reports, flags and frozen sources
remain unchanged. `analysis.json` pins every raw input hash, and the analyzer
checks the acquisition's harness hashes and clean cleanup before reading it.

## Directly measured

| Short C2 actor1 interval | Baseline before | PLE candidate | Baseline after |
| --- | ---: | ---: | ---: |
| Last content to HTTP finish, ms | 51.792245 | 52.220982 | 45.387196 |
| DecodeStep overlap with EndRequest, ms | 50.802974 | 51.325209 | 44.768534 |
| EndRequest return after DecodeStep return, ms | 0.029879 | 0.026039 | 0.038949 |
| Nested MtpForward calls | 4 | 4 | 3 |

In every arm, actor1 has finished publishing its content while actor0 is still
active. A different host thread is in `TpMirroredRunner::EndRequest` throughout
almost the entire remaining sibling decode. The scheduler then publishes that
decode's result to **actor0**, using its recorded managed-request identity.
EndRequest returns only 26–39 microseconds after DecodeStep returns. Actor0's own
last-content-to-HTTP-finish tails are 0.568 / 0.568 / 0.309 ms.

Thus, this observed roughly 50 ms tail coincides with useful sibling computation;
it is not an unexplained 50 ms interval with no model work. Nested Forward spans
are host enclosures containing GPU, synchronization and transport work, not pure
CPU or measured GPU times. The callback queue duration is not transfer latency.

## Source-supported interpretation

In the frozen source, `TpMirroredRunner::DecodeStep` takes `call_mutex_` for its
model call. `EndRequest` registers a pending request on `TpSnapshotGate` and
then takes that same recursive mutex before sending the end instruction.
The gate explicitly does not preempt a call already in progress. The observed
overlap and near-immediate EndRequest return after that call are consistent
with waiting for the one active sibling step. **Lock acquisition and the nested
Send were not directly instrumented**, so this is a strong inference rather
than a separately measured mutex-wait duration.

This does not reopen the earlier starvation fix: that fix prevents a pending
finalizer from losing repeatedly to subsequent calls. It cannot remove a call
that has already acquired the mutex. No Nagle/delayed-ACK diagnosis follows;
the source already requests TCP_NODELAY, and no packet timing is measured here.

This does not fully explain all nine completion-tail flags from the original
ten-pair study. Their individual traces were not collected. It demonstrates the
same broad tail in an unchanged baseline and the candidate on the preserved
first-five-request history. The original flags are retained, not waived.

## Remaining focused check and possible optimization

If more attribution is needed, add a bounded entry/return probe to
`TpControlInstructionSink::Send` inside EndRequest on this same request history.
That separates time before Send from send duration without another broad sweep.
It still must not be called a GPU or network breakdown.

A separate scheduler/finalization experiment could reserve end-instruction
ordering before launching the next sibling step. It must keep peer verdicts,
cache dependencies, cancellation and failure settlement intact. The potential
benefit is earlier completion of the short request; this trace does not predict
faster token generation or complete-wave throughput. It may only move work
between requests. Do not change the ready PLE path to hide a common tail without
measuring both per-request and complete-wave effects.

## Reproduce

From the investigation root, run `python3
tp-cache-retention/ple-owner-end-tail-analysis-v1/analyze.py` into a fresh output
directory (the script refuses to overwrite its completed report). The raw data
are already included in PR12's bounded-latency acquisition archive. No model,
GPU profiler, administrative sampler or new privileged operation is required.
