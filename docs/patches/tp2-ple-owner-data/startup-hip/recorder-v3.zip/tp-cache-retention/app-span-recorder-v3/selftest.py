"""Real recursive user calls and a wrong-PID child; no model/GPU/table I/O."""
from pathlib import Path
import ctypes
import json
import os
import runpy
import signal
import subprocess
import sys
import time

assert os.geteuid() == 0
base = Path(__file__).resolve().parent
root = base.parents[1]
rank = int(sys.argv[1])
assert rank in (0, 1)
out = base / f'selftest-r{rank}'
out.mkdir(exist_ok=False)
library = base / 'test-span.so'
symbols = [s.split() for s in subprocess.check_output(['nm', '-D', '--defined-only', str(library)], text=True).splitlines()]
matches = [int(s[0], 16) for s in symbols if len(s) == 3 and s[2] == 'span_probe']
assert len(matches) == 1
offset = runpy.run_path(str(base / 'elf-offset.py'))['offset'](library, matches[0])
handle = ctypes.CDLL(str(library))
handle.span_probe.argtypes = [ctypes.c_uint]
handle.span_probe.restype = ctypes.c_uint64
handle.span_args.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_int32]
handle.span_args.restype=ctypes.c_uint64
args_offset=runpy.run_path(str(base/'elf-offset.py'))['offset'](library,next(int(s[0],16)for s in symbols if len(s)==3 and s[2]=='span_args'))
fixture=ctypes.CDLL(str(base/'request-fixture.so'))
fixture.fixture_create.argtypes=[ctypes.c_uint64];fixture.fixture_create.restype=ctypes.c_void_p
fixture.fixture_data.argtypes=[ctypes.c_void_p];fixture.fixture_data.restype=ctypes.c_void_p
fixture.fixture_call.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_bool,ctypes.c_bool];fixture.fixture_call.restype=ctypes.c_uint64
fixture.fixture_destroy.argtypes=[ctypes.c_void_p]
flib=base/'request-fixture.so'
fsymbols=[s.split()for s in subprocess.check_output(['nm','-D','--defined-only',str(flib)],text=True).splitlines()]
faddr=next(int(s[0],16)for s in fsymbols if len(s)==3 and s[2]=='fixture_call')
foffset=runpy.run_path(str(base/'elf-offset.py'))['offset'](flib,faddr)
handles=[fixture.fixture_create(19),fixture.fixture_create(27)]
expected_pointers=[fixture.fixture_data(handles[i])for i in(0,1,0)]
assert expected_pointers[0]!=expected_pointers[1]
child = None
files = []
try:
    log = (out / 'app.csv').open('x')
    err = (out / 'app.stderr').open('x')
    files += [log, err]
    args = [str(base / 'record'), str(base / 'probes.bpf.o'), str(os.getpid()),
            str(out / 'stats.json'), '1', str(library), str(offset),'5',str(library),str(args_offset)]
    for ident in(9,10,11):args += [str(ident),str(flib),str(foffset)]
    (out / 'command.json').write_text(json.dumps(args)+'\n')
    child = subprocess.Popen(args, stdout=log, stderr=err)
    deadline = time.monotonic()+10
    while 'APP_READY' not in (out / 'app.csv').read_text().splitlines():
        assert child.poll() is None, (out / 'app.stderr').read_text()
        assert time.monotonic() < deadline
        time.sleep(.002)
    assert [handle.span_probe(x) for x in (0, 1, 3)] == [123, 124, 129]
    expected_args=[1,12884901890,8,18446744069414584321]
    assert [handle.span_args(None,None,None,n,h)for n,h in ((1,0),(2,3),(8,0),(1,-1))]==expected_args
    assert [fixture.fixture_call(None,handles[i],True,False)for i in(0,1,0)]==[20,28,20]
    code = 'import ctypes,sys;h=ctypes.CDLL(sys.argv[1]);h.span_probe.argtypes=[ctypes.c_uint];h.span_probe.restype=ctypes.c_uint64;assert h.span_probe(2)==126'
    subprocess.run([sys.executable, '-I', '-c', code, str(library)], check=True, timeout=10)
    child.send_signal(signal.SIGINT)
    child.wait(timeout=10)
    assert child.returncode == 0
    stats = json.loads((out / 'stats.json').read_text())
    assert stats['counters'][17] == stats['counters'][33] == 7
    assert stats['counters'][21]==stats['counters'][37]==4
    assert not any(stats['counters'][:5]) and not any(stats['program_recursion_misses'])
    assert stats['remaining_depth_keys'] == stats['remaining_span_keys'] == 0
    for ident in(9,10,11):assert stats['counters'][16+ident]==stats['counters'][32+ident]==3
    starts, ends, depth = {}, {}, []
    pointers={9:[],10:[],11:[]};pointer_returns={9:[],10:[],11:[]}
    arguments=[];returns=[]
    for line in (out / 'app.csv').read_text().splitlines():
        if not line.startswith('APP,'):
            continue
        k, ns, begin, tid, ident, d, cpu, pid, value = map(int, line.split(',')[1:])
        assert pid == os.getpid() and ident in (1,5,9,10,11)
        key = tid, ident, d, begin
        if k == 1:
            assert key not in starts
            starts[key] = ns
            depth.append(d)
            if ident==5:arguments.append(value)
            if ident in pointers:pointers[ident].append(value)
        else:
            assert k == 2 and key not in ends and key in starts
            assert ns >= starts[key] >= begin
            ends[key] = ns
            if ident==5:returns.append(value)
            if ident in pointer_returns:pointer_returns[ident].append(value)
    assert len(starts) == 20 and starts.keys() == ends.keys() and max(depth) == 4
    assert arguments==returns==expected_args,(arguments,returns)
    assert all(v==expected_pointers for v in pointers.values()),pointers
    assert all(v==[20,28,20]for v in pointer_returns.values()),pointer_returns
    report = dict(shared_ptr_managed_object_identity_fields_three_IDs_nine_spans=True,argument_spans=4,SysV_span_size_and_signed_hidden_row_verified=True,rank=rank, paired_recursive_spans=7, maximum_depth=4,
                  wrong_PID_excluded=True, zero_ring_map_or_program_recursion_loss=True,
                  remaining_maps_empty=True, collector_exit_code=child.returncode,
                  limitation='Independent uprobe kernel missed counter not exposed by this perf-link API. '
                             'No inference/GPU performance claim.')
    (out / 'validation.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
finally:
    if child is not None and child.poll() is None:
        child.send_signal(signal.SIGINT)
        child.wait(timeout=10)
    for handle in handles:fixture.fixture_destroy(handle)
    for f in files:
        f.close()
    uid, gid = root.stat().st_uid, root.stat().st_gid
    for path in out.rglob('*'):
        os.chown(path, uid, gid)
        if path.is_file():
            path.chmod(0o644)
    os.chown(out, uid, gid)
