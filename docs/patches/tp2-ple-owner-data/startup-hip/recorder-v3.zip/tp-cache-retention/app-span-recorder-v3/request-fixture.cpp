#include <cstdint>
#include <memory>
using Handle = std::shared_ptr<std::uint64_t>;
extern "C" void* fixture_create(std::uint64_t value) { return new Handle(std::make_shared<std::uint64_t>(value)); }
extern "C" void* fixture_data(void* handle) { return static_cast<Handle*>(handle)->get(); }
extern "C" __attribute__((noinline)) std::uint64_t fixture_call(void* self, const Handle& request, bool decode, bool peer) {
  (void)self;
  volatile std::uint64_t result = *request + decode + peer;
  return result;
}
extern "C" void fixture_destroy(void* handle) { delete static_cast<Handle*>(handle); }
