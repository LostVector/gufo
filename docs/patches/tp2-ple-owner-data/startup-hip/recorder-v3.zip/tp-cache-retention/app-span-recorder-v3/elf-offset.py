"""Resolve an ELF symbol virtual address to its actual LOAD-segment file offset."""
from pathlib import Path
import subprocess


def offset(path, address):
    candidates = []
    for line in subprocess.check_output(['readelf', '-lW', str(path)], text=True).splitlines():
        fields = line.split()
        if fields and fields[0] == 'LOAD':
            file_offset, vaddr, _, filesz = [int(x, 16) for x in fields[1:5]]
            if vaddr <= address < vaddr+filesz and 'E' in fields[6:-1]:
                candidates.append(address-vaddr+file_offset)
    assert len(candidates) == 1, (Path(path).name, address, candidates)
    return candidates[0]
