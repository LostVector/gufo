#include <linux/bpf.h>
#include <asm/ptrace.h>
#define SEC(x) __attribute__((section(x),used))
#define __uint(name,val) int (*name)[val]
#define __type(name,val) typeof(val) *name
static void*(*lookup)(void*,const void*)=(void*)BPF_FUNC_map_lookup_elem;
static long(*update)(void*,const void*,const void*,__u64)=(void*)BPF_FUNC_map_update_elem;
static long(*remove_key)(void*,const void*)=(void*)BPF_FUNC_map_delete_elem;
static __u64(*clock_ns)(void)=(void*)BPF_FUNC_ktime_get_ns;
static __u64(*pid_tid)(void)=(void*)BPF_FUNC_get_current_pid_tgid;
static __u32(*cpu_id)(void)=(void*)BPF_FUNC_get_smp_processor_id;
static long(*read_user)(void*,__u32,const void*)=(void*)BPF_FUNC_probe_read_user;
static __u64(*cookie)(void*)=(void*)BPF_FUNC_get_attach_cookie;
static void*(*reserve)(void*,__u64,__u64)=(void*)BPF_FUNC_ringbuf_reserve;
static void(*submit)(void*,__u64)=(void*)BPF_FUNC_ringbuf_submit;
struct key {__u32 tid,id;};
struct span_key {__u32 tid,id,depth,pad;};
struct event {__u64 ns,begin,value;__u32 kind,tid,id,depth,cpu,pid;};
struct {__uint(type,BPF_MAP_TYPE_ARRAY);__uint(max_entries,1);__type(key,__u32);__type(value,__u32);} config SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_ARRAY);__uint(max_entries,64);__type(key,__u32);__type(value,__u64);} stats SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_HASH);__uint(max_entries,16384);__type(key,struct key);__type(value,__u32);} depths SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_HASH);__uint(max_entries,65536);__type(key,struct span_key);__type(value,__u64);} spans SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_RINGBUF);__uint(max_entries,16777216);} events SEC(".maps");
static __inline void count(__u32 n){__u64* v=lookup(&stats,&n);if(v)__sync_fetch_and_add(v,1);}
static __inline void emit(__u32 kind,__u32 id,__u32 depth,__u64 begin,__u64 value){
 struct event* e=reserve(&events,sizeof(*e),0);if(!e){count(0);return;}
 __u64 p=pid_tid();e->ns=clock_ns();e->begin=begin;e->value=value;e->kind=kind;
 e->tid=(__u32)p;e->id=id;e->depth=depth;e->cpu=cpu_id();e->pid=p>>32;submit(e,0);
}
SEC("uprobe") int enter(struct pt_regs* ctx){
 __u32 z=0;__u32* target=lookup(&config,&z);if(!target||(pid_tid()>>32)!=*target)return 0;
 __u32 id=cookie(ctx);if(id<1||id>15){count(4);return 0;}
 struct key key={( __u32)pid_tid(),id};__u32* old=lookup(&depths,&key);__u32 depth=old?*old+1:1;
 if(depth>64){count(3);return 0;}
 __u64 begin=clock_ns();struct span_key sk={key.tid,id,depth,0};
 if(update(&depths,&key,&depth,BPF_ANY)||update(&spans,&sk,&begin,BPF_NOEXIST)){count(1);return 0;}
 count(16+id);
 // Entry-only fields: SysV x86-64 std::span size in RCX; hidden row in R8.
 __u64 value=0;
 if(id==5)value=(__u64)(__u32)ctx->rcx|((__u64)(__u32)ctx->r8<<32);
 else if(id==3)value=ctx->rcx;
 else if(id==9||id==10||id==11){
  // SysV x86-64: non-sret scheduler method(this, shared_ptr<Request>const&, ...).
  // libstdc++ shared_ptr first word is its managed object pointer. Opaque identity only.
  if(read_user(&value,sizeof(value),(const void*)ctx->rsi))count(1);
 }
 emit(1,id,depth,begin,value);return 0;
}
SEC("uretprobe") int leave(struct pt_regs* ctx){
 __u32 z=0;__u32* target=lookup(&config,&z);if(!target||(pid_tid()>>32)!=*target)return 0;
 __u32 id=cookie(ctx);if(id<1||id>15){count(4);return 0;}
 struct key key={( __u32)pid_tid(),id};__u32* old=lookup(&depths,&key);
 if(!old||!*old){count(2);return 0;}
 __u32 depth=*old;struct span_key sk={key.tid,id,depth,0};__u64* begin=lookup(&spans,&sk);
 if(!begin){count(1);return 0;}
 count(32+id);emit(2,id,depth,*begin,ctx->rax);remove_key(&spans,&sk);
 if(depth==1)remove_key(&depths,&key);else *old=depth-1;return 0;
}
char LICENSE[] SEC("license")="GPL";
