#include <stdint.h>
__attribute__((noinline)) uint64_t span_probe(unsigned depth) {
  volatile uint64_t answer = depth ? span_probe(depth-1)+depth : 123;
  return answer;
}

__attribute__((noinline)) uint64_t span_args(void* self, void* session, const int* data, uint64_t rows, int32_t hidden) {
 (void)self;(void)session;(void)data;
 volatile uint64_t result=(uint64_t)(uint32_t)hidden*UINT64_C(4294967296)+rows;
 return result;
}
