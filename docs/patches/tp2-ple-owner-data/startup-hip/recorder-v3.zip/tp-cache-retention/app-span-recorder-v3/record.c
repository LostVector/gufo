#include <bpf/libbpf.h>
#include <bpf/bpf.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct event {uint64_t ns,begin,value;uint32_t kind,tid,id,depth,cpu,pid;};
static volatile sig_atomic_t stop;
static void halt(int signal) {(void)signal;stop=1;}
static int consume(void* context,void* data,size_t size){
 (void)context;if(size!=sizeof(struct event))return -EINVAL;
 const struct event* e=data;
 printf("APP,%u,%llu,%llu,%u,%u,%u,%u,%u,%llu\n",e->kind,
  (unsigned long long)e->ns,(unsigned long long)e->begin,e->tid,e->id,e->depth,
  e->cpu,e->pid,(unsigned long long)e->value);return 0;
}
static int number(const char* text,unsigned long long* value){
 char* end=NULL;errno=0;*value=strtoull(text,&end,0);
 return errno||!*text||*end||*text=='-'?-1:0;
}
int main(int argc,char** argv){
 /* One explicit ID/path/ELF-file-offset triple per selected function. */
 if(argc<7||(argc-4)%3||argc>49)return 2;
 unsigned long long pid;if(number(argv[2],&pid)||pid<=1||pid>INT_MAX)return 2;
 struct bpf_object* object=bpf_object__open_file(argv[1],NULL);
 if(!object||libbpf_get_error(object))return 3;
 struct bpf_link* links[30]={0};struct ring_buffer* ring=NULL;int rc=4,n=0;
 if(bpf_object__load(object))goto cleanup;
 unsigned key=0,target=pid;
 if(bpf_map_update_elem(bpf_object__find_map_fd_by_name(object,"config"),&key,&target,BPF_ANY))goto cleanup;
 struct bpf_program* enter=bpf_object__find_program_by_name(object,"enter");
 struct bpf_program* leave=bpf_object__find_program_by_name(object,"leave");
 if(!enter||!leave)goto cleanup;
 for(int i=4;i<argc;i+=3){
  unsigned long long id,offset;
  if(number(argv[i],&id)||id<1||id>15||number(argv[i+2],&offset)){rc=2;goto cleanup;}
  /* Return first, entries second; readiness is emitted after all attach. */
  for(int ret=1;ret>=0;--ret){
   struct bpf_uprobe_opts opts={.sz=sizeof(opts),.bpf_cookie=id,.retprobe=ret,
    .attach_mode=PROBE_ATTACH_MODE_LINK};
   struct bpf_link* link=bpf_program__attach_uprobe_opts(ret?leave:enter,target,argv[i+1],offset,&opts);
   if(!link||libbpf_get_error(link)){rc=5;goto cleanup;}
   links[n++]=link;
  }
 }
 ring=ring_buffer__new(bpf_object__find_map_fd_by_name(object,"events"),consume,NULL,NULL);
 if(!ring){rc=6;goto cleanup;}
 signal(SIGINT,halt);signal(SIGTERM,halt);printf("APP_READY\n");fflush(stdout);rc=0;
 while(!stop){int result=ring_buffer__poll(ring,50);if(result<0&&result!=-EINTR){rc=6;break;}fflush(stdout);}
 for(int i=0;i<n;i++){bpf_link__destroy(links[i]);links[i]=NULL;}
 if(ring_buffer__consume(ring)<0)rc=6;
 fflush(stdout);
 FILE* out=fopen(argv[3],"wx");if(!out){rc=7;goto cleanup;}
 fprintf(out,"{\"record_exit_code\":%d,\"counters\":[",rc);
 int stats=bpf_object__find_map_fd_by_name(object,"stats");
 for(unsigned k=0;k<64;k++){
  unsigned long long value=0;if(bpf_map_lookup_elem(stats,&k,&value)){fclose(out);rc=8;goto cleanup;}
  fprintf(out,"%s%llu",k?",":"",value);
 }
 fprintf(out,"],\"program_recursion_misses\":[");
 struct bpf_program* programs[]={enter,leave};
 for(int i=0;i<2;i++){
  struct bpf_prog_info info={0};__u32 size=sizeof(info);
  if(bpf_obj_get_info_by_fd(bpf_program__fd(programs[i]),&info,&size)){fclose(out);rc=9;goto cleanup;}
  fprintf(out,"%s%llu",i?",":"",(unsigned long long)info.recursion_misses);
 }
 /* Map cardinality after detach records incomplete spans, not assumed empty. */
 unsigned remaining[2]={0};const char* maps[]={"depths","spans"};
 for(int i=0;i<2;i++){
  unsigned char current[16]={0},next[16]={0};void* previous=NULL;
  int fd=bpf_object__find_map_fd_by_name(object,maps[i]);
  while(!bpf_map_get_next_key(fd,previous,next)){remaining[i]++;for(int k=0;k<16;k++)current[k]=next[k];previous=current;}
  if(errno!=ENOENT){fclose(out);rc=10;goto cleanup;}
 }
 fprintf(out,"],\"remaining_depth_keys\":%u,\"remaining_span_keys\":%u}\n",remaining[0],remaining[1]);
 if(fclose(out))rc=11;
cleanup:
 if(ring)ring_buffer__free(ring);
 for(int i=0;i<n;i++)bpf_link__destroy(links[i]);
 bpf_object__close(object);return rc;
}
