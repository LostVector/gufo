"""Partition first-request Forward host spans using same-thread HIP API calls."""
import ast
import collections
import csv
import hashlib
import json
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
assert (p / 'validation.json').exists()
assert json.loads((p / 'cleanup.json').read_text())['errors'] == []
protocol = json.loads((p / 'protocol.json').read_text())
for name, digest in protocol['harness_sha256'].items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, name
library = json.loads((p / 'hip-library.json').read_text())
tree = ast.parse((p / 'analyze.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'read_spans')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(p / 'analyze.py'), 'exec'))

def union_ns(intervals):
    total = 0
    end = -1
    for lo, hi in sorted(intervals):
        assert hi >= lo
        total += max(0, hi - max(lo, end))
        end = max(end, hi)
    return total

def aggregate(spans, tags):
    result = {}
    for ident, name in tags.items():
        selected = [s for s in spans if s['id'] == ident]
        if selected:
            times = [(s['end'] - s['begin']) / 1e6 for s in selected]
            result[name] = dict(calls=len(selected), sum_host_ms=sum(times),
                                max_host_ms=max(times),
                                nonzero_returns=dict(collections.Counter(str(s['value'] & 0xffffffff)
                                                                       for s in selected if s['value'] & 0xffffffff)))
    return result

report = dict(phases=[], library=library, input_sha256={},
              scope='Same-thread host intervals inside the first request Forward. API unions avoid nested double counting; per-API sums may overlap. Waits can contain useful GPU/peer/transport work, and outside-probed-API time can include untraced CPU launch work and asynchronous GPU execution. Neither is a GPU busy/idle split or an avoidable-overhead estimate. Uprobes perturb API wall durations. No cross-host clock alignment, kernel-launch-count claim or new unprofiled throughput claim. All original flags remain.')
api_rows = []
for phase, role in protocol['sequence']:
    tags = {f['id']: f['tag'] for f in json.loads((p / 'probes.json').read_text())[role]['functions']}
    api_tags = {ident: name for ident, name in tags.items() if name.startswith('hip')}
    all_spans = []
    per_rank = []
    for rank in (0, 1):
        folder = p / phase / f'trace-r{rank}'
        mapped = json.loads((folder / 'hip-library-map.json').read_text())
        assert mapped['library'] == library and mapped['maps']
        spans = read_spans(folder)
        all_spans.append(spans)
        per_rank.append(aggregate(spans, api_tags))
        path = folder / 'app.csv'
        report['input_sha256'][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        for span in spans:
            if span['id'] in api_tags:
                api_rows.append(dict(phase=phase, rank=rank, api=api_tags[span['id']],
                                     tid=span['tid'], begin_ns=span['begin'], end_ns=span['end'],
                                     host_ms=(span['end'] - span['begin']) / 1e6,
                                     return_code=span['value'] & 0xffffffff))
    raw = root / 'results/model-scaling' / f'{p.name}-{phase}.jsonl'
    rows = [json.loads(s) for s in raw.read_text().splitlines()]
    assert len(rows) == 5 and rows[0]['case'] == 'warmup'
    report['input_sha256'][str(raw.relative_to(root))] = hashlib.sha256(raw.read_bytes()).hexdigest()
    row = rows[0]
    lo, hi = round(row['started_at'] * 1e9), round(row['finished_at'] * 1e9)
    head = all_spans[0]
    pre = [s for s in head if s['id'] == 9 and lo <= s['begin'] and s['end'] <= hi]
    assert len({s['entry_value'] for s in pre}) == 1
    forwards = [s for s in head if s['id'] == 3 and any(q['tid'] == s['tid'] and q['begin'] <= s['begin'] and s['end'] <= q['end'] for q in pre)]
    assert forwards and sum(s['entry_value'] for s in forwards) == row['prompt_tokens']
    frames = []
    for frame in forwards:
        inside = [s for s in head if s['id'] in api_tags and s['tid'] == frame['tid']
                  and frame['begin'] <= s['begin'] and s['end'] <= frame['end']]
        total = frame['end'] - frame['begin']
        covered = union_ns([(s['begin'], s['end']) for s in inside])
        assert covered <= total
        frames.append(dict(forward=frame, token_rows=frame['entry_value'],
                           host_ms=total / 1e6, HIP_API_union_ms=covered / 1e6,
                           outside_probed_HIP_APIs_ms=(total - covered) / 1e6,
                           APIs=aggregate(inside, api_tags)))
    report['phases'].append(dict(phase=phase, role=role, warmup_TTFT_ms=row['client_ttft_ms'],
                                 first_request_forwards=frames, full_trace_HIP_APIs_per_rank=per_rank))
(p / 'hip-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
with (p / 'hip-api-spans.csv').open('w') as file:
    writer = csv.DictWriter(file, fieldnames=list(api_rows[0]))
    writer.writeheader()
    writer.writerows(api_rows)
for phase in report['phases']:
    print(phase['phase'], 'TTFT', phase['warmup_TTFT_ms'])
    for frame in phase['first_request_forwards']:
        print('rows', frame['token_rows'], 'wall', frame['host_ms'],
              'api-union', frame['HIP_API_union_ms'], 'outside', frame['outside_probed_HIP_APIs_ms'], frame['APIs'])
