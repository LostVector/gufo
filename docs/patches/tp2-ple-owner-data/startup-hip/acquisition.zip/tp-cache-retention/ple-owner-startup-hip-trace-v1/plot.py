from pathlib import Path
import json
import matplotlib.pyplot as plt

p = Path(__file__).resolve().parent
data = json.loads((p / 'hip-analysis.json').read_text())
frames = [phase['first_request_forwards'][0] for phase in data['phases']]
labels = ['Baseline before', 'PLE candidate', 'Baseline after']
fig, ax = plt.subplots(figsize=(8.4, 5.1))
bottom = [0., 0., 0.]
for name, label, color in [
    ('hipEventSynchronize', 'Event wait API', '#3978a8'),
    ('hipStreamSynchronize', 'Stream wait API', '#66b0b6'),
    ('hipMemcpyAsync', 'Copy enqueue API', '#e9b44c'),
    (None, 'Outside probed HIP APIs', '#aeb6bf'),
]:
    values = [f['APIs'][name]['sum_host_ms'] if name else f['outside_probed_HIP_APIs_ms'] for f in frames]
    ax.bar(labels, values, bottom=bottom, label=label, color=color, width=.6)
    bottom = [a + b for a, b in zip(bottom, values)]
for i, frame in enumerate(frames):
    assert abs(bottom[i] - frame['host_ms']) < 1e-8
    ax.text(i, bottom[i] + 1.4, f"{frame['host_ms']:.2f} ms", ha='center', fontsize=10)
ax.set_ylim(0, 126)
ax.set_ylabel('First 12-row Forward host span (ms)')
ax.set_title('Startup high mode occurs inside an event wait')
ax.spines[['top', 'right']].set_visible(False)
ax.grid(axis='y', alpha=.2)
ax.set_axisbelow(True)
ax.legend(loc='upper center', bbox_to_anchor=(.5, -.13), ncol=2, frameon=False)
fig.text(.5, .018, 'Host intervals; waits include GPU/peer progress. Not a GPU busy/idle split.',
         ha='center', fontsize=9)
fig.subplots_adjust(left=.11, right=.97, top=.88, bottom=.26)
fig.savefig(p / 'first-forward-host-partition.png', dpi=180)
fig.savefig(p / 'first-forward-host-partition.pdf')
