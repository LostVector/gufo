"""Bounded root application-only spans, prearmed with no probes until activated."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import select
import signal
import subprocess
import sys
import tempfile
import time

assert os.geteuid()==0
root=Path('/home/rkuo/strix-dispatch-investigation');base=Path(__file__).resolve().parent
rank,pid,relative,phase=int(sys.argv[1]),int(sys.argv[2]),sys.argv[3],sys.argv[4]
assert rank in(0,1)and phase in('baseline','candidate')and pid>1
out=(root/relative).resolve();assert out.is_relative_to(base)and out.is_dir()and not(out/'status.json').exists()
app=root/'tp-cache-retention/app-span-recorder-v5';entry=json.loads((base/'binaries.json').read_text())[phase]
meta=json.loads((base/'probes.json').read_text())[phase];child=None;status={'returncode':1};proc=Path('/proc')/str(pid)
uid,gid=root.stat().st_uid,root.stat().st_gid

def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def wait_file(name,seconds):
    libc=ctypes.CDLL(None,use_errno=True);libc.inotify_init1.argtypes=[ctypes.c_int];libc.inotify_init1.restype=ctypes.c_int
    libc.inotify_add_watch.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_uint32];libc.inotify_add_watch.restype=ctypes.c_int
    notify=libc.inotify_init1(os.O_CLOEXEC|os.O_NONBLOCK);assert notify>=0
    descriptors=[notify]
    try:
        assert libc.inotify_add_watch(notify,os.fsencode(out),0x100|0x80|0x08|0x04)>=0
        target=os.pidfd_open(pid);descriptors.append(target)
        observed=os.pidfd_open(child.pid)if child is not None else None
        if observed is not None:descriptors.append(observed)
        deadline=time.monotonic()+seconds
        while True:
            if(out/name).exists():return True
            if(out/'capture.stop').exists():return False
            remaining=deadline-time.monotonic();assert remaining>0,name+' timeout'
            available,_,_=select.select(descriptors,[],[],remaining)
            if observed is not None and observed in available:raise RuntimeError('app recorder exited '+str(child.poll()))
            if target in available:return False
            if notify in available:
                while True:
                    try:os.read(notify,65536)
                    except BlockingIOError:break
    finally:
        for fd in descriptors:os.close(fd)
try:
    for name,expected in json.loads((app/'build-info.json').read_text())['files_sha256'].items():
        assert hashlib.sha256((app/name).read_bytes()).hexdigest()==expected,name
    expected=root/'instrumentation/bin'/entry['name'];deadline=time.monotonic()+20
    while True:
        assert time.monotonic()<deadline and proc.exists()
        if(proc/'exe').resolve()==expected:break
        time.sleep(.02)
    assert hashlib.sha256(expected.read_bytes()).hexdigest()==entry['sha256']
    ticks=(proc/'stat').read_text().rsplit(')',1)[1].split()[19]
    save('target.json',{'pid':pid,'start_ticks':ticks,'exe_sha256':entry['sha256'],'rank':rank,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    (out/'armed.ready').write_text(str(time.monotonic_ns())+'\n')
    if not wait_file('capture.start',600):
        status={'returncode':0,'triggered':False}
    else:
        assert(proc/'exe').resolve()==expected and(proc/'stat').read_text().rsplit(')',1)[1].split()[19]==ticks
        with tempfile.TemporaryDirectory(prefix=f'strix-app-{rank}-{pid}-',dir='/dev/shm')as tmp:
            tmp=Path(tmp);args=[str(app/'record'),str(app/'probes.bpf.o'),str(pid),str(tmp/'stats.json'),str(meta['session_stats_offset'])]
            for f in meta['functions']:args += [str(f['id']),f['path'],str(f['file_offset'])]
            save('record-command.json',args)
            with(tmp/'app.csv').open('x')as log,(tmp/'app.stderr').open('x')as error:
                child=subprocess.Popen(args,stdout=log,stderr=error)
                save('collector-process.json',{'pid':child.pid});save('app-collector-process.json',{'pid':child.pid})
                try:
                    deadline=time.monotonic()+20
                    while 'APP_READY'not in(tmp/'app.csv').read_text().splitlines():
                        assert child.poll()is None and time.monotonic()<deadline
                        time.sleep(.002)
                    (out/'trace.ready').write_text(str(time.monotonic_ns())+'\n')
                    wait_file('capture.stop',600)
                finally:
                    if child.poll()is None:child.send_signal(signal.SIGINT)
                    child.wait(timeout=15)
            for name in ('app.csv','app.stderr','stats.json'):
                if(tmp/name).exists():(out/name).write_bytes((tmp/name).read_bytes())
            stats=json.loads((out/'stats.json').read_text());c=stats['counters']
            coverage=not any(c[:6])and c[6]==c[7]==c[30]==c[46]and c[8]==c[24]==c[40]and stats['remaining_object_keys']==0 and not any(stats['program_recursion_misses'])and stats['remaining_depth_keys']==stats['remaining_span_keys']==0 and all(c[16+i]==c[32+i]for i in range(1,16))
            status={'returncode':child.returncode,'app_collector_exit_code':child.returncode,'app_coverage_complete':coverage,'triggered':True,'stats':stats,'scope':'Application spans only; no native NVMe events. Kernel uprobe missed counter independently unavailable.'}
except BaseException as ex:
    status={'returncode':1,'error':repr(ex)}
    raise
finally:
    if child is not None and child.poll()is None:
        child.send_signal(signal.SIGINT);child.wait(timeout=15)
    save('status.json',status)
    (out/'capture.complete').write_text(str(time.monotonic_ns())+'\n')
    for p in out.rglob('*'):
        os.chown(p,uid,gid)
        if p.is_file():p.chmod(0o644)
    os.chown(out,uid,gid)
