from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;d=json.loads((p/'round-analysis.json').read_text());actors=[a['actors'][1]for a in d['phases']];fig,ax=plt.subplots(figsize=(9,5))
labels=['Baseline before','PLE candidate','Baseline after'];bottom=[0.0]*3
for key,label,color in [('prefill','Peer prefill host span','#e6a04b'),('scalar_other_requests','Other scalar decode host span','#6bad83'),('batch_including_request','Shared TP batch-engine host span','#5479ad'),('unclassified_host_interval','Outside these spans','#999999')]:
 values=[a['host_partition_ms'].get(key,0)for a in actors];ax.bar(labels,values,bottom=bottom,label=label,color=color);bottom=[a+b for a,b in zip(bottom,values)]
for i,a in enumerate(actors):ax.text(i,bottom[i]+12,f"{a['engine_completion_calls']} batch steps\n{a['cycles']} speculative + {a['plain_completion_calls']} plain",ha='center',fontsize=9)
ax.set(ylabel='Milliseconds between first and last publication attempts',title='33-token reply: additional time is inside additional batch passes',ylim=(0,1450));fig.legend(*ax.get_legend_handles_labels(),loc='lower center',ncol=2,fontsize=8);ax.grid(axis='y',alpha=.2);fig.tight_layout(rect=[0,.12,1,1]);fig.savefig(p/'host-partition.png',dpi=150);fig.savefig(p/'host-partition.pdf')
