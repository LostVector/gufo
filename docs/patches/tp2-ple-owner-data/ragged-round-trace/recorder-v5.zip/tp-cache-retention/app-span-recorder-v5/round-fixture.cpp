#include "src/models/qwen38_flash_next/engine.hpp"
#include <cstddef>
#include <cstdint>
#include <type_traits>
using Stats = gufo::models::qwen38_flash_next::Session::SpeculativeStats;
static_assert(std::is_standard_layout_v<Stats> && sizeof(Stats) == 48);
static_assert(offsetof(Stats, cycles) == 0 && offsetof(Stats, drafted) == 8 && offsetof(Stats, accepted) == 16);
struct Fixture { std::uint64_t prefix[2]{}; Stats stats; };
static_assert(offsetof(Fixture, stats) == 16);
extern "C" void* round_create() { return new Fixture; }
extern "C" void round_destroy(void* p) { delete static_cast<Fixture*>(p); }
extern "C" __attribute__((noinline)) bool round_sync(void* p) { return p != nullptr; }
extern "C" __attribute__((noinline)) bool round_finish(void* p, unsigned drafts, unsigned accepted, bool speculative, unsigned depth) {
  auto* f = static_cast<Fixture*>(p);
  if (depth) { if (!round_finish(p, drafts, accepted, speculative, depth-1)) return false; }
  if (speculative) { ++f->stats.cycles; f->stats.drafted += drafts; f->stats.accepted += accepted; }
  asm volatile("" : : "r"(p) : "memory"); return true;
}
extern "C" __attribute__((noinline)) bool round_bad(void*) { return true; }
