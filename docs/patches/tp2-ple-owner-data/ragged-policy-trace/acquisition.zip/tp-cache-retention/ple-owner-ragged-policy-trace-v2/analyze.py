"""Validate exact controls/observed widths and retain every phase regression."""
from pathlib import Path
import json,hashlib,re,csv,math,shlex,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'complete').exists();assert not json.loads((p/'cleanup.json').read_text())['errors']
for n,h in proto['harness_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
for n,h in proto['external_harness_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
for folder,manifest in proto['collector_build_manifests'].items():
 for n,h in manifest['files_sha256'].items():assert hashlib.sha256((root/folder/n).read_bytes()).hexdigest()==h
for phase,_ in proto['sequence']:
 for rank in(0,1):
  folder=p/phase/f'trace-r{rank}';s=json.loads((folder/'status.json').read_text());assert s['app_collector_exit_code']==0 and s['app_coverage_complete']
  stats=s['stats'];assert stats['counters'][9]==0 and stats['counters'][10]==stats['counters'][23]==stats['counters'][39]and not any(stats['counters'][:6])and stats['counters'][6]==stats['counters'][7]==stats['counters'][30]==stats['counters'][46]and stats['remaining_object_keys']==0 and not any(stats['program_recursion_misses'])and stats['remaining_span_keys']==stats['remaining_depth_keys']==0
raw={};reports=[];errors={};flags=[];work=[];ids=None
identity=('case','order','max_tokens','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256')
for phase,role in proto['sequence']:
 rows=sorted([json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()],key=lambda r:r['order']);assert len(rows)==20 and [r['order']for r in rows]==list(range(20));raw[phase]=rows
 current=[{k:r[k]for k in identity}for r in rows]
 if ids is None:ids=current
 assert ids==current,(phase,'across-arm identity mismatch')
 assert all(r['draft_tokens']>0 and r['cached_prompt_tokens']==0 and r['prefill_tokens']==r['prompt_tokens']for r in rows)
 controls={(r['request_index'],r['max_tokens']):r for r in rows if r['case']in('solo','solo-ragged')};assert len(controls)==7
 for row in rows:
  if row['case']=='warmup':continue
  other=controls[row['request_index'],row['max_tokens']]
  assert all(row[k]==other[k]for k in('prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256')),(phase,row['case'],row['request_index'],'solo output mismatch')
 waves=[]
 for case,width in [('C3',3),('C4',4),('ragged-C4',4)]:
  group=sorted([r for r in rows if r['case']==case],key=lambda r:r['request_index']);assert len(group)==width
  admissions=[r['raw_gufo']['resident_requests_at_admission']for r in group];assert admissions==list(range(1,width+1)),(phase,case,admissions)
  widths=[r['physical_execution_width']for r in group];assert max(widths)>=width,(phase,case,widths)
  assert all(r['requested_logical_concurrency']>=1 for r in group)
  waves.append(dict(case=case,admissions=admissions,observed_max_physical_widths=widths,client_wave_tok_s=sum(r['completion_tokens']for r in group)/(max(r['finished_at']for r in group)-min(r['started_at']for r in group))))
 for rank in(0,1):
  def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items())
  delta={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};errors[f'{phase}/rank{rank}']=delta;assert not delta,delta
  ident=json.loads((p/f'{p.name}-{phase}-identity-r{rank}.json').read_text());assert ident['binary_sha256']==proto['binaries'][role]['sha256']and ident['SDK_trace_absent']and ident['read_observer_absent']
  for k,v in {'--context':'65536','--sessions':'4','--prefill-chunk':'2048','--cache-ram-bytes':'1073741824','--speculative':'mtp','--tp-world-size':'2','--tp-rank':str(rank),'--think':'off','--tp-rdma-device':'usb4_rdma0'}.items():assert ident['selected_safe_options'][k]==v
  code="from pathlib import Path;import sys;assert not Path('/proc',sys.argv[1]).exists()";args=['python3','-c',code,str(ident['pid'])]
  if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
  subprocess.run(args,check=True,timeout=15)
 reports.append(dict(phase=phase,waves=waves))
for rank in(0,1):
 final=json.loads((p/f'final-inventory-r{rank}.json').read_text());assert final['module']=='81C6FF2FBAC473C7AB21844'and final['refcnt']==0 and len(final['devices'])==4 and all(final[k]==proto['initial'][rank][k]for k in('boot_id','cmdline','routers'))
 assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout|amdgpu.*reset|segfault',(p/f'kernel-window-r{rank}.txt').read_text(),re.I)
for control in('before-baseline','after-baseline'):
 for a,b in zip(raw[control],raw['first-candidate']):
  ident=dict(control=control,case=a['case'],actor=a['request_index'],order=a['order'])
  for k in('draft_tokens','draft_accepted_tokens','physical_execution_width'):
   if a[k]!=b[k]:work.append(ident|dict(metric=k,baseline=a[k],candidate=b[k]))
  if a['raw_gufo']['draft_rounds']!=b['raw_gufo']['draft_rounds']:work.append(ident|dict(metric='raw.draft_rounds',baseline=a['raw_gufo']['draft_rounds'],candidate=b['raw_gufo']['draft_rounds']))
  values={k:(v,b[k])for k,v in a.items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b.get(k),(int,float))}
  values.update({'raw.'+k:(v,b['raw_gufo'][k])for k,v in a['raw_gufo'].items()if k.endswith('_ms')and isinstance(v,(int,float))and isinstance(b['raw_gufo'].get(k),(int,float))})
  for k,(av,bv)in values.items():
   assert math.isfinite(av)and math.isfinite(bv)
   if bv-av>3 and bv>1.05*av:flags.append(ident|dict(metric=k,baseline_ms=av,candidate_ms=bv,delta_ms=bv-av))
report=dict(functional_qualification_pass=True,canonical_records=60,exact_vs_matching_solo_controls=True,actual_MTP_no_prompt_cache=True,settings_frozen_harness_binary_PIDs_boot_topology_kernel_final_idle_pass=True,checked_transport_error_deltas=errors,waves=reports,strict_phase_flags=flags,adaptive_work_fields=work,timing_qualified=not flags,scope='One fixed application-traced B/C/B four-session qualification; not statistical/equivalence/isolated PLE gain. Maximum width metrics do not expose every batch transition; ragged requests have staggered limits. Baselinefbacf9cc vs combined production2669e07c. All timing flags retained, not waived by exact outputs or throughput.')
(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
for n,records in [('phase-flags.csv',flags),('adaptive-work.csv',work)]:
 with(p/n).open('w')as f:w=csv.DictWriter(f,fieldnames=list(records[0])if records else['no_rows']);w.writeheader();w.writerows(records)
print(json.dumps({'canonical_records':60,'functional_pass':True,'strict_flag_entries':len(flags),'adaptive_work_fields':len(work),'waves':reports},indent=2))
