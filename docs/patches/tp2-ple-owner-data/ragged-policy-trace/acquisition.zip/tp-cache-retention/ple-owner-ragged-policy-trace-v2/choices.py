"""Replay every real batch choice and isolate captured input groups offline."""
from pathlib import Path
import collections,ctypes,csv,hashlib,json,struct
p=Path(__file__).resolve().parent;root=p.parents[1];assert(p/'validation.json').exists()and(p/'round-analysis.json').exists();proto=json.loads((p/'protocol.json').read_text());rounds=json.loads((p/'round-analysis.json').read_text());work=list(csv.DictReader((p/'rounds.csv').open()));collector=root/'tp-cache-retention/app-span-recorder-v6'
manifest=json.loads((collector/'build-info.json').read_text())
for n,h in manifest['files_sha256'].items():assert hashlib.sha256((collector/n).read_bytes()).hexdigest()==h,n
lib=ctypes.CDLL(str(collector/'choice-fixture.so'));lib.choice_replay.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint,ctypes.c_uint];lib.choice_replay.restype=ctypes.c_uint

def pack_replay(s,donor=None,mode='original'):
 ms=list(s['ms_bits']);samples=list(s['samples']);cycles=s['cycles'];last=s['last_drafts'];tail=list(s['tail']);policies=[list(r['policy'])for r in s['rows']]
 if donor is not None:
  assert s['count']==donor['count']and s['bin']==donor['bin']
  if mode in('ms','costs','all'):ms=list(donor['ms_bits'])
  if mode in('samples','costs','all'):samples=list(donor['samples'])
  if mode in('schedule','all'):cycles=donor['cycles'];last=donor['last_drafts'];tail=list(donor['tail'])
  if mode in('acceptance','all'):
   by_actor={r['actor']:r['policy']for r in donor['rows']};assert set(by_actor)=={r['actor']for r in s['rows']};policies=[list(by_actor[r['actor']])for r in s['rows']]
 raw=bytearray(5136);offset=((s['count']-1)*8+s['bin'])*80;raw[offset:offset+80]=struct.pack('<16IQII',*ms,*samples,cycles,last,0);raw[5120:]=struct.pack('<QII',*tail)
 flat=[]
 for row,policy in zip(s['rows'],policies):flat+=policy+[row['budget']]
 blob=(ctypes.c_uint8*5136).from_buffer_copy(raw);states=(ctypes.c_uint32*len(flat))(*flat);return lib.choice_replay(blob,states,s['count'],s['context'])

def branch(s):
 cap=min([7]+[r['budget']for r in s['rows']]);stable=s['tail'][0]==s['count']and s['tail'][1]==s['bin']and s['tail'][2]>=2
 if cap==0:return 'budget-zero'
 if stable and(s['samples'][0]==0 or s['cycles']%32<2):return 'headless-calibration'
 if stable and s['samples'][0]!=0 and s['samples'][1]<2:return 'qualify-one-draft'
 if s['cycles']%16==2:return 'explore'
 if stable and s['cycles']%16 in(3,4)and s['last_drafts']!=0 and s['samples'][s['last_drafts']]<2:return 'hold-probe'
 return 'cost-score'

all_choices=[];phases=[];peer_counts={}
for phase,role in proto['sequence']:
 data=next(x for x in rounds['phases']if x['phase']==phase);session_actor={x['session']:x['actor']for x in data['actors']};rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines()];wave_lo=round(min(r['started_at']for r in rows if r['case']=='ragged-C4')*1e9)
 start={};spans={};choices=[]
 for line in(p/phase/'trace-r0/app.csv').read_text().splitlines():
  if line.startswith('APP,'):
   x=dict(zip(('kind','end','begin','tid','id','depth','cpu','pid','value'),map(int,line.split(',')[1:])));key=tuple(x[k]for k in('tid','id','depth','begin'))
   if x['kind']==1:assert key not in start;start[key]=x
   else:assert x['kind']==2 and key in start and key not in spans;x['entry_value']=start[key]['value'];spans[key]=x
  elif line.startswith('CHOICE,'):
   v=list(map(int,line.split(',')[1:]));assert v[0]==6 and v[4]==7 and len(v)==33+23*v[9];choices.append((tuple(v[k]for k in(3,4,5,2)),v))
 assert start.keys()==spans.keys();batches=[x for x in spans.values()if x['id']==12];assert len(choices)==len(batches)>0
 parsed=[]
 for key,v in choices:
  event=spans[key];assert event['id']==7;parent=[x for x in batches if x['tid']==event['tid']and x['begin']<=event['begin']and event['end']<=x['end']];assert len(parent)==1;parent=parent[0];payload=v[8:]
  s=dict(phase=phase,object=payload[0],count=payload[1],context=payload[2],bin=payload[3],ms_bits=payload[4:12],samples=payload[12:20],cycles=payload[20],last_drafts=payload[21],tail=payload[22:25],rows=[],selected=event['value']&0xffffffff,begin_ns=event['begin'],batch_begin_ns=parent['begin'],batch_begin_ms=(parent['begin']-wave_lo)/1e6)
  for i in range(s['count']):
   raw=payload[25+i*23:25+(i+1)*23];session=raw[0]-108;assert session in session_actor;s['rows'].append(dict(object=raw[0],actor=session_actor[session],budget=raw[1],policy=raw[2:]))
  members=[x for x in work if x['phase']==phase and x['batch_begin']==str(parent['begin'])];assert {int(x['actor'])for x in members}=={r['actor']for r in s['rows']}
  assert s['selected']<=min([7]+[r['budget']for r in s['rows']])
  s['ms']=[struct.unpack('<f',struct.pack('<I',x))[0]for x in s['ms_bits']];s['replayed']=pack_replay(s);assert s['replayed']==s['selected'],(phase,s)
  s['branch']=branch(s);s['actual_members']=[{k:int(x[k])for k in('actor','cycles','drafted','accepted')}for x in members];parsed.append(s);all_choices.append(s)
 assert len({x['object']for x in parsed})==1
 peer_counts[phase]=sum(line.startswith('CHOICE,')for line in(p/phase/'trace-r1/app.csv').read_text().splitlines())
 phases.append(dict(phase=phase,choices=len(parsed),selected_counts=dict(collections.Counter(x['selected']for x in parsed)),branch_counts=dict(collections.Counter(x['branch']for x in parsed)),first=parsed[0]))
comparisons=[]
for destination in phases:
 for donor in phases:
  if destination['phase']==donor['phase']:continue
  a,b=destination['first'],donor['first']
  if a['count']!=b['count']or a['bin']!=b['bin']or {r['actor']for r in a['rows']}!={r['actor']for r in b['rows']}:continue
  comparisons.append(dict(own=destination['phase'],donor=donor['phase'],own_selected=a['selected'],donor_selected=b['selected'],own_context=a['context'],donor_context=b['context'],own_budgets=[r['budget']for r in a['rows']],donor_budgets=[r['budget']for r in b['rows']],replayed_swaps={mode:pack_replay(a,b,mode)for mode in ['ms','samples','costs','schedule','acceptance','all']}))
report=dict(all_actual_choices_replayed_exactly=True,choice_count=len(all_choices),peer_choice_counts=peer_counts,phases=phases,first_choice_input_swaps=comparisons,scope='Recorded real planner inputs plus actual uint32 return, exact header C++ CPU replay; input-group swaps are offline decision counterfactuals, not inference performance results. Rows map via exact Session acceptance offset108, then Sync/StepPrefill identity. No crosshost clocks or order-only attribution. Every captured choice retained; no performance significance or phase-flag waiver.')
(p/'choices.json').write_text(json.dumps(all_choices,indent=2)+'\n');(p/'choice-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
