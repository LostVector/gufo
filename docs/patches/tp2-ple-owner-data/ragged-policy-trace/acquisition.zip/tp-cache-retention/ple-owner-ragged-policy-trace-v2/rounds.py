"""Actual per-Session counters joined to head scheduler request identity."""
from pathlib import Path
import json,csv,collections,math
p=Path(__file__).resolve().parent;root=p.parents[1];proto=json.loads((p/'protocol.json').read_text());assert(p/'validation.json').exists();reports=[];round_rows=[]
def parse(folder):
 starts={};ends={};details=[]
 for line in(folder/'app.csv').read_text().splitlines():
  if line.startswith('APP,'):
   values=list(map(int,line.split(',')[1:]));x=dict(zip(('kind','end','begin','tid','id','depth','cpu','pid','value'),values));key=tuple(x[k]for k in('tid','id','depth','begin'))
   if x['kind']==1:assert key not in starts;starts[key]=x
   else:assert x['kind']==2 and key in starts and key not in ends;x['entry_value']=starts[key]['value'];ends[key]=x
  elif line.startswith('DETAIL,'):
   x=dict(zip(('kind','ns','begin','tid','id','depth','cpu','pid','object','cycles','drafted','accepted'),map(int,line.split(',')[1:])));details.append(x)
 assert starts.keys()==ends.keys()
 return sorted(ends.values(),key=lambda x:x['begin']),details,ends

def contains(a,b):return a['tid']==b['tid']and a['begin']<=b['begin']and b.get('end',b['begin'])<=a['end']
for phase,_ in proto['sequence']:
 rows=sorted([r for r in map(json.loads,(root/'results/model-scaling'/f'{p.name}-{phase}.jsonl').read_text().splitlines())if r['case']=='ragged-C4'],key=lambda r:r['request_index']);assert len(rows)==4
 spans,details,bykey=parse(p/phase/'trace-r0');prefill=[x for x in spans if x['id']==9];tids={x['tid']for x in prefill};assert len(tids)==1;tid=next(iter(tids))
 ptrs=list(dict.fromkeys(x['entry_value']for x in prefill));assert len(ptrs)==4 and all(ptrs);ptr_actor={ptr:i for i,ptr in enumerate(ptrs)}
 sessions={}
 for x in details:
  if x['kind']!=5:continue
  assert x['id']==8 and x['object'];parent=[a for a in prefill if contains(a,x)];assert len(parent)==1
  ptr=parent[0]['entry_value'];previous=sessions.setdefault(x['object'],ptr);assert previous==ptr
 assert len(sessions)==4 and set(sessions.values())==set(ptrs)
 pubs={ptr:[x for x in spans if x['id']==11 and x['entry_value']==ptr]for ptr in ptrs}
 assert all(len(pubs[ptr])==rows[i]['completion_tokens']for ptr,i in ptr_actor.items())
 entries={};returns={}
 for x in details:
  if x['id']!=14:continue
  key=tuple(x[k]for k in('tid','id','depth','begin'));assert key in bykey and x['kind']in(3,4)
  dest=entries if x['kind']==3 else returns;assert key not in dest;dest[key]=x
 assert entries.keys()==returns.keys();batches=[x for x in spans if x['id']==12];scalar=[x for x in spans if x['id']==10];engine_scalar=[x for x in spans if x['id']==13];cycle_data=[]
 for key,a in entries.items():
  b=returns[key];span=bykey[key];assert a['object']==b['object']and a['object']in sessions and span['value']&255==1
  delta={k:b[k]-a[k]for k in('cycles','drafted','accepted')};assert delta['cycles']in(0,1)and 0<=delta['accepted']<=delta['drafted']
  if not delta['cycles']:assert delta['accepted']==delta['drafted']==0
  ptr=sessions[a['object']];actor=ptr_actor[ptr];parents=[x for x in batches if contains(x,span)];assert len(parents)<=1
  scalars=[x for x in scalar if contains(x,span)];assert len(scalars)<=1
  if scalars:assert scalars[0]['entry_value']==ptr
  assert parents or scalars,'Unattributed engine completion'
  record=dict(phase=phase,actor=actor,session=a['object'],request=ptr,begin_ns=span['begin'],end_ns=span['end'],finish_host_ms=(span['end']-span['begin'])/1e6,**delta,batch_begin=parents[0]['begin']if parents else None,scalar_begin=scalars[0]['begin']if scalars else None)
  cycle_data.append(record);round_rows.append(record)
 actor_reports=[];wave_lo=round(min(r['started_at']for r in rows)*1e9)
 for actor,row in enumerate(rows):
  ptr=ptrs[actor];items=[x for x in cycle_data if x['actor']==actor];totals={k:sum(x[k]for x in items)for k in('cycles','drafted','accepted')};assert totals==dict(cycles=row['raw_gufo']['draft_rounds'],drafted=row['draft_tokens'],accepted=row['draft_accepted_tokens']),(phase,actor,totals,row['raw_gufo'])
  plain=sum(x['cycles']==0 for x in items);assert totals['cycles']+totals['accepted']+plain==row['completion_tokens'],(phase,actor,'output accounting',totals,plain)
  lo=pubs[ptr][0]['begin'];hi=pubs[ptr][-1]['begin'];segments=[]
  for outer in batches:
   if outer['tid']!=tid:continue
   actors={x['actor']for x in cycle_data if x['batch_begin']==outer['begin']};assert actors
   segments.append((outer['begin'],outer['end'],'batch_including_request'if actor in actors else'batch_other_requests'))
  for outer in scalar:
   if outer['tid']==tid and not any(contains(batch,outer)for batch in batches):segments.append((outer['begin'],outer['end'],'scalar_this_request'if outer['entry_value']==ptr else'scalar_other_requests'))
  segments += [(x['begin'],x['end'],'prefill')for x in prefill]
  clipped=sorted((max(a,lo),min(b,hi),tag)for a,b,tag in segments if a<hi and b>lo)
  assert all(a<=b for a,b,tag in clipped)and all(prev[1]<=nxt[0]for prev,nxt in zip(clipped,clipped[1:])),(phase,actor,'overlapping host categories')
  partition=collections.defaultdict(float)
  for a,b,tag in clipped:partition[tag]+=(b-a)/1e6
  partition['unclassified_host_interval']=(hi-lo)/1e6-sum(partition.values());assert partition['unclassified_host_interval']>=-1e-6
  actor_reports.append(dict(actor=actor,session=next(s for s,q in sessions.items()if q==ptr),completion_tokens=row['completion_tokens'],plain_completion_calls=plain,**totals,publication_span_ms=(hi-lo)/1e6,first_publication_ms=(lo-wave_lo)/1e6,last_publication_ms=(hi-wave_lo)/1e6,host_partition_ms=dict(partition),engine_completion_calls=len(items),batch_completion_calls=sum(x['batch_begin']is not None for x in items),scalar_completion_calls=sum(x['scalar_begin']is not None for x in items)))
 batch_reports=[]
 for x in batches:
  children=[a for a in cycle_data if a['batch_begin']==x['begin']];forward=[a for a in spans if a['id']==6 and contains(x,a)];mtp=[a for a in spans if a['id']==2 and contains(x,a)]
  batch_reports.append(dict(begin_ms=(x['begin']-wave_lo)/1e6,end_ms=(x['end']-wave_lo)/1e6,host_ms=(x['end']-x['begin'])/1e6,actors=[a['actor']for a in children],cycles=[a['cycles']for a in children],drafted=[a['drafted']for a in children],accepted=[a['accepted']for a in children],forward_batch_calls=len(forward),mtp_forward_batch_calls=len(mtp)))
 reports.append(dict(phase=phase,actors=actor_reports,batches=batch_reports,span_counts=dict(collections.Counter(x['id']for x in spans))))
report=dict(phases=reports,per_request_counter_totals_equal_server=True,publication_counts_and_completion_accounting_exact=True,scope='Direct read-only cumulative Session deltas at exact FinishDecode entry/return; Sync this pointers map to containing head StepPrefill shared_ptr identity. No order-only attribution or crosshost clocks. Host publication-span categories are disjoint clipped head-thread enclosures, not pure CPU/GPU/transport durations. Batch time is shared, never additive per member; unclassified intervals are not assumed idle. Tracing may alter scheduling; no previous flag waiver or untraced performance gain.')
(p/'round-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
with(p/'rounds.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=list(round_rows[0]));w.writeheader();w.writerows(round_rows)
print(json.dumps({'phases':[dict(phase=a['phase'],actors=a['actors'])for a in reports]},indent=2))
