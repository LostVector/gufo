from pathlib import Path
import runpy,sys
from trace_state import observer
out=Path(__file__).resolve().parent
try:runpy.run_path(str(out/'client.py'),run_name='__main__')
finally:
 if observer.active:observer.stop()
