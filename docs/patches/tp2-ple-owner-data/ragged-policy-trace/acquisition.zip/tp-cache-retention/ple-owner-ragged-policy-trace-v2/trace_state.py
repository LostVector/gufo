from pathlib import Path
import sys
from observer import Observer
out=Path(__file__).resolve().parent;phase=Path(sys.argv[1]).stem.removeprefix(out.name+'-')
observer=Observer(out,phase);observer.active=False
