"""Replay the first width divergence with verified equal request-side inputs."""
import ast
import ctypes
import hashlib
import json
from pathlib import Path
import struct

p = Path(__file__).resolve().parent
collector = p.parent / 'app-span-recorder-v6'
manifest = json.loads((collector / 'build-info.json').read_text())
for name, digest in manifest['files_sha256'].items():
    assert hashlib.sha256((collector / name).read_bytes()).hexdigest() == digest
lib = ctypes.CDLL(str(collector / 'choice-fixture.so'))
lib.choice_replay.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint]
lib.choice_replay.restype = ctypes.c_uint
# Use the exact audited packing function without executing acquisition analysis.
tree = ast.parse((p / 'choices.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'pack_replay')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(p / 'choices.py'), 'exec'))
choices = json.loads((p / 'choices.json').read_text())
by_phase = {phase: [c for c in choices if c['phase'] == phase]
            for phase in ('before-baseline', 'first-candidate', 'after-baseline')}

def request_inputs(c):
    return c['context'], sorted((r['actor'], r['budget'], tuple(r['policy'])) for r in c['rows'])

comparisons = []
for phase in ('before-baseline', 'first-candidate'):
    a = by_phase[phase]
    b = by_phase['after-baseline']
    index = next(i for i, (x, y) in enumerate(zip(a, b)) if x['selected'] != y['selected'])
    x, y = a[index], b[index]
    assert all(request_inputs(x0) == request_inputs(y0)
               and x0['selected'] == y0['selected']
               for x0, y0 in zip(a[:index], b[:index]))
    assert request_inputs(x) == request_inputs(y)
    assert sorted(x['actual_members'], key=lambda m: m['actor']) != sorted(y['actual_members'], key=lambda m: m['actor'])
    swaps = {}
    for own, donor in ((x, y), (y, x)):
        assert pack_replay(own) == own['selected']
        swaps[own['phase']] = {mode: pack_replay(own, donor, mode)
                              for mode in ('ms', 'samples', 'costs', 'schedule', 'acceptance', 'all')}
    comparisons.append(dict(phase=phase, other='after-baseline', zero_based_choice=index,
                            request_inputs_identical=True, own=x, other_choice=y,
                            input_group_swaps=swaps))
report = dict(comparisons=comparisons,
              scope='Exact captured-input CPU decision replay. Input swaps prove decision sensitivity, not live inference speed or a beneficial replacement policy. Actual draft work can differ from chosen caps because of confidence and lookup paths.')
(p / 'divergence-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
for x in comparisons:
    print(x['phase'], 'choice', x['zero_based_choice'],
          x['own']['selected'], x['other_choice']['selected'],
          json.dumps(x['input_group_swaps']))
