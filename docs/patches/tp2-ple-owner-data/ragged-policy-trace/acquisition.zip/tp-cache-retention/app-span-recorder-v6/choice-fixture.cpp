#include "src/models/qwen38_flash_next/mtp_policy.hpp"
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <type_traits>
#include <vector>
using namespace gufo::models::qwen38_flash_next;
struct RawCell {std::uint32_t ms[8],samples[8];std::uint64_t cycles;std::uint32_t last,pad;};
struct RawBatch {RawCell cells[8][8];std::uint64_t concurrency;std::uint32_t bin,stable;};
static_assert(sizeof(RawCell)==80 && sizeof(RawBatch)==5136);
static_assert(sizeof(MtpBatchController)==5136 && sizeof(MtpLengthController)==84);
static_assert(std::is_trivially_copyable_v<MtpBatchController> && std::is_standard_layout_v<MtpBatchController>);
static_assert(std::is_trivially_copyable_v<MtpLengthController> && std::is_standard_layout_v<MtpLengthController>);
static_assert(sizeof(MtpBatchController::Row)==16 && offsetof(MtpBatchController::Row,acceptance)==0 && offsetof(MtpBatchController::Row,budget)==8);
using Method=std::uint32_t(MtpBatchController::*)(std::span<const MtpBatchController::Row>,std::uint32_t)const noexcept;
static Method volatile method=&MtpBatchController::Choose;
struct Owner {MtpBatchController batch;std::vector<MtpLengthController> lengths;std::vector<MtpBatchController::Row> rows;std::uint32_t context;};
static std::string expected;
static unsigned Bin(unsigned context){unsigned b=0;for(unsigned bound=4096;context>=bound&&b<7;bound*=2)++b;return b;}
static void Describe(Owner* o){
 RawBatch raw;std::memcpy(&raw,&o->batch,sizeof(raw));auto bin=Bin(o->context);const auto& cell=raw.cells[o->rows.size()-1][bin];
 std::ostringstream s;s<<'['<<reinterpret_cast<std::uintptr_t>(&o->batch)<<','<<o->rows.size()<<','<<o->context<<','<<bin;
 for(auto x:cell.ms)s<<','<<x;for(auto x:cell.samples)s<<','<<x;
 s<<','<<cell.cycles<<','<<cell.last<<','<<raw.concurrency<<','<<raw.bin<<','<<raw.stable;
 for(const auto& row:o->rows){std::array<std::uint32_t,21> policy;std::memcpy(policy.data(),row.acceptance,84);s<<','<<reinterpret_cast<std::uintptr_t>(row.acceptance)<<','<<row.budget;for(auto v:policy)s<<','<<v;}
 s<<']';expected=s.str();
}
extern "C" void* choice_create(unsigned count,unsigned context,unsigned target){
 auto* o=new Owner;o->context=context;o->lengths.reserve(count);o->rows.reserve(count);
 for(unsigned i=0;i<count;i++)o->lengths.emplace_back(7,count);
 for(unsigned i=0;i<count;i++)o->rows.push_back({&o->lengths[i],7});
 for(unsigned width=0;width<8;width++)for(unsigned repeat=0;repeat<3;repeat++)o->batch.Observe(count,context,width,width==0?40.0F:(width==target?45.0F:200.0F));
 return o;
}
extern "C" unsigned choice_run(void* ptr){auto* o=static_cast<Owner*>(ptr);Describe(o);return (o->batch.*method)(o->rows,o->context);}
extern "C" const char* choice_expected(){return expected.c_str();}
extern "C" void choice_destroy(void* ptr){delete static_cast<Owner*>(ptr);}
extern "C" unsigned choice_replay(const std::uint8_t* bytes,const std::uint32_t* states,unsigned count,unsigned context){
 if(!count||count>8)return 0xffffffffU;
 MtpBatchController batch;std::memcpy(&batch,bytes,5136);std::vector<MtpLengthController> lengths;std::vector<MtpBatchController::Row> rows;lengths.reserve(count);rows.reserve(count);
 for(unsigned i=0;i<count;i++){lengths.emplace_back(7,count);std::memcpy(&lengths.back(),states+i*22,84);}
 for(unsigned i=0;i<count;i++)rows.push_back({&lengths[i],states[i*22+21]});
 return (batch.*method)(rows,context);
}
extern "C" __attribute__((noinline)) unsigned choice_bad(void*,const void*,std::size_t,std::uint32_t){return 7;}
