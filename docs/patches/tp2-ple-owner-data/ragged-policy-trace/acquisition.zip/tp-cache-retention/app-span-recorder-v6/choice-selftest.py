"""Real-header planner snapshots, exact decision replay, and bad-pointer rejection."""
from pathlib import Path
import ctypes,json,os,runpy,signal,struct,subprocess,sys,time
assert os.geteuid()==0
base=Path(__file__).resolve().parent;root=base.parents[1];rank=int(sys.argv[1]);assert rank in(0,1)
out=base/f'choice-selftest-r{rank}';out.mkdir(exist_ok=False);lib=base/'choice-fixture.so';f=ctypes.CDLL(str(lib))
f.choice_create.argtypes=[ctypes.c_uint]*3;f.choice_create.restype=ctypes.c_void_p;f.choice_run.argtypes=[ctypes.c_void_p];f.choice_run.restype=ctypes.c_uint;f.choice_expected.restype=ctypes.c_char_p;f.choice_destroy.argtypes=[ctypes.c_void_p]
f.choice_replay.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint,ctypes.c_uint];f.choice_replay.restype=ctypes.c_uint
f.choice_bad.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint];f.choice_bad.restype=ctypes.c_uint
symbols=[s.split()for s in subprocess.check_output(['nm','-D','--defined-only',str(lib)],text=True).splitlines()];names=subprocess.check_output(['c++filt'],input='\n'.join(s[2]for s in symbols if len(s)==3)+'\n',text=True).splitlines();triples=[s for s in symbols if len(s)==3];choose=next(s[2]for s,n in zip(triples,names)if n.startswith('gufo::models::qwen38_flash_next::MtpBatchController::Choose('))
offset=runpy.run_path(str(base/'elf-offset.py'))['offset']
def address(name):return offset(lib,next(int(s[0],16)for s in symbols if len(s)==3 and s[2]==name))
child=None;handles=[]
def capture(folder,symbol,work):
 global child
 folder.mkdir(exist_ok=False);command=[str(base/'record'),str(base/'probes.bpf.o'),str(os.getpid()),str(folder/'stats.json'),'16','7',str(lib),str(address(symbol))];(folder/'command.json').write_text(json.dumps(command)+'\n')
 with(folder/'app.csv').open('x')as log,(folder/'app.stderr').open('x')as err:
  child=subprocess.Popen(command,stdout=log,stderr=err)
  try:
   deadline=time.monotonic()+10
   while 'APP_READY'not in(folder/'app.csv').read_text().splitlines():
    assert child.poll()is None,(folder/'app.stderr').read_text();assert time.monotonic()<deadline;time.sleep(.002)
   work()
  finally:
   if child.poll()is None:child.send_signal(signal.SIGINT)
   child.wait(timeout=10)
  assert child.returncode==0
 return json.loads((folder/'stats.json').read_text())
expected=[];results=[]
def good():
 for n,context,target in [(2,39,2),(2,39,3),(3,32768,3)]:
  h=f.choice_create(n,context,target);handles.append(h);results.append(f.choice_run(h));expected.append(json.loads(f.choice_expected()))
 code='import ctypes,sys;f=ctypes.CDLL(sys.argv[1]);f.choice_create.argtypes=[ctypes.c_uint]*3;f.choice_create.restype=ctypes.c_void_p;f.choice_run.argtypes=[ctypes.c_void_p];f.choice_run.restype=ctypes.c_uint;assert f.choice_run(f.choice_create(2,39,2))==2'
 subprocess.run([sys.executable,'-I','-c',code,str(lib)],check=True,timeout=10)
try:
 stats=capture(out/'positive',choose,good);c=stats['counters'];assert not any(c[:6])and c[9]==0 and c[10]==c[23]==c[39]==3 and not any(stats['program_recursion_misses'])
 assert stats['remaining_span_keys']==stats['remaining_depth_keys']==stats['remaining_object_keys']==0
 starts={};ends={};snapshots=[]
 for line in(out/'positive/app.csv').read_text().splitlines():
  if line.startswith('APP,'):
   kind,ns,begin,tid,ident,depth,cpu,pid,value=map(int,line.split(',')[1:]);assert pid==os.getpid()and ident==7;key=tid,ident,depth,begin
   if kind==1:assert key not in starts;starts[key]=ns
   else:assert kind==2 and key in starts and key not in ends;ends[key]=value
  elif line.startswith('CHOICE,'):
   v=list(map(int,line.split(',')[1:]));assert v[0]==6 and v[4]==7 and v[7]==os.getpid()and len(v)==33+23*v[9]
   key=v[3],v[4],v[5],v[2];assert key in starts;snapshots.append((key,v[8:]))
 assert len(starts)==len(ends)==len(snapshots)==3 and [x[1]for x in snapshots]==expected and results==[2,3,3]
 for (key,payload),wanted in zip(snapshots,results):
  assert ends[key]==wanted
  n,context,bin=payload[1:4];raw=bytearray(5136);cell=struct.pack('<16IQII',*payload[4:20],payload[20],payload[21],0);start=((n-1)*8+bin)*80;raw[start:start+80]=cell;raw[5120:]=struct.pack('<QII',*payload[22:25]);flat=[]
  for i in range(n):
   row=payload[25+i*23:25+(i+1)*23];flat+=row[2:]+[row[1]]
  blob=(ctypes.c_uint8*len(raw)).from_buffer_copy(raw);rows=(ctypes.c_uint32*len(flat))(*flat);assert f.choice_replay(blob,rows,n,context)==wanted
 bad=capture(out/'negative','choice_bad',lambda: f.choice_bad(None,None,1,39));c=bad['counters'];assert c[9]==1 and c[10]==0 and c[23]==c[39]==1 and not any(c[:6])and not any(bad['program_recursion_misses'])
 assert bad['remaining_span_keys']==bad['remaining_depth_keys']==bad['remaining_object_keys']==0
 assert not any(x.startswith('CHOICE,')for x in(out/'negative/app.csv').read_text().splitlines())
 report=dict(real_header_layout_and_2_3_row_snapshots_exact=True,contexts39_32768_bins0_4=True,decisions_2_3_3_and_offline_replay_exact=True,wrong_PID_excluded=True,invalid_pointer_rejected=True,zero_unexpected_read_ring_map_recursion_errors=True,remaining_maps_empty=True,rank=rank,scope='CPU recorder/replay sensitivity only; synthetic cost cells are not measured inference improvements.')
 (out/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
finally:
 if child is not None and child.poll()is None:child.send_signal(signal.SIGINT);child.wait(timeout=10)
 for h in handles:f.choice_destroy(h)
 for path in out.rglob('*'):
  os.chown(path,root.stat().st_uid,root.stat().st_gid)
 os.chown(out,root.stat().st_uid,root.stat().st_gid)
