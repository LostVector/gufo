#include <linux/bpf.h>
#include <asm/ptrace.h>
#define SEC(x) __attribute__((section(x),used))
#define __uint(name,val) int (*name)[val]
#define __type(name,val) typeof(val) *name
static void*(*lookup)(void*,const void*)=(void*)BPF_FUNC_map_lookup_elem;
static long(*update)(void*,const void*,const void*,__u64)=(void*)BPF_FUNC_map_update_elem;
static long(*remove_key)(void*,const void*)=(void*)BPF_FUNC_map_delete_elem;
static __u64(*clock_ns)(void)=(void*)BPF_FUNC_ktime_get_ns;
static __u64(*pid_tid)(void)=(void*)BPF_FUNC_get_current_pid_tgid;
static __u32(*cpu_id)(void)=(void*)BPF_FUNC_get_smp_processor_id;
static long(*read_user)(void*,__u32,const void*)=(void*)BPF_FUNC_probe_read_user;
static __u64(*cookie)(void*)=(void*)BPF_FUNC_get_attach_cookie;
static void*(*reserve)(void*,__u64,__u64)=(void*)BPF_FUNC_ringbuf_reserve;
static void(*submit)(void*,__u64)=(void*)BPF_FUNC_ringbuf_submit;
static void(*discard)(void*,__u64)=(void*)BPF_FUNC_ringbuf_discard;
struct key {__u32 tid,id;};
struct span_key {__u32 tid,id,depth,pad;};
struct event {__u64 ns,begin,value;__u32 kind,tid,id,depth,cpu,pid;};
struct {__uint(type,BPF_MAP_TYPE_ARRAY);__uint(max_entries,2);__type(key,__u32);__type(value,__u32);} config SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_ARRAY);__uint(max_entries,64);__type(key,__u32);__type(value,__u64);} stats SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_HASH);__uint(max_entries,16384);__type(key,struct key);__type(value,__u32);} depths SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_HASH);__uint(max_entries,65536);__type(key,struct span_key);__type(value,__u64);} spans SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_HASH);__uint(max_entries,65536);__type(key,struct span_key);__type(value,__u64);} objects SEC(".maps");
struct {__uint(type,BPF_MAP_TYPE_RINGBUF);__uint(max_entries,16777216);} events SEC(".maps");
static __inline void count(__u32 n){__u64* v=lookup(&stats,&n);if(v)__sync_fetch_and_add(v,1);}
static __inline void emit(__u32 kind,__u32 id,__u32 depth,__u64 begin,__u64 value){
 struct event* e=reserve(&events,sizeof(*e),0);if(!e){count(0);return;}
 __u64 p=pid_tid();e->ns=clock_ns();e->begin=begin;e->value=value;e->kind=kind;
 e->tid=(__u32)p;e->id=id;e->depth=depth;e->cpu=cpu_id();e->pid=p>>32;submit(e,0);
}
// id8: Session::Sync this pointer. id14: Session::FinishDecode cumulative stats.
struct detail_event {struct event header;__u64 object,cycles,drafted,accepted;};
static __inline void detail(__u32 kind,__u32 id,__u32 depth,__u64 begin,__u64 object){
 struct detail_event data={0};
 if(id==14){
  __u32 one=1;__u32* offset=lookup(&config,&one);
  if(!object||!offset||!*offset||*offset>16777216||
     read_user(&data.cycles,24,(const void*)(object+*offset))){count(5);return;}
 }
 struct detail_event* e=reserve(&events,sizeof(*e),0);
 if(!e){count(0);return;}
 __u64 proc=pid_tid();e->header.ns=clock_ns();e->header.begin=begin;
 e->header.value=0;e->header.kind=kind;e->header.tid=(__u32)proc;
 e->header.id=id;e->header.depth=depth;e->header.cpu=cpu_id();e->header.pid=proc>>32;
 e->object=object;e->cycles=data.cycles;e->drafted=data.drafted;e->accepted=data.accepted;
 submit(e,0);count(id==8?8:(kind==3?6:7));
}
// id7: exact MtpBatchController::Choose, standard-layout5136bytes.
struct row_data {__u64 object;__u32 budget,pad,policy[21],padding;};
struct batch_event {
 struct event header;__u64 object;__u32 count,context,bin,pad;
 __u32 ms[8],samples[8];__u64 cycles;__u32 last_drafts,padding;
 __u64 last_concurrency;__u32 last_context,stable;
 struct row_data rows[8];
};
static __inline void batch_detail(struct pt_regs* ctx,__u32 depth,__u64 begin){
 __u64 count_rows=ctx->rdx,object=ctx->rdi,rows=ctx->rsi;__u32 context=ctx->rcx,bin=0;
 if(!object||!rows||!count_rows||count_rows>8){count(9);return;}
 #pragma unroll
 for(int j=0;j<7;j++)if(context>=(4096U<<j))bin++;
 struct batch_event* e=reserve(&events,sizeof(*e),0);
 if(!e){count(0);return;}
 __builtin_memset(e,0,sizeof(*e));
 __u64 proc=pid_tid();e->header.kind=6;e->header.id=7;e->header.depth=depth;
 e->header.ns=clock_ns();e->header.begin=begin;e->header.tid=(__u32)proc;
 e->header.pid=proc>>32;e->header.cpu=cpu_id();e->object=object;
 e->count=count_rows;e->context=context;e->bin=bin;
 __u64 cell=((count_rows-1)*8+bin)*80;
 if(read_user(&e->ms,80,(const void*)(object+cell))||
    read_user(&e->last_concurrency,16,(const void*)(object+5120))){count(9);discard(e,0);return;}
 #pragma unroll
 for(unsigned j=0;j<8;j++){
  if(j<count_rows){
   if(read_user(&e->rows[j].object,16,(const void*)(rows+j*16))||
      !e->rows[j].object||read_user(&e->rows[j].policy,84,(const void*)e->rows[j].object)){
    count(9);discard(e,0);return;
   }
  }
 }
 submit(e,0);count(10);
}
SEC("uprobe") int enter(struct pt_regs* ctx){
 __u32 z=0;__u32* target=lookup(&config,&z);if(!target||(pid_tid()>>32)!=*target)return 0;
 __u32 id=cookie(ctx);if(id<1||id>15){count(4);return 0;}
 struct key key={( __u32)pid_tid(),id};__u32* old=lookup(&depths,&key);__u32 depth=old?*old+1:1;
 if(depth>64){count(3);return 0;}
 __u64 begin=clock_ns();struct span_key sk={key.tid,id,depth,0};
 if(update(&depths,&key,&depth,BPF_ANY)||update(&spans,&sk,&begin,BPF_NOEXIST)){count(1);return 0;}
 count(16+id);
 // Entry-only fields: SysV x86-64 std::span size in RCX; hidden row in R8.
 __u64 value=0;
 if(id==5)value=(__u64)(__u32)ctx->rcx|((__u64)(__u32)ctx->r8<<32);
 else if(id==3)value=ctx->rcx;
 else if(id==9||id==10||id==11){
  // SysV x86-64: non-sret scheduler method(this, shared_ptr<Request>const&, ...).
  // libstdc++ shared_ptr first word is its managed object pointer. Opaque identity only.
  if(read_user(&value,sizeof(value),(const void*)ctx->rsi))count(1);
 }
 emit(1,id,depth,begin,value);
 if(id==7)batch_detail(ctx,depth,begin);
 if(id==8)detail(5,id,depth,begin,ctx->rdi);
 if(id==14){
  __u64 object=ctx->rdi;
  if(update(&objects,&sk,&object,BPF_NOEXIST))count(1);
  detail(3,id,depth,begin,object);
 }
 return 0;
}
SEC("uretprobe") int leave(struct pt_regs* ctx){
 __u32 z=0;__u32* target=lookup(&config,&z);if(!target||(pid_tid()>>32)!=*target)return 0;
 __u32 id=cookie(ctx);if(id<1||id>15){count(4);return 0;}
 struct key key={( __u32)pid_tid(),id};__u32* old=lookup(&depths,&key);
 if(!old||!*old){count(2);return 0;}
 __u32 depth=*old;struct span_key sk={key.tid,id,depth,0};__u64* begin=lookup(&spans,&sk);
 if(!begin){count(1);return 0;}
 if(id==14){
  __u64* object=lookup(&objects,&sk);
  if(!object)count(1);else detail(4,id,depth,*begin,*object);
  remove_key(&objects,&sk);
 }
 count(32+id);emit(2,id,depth,*begin,ctx->rax);remove_key(&spans,&sk);
 if(depth==1)remove_key(&depths,&key);else *old=depth-1;return 0;
}
char LICENSE[] SEC("license")="GPL";
