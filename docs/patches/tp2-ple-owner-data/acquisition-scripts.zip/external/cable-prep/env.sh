# Source from scripts; no system-wide environment changes.
ROCM_STACK=${ROCM_STACK:-/home/rkuo/.local/opt/rocm-7.14.1}
CLUSTER_TOOLS=${CLUSTER_TOOLS:-/home/rkuo/.local/opt/strix-cluster-tools}
export HIP_PATH="$ROCM_STACK" ROCM_PATH="$ROCM_STACK"
export LD_LIBRARY_PATH="$ROCM_STACK/lib:$CLUSTER_TOOLS/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
