#!/bin/bash
native_root=/home/rkuo/strix-dispatch-investigation/native-rdma
export LD_LIBRARY_PATH="$native_root/runtime/lib:/home/rkuo/.local/opt/rocm-7.14.1/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# Absolute provider name avoids installing anything into system RDMA directories.
export RDMAV_DRIVERS="$native_root/runtime/lib/libusb4_rdma"
export PATH="$native_root/runtime/bin:$PATH"
