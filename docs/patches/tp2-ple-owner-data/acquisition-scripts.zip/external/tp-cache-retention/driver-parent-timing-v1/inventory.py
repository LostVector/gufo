from pathlib import Path
import json,os,re,socket,subprocess,sys,time
profile=sys.argv[1];assert profile in ('baseline','parent','candidate')
if profile=='off':
 info=json.loads(subprocess.check_output(['python3',str(Path(__file__).with_name('topology.py'))],text=True))
 assert not info['module_loaded']
 info.update(kernel=os.uname().release,cmdline=Path('/proc/cmdline').read_text().strip())
 addresses=json.loads(subprocess.check_output(['ip','-j','-4','address','show'],text=True))
 info['management_ipv4']=[a['local']for i in addresses if i['ifname']!='tbv_strix'for a in i['addr_info']if a.get('scope')=='global']
 print(json.dumps(info,indent=2));sys.exit(0)
expected={'baseline':'81C6FF2FBAC473C7AB21844','parent':'6C607C44DDF7AC1A9A38F61','candidate':'844E9145B923CA473A7AD39'}[profile]
mod=Path('/sys/module/thunderbolt_ibverbs');assert (mod/'srcversion').read_text().strip()==expected
assert (mod/'refcnt').read_text().strip()=='0'
assert (mod/'parameters/native_tx_max_inflight').read_text().strip()=='32'
mask=int((mod/'parameters/native_domain_mask').read_text())
assert mask==4294967295
assert os.uname().release=='7.3.0-strix-test'
assert Path('/sys/module/thunderbolt/srcversion').read_text().strip()=='BDA6ED32433F9503D84E02F'
cmd=Path('/proc/cmdline').read_text().strip();assert 'amdgpu.gttsize='not in cmd and 'ttm.pages_limit=32505856'in cmd and 'amd_iommu=off'in cmd
def text(p):
 try:return Path(p).read_text().strip()
 except OSError:return None
routers=[]
for p in sorted(Path('/sys/bus/thunderbolt/devices').glob('*')):
 if ':'in p.name or '-'not in p.name or not(p/'unique_id').exists():continue
 domain=int(p.name.split('-')[0]);pci=[x for x in p.resolve().parts if re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]',x)]
 routers.append({'router':p.name,'domain':domain,'uuid':text(p/'unique_id'),'NHI':pci[-1]if pci else None,'remote':(p/'rx_speed').exists(),**{k:text(p/k)for k in('rx_speed','tx_speed','rx_lanes','tx_lanes')}})
remote=[p for p in routers if p['remote']];assert len(remote)==2
expected_topology=json.loads((Path('/home/rkuo/strix-dispatch-investigation/driver-frame-investigation/link-cross-v1')/('topology-stable-r'+('0'if socket.gethostname()=='rk-evo-x2'else'1')+'.json')).read_text())
expected_remote={r['domain']:r for r in expected_topology['routers']if r['remote']}
for p in remote:
 assert all(p[k]==expected_remote[p['domain']][k]for k in('uuid','rx_speed','tx_speed','rx_lanes','tx_lanes'))
active_domains={r['domain']for r in remote if mask&(1<<r['domain'])}
devices=[]
for p in sorted(Path('/sys/class/infiniband').glob('usb4_rdma*')):
 assert text(p/'ports/1/state').startswith('4:'),(p,'not ACTIVE')
 controller=(p/'device').resolve().name
 domain={r['domain']for r in routers if r['NHI']==controller};assert len(domain)==1
 domain=next(iter(domain));assert domain in active_domains
 devices.append({'device':p.name,'guid':text(p/'node_guid'),'controller':controller,'domain':domain})
assert len(devices)==2*len(active_domains)
assert {d['domain']for d in devices}==active_domains
assert len(active_domains)==2
if profile!='baseline':assert (mod/'parameters/native_rx_active_poll_us').read_text().strip()=='0'
assert (mod/'parameters/native_rx_recheck_ms').read_text().strip()=='1'
addresses=json.loads(subprocess.check_output(['ip','-j','-4','address','show'],text=True))
ips=[a['local']for i in addresses if i['ifname']!='tbv_strix'for a in i['addr_info']if a.get('scope')=='global']
print(json.dumps({'host':socket.gethostname(),'kernel':os.uname().release,'boot_id':text('/proc/sys/kernel/random/boot_id'),'cmdline':cmd,'module':expected,'refcnt':0,'mask':mask,'routers':routers,'devices':devices,'selected_device':min(devices,key=lambda d:d['guid'])['device'],'management_ipv4':ips,'sample_monotonic_ns':time.monotonic_ns()},indent=2))
