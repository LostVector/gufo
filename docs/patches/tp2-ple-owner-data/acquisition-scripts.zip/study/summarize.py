"""Describe all completed untraced pairs; never inspect a partial family."""
from pathlib import Path
import csv
import hashlib
import json
import statistics

out = Path(__file__).resolve().parent
root = out.parents[1]
assert (out / 'complete').exists()
assert json.loads((out / 'validation.json').read_text())[
    'driver_error_kernel_idle_source_harness_checks_pass']
protocol = json.loads((out / 'protocol.json').read_text())
identity = ('case', 'repetition', 'request_index')
rows, inputs = [], {}
for phase, role in protocol['sequence']:
    path = root / 'results/model-scaling' / f'{out.name}-{phase}.jsonl'
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    for r in map(json.loads, path.read_text().splitlines()):
        assert r['content_events']
        tail = r['finished_at'] * 1000 - r['content_events'][-1]['perf_counter_ns'] / 1e6
        assert tail >= 0
        rows.append(dict(pair=phase.split('-')[0], role=role,
                         **{k: r[k] for k in identity},
                         wall_ms=r['wall_ms'], client_ttft_ms=r['client_ttft_ms'],
                         final_content_to_HTTP_finish_ms=tail,
                         prefill_ms=r['prefill_ms'], decode_ms=r['decode_ms'],
                         server_max_inter_token_ms=r['server_max_inter_token_ms'],
                         queue_ms=r['queue_ms'], server_ttft_ms=r['server_ttft_ms'],
                         first_followup_content_gap_ms=r['first_followup_content_gap_ms'],
                         maximum_content_gap_ms=r['maximum_content_gap_ms'],
                         raw_cache_snapshot_ms=r['raw_gufo']['cache_snapshot_ms'],
                         draft_tokens=r['draft_tokens'],
                         draft_accepted_tokens=r['draft_accepted_tokens'],
                         draft_rounds=r['raw_gufo']['draft_rounds'],
                         completion_tokens=r['completion_tokens'],
                         server_accounted_decode_tps=r['decode_tokens_per_second']))
assert len(rows) == 240
flags, c1_work_differences = [], []
metrics = ('wall_ms', 'client_ttft_ms', 'final_content_to_HTTP_finish_ms',
           'prefill_ms', 'decode_ms', 'server_max_inter_token_ms',
           'queue_ms', 'server_ttft_ms', 'first_followup_content_gap_ms',
           'maximum_content_gap_ms', 'raw_cache_snapshot_ms')
for candidate in (r for r in rows if r['role'] == 'candidate'):
    baseline = next(r for r in rows if r['role'] == 'baseline'
                    and r['pair'] == candidate['pair']
                    and all(r[k] == candidate[k] for k in identity))
    if candidate['case'] == 'pp2048-tg128':
        for field in ('draft_tokens', 'draft_accepted_tokens', 'draft_rounds'):
            if baseline[field] != candidate[field]:
                c1_work_differences.append(dict(pair=candidate['pair'],
                    case=candidate['case'], repetition=candidate['repetition'],
                    field=field, baseline=baseline[field], candidate=candidate[field]))
    for metric in metrics:
        a, b = baseline[metric], candidate[metric]
        if a is not None and b is not None and b-a > 3 and b > a*1.05:
            flags.append(dict(pair=candidate['pair'],
                **{k: candidate[k] for k in identity}, metric=metric,
                baseline=a, candidate=b, delta_ms=b-a))
summary = {}
for case in sorted({r['case'] for r in rows}):
    summary[case] = {}
    for role in ('baseline', 'candidate'):
        selected = [r for r in rows if r['case'] == case and r['role'] == role]
        summary[case][role] = {}
        for metric in metrics + ('server_accounted_decode_tps',):
            values = [r[metric] for r in selected if r[metric] is not None]
            summary[case][role][metric] = dict(n=len(values),
                median=statistics.median(values), worst=max(values), values=values)
for filename, records in [('per-request.csv', rows), ('timing-flags.csv', flags)]:
    with (out / filename).open('w', newline='') as f:
        if records:
            writer = csv.DictWriter(f, fieldnames=list(records[0]), lineterminator='\n')
            writer.writeheader()
            writer.writerows(records)
first_finishers = {}
for case, actor in [('short-c2', 1), ('coding-c2', 0)]:
    first_finishers[case] = {}
    for role in ('baseline', 'candidate'):
        selected = [r for r in rows if r['case'] == case
                    and r['request_index'] == actor and r['role'] == role]
        values = [r['final_content_to_HTTP_finish_ms'] for r in selected]
        first_finishers[case][role] = dict(actor=actor, n=len(values),
            median=statistics.median(values), worst=max(values), values=values)
report = dict(summary=summary, first_finisher_completion_tail_ms=first_finishers,
              timing_flag_count=len(flags),
              c1_speculative_work_differences=c1_work_differences,
              raw_inputs_sha256=inputs,
              scope='Ten fixed randomized balanced-order untraced pairs; descriptive confirmation. '
                    'All per-request timing flags retained. No throughput significance '
                    'claim or pooling with previous experiments. Completion tails use '
                    'one client monotonic clock. Decode rate is server-accounted.')
(out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(records=len(rows), timing_flags=len(flags),
                     c1_work_differences=len(c1_work_differences)), indent=2))
