"""Frozen ten-pair cooperative PLE comparison; analyze only the complete family."""
from pathlib import Path
import hashlib
import json
import math
import statistics

from paired_statistics import holm_primary, summarize

out = Path(__file__).resolve().parent
root = out.parents[1]
assert (out / 'complete').exists()
assert json.loads((out / 'validation.json').read_text())[
    'all_prompt_output_cachework_identities_exact']
p = json.loads((out / 'protocol.json').read_text())
assert len(p['sequence']) == 20
data, inputs = {}, {}
for phase, role in p['sequence']:
    path = root / 'results/model-scaling' / f'{out.name}-{phase}.jsonl'
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(rows) == 12
    data[phase.split('-')[0], role] = rows

def c1(rows, repetition):
    selected = [r for r in rows if r['case'] == 'pp2048-tg128'
                and r['repetition'] == repetition]
    assert len(selected) == 1
    return selected[0]

def wave(rows, case):
    selected = [r for r in rows if r['case'] == case]
    assert len(selected) == 2 and all(r['concurrency'] == 2 for r in selected)
    span = max(r['finished_at'] for r in selected) - min(r['started_at'] for r in selected)
    assert span > 0
    return sum(r['completion_tokens'] for r in selected) / span

observed = []
metrics = {name: dict(baseline=[], candidate=[]) for name in
           ['C1-first-server-decode', 'C2-short-client-wave',
            'C1-repeat-server-decode', 'C2-coding-client-wave']}
c2_work_changes = []
for i in range(1, 11):
    pair = f'pair{i:02d}'
    roles = [role for phase, role in p['sequence'] if phase.startswith(pair + '-')]
    assert set(roles) == {'baseline', 'candidate'}
    observed.append(1 if roles[0] == 'baseline' else -1)
    a, b = [data[pair, role] for role in ['baseline', 'candidate']]
    for repetition in [1, 2]:
        x, y = c1(a, repetition), c1(b, repetition)
        assert all(x[k] == y[k] for k in ['draft_tokens', 'draft_accepted_tokens',
                                         'physical_execution_width'])
        assert x['raw_gufo']['draft_rounds'] == y['raw_gufo']['draft_rounds']
    for x, y in zip(a, b):
        if x['concurrency'] == 2:
            changes = [k for k in ['draft_tokens', 'draft_accepted_tokens',
                                   'physical_execution_width'] if x[k] != y[k]]
            if x['raw_gufo']['draft_rounds'] != y['raw_gufo']['draft_rounds']:
                changes.append('draft_rounds')
            if changes:
                c2_work_changes.append(dict(pair=pair, case=x['case'],
                    actor=x['request_index'], fields=changes))
    for role, rows in [('baseline', a), ('candidate', b)]:
        metrics['C1-first-server-decode'][role].append(c1(rows, 1)['decode_tokens_per_second'])
        metrics['C1-repeat-server-decode'][role].append(c1(rows, 2)['decode_tokens_per_second'])
        metrics['C2-short-client-wave'][role].append(wave(rows, 'short-c2'))
        metrics['C2-coding-client-wave'][role].append(wave(rows, 'coding-c2'))
assert sorted(observed) == [-1]*5 + [1]*5
results = []
for index, (name, values) in enumerate(metrics.items()):
    logs = [math.log(b/a) for a, b in zip(values['baseline'], values['candidate'])]
    result = summarize(logs, observed, 202611011540 + index)
    result.update(metric=name, baseline_values=values['baseline'],
        candidate_values=values['candidate'],
        baseline_geometric_mean=math.exp(statistics.mean(map(math.log, values['baseline']))),
        candidate_geometric_mean=math.exp(statistics.mean(map(math.log, values['candidate']))),
        primary=index < 2)
    results.append(result)
holm_primary(results[:2])
for result in results:
    lower, upper = result['marginal_bootstrap95_throughput_increase_pct']
    adjusted = result.get('holm_adjusted_p')
    result['interpretation'] = (
        'primary decrease supported by paired evidence'
        if adjusted is not None and adjusted <= .05 and upper < 0 else
        'primary increase supported by paired evidence'
        if adjusted is not None and adjusted <= .05 and lower > 0 else
        'inconclusive; not equivalence' if result['primary'] else
        'secondary exploratory estimate; no multiplicity-adjusted conclusion')
report = dict(pairs=10, all_240_request_identities_exact=True,
    c1_speculative_work_exact=True, c2_work_changes=c2_work_changes,
    observed_order=observed, metrics=results, raw_inputs_sha256=inputs,
    scope='Predeclared two-primary cooperative PLE comparison. All pairs retained. '
          'C1 rate is server-accounted; C2 wave includes prefill/admission/terminal wait. '
          'Balanced-assignment p and sign-flip p retain their stated assumptions; '
          'bootstrap confidence intervals are marginal. Not an equivalence claim. '
          'Per-request flags are separate and cannot be waived by aggregates.')
(out / 'statistical-summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps([dict(metric=r['metric'], change_pct=r['paired_geometric_throughput_increase_pct'],
    CI=r['marginal_bootstrap95_throughput_increase_pct'], p=r.get('holm_adjusted_p'),
    interpretation=r['interpretation']) for r in results], indent=2))
