from pathlib import Path
import hashlib,json,shlex,subprocess
root=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
entry=json.loads((out/'binaries.json').read_text())['candidate'];binary=root/'instrumentation/bin'/entry['name']
def remote(code):return subprocess.check_output(['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(['python3','-c',code])],text=True,stderr=subprocess.STDOUT,timeout=30)
def verify(label,fault_rank=None):
 ids=[]
 for rank in (0,1):
  script="rank="+str(rank)+";from pathlib import Path;import json,hashlib;root=Path('/home/rkuo/strix-dispatch-investigation');pid=int((root/"+repr(f'results/model-scaling/{label}-rank{rank}.pid')+").read_text());p=Path('/proc')/str(pid);exe=(p/'exe').resolve();assert str(exe)=="+repr(str(binary))+";assert hashlib.sha256(exe.read_bytes()).hexdigest()=="+repr(entry['sha256'])+";args=(p/'cmdline').read_bytes().decode().split(chr(0));safe={k:args[args.index(k)+1]for k in ('--context','--sessions','--prefill-chunk','--cache-ram-bytes','--speculative','--tp-world-size','--tp-rank','--think','--tp-rdma-device')};assert safe['--context']=='65536'and safe['--sessions']=='2'and safe['--prefill-chunk']=='2048'and safe['--speculative']=='mtp'and safe['--think']=='off'and safe['--tp-rdma-device']=='usb4_rdma0'and safe['--tp-world-size']=='2'and safe['--tp-rank']==str(rank)and safe['--cache-ram-bytes']=='1073741824';maps=(p/'maps').read_text();loaded='/event-fault.so'in maps;assert loaded=="+repr(fault_rank==rank)+";print(json.dumps({'pid':pid,'sha256':"+repr(entry['sha256'])+",'start_ticks':(p/'stat').read_text().rsplit(')',1)[1].split()[19],'launch_fault_present':loaded,'safe_options':safe}))"
  args=['python3','-c',script]if rank==0 else ['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(['python3','-c',script])]
  data=json.loads(subprocess.check_output(args,text=True,stderr=subprocess.STDOUT,timeout=45));ids.append(data);(out/f'{label}-identity-r{rank}.json').write_text(json.dumps(data,indent=2)+'\n')
 return ids
