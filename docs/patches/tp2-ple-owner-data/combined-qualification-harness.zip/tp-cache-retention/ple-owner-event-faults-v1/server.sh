#!/bin/bash
set -euo pipefail
cd /home/rkuo/strix-dispatch-investigation
source cable-prep/env.sh
export LD_LIBRARY_PATH=/home/rkuo/strix-dispatch-investigation/tp-cache-retention/fork-integration-v1/runtime/lib:"$LD_LIBRARY_PATH"
if [[ ${SCALING_NATIVE_RDMA:-0} = 1 ]]; then
 source native-rdma/env.sh
 export SCALING_TP_HEAD=192.168.64.125
 export SCALING_TP_DEVICE=${SCALING_TP_DEVICE:-usb4_rdma0}
fi
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
label=${1:?};rank=${3:?};phase=${label#ple-owner-event-faults-v1-}
if [[ ( $rank == 0 && $phase == rank0-event-error ) || ( $rank == 1 && $phase == rank1-event-error ) ]]; then
 export STRIX_PLE_EVENT_ARM="$PWD/tp-cache-retention/ple-owner-event-faults-v1/armed-$phase"
 export STRIX_PLE_EVENT_LOG="$PWD/tp-cache-retention/ple-owner-event-faults-v1/injected-$phase.jsonl"
 export STRIX_PLE_EVENT_PC="0x59d67ab"
 export LD_PRELOAD="$PWD/tp-cache-retention/ple-owner-event-faults-v1/event-fault.so"
fi
label=${1:?};world=${2:?};rank=${3:?};binary=${4:-head-gather2};profile=${5:-short};speculation=${6:-${STRIX_SPECULATION:-off}}
[[ "$label" =~ ^[A-Za-z0-9_-]+$ ]] || exit 2
mkdir -p results/model-scaling
printf '%s\n' "$$" > "results/model-scaling/$label-rank$rank.pid"
model=/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf
args=(serve llm --model "$model" --served-model-name flash-next-tp-test --context "${STRIX_CONTEXT:-4096}" --sessions "${STRIX_SESSIONS:-2}" --prefill-chunk "${STRIX_CHUNK:-512}" --cache-ram-bytes 1073741824 --speculative off --think off --host 127.0.0.1 --port 28530 --temperature 0 --seed 1)
if [[ "$world" = 2 ]]; then
 token=$(cat model-scaling/control-token)
 args+=(--tp-world-size 2 --tp-rank "$rank" --tp-bootstrap-host "${SCALING_TP_HEAD:-10.77.0.1}" --tp-bootstrap-port 28531 --tp-control-port 28532 --tp-control-token "$token" --tp-rdma-device "${SCALING_TP_DEVICE:-rxe_strix0}")
fi
if [[ "$binary" = *traced* ]]; then
 export GUFO_TP_TRACE_PREFIX="$PWD/results/model-scaling/$label-rank$rank" GUFO_TP_TRACE_CAPACITY=262144
fi
devices=(/sys/class/infiniband/usb4_rdma*)
((${#devices[@]})) || exit 3
if [[ "$world" = 2 ]]; then
 for ((i=0;i<${#args[@]};i++)); do
  if [[ ${args[i]} = --tp-rdma-device ]]; then args[i+1]="${devices[0]##*/}"; fi
 done
fi
if [[ "$speculation" = mtp ]]; then
 for ((i=0;i<${#args[@]};i++)); do
  if [[ ${args[i]} = --speculative ]]; then args[i+1]=mtp; fi
 done
 args+=(--mtp-model /home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf)
fi
exec "instrumentation/bin/gufo-$binary" "${args[@]}" > "results/model-scaling/$label-rank$rank.stdout" 2> "results/model-scaling/$label-rank$rank.stderr"
