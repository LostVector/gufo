from pathlib import Path
import concurrent.futures,json,sys,time,threading,urllib.request,subprocess
from identity import root,out,binary,remote,verify
from failure_policy import wait_for_pair_exit
label=Path(sys.argv[1]).stem;phase=label.removeprefix(out.name+'-');assert phase in('rank0-event-error','rank1-event-error');rank=0 if phase.startswith('rank0')else 1;base=sys.argv[2];ids=verify(label,rank);owner=ids[rank]
def on_owner(code):return remote(code)if rank else subprocess.check_output(['python3','-c',code],text=True,stderr=subprocess.STDOUT,timeout=10)
arm=out/('armed-'+phase);log=out/('injected-'+phase+'.jsonl');target=json.loads((out/'target.json').read_text())
body={'model':'flash-next-tp-test','messages':[{'role':'user','content':'Write a detailed numbered list of thirty practical ways to debug a slow distributed inference server. Explain each item.'}],'max_tokens':512,'temperature':0,'seed':1,'cache_prompt':False,'stream':True,'chat_template_kwargs':{'enable_thinking':False}}
barrier=threading.Barrier(2);lock=threading.Lock();counts=[0,0];state={'armed':False}
def request(actor):
 b={**body,'messages':[{'role':'user','content':body['messages'][0]['content']+'\nRequest variant '+str(actor)+'.'}]};req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(b).encode(),headers={'Content-Type':'application/json'});events=[];normal=False;explicit=None;exception=None;barrier.wait(timeout=10);began=time.monotonic()
 try:
  with urllib.request.urlopen(req,timeout=30)as response:
   assert response.status==200
   for line in response:
    if not line.startswith(b'data:'):continue
    data=line[5:].strip()
    if data==b'[DONE]':break
    event=json.loads(data);events.append(event)
    if event.get('error'):explicit=event['error']
    for c in event.get('choices',[]):
     normal=normal or c.get('finish_reason')is not None
     if c.get('delta',{}).get('content'):
      with lock:
       counts[actor]+=1
       if min(counts)>=8 and not state['armed']:
        state['armed']=True;state['arm_begin']=time.monotonic();code="from pathlib import Path;p=Path('/proc/"+str(owner['pid'])+"');assert(p/'exe').resolve()==Path("+repr(str(binary))+");assert(p/'stat').read_text().rsplit(')',1)[1].split()[19]=="+repr(owner['start_ticks'])+";Path("+repr(str(arm))+").touch(exist_ok=False);print('armed')";assert on_owner(code).strip()=='armed'
 except Exception as e:exception=repr(e)
 return {'actor':actor,'events':events,'explicit':explicit,'normal':normal,'exception':exception,'elapsed':time.monotonic()-began}
began=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:responses=list(pool.map(request,[0,1]))
raw=on_owner("from pathlib import Path;p=Path("+repr(str(log))+");print(p.read_text()if p.exists()else'')");faults=[json.loads(s)for s in raw.splitlines()if s.strip()]
valid=len(faults)==1 and faults[0]['pid']==owner['pid']and faults[0]['api']=='hipEventRecord'and faults[0]['return_pc']==target['return_pc']and faults[0]['error']==1 and faults[0]['real_api_called']is False
record={'phase':phase,'fault_rank':rank,'owner':owner,'responses':responses,'observed_content_pieces':counts,'faults':faults,'valid_exact_event_failure':valid,'elapsed_seconds':time.monotonic()-began,'scope':'Arm after8content pieces from EACH live SSEclient. Exact current-binary PLE callback return PC; one simulated EventRecord API failure, no actual event submitted for that call. No realGPUfault, precise token/collective-inflight or latency claim.'}
(out/f'{phase}-capture.json').write_text(json.dumps(record,indent=2)+'\n')
assert valid and state['armed']and min(counts)>=8,'No exact current new-path API fault'
assert all(x['explicit']and not x['normal']and x['exception']is None and x['elapsed']<10 and not any(s in json.dumps(x['explicit']).lower()for s in('timed out','timeout'))for x in responses),'Both admitted live streams must fail explicitly within10s'
record['pair_exit']=wait_for_pair_exit(out,label,base,body,str(binary));record['failed_pair_exited']=True
(out/f'{phase}-result.json').write_text(json.dumps(record,indent=2)+'\n');Path(sys.argv[1]).write_text(json.dumps(record)+'\n');print('PASS exact newPLE EventRecord return failure',phase,flush=True)
