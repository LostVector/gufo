from pathlib import Path
import json,hashlib,re,subprocess,shlex
r=Path('/home/rkuo/strix-dispatch-investigation');o=Path(__file__).resolve().parent;assert(o/'complete').exists();p=json.loads((o/'protocol.json').read_text());assert not json.loads((o/'cleanup.json').read_text())['errors']
for n,h in p['harness_sha256'].items():assert hashlib.sha256((o/n).read_bytes()).hexdigest()==h,n
for n,h in p['external_harness_sha256'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
for meta in json.loads((o/'source-preflight.json').read_text()).values():
 for n,h in meta['source_sha256'].items():assert hashlib.sha256((Path(meta['path'])/n).read_bytes()).hexdigest()==h,n
selftest=json.loads((o/'selftest.json').read_text());assert len(selftest['records'])==5 and all(x['passed']for x in selftest['records'])
for n in('event-fault.cpp','event-fault.so'):assert hashlib.sha256((o/n).read_bytes()).hexdigest()==selftest['source_artifact_SHA256'][n]
target=json.loads((o/'target.json').read_text());assert target['binary']['sha256']==p['binaries']['candidate']['sha256']
ref=json.loads((o/'fresh-reference.json').read_text());assert hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest()==ref['sha256'];keys=('case','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256');faults=[];deltas={}
for phase,_ in p['sequence']:
 assert(o/f'{phase}-complete').exists();rows=[json.loads(s)for s in(r/'results/model-scaling'/f'{o.name}-{phase}.jsonl').read_text().splitlines()];failure=phase.endswith('event-error')
 if failure:
  assert len(rows)==1;x=rows[0];assert x['valid_exact_event_failure']and x['failed_pair_exited']and min(x['observed_content_pieces'])>=8
  assert all(y['explicit']and not y['normal']and y['exception']is None and y['elapsed']<10 for y in x['responses'])
  assert all(not y['alive']for y in x['pair_exit']['states'])and x['pair_exit']['new_connection_rejected']
  assert len(x['faults'])==1;f=x['faults'][0];assert f['pid']==x['owner']['pid']and f['api']=='hipEventRecord'and f['return_pc']==target['return_pc']and f['error']==1 and f['real_api_called']is False
  faults.append(x)
 else:
  assert len(rows)==4 and all(all(a[k]==b[k]for k in keys)for a,b in zip(ref['rows'],rows));assert all(x['draft_tokens']>0 and x['cached_prompt_tokens']==0 for x in rows)
 for rank in(0,1):
  def counts(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(o/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counts('before'),counts('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());delta={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};deltas[f'{phase}/rank{rank}']=delta
  if not failure:assert not delta,(phase,rank,delta)
  identity=json.loads((o/f'{o.name}-{phase}-identity-r{rank}.json').read_text());h=identity.get('sha256',identity.get('binary_sha256'));assert h==p['binaries']['candidate']['sha256'];pid=identity['pid'];code="from pathlib import Path;import sys;p=Path('/proc')/sys.argv[1];assert not(p/'exe').exists()";args=['python3','-c',code,str(pid)]
  if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
  subprocess.run(args,check=True,timeout=10)
for rank in(0,1):
 final=json.loads((o/f'final-inventory-r{rank}.json').read_text());assert final['module']=='81C6FF2FBAC473C7AB21844'and final['refcnt']==0 and all(final[k]==p['initial'][rank][k]for k in('boot_id','cmdline','routers'));assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout|segfault|amdgpu.*(?:reset|timeout)',(o/f'kernel-window-r{rank}.txt').read_text(),re.I)
report={'rank0_and_rank1_exact_new_PLE_event_record_failure_rejected':True,'live_streams_failed_explicitly':4,'exact_independent_fresh_recovery_outputs':8,'initial_fresh_control_requests':4,'failed_pairs_exit_automatically':True,'faults':faults,'checked_transport_error_deltas':deltas,'source_harness_binary_boot_topology_PID_kernel_approved_idle_checks':True,'scope':'Current combined2669e07c production release, exactnewPLE callback hipEventRecord return failure only. Five CPU shim controls. Both SSEclients live before arm; both fail explicitly, pair exits, fresh processes recover. Not actual GPUhardware fault, native completion latency, precise collective-inflight loss, performance, or same-engine reconnect.'};(o/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
