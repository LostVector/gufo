#include <hip/hip_runtime_api.h>
#include <atomic>
static std::atomic<int> count{0};
extern "C" hipError_t hipEventRecord(hipEvent_t, hipStream_t) {
  ++count;
  return hipSuccess;
}
extern "C" int RealEventCalls() { return count.load(); }
