from pathlib import Path
import subprocess,json,os,re,hashlib
r=Path('/home/rkuo/strix-dispatch-investigation');o=Path(__file__).resolve().parent;assert not(o/'selftest.json').exists()
compiler='/home/rkuo/.local/opt/rocm-7.14.1/bin/amdclang++';common=[compiler,'-std=c++20','-D__HIP_PLATFORM_AMD__','-I/home/rkuo/.local/opt/rocm-7.14.1/include']
commands=[common+['-shared','-fPIC','-O2',str(o/'event-fault.cpp'),'-ldl','-o',str(o/'event-fault.so')],common+['-shared','-fPIC','-O2',str(o/'fake-hip.cpp'),'-o',str(o/'libfakehip.so')],common+['-O0','-g','-fno-optimize-sibling-calls',str(o/'fixture.cpp'),'-L'+str(o),'-lfakehip','-Wl,-rpath,$ORIGIN','-pthread','-o',str(o/'fixture')]]
with(o/'build.log').open('x')as log:
 for cmd in commands:subprocess.run(cmd,cwd=o,stdout=log,stderr=subprocess.STDOUT,check=True)
dis=subprocess.check_output(['objdump','-d','--no-show-raw-insn','--disassemble=IssueEvent',str(o/'fixture')],text=True);(o/'fixture-disassembly.txt').write_text(dis)
ins=[(int(a,16),s)for a,s in re.findall(r'^\s*([0-9a-f]+):\s+(.*)$',dis,re.M)];calls=[i for i,(a,s)in enumerate(ins)if'call'in s and'hipEventRecord@plt'in s];assert len(calls)==1;pc=ins[calls[0]+1][0]
(o/'armed').touch(exist_ok=False);records=[]
for name,target,armed,count,expected in [('no-target',None,True,4,0),('wrong-PC',pc+1,True,4,0),('not-armed',pc,False,4,0),('one-failure',pc,True,4,1),('thread-race',pc,True,8,1)]:
 env=os.environ.copy();env['LD_PRELOAD']=str(o/'event-fault.so');env['STRIX_PLE_EVENT_ARM']=str(o/('armed'if armed else'not-created'));env['STRIX_PLE_EVENT_LOG']=str(o/(name+'.jsonl'))
 if target is None:env.pop('STRIX_PLE_EVENT_PC',None)
 else:env['STRIX_PLE_EVENT_PC']=hex(target)
 res=subprocess.run([str(o/'fixture'),str(count),str(expected)],cwd=o,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/(name+'.log')).write_text(res.stdout);assert res.returncode==0,(name,res.stdout)
 log=o/(name+'.jsonl')
 if expected:
  rows=[json.loads(s)for s in log.read_text().splitlines()];assert len(rows)==1 and rows[0]['return_pc']==pc and rows[0]['error']==1 and rows[0]['real_api_called']is False
 else:assert not log.exists()
 records.append({'case':name,'calls':count,'errors':expected,'passed':True,'output':res.stdout.strip()})
files=['event-fault.cpp','event-fault.so','fake-hip.cpp','libfakehip.so','fixture.cpp','fixture','build-test.py'];report={'records':records,'source_artifact_SHA256':{n:hashlib.sha256((o/n).read_bytes()).hexdigest()for n in files},'fixture_return_pc':pc,'commands':commands,'scope':'Five CPU-only ABI/caller/arming/once/thread-race controls with typed HIP header declarations and fake next API; no real GPU, model error handling or performance proof.'};(o/'selftest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(records,indent=2))
