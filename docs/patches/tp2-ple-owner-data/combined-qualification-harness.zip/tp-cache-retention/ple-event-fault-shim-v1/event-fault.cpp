#define _GNU_SOURCE
#include <hip/hip_runtime_api.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <unistd.h>

// Test-only API-return injection. No event is submitted at the one failed call.
// The exact caller PC and explicitly armed file constrain it to a task-owned path.
static std::atomic<bool> fired{false};
extern "C" hipError_t hipEventRecord(hipEvent_t event, hipStream_t stream) {
  void* caller = __builtin_extract_return_addr(__builtin_return_address(0));
  Dl_info image{};
  const char* target = std::getenv("STRIX_PLE_EVENT_PC");
  const char* arm = std::getenv("STRIX_PLE_EVENT_ARM");
  const auto pc = target ? std::strtoull(target, nullptr, 0) : 0;
  if (pc != 0 && arm && dladdr(caller, &image) &&
      reinterpret_cast<unsigned long long>(caller) -
              reinterpret_cast<unsigned long long>(image.dli_fbase) == pc &&
      access(arm, F_OK) == 0) {
    bool expected = false;
    if (fired.compare_exchange_strong(expected, true)) {
      if (const char* log = std::getenv("STRIX_PLE_EVENT_LOG")) {
        const int fd = open(log, O_CREAT | O_EXCL | O_WRONLY | O_CLOEXEC, 0600);
        if (fd >= 0) {
          char row[512];
          const int size = std::snprintf(row, sizeof(row),
              "{\"pid\":%d,\"tid\":%ld,\"api\":\"hipEventRecord\",\"return_pc\":%llu,\"error\":1,\"real_api_called\":false}\n",
              getpid(), syscall(SYS_gettid), pc);
          if (size > 0 && size < static_cast<int>(sizeof(row)))
            (void)write(fd, row, static_cast<size_t>(size));
          close(fd);
        }
      }
      return hipErrorInvalidValue;
    }
  }
  using Next = hipError_t (*)(hipEvent_t, hipStream_t);
  static Next next = reinterpret_cast<Next>(dlsym(RTLD_NEXT, "hipEventRecord"));
  return next ? next(event, stream) : hipErrorNotInitialized;
}
