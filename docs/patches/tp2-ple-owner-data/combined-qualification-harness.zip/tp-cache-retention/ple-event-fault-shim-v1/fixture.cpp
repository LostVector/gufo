#include <hip/hip_runtime_api.h>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <vector>
extern "C" int RealEventCalls();
extern "C" __attribute__((noinline)) hipError_t IssueEvent() {
  return hipEventRecord(reinterpret_cast<hipEvent_t>(0x1010),
                         reinterpret_cast<hipStream_t>(0x2020));
}
int main(int argc, char** argv) {
  if (argc != 3) return 2;
  const int n = std::atoi(argv[1]), expected = std::atoi(argv[2]);
  std::vector<hipError_t> results(n);
  if (n == 8) {
    std::vector<std::thread> threads;
    for (int i = 0; i < n; ++i) threads.emplace_back([&, i] { results[i] = IssueEvent(); });
    for (auto& t : threads) t.join();
  } else for (auto& result : results) result = IssueEvent();
  int errors = 0;
  for (auto result : results) {
    if (result == hipErrorInvalidValue) ++errors;
    else if (result != hipSuccess) return 3;
  }
  if (errors != expected || RealEventCalls() != n - expected) return 4;
  std::printf("PASS calls=%d errors=%d real=%d\n", n, errors, RealEventCalls());
}
