"""Compare only identical emitted byte frontiers, without interpolation."""
from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;root=p.parents[1];phases=['before-baseline','first-candidate','after-baseline'];rows={};raws={}
for phase in phases:
 f=root/'results/model-scaling'/f'{p.name}-{phase}.jsonl';raws[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest();rows[phase]=next(r for r in map(json.loads,f.read_text().splitlines())if r['case']=='ragged-C4'and r['request_index']==1)
assert len({r['completion_sha256']for r in rows.values()})==1
frontiers={}
for phase,row in rows.items():
 cumulative=0;times={}
 for event in row['content_events']:
  if not event['content_bytes']:continue
  cumulative+=event['content_bytes'];assert cumulative not in times
  times[cumulative]=(event['perf_counter_ns']-round(row['started_at']*1e9))/1e6
 frontiers[phase]=times
assert len({max(t)for t in frontiers.values()})==1
common=sorted(set.intersection(*(set(t)for t in frontiers.values())))
values=[{'bytes':n,**{phase:frontiers[phase][n]for phase in phases},'candidate_minus_before_ms':frontiers['first-candidate'][n]-frontiers['before-baseline'][n],'candidate_minus_after_ms':frontiers['first-candidate'][n]-frontiers['after-baseline'][n]}for n in common]
report={'raw_sha256':raws,'same_final_output':True,'matched_byte_frontiers':values,'request_values':{phase:{k:r[k]for k in ['wall_ms','client_ttft_ms','decode_ms','draft_tokens','draft_accepted_tokens']}|{'draft_rounds':r['raw_gufo']['draft_rounds']}for phase,r in rows.items()},'observation':'Flagged actor1 candidate and later baseline both have13rounds/22drafts/15accepted versus firstbaseline10rounds/23drafts/21accepted. Candidate whole reply1758.7ms versus1540.6/1779.1ms controls. Shared later-baseline work/latency mode is observed, not proof that all218ms is caused by3extra rounds. No fixed-work replay, per-round trace or causal attribution. All6strict entries remain; do not waive them based on whole-wave throughput or similar control.','scope':'Same-output cumulative emitted byte frontiers only, matched exact offsets without interpolation/token-identity assumptions. No GPU/transport measurement, significance/equivalence or new performance gain.'}
(p/'timing-flag-review.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS identical output;',len(values),'common emitted byte frontiers')
