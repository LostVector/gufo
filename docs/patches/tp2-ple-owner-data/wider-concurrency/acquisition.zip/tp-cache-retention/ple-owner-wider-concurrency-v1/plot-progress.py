from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;d=json.loads((p/'timing-flag-review.json').read_text());rows=d['matched_byte_frontiers'];fig,ax=plt.subplots(figsize=(8,4.5))
for phase,style in [('before-baseline','o-'),('first-candidate','s-'),('after-baseline','^-')]:ax.plot([r['bytes']for r in rows],[r[phase]for r in rows],style,label=phase,markersize=3,linewidth=1)
ax.set(xlabel='Identical emitted byte frontier (not tokens)',ylabel='Milliseconds from client request start',title='Flagged 33-token reply: matched visible progress')
ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(p/'matched-progress.png',dpi=150);fig.savefig(p/'matched-progress.pdf')
