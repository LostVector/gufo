# Four-session PLE qualification

Fixed baseline/candidate/baseline,20 requests per start. Model and native transport
settings match the retained study except session capacity4. Baseline production
sourcefbacf9cc; combined candidate2669e07c includes PLE plus later cache/platform
fixes. Current review2bbd6575 changes tests/docs only relative to2669e07c in
src/include/cmake/top-level CMake. This is functional and phase-latency
qualification, not an isolated-PLE speed or statistical/equivalence claim.

Order: warmup8; four solo128 controls; solo17/33/65 controls; C3x128; C4x128;
raggedC4 limits17/33/65/128; post-wave solo128 replay. Requests save on completion
with fixed order keys, so failure preserves completed results without assuming
completion order. Require each concurrent/replayed output exactly match its
same-prompt/same-limit solo control; all60 cross-arm identities exact, actualMTP,
zero prompt cache reuse, expected admission resident counts, maximum physical
width at least logical wave width. Maximum-width metrics do not expose every
transient step shape; no claim of an observed complete4→3→2→1 batch trace.

Retain all per-request5%AND3ms phase flags against both controls and adaptive work
changes. A functional pass is separate from timing qualification. No SDK, GPU,
NVMe/admin probes, new profiler shim, driver/module/boot changes, added idle,
priming or full-table warming. The normal solo controls are recorded workload,
not an unreported table warmup. The inherited engine retains its10s post-stop
cleanup interval between fresh arms; no extra request-time idle is introduced. All stages acquire the shared model lock and
validate exact artifacts/settings/boot/topology/PIDs/native counters/kernel/idle.

From project root, with existing private ROCm/native environment and runtime lib:

```sh
python3 -u tp-cache-retention/ple-owner-wider-concurrency-v1/run.py
python3 tp-cache-retention/ple-owner-wider-concurrency-v1/analyze.py
```

The protocol freezes acquisition/analysis scripts before model launch. Scripts
need this lab's model paths, SSH management host and existing privileged read-only
inventory helpers. No generic network simulator is substituted.
