from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time

assert os.geteuid() == 0
root = Path('/home/rkuo/strix-dispatch-investigation')
base = Path(__file__).resolve().parent
mode, rank, pid = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
assert mode in ('baseline', 'candidate') and rank in (0, 1) and pid > 1
entry = json.loads((base / 'binaries.json').read_text())[mode]
binary = root / 'instrumentation/bin' / entry['name']
assert hashlib.sha256(binary.read_bytes()).hexdigest() == entry['sha256']
proc = Path('/proc') / str(pid)
folder = base / mode / f'trace-r{rank}'
dest = folder / 'gpu'
dest.mkdir()
owner = root.stat()
ram = Path('/dev/shm') / f'strix-mtp-gpu-{rank}-{pid}-{os.getpid()}'
assert not ram.exists() and shutil.disk_usage('/dev/shm').free > 2 * 1024**3
ram.mkdir()
os.chown(ram, owner.st_uid, owner.st_gid)
ram.chmod(0o700)
# The injected SDK writes from the target's UID, not the root collector.
# Verify actual creation/removal with that UID before attaching any profiler.
check = "from pathlib import Path;p=Path("+repr(str(ram / '.writecheck'))+");p.write_text('ok');p.unlink()"
subprocess.run(['/usr/bin/python3', '-c', check], user=owner.st_uid,
               group=owner.st_gid, extra_groups=[], check=True)
(dest / 'ram-permissions.json').write_text(json.dumps({
    'uid': ram.stat().st_uid, 'gid': ram.stat().st_gid,
    'mode': oct(ram.stat().st_mode & 0o777), 'target_uid_write_test': 'passed'})+'\n')
stack = Path('/home/rkuo/.local/opt/rocm-7.14.1')
env = dict(os.environ, LD_LIBRARY_PATH=':'.join([
    str(stack / 'lib'), str(root / 'dependencies/gufo-dev/usr/lib/x86_64-linux-gnu'),
    str(root / 'native-rdma/runtime/lib')]), PYTHONUNBUFFERED='1')
args = [str(stack / 'bin/rocprofv3'), '--attach', str(pid), '--attach-children=false',
        '--attach-duration-msec', '30000', '--attach-sync-output', 'true',
        '--kernel-trace', '--hip-runtime-trace', '--memory-copy-trace',
        '--output-format', 'csv', '--output-file', 'trace',
        '--output-directory', str(ram)]
(dest / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
profiler = None
start = time.monotonic()
ready_ns = None
status = {}
try:
    deadline = start + 60
    while True:
        assert proc.exists() and time.monotonic() < deadline, 'target/helper startup timeout'
        try:
            maps = (proc / 'maps').read_text()
            if (proc / 'exe').resolve() == binary and 'librocprofiler-sdk-attach.so' in maps:
                break
        except OSError:
            pass
        time.sleep(.02)
    (dest / 'helper-ready.json').write_text(json.dumps({
        'pid': pid, 'monotonic_ns': time.monotonic_ns(), 'binary_sha256': entry['sha256'],
        'scope': 'ROCP_TOOL_ATTACH helper mapped; wait performed during model loading.'}) + '\n')
    # Use the previously validated post-initialization attach boundary. Worker
    # preparation overlaps model loading, then the client starts both SDKs as
    # soon as HTTP is ready and records the necessary setup delay.
    deadline = time.monotonic() + 90
    while not (folder / 'gpu.start').exists():
        assert proc.exists() and time.monotonic() < deadline, 'SDK start marker timeout'
        time.sleep(.02)
    with (ram / 'attach.log').open('x') as log:
        profiler = subprocess.Popen(args, env=env, stdout=log, stderr=subprocess.STDOUT)
        (dest/'profiler-process.json').write_text(json.dumps({'pid':profiler.pid,'supervisor_pid':os.getpid()})+'\n')
        attach_start = time.monotonic()
        while profiler.poll() is None and time.monotonic() - attach_start < 100:
            text = (ram / 'attach.log').read_text()
            if ready_ns is None and ':: success' in text and 'Attaching for 30000 msec' in text:
                ready_ns = time.monotonic_ns()
                (folder / 'gpu.ready').write_text(str(ready_ns) + '\n')
                (folder / 'gpu.ready').chmod(0o644)
            if not proc.exists():
                break
            time.sleep(.1)
        if profiler.poll() is None:
            profiler.send_signal(signal.SIGINT)
            profiler.wait(timeout=15)
    log_text = (ram / 'attach.log').read_text()
    valid = (profiler.returncode == 0 and ready_ns is not None and
             'Detaching from PID' in log_text and 'Detachment failed' not in log_text and
             bool(list(ram.glob('*kernel_trace.csv'))))
    status = {'exit': profiler.returncode, 'complete': valid, 'ready_ns': ready_ns,
              'finished_monotonic_ns': time.monotonic_ns(),
              'independent_SDK_drop_counter_available': False,
              'collection_output': 'RAM during collection; persisted only after profiler exits'}
    assert valid, log_text[-1500:]
except BaseException as error:
    status = {'complete': False, 'ready_ns': ready_ns, 'error': repr(error)}
    raise
finally:
    if profiler is not None and profiler.poll() is None:
        profiler.send_signal(signal.SIGINT)
        try:
            profiler.wait(timeout=15)
        except subprocess.TimeoutExpired:
            profiler.terminate()
            profiler.wait(timeout=10)
    shutil.copytree(ram, dest, dirs_exist_ok=True)
    shutil.rmtree(ram)
    (dest / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
    for path in [dest] + list(dest.rglob('*')):
        os.chown(path, owner.st_uid, owner.st_gid)
        if path.is_file():
            path.chmod(0o644)
