from pathlib import Path
import json,shlex,subprocess,time
class GPU:
 def __init__(self,base):self.base=base
 def call(self,rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args,text=True,stderr=subprocess.STDOUT,timeout=30)
 def __enter__(self):
  start=time.monotonic()
  for rank in(0,1):self.call(rank,['touch',str(self.base/'candidate'/f'trace-r{rank}/gpu.start')])
  while True:
   states=[]
   for rank in(0,1):
    folder=self.base/'candidate'/f'trace-r{rank}'
    states.append(json.loads(self.call(rank,['python3','-c','from pathlib import Path;import json,sys;p=Path(sys.argv[1]);print(json.dumps(dict(ready=(p/"gpu.ready").exists(),ended=(p/"gpu/status.json").exists())))',str(folder)])))
   assert not any(x['ended']for x in states),states
   if all(x['ready']for x in states):break
   assert time.monotonic()-start<60,'GPU ready timeout'
   time.sleep(.1)
  (self.base/'gpu-setup.json').write_text(json.dumps(dict(setup_seconds=time.monotonic()-start,requests_begin_monotonic_ns=time.monotonic_ns(),scope='Existing standard SDK post-initialization attachment, no hardware counters or custom ABI shim; observed execution may be perturbed.'),indent=2)+'\n')
  return self
 def __exit__(self,*exc):
  statuses={};deadline=time.monotonic()+100
  while len(statuses)<2:
   for rank in(0,1):
    if rank in statuses:continue
    try:statuses[rank]=json.loads(self.call(rank,['cat',str(self.base/'candidate'/f'trace-r{rank}/gpu/status.json')]))
    except subprocess.CalledProcessError:pass
   assert time.monotonic()<deadline,'GPU detach timeout'
   if len(statuses)<2:time.sleep(.2)
  (self.base/'GPU-statuses.json').write_text(json.dumps(statuses,indent=2)+'\n')
  subprocess.run(['rsync','-a','--no-owner','--no-group',f'rk-corsair-ai:{self.base}/candidate/trace-r1/',str(self.base/'candidate/trace-r1')+'/'],check=True)
  assert all(v.get('complete')and v.get('exit')==0 for v in statuses.values()),statuses
