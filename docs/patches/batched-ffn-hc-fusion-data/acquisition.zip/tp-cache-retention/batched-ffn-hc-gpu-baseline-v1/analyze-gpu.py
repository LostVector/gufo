from pathlib import Path
import collections,csv,json,re,statistics
out=Path(__file__).resolve().parent;r=out.parents[1]
assert json.loads((out/'validation.json').read_text())['functional_qualification_pass']
statuses=json.loads((out/'GPU-statuses.json').read_text());assert all(s['complete']and s['exit']==0 for s in statuses.values())
def fields(s):return {k:int(v)if re.fullmatch(r'-?\d+',v)else v for k,v in re.findall(r'(\w+)=([^ ]+)',s)}
def merged(spans):
 result=[]
 for a,b in sorted(spans):
  if b<=a:continue
  if result and a<=result[-1][1]:result[-1]=(result[-1][0],max(b,result[-1][1]))
  else:result.append((a,b))
 return result
def length(spans):return sum(b-a for a,b in merged(spans))
def clip(a,b,start,end):return(max(start,a),min(end,b))
def category(name):
 if 'WaitValueKernel'in name:return'wait_value'
 if name.startswith('__amd_rocclr_copy')or name.startswith('__amd_rocclr_fill'):return'runtime_copy_fill'
 return'model_or_other_kernel'
def ns(x):return int(x['Start_Timestamp']),int(x['End_Timestamp'])
report=dict(scope='Standard SDK HIP/kernel/copy trace, first4realC3 target-forward windows, baseline source9c. Bracketed public SDK timestamp aligns each same-host C++ window; never subtract peer clocks. Kernel classes by name, not FLOPs. WaitValue is a required dependency spin, not useful compute or automatically avoidable work. API/kernel categories overlap; do not add host API wall to GPU wall. Uncovered trace time may contain needed transport/CPU work, runtime/otherGPU work or unobserved activity; not established avoidable launch latency. SDK exposes no independent loss counter. Instrumented timings, not untraced speed/equivalence.',ranks=[])
for rank in(0,1):
 parent=r/'results/model-scaling';parent=parent/'corsair'if rank else parent
 lines=(parent/f'{out.name}-candidate-rank{rank}.stderr').read_text().splitlines();clocks={};stages={}
 for s in lines:
  if s.startswith('C3_CLOCK '):
   e=fields(s);assert e['rank']==rank and e['status']==0 and 0<e['after_ns']-e['before_ns']<=200000;clocks[e['cycle']]=e
  elif s.startswith('C3_STAGE '):
   e=fields(s)
   if e['stage']=='target-forward':stages[e['cycle']]=e
 assert set(clocks)==set(stages)=={1,2,3,4}
 offsets=[x['sdk_ns']-(x['before_ns']+x['after_ns'])//2 for x in clocks.values()];assert max(offsets)-min(offsets)<=50000
 d=out/'candidate'/f'trace-r{rank}/gpu'
 def load(name):
  with(d/name).open()as f:return list(csv.DictReader(f))
 kernels=load('trace_kernel_trace.csv');apis=load('trace_hip_api_trace.csv');copies=load('trace_memory_copy_trace.csv');windows=[]
 for cid in(1,2,3,4):
  pair=clocks[cid];offset=pair['sdk_ns']-(pair['before_ns']+pair['after_ns'])//2;a=stages[cid]['begin_ns']+offset;b=stages[cid]['end_ns']+offset;wall=b-a
  assert statuses[str(rank)]['ready_ns']<=stages[cid]['begin_ns']<stages[cid]['end_ns']<=statuses[str(rank)]['finished_monotonic_ns']
  assert min(ns(k)[0]for k in kernels)<a and max(ns(k)[1]for k in kernels)>b
  ks=[k for k in kernels if ns(k)[0]<b and ns(k)[1]>a];cp=[k for k in copies if ns(k)[0]<b and ns(k)[1]>a];aa=[k for k in apis if ns(k)[0]<b and ns(k)[1]>a];assert ks and aa
  assert len({k['Dispatch_Id']for k in ks})==len(ks)
  allspans=[clip(*ns(k),a,b)for k in ks+cp];gpu_union=merged(allspans);covered=length(allspans)
  dispatch_threads=collections.Counter(k['Thread_Id']for k in ks);main_tid=dispatch_threads.most_common(1)[0][0];main_api=[x for x in aa if x['Thread_Id']==main_tid]
  waits=[x for x in main_api if x['Function']in('hipStreamSynchronize','hipEventSynchronize','hipDeviceSynchronize')]
  launches=[x for x in main_api if 'Launch'in x['Function']]
  fn=collections.defaultdict(list)
  for x in main_api:fn[x['Function']].append(clip(*ns(x),a,b))
  names=collections.defaultdict(list);classes=collections.defaultdict(list);shapes=collections.defaultdict(list)
  for x in ks:
   interval=clip(*ns(x),a,b);names[x['Kernel_Name']].append(interval);classes[category(x['Kernel_Name'])].append(interval)
   key=(x['Kernel_Name'],x['Grid_Size_X'],x['Grid_Size_Y'],x['Grid_Size_Z'],x['Workgroup_Size_X'],x['Workgroup_Size_Y'],x['Workgroup_Size_Z']);shapes[key].append(interval)
  gaps=[];previous=a
  for begin,end in gpu_union:
   if begin>previous:gaps.append((previous,begin))
   previous=end
  if previous<b:gaps.append((previous,b))
  gapinfo=[]
  for begin,end in sorted(gaps,key=lambda s:s[1]-s[0],reverse=True)[:20]:
   before=[k for k in ks if ns(k)[1]<=begin];after=[k for k in ks if ns(k)[0]>=end]
   overlap=collections.defaultdict(list)
   for x in main_api:
    s,z=ns(x)
    if s<end and z>begin:overlap[x['Function']].append(clip(s,z,begin,end))
   gapinfo.append(dict(begin_sdk_ns=begin,end_sdk_ns=end,duration_us=(end-begin)/1000,preceding_kernel=max(before,key=lambda k:ns(k)[1])['Kernel_Name']if before else None,following_kernel=min(after,key=lambda k:ns(k)[0])['Kernel_Name']if after else None,overlapping_main_API_us={k:length(v)/1000 for k,v in overlap.items()}))
  models=length(classes['model_or_other_kernel']);waitvals=length(classes['wait_value']);runtime=length(classes['runtime_copy_fill']);copies_union=length([clip(*ns(x),a,b)for x in cp]);launch_union=length([clip(*ns(x),a,b)for x in launches]);wait_union=length([clip(*ns(x),a,b)for x in waits]);api_union=length([clip(*ns(x),a,b)for x in main_api])
  launch_spans=[clip(*ns(x),a,b)for x in launches]; wait_spans=[clip(*ns(x),a,b)for x in waits]
  launch_gpu_overlap=launch_union+covered-length(launch_spans+allspans);wait_gpu_overlap=wait_union+covered-length(wait_spans+allspans)
  windows.append(dict(cycle=cid,rows=stages[cid]['rows'],wall_ms=wall/1e6,clock_offset_ns=offset,clock_bracket_ns=pair['after_ns']-pair['before_ns'],GPU_kernel_dispatches=len(ks),GPU_kernel_union_ms=length([clip(*ns(x),a,b)for x in ks])/1e6,GPU_kernel_or_copy_union_ms=covered/1e6,model_or_other_kernel_union_ms=models/1e6,wait_value_kernel_union_ms=waitvals/1e6,wait_value_kernel_count=sum(category(x['Kernel_Name'])=='wait_value'for x in ks),runtime_copy_fill_kernel_union_ms=runtime/1e6,memory_copy_activity_union_ms=copies_union/1e6,not_covered_by_GPU_records_ms=(wall-covered)/1e6,inferred_dispatch_thread=int(main_tid),dispatch_thread_counts=dict(dispatch_threads),main_API_union_ms=api_union/1e6,main_API_sync_wait_union_ms=wait_union/1e6,main_API_launch_union_ms=launch_union/1e6,main_API_launch_GPU_overlap_ms=launch_gpu_overlap/1e6,main_API_launch_not_GPU_covered_ms=(launch_union-launch_gpu_overlap)/1e6,main_API_sync_GPU_overlap_ms=wait_gpu_overlap/1e6,main_API_other_union_ms=(api_union-wait_union-launch_union)/1e6,outside_main_HIP_API_union_ms=(wall-api_union)/1e6,main_API_functions=[dict(function=k,count=len(v),union_ms=length(v)/1e6,sum_clipped_ms=sum(z-s for s,z in v)/1e6)for k,v in sorted(fn.items(),key=lambda kv:length(kv[1]),reverse=True)],top_kernels=[dict(name=k,count=len(v),union_ms=length(v)/1e6,sum_clipped_ms=sum(z-s for s,z in v)/1e6)for k,v in sorted(names.items(),key=lambda kv:length(kv[1]),reverse=True)],kernel_shapes=[dict(name=k[0],grid=list(k[1:4]),workgroup=list(k[4:]),count=len(v),sum_clipped_ms=sum(z-s for s,z in v)/1e6)for k,v in sorted(shapes.items(),key=lambda kv:sum(z-s for s,z in kv[1]),reverse=True)],largest_uncovered_gaps=gapinfo,idealized_gain_ceiling_for_uncovered_gaps_only=wall/covered,ceiling_scope='Hypothetically filling every uncovered interval while preserving all traced GPU activity at the same speed; not attainable savings or bound on wait-value/transport optimization.'))
 report['ranks'].append(dict(rank=rank,clock_offset_drift_ns=max(offsets)-min(offsets),SDK_kernel_records=len(kernels),SDK_API_records=len(apis),SDK_copy_records=len(copies),windows=windows))
(out/'gpu-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
with(out/'gpu-summary.csv').open('w')as f:
 names=['rank','cycle','rows','wall_ms','GPU_kernel_dispatches','GPU_kernel_or_copy_union_ms','model_or_other_kernel_union_ms','wait_value_kernel_union_ms','not_covered_by_GPU_records_ms','main_API_sync_wait_union_ms','main_API_launch_union_ms','outside_main_HIP_API_union_ms'];w=csv.DictWriter(f,fieldnames=names);w.writeheader()
 for rank in report['ranks']:
  for e in rank['windows']:w.writerow({k:rank['rank']if k=='rank'else e[k]for k in names})
for rank in report['ranks']:
 for e in rank['windows']:print(rank['rank'],e['cycle'],'rows',e['rows'],{k:round(e[k],4)for k in('wall_ms','GPU_kernel_or_copy_union_ms','model_or_other_kernel_union_ms','wait_value_kernel_union_ms','not_covered_by_GPU_records_ms','main_API_sync_wait_union_ms','main_API_launch_union_ms','outside_main_HIP_API_union_ms')})
