"""Analyze the complete fixed12pair study only; no interim testing."""
from pathlib import Path
import hashlib,itertools,json,math,random,sys
# All means are explicit sums; this analysis has no numerical package dependency.
p=Path(__file__).resolve().parent;r=p.parents[1]
assert(p/'complete').exists();v=json.loads((p/'validation.json').read_text());assert v['functional_qualification_pass'] and v['canonical_records']==624
protocol=json.loads((p/'protocol.json').read_text());design=protocol['design'];assert len(protocol['sequence'])==24
inputs={};data={}
for phase,role in protocol['sequence']:
 f=r/'results/model-scaling'/f'{p.name}-{phase}.jsonl';inputs[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest();xs=[json.loads(s)for s in f.read_text().splitlines()];assert len(xs)==26;data[phase]=xs
mean=lambda xs:sum(xs)/len(xs)
results=[]
for width in [2,4,8]:
 ratios=[];raw=[];observed=[]
 for pair in range(1,13):
  scores={}
  for arm in ['baseline','candidate']:
   xs=[x for x in data[f'pair{pair:02d}-{arm}']if x['case']==f'C{width}'];assert len(xs)==width
   span=max(x['finished_at']for x in xs)-min(x['started_at']for x in xs);assert span>0
   scores[arm]=sum(x['completion_tokens']for x in xs)/span
  ratios.append(math.log(scores['candidate']/scores['baseline']));raw.append({'pair':pair,**scores});observed.append(1 if pair in design['randomization']['baseline_first_pairs']else-1)
 assert sorted(observed)==[-1]*6+[1]*6
 center=mean(ratios);null=[mean([v*s for v,s in zip(ratios,signs)])for signs in itertools.product([-1,1],repeat=12)]
 balanced=[]
 for chosen in itertools.combinations(range(12),6):
  chosen=set(chosen);balanced.append(mean([v*o*(1 if i in chosen else-1)for i,(v,o)in enumerate(zip(ratios,observed))]))
 rng=random.Random(202611021601+width);boot=sorted(mean(rng.choices(ratios,k=12))for _ in range(20000));lo,hi=boot[500],boot[19499]
 results.append({'co_primary':f'C{width}-client-wave','pairs':12,'per_pair':raw,'paired_log_ratios':ratios,'mean_log_ratio':center,'paired_geometric_throughput_change_pct':100*math.expm1(center),'marginal_bootstrap95_change_pct':[100*math.expm1(lo),100*math.expm1(hi)],'signflip_p':sum(abs(x)>=abs(center)-1e-12 for x in null)/4096,'signflip_assumption':'Pairwise log-ratio sign symmetry,4096patterns; balanced assignment sensitivity separate.','balanced_assignment_sensitivity_p':sum(abs(x)>=abs(center)-1e-12 for x in balanced)/924,'positive_pairs':sum(x>0 for x in ratios),'negative_pairs':sum(x<0 for x in ratios)})
adjusted=0
for i,x in enumerate(sorted(results,key=lambda x:x['signflip_p'])):
 adjusted=max(adjusted,(3-i)*x['signflip_p']);x['holm3_signflip_p']=min(1.,adjusted);x['confirmatory_gain']=x['holm3_signflip_p']<=.05 and x['marginal_bootstrap95_change_pct'][0]>0
report={'scope':'Prespecified12pair completeclientwave throughput; unprofiled fullrelease9c/74f,3co-primaries,Holm3signflip with marginalpairedbootstrapCI andbalancedassignment sensitivity. No pooled earlier tests/exclusions/replacements/interimtesting. Small gain not rejected by size. Source/runtime/output/phase flags remain separate and mandatory; no equivalence inference from null result.','input_sha256':inputs,'primary_results':results,'strict_phase_flag_entries':len(v['strict_phase_flags']),'adaptive_work_fields':len(v['adaptive_work_fields']),'functional_pass':True}
(p/'statistics.json').write_text(json.dumps(report,indent=2)+'\n')
for x in results:print(x['co_primary'],x['paired_geometric_throughput_change_pct'],x['marginal_bootstrap95_change_pct'],'Holm3 p',x['holm3_signflip_p'],'confirmatory',x['confirmatory_gain'])
