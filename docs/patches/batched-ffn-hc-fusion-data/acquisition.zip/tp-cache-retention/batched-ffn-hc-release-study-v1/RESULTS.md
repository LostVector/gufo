# Fixed study result: serving gain remains inconclusive

All24starts/12balancedrandomizedpairs completed underexec67970, observed terminal0. All624 prompt/output/cache-work identities and matching solo controls pass, including actualMTP/source/binary/settings/PID/boot/topology/kernel/driver/idle guards. No transport-error deltas. The full release pair has336identical normalizedcompilecommands and one changed compiledsource, batch.cpp.

| Co-primary completeclient-wave | Paired change | Marginal95% paired bootstrapCI | Holm3 signflip p |
| --- | ---: | --- | ---: |
| C2-client-wave | +0.3694% | [-0.000628%, +0.758381%] | 0.282715 |
| C4-client-wave | +0.2110% | [-0.075363%, +0.501275%] | 0.386719 |
| C8-client-wave | +0.0581% | [-0.825238%, +0.926523%] | 0.898438 |

None meets the prespecified significance criterion. This is inconclusive, not equivalence, rejection by small gain size or proof of no benefit. No new starts, exclusions, replacements or historical pooling were used. Co-primary metrics include queue/prefill/stream completion; they are not pureGPUdecode or sum of individual requestdecode rates. Capacity65536 is not actual promptdepth: concurrent prompts are shallow and C1 controls actual2048tokens, max128output.

## Per-request observations

There are228flagentries across64unique paired request comparisons at5%AND3ms. Correlated client/server/raw fields are not228independent regressions.291adaptive-work comparisons change (114proposalcounts,91acceptedcounts,86roundcounts), all in concurrentC2/C4/C8; C1/solo work matches. Original flags and all work are preserved in validation.json/phase-flags.csv/adaptive-work.csv.

A posthoc descriptive audit (phase-audit.json) finds both modes in unchanged controls: C4actor2firstgap ranges~138–216ms inbaseline and~137–216ms incandidate, with7/12baseline and5/12candidate observations above180ms. Three paired candidate-only highmode flags are mirrored by five baseline-only highmodes in otherpairs. C8actor7TTFT likewise occupies overlapping~1.64–1.83s ranges inboth. This does not clear any flags or establish a scheduling cause; no equalcyclework is inferred from aggregatecounts. Necessary nextattribution, if pursued, is narrowlyactualC4/C8firstpublication scheduling/work, not broadSSD/driver sweeps.

## Decision and next actions

Keep74f isolated and unadopted. Independent trace proves384fewerGPUlaunches/48existingfusedHCcalls pereligible3/8rowtargetpass (~17.2%); nine-row fallback unchanged. That component improvement alone does not demonstrate practical servinggain. Validate the additivebatch-reference regressiontest preservingalloldercases, prepare honest component/evidence review, and independently qualify any canonicalTP1port. ExistingPR14 is separate. Latestcanonicalb911capacity-error message intake remains a separate correctnesssync.

Figures are supplemental post-completion output in ../batched-ffn-hc-review-prep-v1/paired-performance.png/.pdf, generated with existing project.venv. Initial systemPython lackedmatplotlib; report.log preserves that failedplotattempt and report-venv.log the successfulretry. No measurement was rerun.
