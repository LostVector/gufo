from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,secrets,shlex,subprocess,time
root=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
lock=(root/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'protocol.json').exists()
def call(rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','rk-corsair-ai',shlex.join(args)]if rank else args,text=True,stderr=subprocess.STDOUT,timeout=90)
def inventory(tag):
 rows=[]
 for rank in(0,1):
  d=json.loads(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']));rows.append(d);(out/f'{tag}-r{rank}.json').write_text(json.dumps(d,indent=2)+'\n')
 return rows
def snapshot(tag):
 for rank in(0,1):(out/f'{tag}-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
qualified=json.loads((root/'tp-cache-retention/fork-integration-v1/extension-http-qualified.json').read_text())
assert len(qualified['checks'])>=7
for name,gate in qualified['checks'].items():
 assert hashlib.sha256(Path(gate['path']).read_bytes()).hexdigest()==gate['sha256'],name
gates=json.loads((out/'functional-gates.json').read_text())
for label,item in gates.items():
 assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],label
initial=inventory('initial-inventory');assert all(x['refcnt']==0 and x['module']=='81C6FF2FBAC473C7AB21844' and len(x['devices'])==4 for x in initial);bins=json.loads((out/'binaries.json').read_text());source=json.loads((out/'source-preflight.json').read_text());design=json.loads((out/'design.json').read_text())
for role,meta in source.items():
 for n,h in meta['source_sha256'].items():assert hashlib.sha256((Path(meta['path'])/n).read_bytes()).hexdigest()==h,n
for entry in bins.values():
 p=root/'instrumentation/bin'/entry['name'];assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'];subprocess.run(['rsync','-a',str(p),f'rk-corsair-ai:{p}'],check=True);assert call(1,['sha256sum',str(p)]).split()[0]==entry['sha256']
call(1,['mkdir','-p',str(out)]);subprocess.run(['rsync','-a',str(out/'server-rank.sh'),f'rk-corsair-ai:{out}/server-rank.sh'],check=True)
spec=importlib.util.spec_from_file_location('engine',out/'engine.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
os.environ.update(SCALING_NATIVE_RDMA='1',STRIX_SESSIONS='8',STRIX_CONTEXT='65536',STRIX_CHUNK='2048',STRIX_SPECULATION='mtp',SCALING_REQUEST_SCRIPT=str(out/'requests.py'))
for key in('LD_PRELOAD','ROCP_TOOL_ATTACH','STRIX_READ_OUTPUT','STRIX_FINISH_TRACE','GUFO_TP_TRACE_PREFIX'):os.environ.pop(key,None)
p=dict(initial=initial,binaries=bins,design=design,sequence=design['sequence'],settings=dict(quant='UD-Q4_K_XL',MTP='sharedQ8_0/enabled/current upstream confidence controller',context_capacity=65536,sessions=8,chunk=2048,cache_RAM_bytes=1073741824,driver='81C6/TX32 unchanged in all arms',device='existing lexical-first HTTPHCA0',thinking='off',sampling='greedy'),harness_sha256={n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in('run.py','requests.py','analyze.py','engine.py','server-rank.sh','binaries.json','source-preflight.json','design.json','release-build-provenance.json','paired-summary.py','functional-gates.json')},external_harness_sha256={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in('reference/gufo-rdma/tools/gufo/serving_bench.py','prefill-scaling/results/prompts.json','native-rdma/env.sh','cable-prep/env.sh','tp-cache-retention/driver-parent-timing-v1/inventory.py')})
(out/'protocol.json').write_text(json.dumps(p,indent=2)+'\n');token=root/'model-scaling/control-token';assert not token.exists();start=int(time.time())-2;reference=None
identity=('case','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256')

try:
 token.write_text(secrets.token_hex(32));token.chmod(0o600);subprocess.run(['rsync','-a',str(token),f'{e.peer}:{token}'],check=True)
 for phase,role in design['sequence']:
  inventory(phase+'-initial-inventory');snapshot(phase+'-before');print(time.strftime('%F %T'),'START',phase,flush=True)
  e.run(out.name+'-'+phase,2,e.local,bins[role]['name'].removeprefix('gufo-'));snapshot(phase+'-after');inventory(phase+'-final-inventory')
  rows=sorted([json.loads(s)for s in(e.out/f'{out.name}-{phase}.jsonl').read_text().splitlines()if s.strip()],key=lambda r:r['order']);assert len(rows)==design['requests_per_start']
  ids=[{k:r[k]for k in identity}for r in rows]
  if reference is None:reference=ids
  assert ids==reference,(phase,'canonical output/prompt/cache work mismatch')
  assert all(r['cached_prompt_tokens']==0 and r['prefill_tokens']==r['prompt_tokens']and r['draft_tokens']>0 for r in rows)
  (out/f'{phase}-complete').touch();print(time.strftime('%F %T'),'PASS',phase,flush=True)
 (out/'complete').touch();e.status('COMPLETE '+out.name)
finally:
 token.unlink(missing_ok=True);subprocess.run(['ssh',e.peer,'rm','-f',str(token)],check=False);errors=[]
 try:inventory('final-inventory')
 except Exception as ex:errors.append(repr(ex))
 for rank in(0,1):
  try:(out/f'kernel-window-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-driver-lab','run','fork-integration/hardware/kernel-window.py',str(start)]))
  except Exception as ex:errors.append(repr(ex))
 (out/'cleanup.json').write_text(json.dumps(dict(errors=errors),indent=2)+'\n');assert not errors,errors
