from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess
out=Path(__file__).resolve().parent;r=out.parents[1];build=r/'tp-cache-retention/tp2-upstream-773a1641-gpu-build';source=r/'tp-cache-retention/tp2-upstream-773a1641-worktree'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'commands.json').exists()
entries=json.loads((build/'compile_commands.json').read_text());e=next(e for e in entries if e['file'].endswith('/tests/models/qwen38_flash_next/hc_mix_ops_test.cpp'));cmd=shlex.split(e['command']);cmd[cmd.index('-o')+1]=str(out/'probe.o');cmd[-1]=str(out/'probe.cpp');assert '-DENGINE_ENABLE_HIP=1'in cmd and '-UNDEBUG'in cmd
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','qwen38_flash_next_hc_mix_ops_test'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2];i=next(i for i,x in enumerate(link)if x.endswith('/hc_mix_ops_test.cpp.o'));link[i]=str(out/'probe.o');link[link.index('-o')+1]=str(out/'probe')
if '-Xlinker'in link:
 i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
env=os.environ.copy();env['CPLUS_INCLUDE_PATH']=str(r/'dependencies/gufo-dev/usr/include/x86_64-linux-gnu');env['LD_LIBRARY_PATH']=str(r/'dependencies/gufo-dev/usr/lib/x86_64-linux-gnu')+':/home/rkuo/.local/opt/rocm-7.14.1/lib'
(out/'commands.json').write_text(json.dumps(dict(compile=cmd,link=link,cwd=str(build),source=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),source_sha256=hashlib.sha256((out/'probe.cpp').read_bytes()).hexdigest(),scope='Contract rejection screen, not optimization patch or performance artifact. Current CombineBatch Vec4 plus separate norm/lo/mixed quantization reference against existing fused scalar mixer, rows1..8/injectoffon/three scales, all original exact/intermediate/alias/graph/finite assertions. No production source/library/GPU changes or tolerances relaxed.'),indent=2)+'\n')
with(out/'build.log').open('w')as f:
 for c in(cmd,link):subprocess.run(c,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
with(out/'run.log').open('w')as f:p=subprocess.run([str(out/'probe')],env=env,stdout=f,stderr=subprocess.STDOUT)
(out/'result.json').write_text(json.dumps(dict(exit=p.returncode,binary_sha256=hashlib.sha256((out/'probe').read_bytes()).hexdigest(),scope='Strict production-batch arithmetic contract; any mismatch rejects routing as-is. No performance test or engine patch has been attempted.'),indent=2)+'\n');print((out/'run.log').read_text()[-3000:]);print('Contract exit',p.returncode)
