from pathlib import Path
import json,hashlib,re,csv,subprocess,shlex
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent;assert(o/'complete').exists();p=json.loads((o/'protocol.json').read_text())
for n,h in p['harness_sha256'].items():assert hashlib.sha256((o/n).read_bytes()).hexdigest()==h,n
for n,h in p['external_harness_sha256'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
pre=json.loads((o/'source-preflight.json').read_text())
for n,h in pre['source_sha256'].items():assert hashlib.sha256((Path(pre['path'])/n).read_bytes()).hexdigest()==h,n
assert hashlib.sha256((o/'probe').read_bytes()).hexdigest()==p['probe_sha256']['candidate'];data=[]
for rank in[0,1]:
 xs=[json.loads(s)for s in(o/f'candidate-r{rank}.jsonl').read_text().splitlines()]
 assert len(xs)==1992
 assert 'PASS records=1992 actual_ffn_hc_batches=180 full_state_pairs=498' in(o/f'candidate-r{rank}.stdout').read_text()
 cases={'C2-n2':(2,2),'C3-n3':(3,3),'C5-n5':(5,5),'C7-n7':(7,7),'C8-fallback9':(8,9),'C8-fallback12':(8,12),'C4-n4':(4,4),'C4-n5':(4,5),'C4-n7':(4,7),'C4-fallback8':(4,8),'C6-n6':(6,6),'C6-n7':(6,7),'C6-fallback8':(6,8),'C8-fallback8':(8,8),'C4-mixedAR-n4':(4,4),'C4-mixedAR-n5':(4,5)}
 keys={}
 for x in xs:
  key=tuple(x[k] for k in ['depth','mode','case','arm','stage','actor'])
  assert key not in keys
  keys[key]=x
  assert len(x['scores_sha256'])==64 and x['tokens'] and x['position']>x['depth']
 for depth in [0,32768]:
  for mode in ['greedy','sampled','mixed-sampler']:
   for case,(width,rows) in cases.items():
    for stage in [0,1]:
     for actor in range(width):
      a,b=[keys[(depth,mode,case,arm,stage,actor)]for arm in ['unfused','fused']]
      assert all(a[k]==b[k]for k in ['depth','mode','case','stage','actor','rows','position','rng','drafted','accepted','scores_sha256','tokens'])
      expected_rows=rows if stage==0 else width
      assert a['rows']==expected_rows and a['ffn_hc_eligible']==0
      assert b['ffn_hc_eligible']==int(expected_rows<=8)
 assert sum(x['ffn_hc_eligible'] for x in xs if x['actor']==0)==180
 pid=(o/f'candidate-r{rank}.pid').read_text().strip();args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',pid];subprocess.run(['ssh','rk-corsair-ai',shlex.join(args)]if rank else args,check=True)
 def counters(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(o/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
 a,b=counters('candidate-before'),counters('candidate-after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());assert not{k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
 initial=p['initial'][rank];final=json.loads((o/f'final-inventory-r{rank}.json').read_text());assert final['refcnt']==0 and len(final['devices'])==4 and all(initial[k]==final[k]for k in ['module','boot_id','cmdline','routers']);assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout',(o/f'kernel-window-r{rank}.txt').read_text(),re.I);data.append(xs)
assert data[0]==data[1]
report=dict(records_per_rank=1992,paired_cases_per_rank=96,actual_FFN_HC_eligible_cycles_per_rank=180,complete_materialized_state_pairs_per_rank=498,actual_concurrencies=[2,3,4,5,6,7,8],contexts=["short",32768],context_capacity=65536,all_complete_scores_tokens_positions_RNG_proposal_work_exact=True,eligible_and_fallback_row_counts_verified=True,cross_rank_records_exact=True,frozen_sources_harness_binary_PIDs_counters_kernel_boot_topology_idle_pass=True,scope=p['scope'],limits='Diagnostic host toggle/counters; identical qualified GPU/transport math. Complete state byte equality asserted within rank. No natural adaptive HTTP speed, serialized/borrowed/disk cache or batch-context failure/recovery claim.')
(o/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
