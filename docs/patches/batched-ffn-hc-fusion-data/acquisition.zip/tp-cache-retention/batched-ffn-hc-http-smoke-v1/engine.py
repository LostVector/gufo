#!/usr/bin/env python3
"""Resumable, task-owned model download + matched Gufo scaling experiment."""
import hashlib,json,os,pathlib,secrets,shlex,subprocess,sys,time,urllib.request
root=pathlib.Path('/home/rkuo/strix-dispatch-investigation');os.chdir(root)
out=root/'results/model-scaling';out.mkdir(parents=True,exist_ok=True)
peer='rkuo@rk-corsair-ai';local='rkuo@localhost'
def status(s):
 print(time.strftime('%Y-%m-%d %H:%M:%S'),s,flush=True);(out/'status.txt').write_text(s+'\n')
def call(cmd,**kw):return subprocess.run(cmd,check=True,**kw)
def remote(host,cmd,**kw):return call(['ssh','-o','BatchMode=yes',host,cmd],**kw)
def wait_ready(host,processes):
 for _ in range(120):
  for p in processes:
   if p.poll() is not None:raise RuntimeError('A server exited before readiness; inspect rank logs')
  try:
   with urllib.request.urlopen('http://'+host+':28530/v1/models',timeout=2) as r:
    if r.status==200:return
  except Exception:pass
  time.sleep(1)
 raise TimeoutError('Server loading exceeded 30 minutes')
expected_by_label={}
def stop(host,label,rank):
 code="from pathlib import Path\nimport os,signal,sys\nroot=Path('/home/rkuo/strix-dispatch-investigation')\npid=int((root/'results/model-scaling'/f'{sys.argv[1]}-rank{sys.argv[2]}.pid').read_text())\nproc=Path('/proc')/str(pid)\nif proc.exists():\n assert (proc/'exe').resolve()==Path(sys.argv[3])\n os.kill(pid,signal.SIGINT)\n"
 subprocess.run(['ssh','-o','BatchMode=yes',host,shlex.join(['python3','-c',code,label,str(rank),expected_by_label[label]])],check=True)
def run(label,world,head=local,binary='baseline'):
 expected_by_label[label]=str(root/'instrumentation/bin'/('gufo-'+binary))
 status('RUNNING '+label)
 remote(peer,f'mkdir -p {root}/results/model-scaling')
 processes=[];hosts=[(head,0)] if world==1 else [(local,0),(peer,1)]
 try:
  for host,rank in hosts:
   native_setting='SCALING_NATIVE_RDMA=1 STRIX_CONTEXT='+os.environ.get('STRIX_CONTEXT','4096')+' STRIX_CHUNK='+os.environ.get('STRIX_CHUNK','512')+' STRIX_SPECULATION='+os.environ.get('STRIX_SPECULATION','off')+' STRIX_SESSIONS='+os.environ.get('STRIX_SESSIONS','2')+' ' if os.environ.get('SCALING_NATIVE_RDMA')=='1' else ''
   cmd=f'cd {root}; {native_setting}/home/rkuo/strix-dispatch-investigation/tp-cache-retention/batched-ffn-hc-http-smoke-v1/server-rank.sh {label} {world} {rank} {binary}'
   processes.append(subprocess.Popen(['ssh','-o','BatchMode=yes',host,cmd]))
  # HTTP binds to localhost. Forward the Corsair single-host test through SSH.
  tunnel=None
  if head==peer:
   tunnel=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ExitOnForwardFailure=yes','-N','-L','127.0.0.1:28533:127.0.0.1:28530',peer])
  port=28533 if head==peer else 28530
  # readiness through the tunnel, preserving local-only inference listeners.
  for _ in range(120):
   codes=[p.poll() for p in processes]
   if any(code is not None for code in codes):raise RuntimeError('Server exited; inspect rank logs: '+repr(codes))
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=2) as r:
     if r.status==200:break
   except Exception:pass
   time.sleep(1)
  else:raise TimeoutError('Load timeout')
  call([sys.executable,os.environ.get('SCALING_REQUEST_SCRIPT','model-scaling/requests.py'),str(out/f'{label}.jsonl'),f'http://127.0.0.1:{port}'])
 finally:
  # Stop the head first, allowing worker control disconnect to unwind and dump traces.
  stop(hosts[0][0],label,hosts[0][1])
  try:processes[0].wait(timeout=60)
  except subprocess.TimeoutExpired:pass
  if len(hosts)>1 and processes[1].poll() is None:
   try:processes[1].wait(timeout=10)
   except subprocess.TimeoutExpired:stop(hosts[1][0],label,hosts[1][1])
  for p in processes:
   try:p.wait(timeout=60)
   except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
  if 'tunnel' in locals() and tunnel is not None:tunnel.terminate();tunnel.wait(timeout=10)
  call(['rsync','-a',f'{peer}:{root}/results/model-scaling/',str(out/'corsair')+'/'])
 time.sleep(10)
if __name__ == '__main__':
 try:
  if os.environ.get('SCALING_SKIP_VERIFIED_PREP') != '1':
   status('WAITING for initial model download')
   while pathlib.Path('/proc/2077664').exists():time.sleep(10)
   status('VERIFYING model; resume any interrupted downloads')
   call([sys.executable,'model-scaling/download-model.py'],stdout=open('model-scaling/download-verify.log','a'),stderr=subprocess.STDOUT)
   status('COPYING verified weights to Corsair over USB4')
   remote(peer,'mkdir -p /home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL')
   call(['rsync','-a','--partial','-e','ssh -o BatchMode=yes -o HostKeyAlias=rk-corsair-ai','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/', 'rkuo@10.77.0.2:/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/'],stdout=open(out/'model-copy.log','w'),stderr=subprocess.STDOUT)
   status('VERIFYING Corsair model hashes')
   # Python-only verification works without curl on the remote host once files are complete.
   remote(peer,f'cd {root}; python3 model-scaling/download-model.py',stdout=open(out/'corsair-model-verification.log','w'),stderr=subprocess.STDOUT)
  token=root/'model-scaling/control-token';token.write_text(secrets.token_hex(32));token.chmod(0o600)
  call(['rsync','-a',str(token),f'{peer}:{token}'])
  for label,world,head,binary in [('one-evo',1,local,'baseline'),('two-baseline',2,local,'baseline'),('one-corsair',1,peer,'baseline'),('two-traced',2,local,'traced')]:run(label,world,head,binary)
  call([sys.executable,'model-scaling/summarize.py'])
  status('COMPLETE: inspect results/model-scaling/analysis.md')
 except BaseException as e:
  status('BLOCKED: '+repr(e));raise
 finally:
  (root/'model-scaling/control-token').unlink(missing_ok=True)
  subprocess.run(['ssh','-o','BatchMode=yes',peer,f'rm -f {root}/model-scaling/control-token'],check=False)
