# Observed eligibility boundary, not a new optimization

The equal-work firstC3 target pass has9packedrows, so current74f uses the existing fallback and removes0launches. Following8/3rowpasses remove384launches. This is direct measured coverage, not proof that extending the fused path is faster. Actual C4/C8 speculative passes may exceed8; maximum resident width does not reveal packedrowhistories.

Code inspection: kernels.hip.cpp defines kFusedMaxTokens=8; HcFusedState down/dots arrays and template-dependent shared arrays/reduction layout use that bound. Executor FusedMixer and kVecBatch independently limit8. Widening this is not a launch flag; it requires compatible state/scratch/reduction arithmetic plus all row9..16 exactness, graph/lifecycle/activation and real inference gates. No edit/build/test attempted, and no candidate/study scope change.

Only consider a separate wider-shape hypothesis after the current fixed study and if real execution-path counts justify it. Preserve the original current8row study regardless of outcome.
