"""Supplemental plots of the complete prespecified primary results; no new test."""
from pathlib import Path
import json
p=Path(__file__).resolve().parent;lab=p.parent/'batched-ffn-hc-release-study-v1'
assert(lab/'complete').exists(),'Never plot an incomplete family'
v=json.loads((lab/'validation.json').read_text());s=json.loads((lab/'statistics.json').read_text());assert v['functional_qualification_pass'] and v['canonical_records']==624
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
results=s['primary_results'];fig,axes=plt.subplots(1,2,figsize=(11.5,4.8))
for i,x in enumerate(results):
 effect=x['paired_geometric_throughput_change_pct'];lo,hi=x['marginal_bootstrap95_change_pct'];color='#168568'if x['confirmatory_gain']else'#415d88'
 axes[0].hlines(i,lo,hi,color=color);axes[0].vlines([lo,hi],i-.08,i+.08,color=color);axes[0].plot(effect,i,'o',color=color)
 axes[0].text(hi+.05,i,f"Holm p={x['holm3_signflip_p']:.3g}",va='center',fontsize=9)
 for arm,style in [('baseline','--'),('candidate','-')]:
  axes[1].plot([a['pair']for a in x['per_pair']],[a[arm]for a in x['per_pair']],style,marker='o',markersize=3,label=f"{x['co_primary'].split('-')[0]} {arm}")
axes[0].axvline(0,color='0.5',linewidth=1);axes[0].set_yticks(range(len(results)),[x['co_primary'].split('-')[0]for x in results]);axes[0].set_xlabel('Paired geometric throughput change (%)');axes[0].set_title('Candidate vs baseline; marginal 95% paired bootstrap CI');axes[0].grid(axis='x',alpha=.2);axes[0].margins(x=.35)
axes[1].set_xlabel('Randomized pair');axes[1].set_ylabel('Complete client-wave output tokens/s');axes[1].set_title('All 12 pairs; no exclusions');axes[1].legend(fontsize=8,ncol=2);axes[1].grid(alpha=.2)
fig.suptitle('Gufo TP2: immediate FFN HC fusion — full release 9c / 74f')
fig.text(.02,.015,f"UD-Q4_K_XL + shared-Q8 MTP; 8 slots, context capacity 65,536; shallow concurrent prompts.\n624 records; phase flags: {len(v['strict_phase_flags'])}; adaptive work comparisons: {len(v['adaptive_work_fields'])}. CI is marginal; Holm3 p uses paired sign symmetry. No equivalence claim.",fontsize=8)
fig.tight_layout(rect=[0,.1,1,.94]);fig.savefig(p/'paired-performance.png',dpi=180);fig.savefig(p/'paired-performance.pdf');plt.close(fig)
print('Supplemental complete-family figures written; all source statistics remain in original lab.')
