Batched target FFN mixing currently launches its combine, projections, activation and quantization separately even when the existing fused decode mixer supports the shape. Route the immediate combine/mix pair through that implementation for eligible1–8rows and supported Q8geometry, preserving residual/deferred-state guards and the existing wider fallback. The existing fused producer also supplies readyQ8 output.

Measured code:74f385dc on maintainedd038/code9c. Review test/evidence commits are not yet applied or published.

- Exact component arithmetic48conditions, short/32K full-score/RNG/state104records perrank, widerC2..8/mixedAR/ragged1992records perrank, smoke12/cache4/livecancel9 pass. Full freshrelease336compile-unit equivalence checks pass; natural C8/ragged29requests match solo controls.
- Independent standardSDK/source-clock capture: all8rank/cycle ordered-work comparisons exact,48actualfusedcalls and384fewerGPUdispatches pereligible3/8rowtargetpass (~17.2%);9rowfallback remains2993dispatches. Instrumented timings are not an unprofiled throughput claim.
- First unprofiled9c/74f/9c60request screen: exact identities/runtime checks, zero5%AND3ms phaseflags, one C3 proposal count85/84/85 retained. Fixed12balancedrandomizedpair fullrelease study is running; no interim significance or adoption claim. Final primary results and every phaseflag must be inserted before publication.

The additive regression patch keeps every existing scalar/projection/injection test and adds the batch-reference sequence, scales and inject variants. It is currently prepared only and must pass formatting/compile/GPU checks in the review tree after the frozen performance study. No PR-ready claim until those checks/evidence are complete.
