from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess,time
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';o=Path(__file__).resolve().parent;src=p/'batched-ffn-hc-review-worktree';base=p/'tp2-upstream-773a1641-worktree';build=p/'tp2-upstream-773a1641-gpu-build'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(o/'commands.json').exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for n in ['src/models/qwen38_flash_next/kernels/rocm/kernels.hip.cpp','src/models/qwen38_flash_next/kernels/rocm/kernels.hpp','src/models/qwen38_flash_next/kernels/rocm/mmq/qfn_mmq.h']:assert sha(src/n)==sha(base/n),n
entries=json.loads((build/'compile_commands.json').read_text());e=next(e for e in entries if e['file'].endswith('/tests/models/qwen38_flash_next/hc_mix_ops_test.cpp'));cmd=shlex.split(e['command']);assert '-DENGINE_ENABLE_HIP=1'in cmd and '-UNDEBUG'in cmd
cmd[-1]=str(src/'tests/models/qwen38_flash_next/hc_mix_ops_test.cpp');cmd[cmd.index('-o')+1]=str(o/'test.cpp.o')
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','qwen38_flash_next_hc_mix_ops_test'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2];idx=next(i for i,x in enumerate(link)if x.endswith('/hc_mix_ops_test.cpp.o'));link[idx]=str(o/'test.cpp.o');link[link.index('-o')+1]=str(o/'test')
if '-Xlinker'in link:
 idx=link.index('-Xlinker');assert link[idx+1].startswith('--dependency-file=');del link[idx:idx+2]
env=dict(os.environ);env['CPLUS_INCLUDE_PATH']=str(r/'dependencies/gufo-dev/usr/include/x86_64-linux-gnu');env['LD_LIBRARY_PATH']=str(r/'dependencies/gufo-dev/usr/lib/x86_64-linux-gnu')+':/home/rkuo/.local/opt/rocm-7.14.1/lib'
for key in ['LD_PRELOAD','ROCP_TOOL_ATTACH','STRIX_READ_OUTPUT','STRIX_FINISH_TRACE','GUFO_TP_TRACE_PREFIX']:env.pop(key,None)
record=dict(cwd=str(build),commands=[cmd,link],test_sha256=sha(src/'tests/models/qwen38_flash_next/hc_mix_ops_test.cpp'),HIP_enabled=True,assertions_enabled=True,library=str(build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a'),library_sha256=sha(build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a'),scope='Additive reviewtest, unchanged qualified9c GPU/header library bytes, all originalscalar/projection/injection checks plus48batchreferenceconditions/eager/graph/alias/activebytes/guards. Operatoronly, not modelbranch/freshperformanceartifact.')
(o/'commands.json').write_text(json.dumps(record,indent=2)+'\n')
with(o/'build.log').open('w')as log:
 for c in [cmd,link]:subprocess.run(c,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
start=time.monotonic()
with(o/'run.log').open('w')as log:result=subprocess.run([str(o/'test')],cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(o/'result.json').write_text(json.dumps(dict(exit=result.returncode,elapsed_seconds=time.monotonic()-start,binary_sha256=sha(o/'test'),scope=record['scope']),indent=2)+'\n');assert result.returncode==0
print('PASS additive full HC operator fixture including original cases and48batch reference conditions')
