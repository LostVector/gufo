from pathlib import Path
import fcntl,hashlib,json,os,shlex,shutil,subprocess
out=Path(__file__).resolve().parent;r=out.parents[1];src=r/'tp-cache-retention/tp2-batched-ffn-hc-fusion-worktree';build=r/'tp-cache-retention/tp2-upstream-773a1641-release-build'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(out/'build-commands.json').exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
os.environ['CPLUS_INCLUDE_PATH']=str(r/'dependencies/gufo-dev/usr/include/x86_64-linux-gnu')
entries=json.loads((build/'compile_commands.json').read_text())
def compile(suffix,source,dest):
 e=next(e for e in entries if e['file'].endswith(suffix));c=shlex.split(e['command']);c[c.index('-o')+1]=str(dest);c[-1]=str(source);assert '-DNDEBUG'in c and '-UNDEBUG'not in c;return c
batch=compile('/src/models/qwen38_flash_next/kernels/rocm/batch.cpp',out/'diagnostic-batch.cpp',out/'batch.cpp.o');main=compile('/src/cli/main.cpp',out/'probe.cpp',out/'probe.o')
archive=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';copy=out/archive.name;assert not copy.exists();shutil.copy2(archive,copy)
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','gufo'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2]
i=next(i for i,x in enumerate(link)if x.endswith('/src/cli/main.cpp.o'));link[i]=str(out/'probe.o');rel=str(archive.relative_to(build));link=[str(copy)if x==rel else x for x in link];link[link.index('-o')+1]=str(out/'probe')
if '-Xlinker'in link:
 i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
commands=[batch,['ar','r',str(copy),str(out/'batch.cpp.o')],main,link]
record=dict(environment={'CPLUS_INCLUDE_PATH':os.environ['CPLUS_INCLUDE_PATH']},cwd=str(build),commands=commands,source_commit=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip(),source_sha256={n:sha(out/n)for n in('probe.cpp','diagnostic-batch.cpp')},scope='Test-only optional targetFFN existingfusedmixer route toggle+actual route/head-row counters. Existingtargetheadgather unchanged. Disabledmatches9c originalbatchpath; enabledmatches74f existingfusedroute includingitsproducerQ8rows. Current9c headers/GPU/otherobjects/wire22. Numerical/state/counters only, not performance artifact.')
(out/'build-commands.json').write_text(json.dumps(record,indent=2)+'\n')
with(out/'build.log').open('w')as log:
 for c in commands:subprocess.run(c,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
members=subprocess.check_output(['ar','t',str(archive)],text=True).splitlines();changes=[]
for m in members:
 if subprocess.check_output(['ar','p',str(archive),m])!=subprocess.check_output(['ar','p',str(copy),m]):changes.append(m)
assert changes==['batch.cpp.o'],changes
(out/'post-build.json').write_text(json.dumps(dict(binary_sha256=sha(out/'probe'),changed_archive_members=changes,reference_semantics='Current9cunfusedtargetFFNHcMixBatch',candidate_semantics='74fexistingfusedtargetFFNmixer+existingreadyQ8outputs',other_GPU_headers_transport_unchanged=True),indent=2)+'\n')
files=[p for n in('src','include')for p in(src/n).rglob('*')if p.is_file()and '__pycache__'not in p.parts]
(out/'source-preflight.json').write_text(json.dumps(dict(path=str(src),source_sha256={str(p.relative_to(src)):sha(p)for p in files}),indent=2)+'\n')
print('Numerical/state diagnostic built; not yet executed')
