from pathlib import Path
import json,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');old=r/'tp-cache-retention/batched-hc-q8-state-v2';out=Path(__file__).resolve().parent;source=r/'tp-cache-retention/tp2-batched-ffn-hc-fusion-worktree';assert not(out/'diagnostic-batch.cpp').exists()
s=(source/'src/models/qwen38_flash_next/kernels/rocm/batch.cpp').read_text();s=s.replace('#include <algorithm>','#include <algorithm>\n#include <atomic>',1)
helper='''namespace {
std::atomic<bool> ffn_hc_probe_enabled{false};
std::array<std::atomic<std::uint64_t>, 65> ffn_hc_probe_heads{};
std::array<std::atomic<std::uint64_t>, 65> ffn_hc_probe_produced{};
}
void FfnHcProbeReset(bool enabled) {
  ffn_hc_probe_enabled.store(enabled, std::memory_order_relaxed);
  for (auto& x : ffn_hc_probe_heads) x.store(0, std::memory_order_relaxed);
  for (auto& x : ffn_hc_probe_produced) x.store(0, std::memory_order_relaxed);
}
std::uint64_t FfnHcProbeHeads(unsigned n) { return n <= 64 ? ffn_hc_probe_heads[n].load(std::memory_order_relaxed) : 0; }
std::uint64_t FfnHcProbeProduced(unsigned n) { return n <= 64 ? ffn_hc_probe_produced[n].load(std::memory_order_relaxed) : 0; }
'''
needle='namespace gufo::models::qwen38_flash_next::rocm {\n';assert s.count(needle)==1;s=s.replace(needle,needle+helper,1)
needle='      if (rows != 0 && FusedMixer(l.hc_ffn, rows) &&';assert s.count(needle)==1;s=s.replace(needle,'      if (ffn_hc_probe_enabled.load(std::memory_order_relaxed) &&\n          rows != 0 && FusedMixer(l.hc_ffn, rows) &&',1)
needle='''      } else {
        CombineBatch(base.res, l.hc_ffn.norm.f32(), rows);''';assert s.count(needle)==1;s=s.replace(needle,'        ffn_hc_probe_produced[rows].fetch_add(1, std::memory_order_relaxed);\n'+needle,1)
needle='    const auto& output = model_->output();';assert s.count(needle)==1;s=s.replace(needle,'    if (rows <= 64) ffn_hc_probe_heads[rows].fetch_add(1, std::memory_order_relaxed);\n'+needle,1);(out/'diagnostic-batch.cpp').write_text(s)
p=(old/'probe.cpp').read_text().replace('HcQ8Probe','FfnHcProbe').replace('fused_q8','fused_ffn_hc').replace('optional Q8 producer','optional target-FFN HC fusion').replace('actual_q8_enabled_batches','actual_ffn_hc_enabled_batches');(out/'probe.cpp').write_text(p)
s=(old/'build.py').read_text().replace('tp2-batched-hc-q8-worktree','tp2-batched-ffn-hc-fusion-worktree').replace('tp2-upstream-c32136f8-release-build','tp2-upstream-773a1641-release-build');s=s.replace('Current94unfusedHcMixBatch','Current9cunfusedtargetFFNHcMixBatch').replace('f5ebatchedHCQ8producer+ReadyRows','74fexistingfusedtargetFFNmixer+existingreadyQ8outputs');s=s.replace('Test-only optional batchedHCQ8 producer toggle+actual producer/head-row counters. Existing targetheadgather ALWAYS unchanged. Reference disables optional producer/ready descriptor, enabled matches f5e. Existing production94 headers/GPU/otherobjects/wire22. Numerical/state/counters only, not performance artifact.', 'Test-only optional targetFFN existingfusedmixer route toggle+actual route/head-row counters. Existingtargetheadgather unchanged. Disabledmatches9c originalbatchpath; enabledmatches74f existingfusedroute includingitsproducerQ8rows. Current9c headers/GPU/otherobjects/wire22. Numerical/state/counters only, not performance artifact.');(out/'build.py').write_text(s)
s=(old/'run.py').read_text().replace('f5e','74f').replace('batched-HC optionalQ8','targetFFN existingfusedHC route').replace("'sessions':2","'sessions':4,'active_actors':2").replace('44Q8enabledcycles','44FFNHcEnabledCycles').replace('Q8enabledcycles','FFNHcEnabledCycles');(out/'run.py').write_text(s)
(out/'analyze.py').write_text((old/'analyze.py').read_text().replace('actual_q8_enabled_batches','actual_ffn_hc_enabled_batches').replace('fused_q8','fused_ffn_hc'))
(out/'preparation-note.txt').write_text('First inline preparation failed exact-match assertion on clang-formatted HcMix argument indentation, before files/compilation/models. This version anchors the branch boundary instead. No production source or assertion was weakened.\n')
(out/'design.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),compiled_parent='9c7157201e8aa30cbfc51ddf3595a3dea13b196a',sessions=4,active_actors=2,context_capacity=65536,actual_depths=[0,32768],modes=['greedy','sampled'],scope='Exact complete-logit/RNG/token/work/state replay with controlled same proposal inputs; current9c batch reference versus optional74f existing scalar fused targetFFN combine/mixer. Includes existingfusedproducerQ8outputs, not a pure launch-only intervention. No global batched-Q8 draft, GPU arithmetic or transport change. Diagnostic counters are branch use, not independent GPU dispatch trace. All failures retained; no performance claim.'),indent=2)+'\n')
