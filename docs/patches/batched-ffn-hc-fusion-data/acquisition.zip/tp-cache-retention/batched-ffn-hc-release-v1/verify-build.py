from pathlib import Path
import hashlib,json,shlex,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';o=Path(__file__).resolve().parent;assert(o/'build-complete').exists()
roles={'baseline':(p/'tp2-upstream-773a1641-worktree',p/'tp2-upstream-773a1641-release-build'),'candidate':(p/'tp2-batched-ffn-hc-fusion-worktree',p/'tp2-batched-ffn-hc-fusion-release-build')};collected={}
for role,(src,build)in roles.items():
 cache=(build/'CMakeCache.txt').read_text();assert all(s in cache for s in ['BUILD_TESTING:BOOL=OFF','GUFO_ENABLE_TP2_RDMA:BOOL=ON','CMAKE_BUILD_TYPE:STRING=RelWithDebInfo'])
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True).strip()
 commands={}
 for e in json.loads((build/'compile_commands.json').read_text()):
  path=Path(e['file']);assert path.is_relative_to(src) or path==build/'extensions/gufo/extension_registry.cpp',str(path)
  n=str(path.relative_to(src))if path.is_relative_to(src)else '<GENERATED>/'+str(path.relative_to(build));tokens=shlex.split(e['command']);assert not any('GUFO_CACHE_TESTING'in t for t in tokens)
  tokens=['-DGUFO_REVISION=<RECORDED_REVISION>'if t.startswith('-DGUFO_REVISION=')else t for t in tokens]
  norm='\n'.join(tokens).replace(str(build),'<BUILD>').replace(str(src),'<SOURCE>');assert n not in commands,n
  commands[n]={'normalized_command':norm,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 collected[role]=commands
assert collected['baseline'].keys()==collected['candidate'].keys()
changed_commands=[n for n in collected['baseline']if collected['baseline'][n]['normalized_command']!=collected['candidate'][n]['normalized_command']]
changed_sources=[n for n in collected['baseline']if collected['baseline'][n]['source_sha256']!=collected['candidate'][n]['source_sha256']]
report=dict(compile_units=len(collected['baseline']),changed_normalized_commands=changed_commands,changed_compiled_sources=changed_sources,revision_definition_normalization_only=True,source='74f385dc46e68e06be8975c6ab41682d7591add4',baseline_source='9c7157201e8aa30cbfc51ddf3595a3dea13b196a',scope='Fresh full officialrelease builds,RelWithDebInfo/BUILD_TESTINGOFF/RDMAON; no source observer or test shim, same toolchain/flags/header closure apart from normalized roots and recorded revision metadata.')
(o/'compile-comparison.json').write_text(json.dumps(report,indent=2)+'\n');assert not changed_commands,changed_commands;assert changed_sources==['src/models/qwen38_flash_next/kernels/rocm/batch.cpp'],changed_sources
src,build=roles['candidate'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();assert head==report['source']
binary=r/'instrumentation/bin/gufo-tp2-ffn-hc-release-74f385dc';assert not binary.exists();shutil.copy2(build/'gufo',binary)
meta=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_commit=head,source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip(),build_testing=False,build_type='RelWithDebInfo',TP2_RDMA=True,diagnostic=False,full_fresh_release=True,compile_comparison=str(o/'compile-comparison.json'))
(o/'binary.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
