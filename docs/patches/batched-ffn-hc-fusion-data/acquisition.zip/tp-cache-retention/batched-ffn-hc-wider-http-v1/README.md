# FFN HC fusion: fixed unprofiled serving screen

Source9c baseline /74f candidate /9c baseline, identical production9c toolchain/library closure; candidate only batch.cpp host object changed, version metadata retains9c. Four sessions,65536 capacity, shallow actual prompts,chunk2048,cache1GiB,UD-Q4_K_XL/sharedQ8_0 MTP,greedy/thinkingoff. No profiler/sourceobserver/adminsampler. This is not actual32K speed evidence; long-history exactness is separate.

All60 prompt/output/cache-work identities and matching solo controls pass. ActualMTP/settings/binary/source/kernel/boot/topology/driver/idle guards pass with no transport error changes. There are **zero** perrequest phase flags at the preregistered5%AND3ms threshold. This is a screen, not significance/equivalence. Two adaptive-work comparisons reflect the same C3 actor1 proposal count85baseline/84candidate; all raw work retained. Outputs/work identity does not mean all actual percycle scheduling is identical.

| Run | C3 client wave tok/s | C4 client wave tok/s | RaggedC4 client wave tok/s |
| --- | ---: | ---: | ---: |
| before-baseline | 85.858 | 97.962 | 66.504 |
| first-candidate | 86.179 | 98.294 | 66.768 |
| after-baseline | 85.864 | 98.419 | 66.524 |

Client wave rate is total completed outputtokens divided by earliest requeststart to latest requestfinish, including queue/prefill/streamcompletion. It is neither sum of perrequest decode rates nor pure steadyGPUdecode. Only one candidate start and two controls: no confidence/significance or equivalence claim. Do not reject or adopt based on estimated size.

Independent equal-work standardSDK captures in `../batched-ffn-hc-cycle-gpu-build-v1/README.md` prove384 fewer launches/48actualfusedcalls in eligible3/8rowtargetpasses and unchanged9rowfallback. The component observation does not establish serving speed. Wider8slot natural serving, fresh full candidate release, and a fixed randomized matched end-to-end comparison remain next.

`protocol.json` freezes sources/binaries/harness/environment; `validation.json`, `phase-flags.csv` and `adaptive-work.csv` retain all checks. Raw requestSSE/content/phase/work records are under `results/model-scaling/` with this lab prefix. `controller.log` retains each launch; exec85188 observed terminal0. Maintainedtp2 remains unchanged.
