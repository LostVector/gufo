# FFN HC fusion: independent actual-dispatch comparison

## Directly measured

Fresh baseline9c and candidate74f standard rocprofiler-SDK kernel/HIP/copy captures on both nodes, same source stage/clock observer, toolchain, model UD-Q4_K_XL/sharedQ8_0 MTP,4sessions/context65536/chunk2048/cache1GiB, shallow actual prompts. Exact same preceding8 warmup/solo requests thenC3x128. Not a long-context speed result. No hardware counters/custom ABI shim, BPF, admin sampler or system/driver changes.

All11 prompt/output/cache-work identities match, and all8 rank/cycle ordered proposal-chain/stage/row work comparisons are exact. Both captures pass source/binary/PID/boot/topology/error/kernel/idle checks. Public samehost SDK clock brackets and drift pass. No peer clock subtraction.

| Rank | Cycle | Rows | Baseline launches | Candidate launches | Removed | Baseline stage ms | Candidate stage ms |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 1 | 9 | 2993 | 2993 | 0 | 60.935 | 61.067 |
| 0 | 2 | 8 | 2228 | 1844 | 384 | 53.219 | 52.455 |
| 0 | 3 | 3 | 2230 | 1846 | 384 | 37.891 | 36.615 |
| 0 | 4 | 3 | 2230 | 1846 | 384 | 37.558 | 36.759 |
| 1 | 1 | 9 | 2993 | 2993 | 0 | 60.892 | 61.060 |
| 1 | 2 | 8 | 2228 | 1844 | 384 | 53.221 | 52.456 |
| 1 | 3 | 3 | 2231 | 1847 | 384 | 37.400 | 36.375 |
| 1 | 4 | 3 | 2231 | 1847 | 384 | 37.408 | 35.994 |

Candidate has48 actual HcMixQ8FusedKernel<8> or<3> launches per eligible target pass, absent from baseline. Exactly384 dispatches disappear (eight per eligible target layer); about17.2% of all dispatches in these passes. Both builds retain one final hipStreamSynchronize, not a blocking CPU sync per layer. Nine-row fallback has zero fused calls and unchanged2993dispatches. Existing fused output also supplies readyQ8, so this is fusion plus existing producer reuse, not pure launch-only savings.

Eligible instrumented target-forward spans are0.76–1.41ms shorter in this single comparison, while9row fallback differs+0.13–0.17ms. These are **instrumented observations**, not significant end-to-end speed/equivalence or proof that all removed launch time is saved. HostAPI walls overlapGPU/communication; rank1cycle3 launchAPIwall even increases despite fewer launches, illustrating scheduling/profiling variance. Do not add API/GPU totals or subtract final wait as avoidable overhead.

## Raw files and reproduction

`capture-controller.py` ran each fresh arm once; `../batched-ffn-hc-gpu-{baseline,candidate}-v1/` retain design/protocol, standardSDK CSVs, attach logs/status, calibrated GPU-attribution and actual-cycle work. `build.py/build.json` and the diagnostic batch source pin candidate source74f and the single archive member differing from the equally instrumented9c baseline. Other serving/engine/GPU/headers/transport objects identical. Binary version retains parent9c; actual candidateSHA/source proof required. `compare.py` checks identities and work and writes comparison.json/comparison.csv. Rerunning acquisitions requires fresh directories, not overwriting these records.

## Next gate

Fixed unprofiled9c/74f/9c C1/C3/C4/ragged serving screen completed PASS60records/zero phaseflags in `../batched-ffn-hc-wider-http-v1/`; timings/actualMTPwork/phaseflags retained per request. C8 and fixed randomized matched evidence remain pending. No maintained branch update or performance adoption yet.
