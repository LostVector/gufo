from pathlib import Path
import subprocess,time
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention'
for arm in ['baseline','candidate']:
 lab=p/f'batched-ffn-hc-gpu-{arm}-v1';assert not(lab/'protocol.json').exists()
 print(time.strftime('%F %T'),'START',arm,flush=True)
 with(lab/'controller.log').open('w')as log:subprocess.run(['python3','-u',str(lab/'run.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 for name in ['analyze.py','analyze-cycles.py','summarize-source.py','analyze-gpu.py']:
  with(lab/(name+'.log')).open('w')as log:subprocess.run(['python3',str(lab/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(time.strftime('%F %T'),'PASS capture',arm,flush=True)
print('Both captures complete; matched work comparison still required',flush=True)
