from pathlib import Path
import fcntl,hashlib,json,os,shlex,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';o=Path(__file__).resolve().parent;b=p/'tp2-upstream-773a1641-release-build';old=p/'upstream-773a1641-cycle-gpu-trace-v1'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(o/'build.json').exists();os.environ['CPLUS_INCLUDE_PATH']=str(r/'dependencies/gufo-dev/usr/include/x86_64-linux-gnu')
e=next(x for x in json.loads((b/'compile_commands.json').read_text())if x['file'].endswith('/src/models/qwen38_flash_next/kernels/rocm/batch.cpp'));c=shlex.split(e['command']);c[-1]=str(o/'candidate-batch.cpp');c[c.index('-o')+1]=str(o/'batch.cpp.o')
archive=old/'candidate-libgufo_qwen38_flash_next_hip.a';copy=o/'candidate-libgufo_qwen38_flash_next_hip.a';shutil.copy2(archive,copy)
parent=json.loads((old/'build.json').read_text())['roles']['candidate'];link=list(parent['commands'][-1]);assert str(archive)in link;link=[str(copy)if x==str(archive)else x for x in link];binary=r/'instrumentation/bin/gufo-tp2-ffn-hc-cycle-gpu-v1-candidate';assert not binary.exists();link[link.index('-o')+1]=str(binary)
commands=[c,['ar','r',str(copy),str(o/'batch.cpp.o')],link];record=dict(commands=commands,cwd=str(b),source='74f385dc46e68e06be8975c6ab41682d7591add4',parent_trace_build=str(old/'build.json'),scope='Identical4hostobject source observers/publicclock instrumentation on9c vs74f. One batch object differs from baseline trace, unchanged all GPU/headers/engine/serving/transport. Parent9c versionmetadata; source/SHA diagnostic proof, not performance artifact.')
(o/'build.json').write_text(json.dumps(record,indent=2)+'\n')
with(o/'build.log').open('w')as log:
 for cmd in commands:subprocess.run(cmd,cwd=b,stdout=log,stderr=subprocess.STDOUT,check=True)
changed=[n for n in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()if subprocess.check_output(['ar','p',str(archive),n])!=subprocess.check_output(['ar','p',str(copy),n])];assert changed==['batch.cpp.o'],changed
record.update(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),changed_vs_baseline_trace=changed,diagnostic_batch_sha256=hashlib.sha256((o/'candidate-batch.cpp').read_bytes()).hexdigest());(o/'build.json').write_text(json.dumps(record,indent=2)+'\n');print('Built exact comparison source observer candidate',flush=True)
