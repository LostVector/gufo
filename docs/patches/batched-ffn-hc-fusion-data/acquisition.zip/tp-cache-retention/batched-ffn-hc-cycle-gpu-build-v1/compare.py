from pathlib import Path
import collections,csv,hashlib,json
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';out=Path(__file__).resolve().parent
arms={name:p/f'batched-ffn-hc-gpu-{name}-v1'for name in ['baseline','candidate']}
reports={name:json.loads((lab/'gpu-attribution.json').read_text())for name,lab in arms.items()}
cycles={name:json.loads((lab/'cycles.json').read_text())['phases'][0]['ranks']for name,lab in arms.items()}
identity=['case','order','max_tokens','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256']
ids={}
for name,lab in arms.items():
 assert json.loads((lab/'validation.json').read_text())['functional_qualification_pass']
 rows=sorted([json.loads(s)for s in(r/'results/model-scaling'/f'{lab.name}-candidate.jsonl').read_text().splitlines()],key=lambda x:x['order'])
 ids[name]=[{k:x[k]for k in identity}for x in rows]
assert ids['baseline']==ids['candidate'],'outputs/prompt/cache work differ'
records=[]
for rank in [0,1]:
 for i in range(4):
  a=reports['baseline']['ranks'][rank]['windows'][i];b=reports['candidate']['ranks'][rank]['windows'][i]
  wa=cycles['baseline'][rank][i]['work'];wb=cycles['candidate'][rank][i]['work'];same=wa==wb
  keys=set(wa)|set(wb);diff={k:{'baseline':wa.get(k),'candidate':wb.get(k)}for k in keys if wa.get(k)!=wb.get(k)}
  names={}
  for arm,w in [('baseline',a),('candidate',b)]:
   names[arm]=[{k:x[k]for k in ['name','count','union_ms']}for x in w['top_kernels']if any(s in x['name']for s in ['Hc','HC','Silu','FusedMix'])]
  row=dict(rank=rank,cycle=i+1,baseline_rows=a['rows'],candidate_rows=b['rows'],exact_ordered_work=same,work_differences=diff,baseline_dispatches=a['GPU_kernel_dispatches'],candidate_dispatches=b['GPU_kernel_dispatches'],dispatch_reduction_equal_work=a['GPU_kernel_dispatches']-b['GPU_kernel_dispatches']if same else None,baseline_wall_ms=a['wall_ms'],candidate_wall_ms=b['wall_ms'],baseline_gpu_union_ms=a['GPU_kernel_or_copy_union_ms'],candidate_gpu_union_ms=b['GPU_kernel_or_copy_union_ms'],baseline_launch_api_ms=a['main_API_launch_union_ms'],candidate_launch_api_ms=b['main_API_launch_union_ms'],baseline_waitvalue_ms=a['wait_value_kernel_union_ms'],candidate_waitvalue_ms=b['wait_value_kernel_union_ms'],baseline_uncovered_ms=a['not_covered_by_GPU_records_ms'],candidate_uncovered_ms=b['not_covered_by_GPU_records_ms'],HC_kernel_records=names)
  records.append(row)
report=dict(scope='Single fresh9c baseline and74f candidate standardSDK/source-observer captures, not unprofiled speed/significance or equivalence. Samehost clocks validated independently. Full actual ordered work required for count attribution. Rows>8 retain fallback. HostAPI/GPU intervals overlap, never add. Any unequalwork retained as such. No hardwarecounter/customABI shim or system change.',all11_prompt_output_cache_identities_exact=True,exact_ordered_work_comparisons=sum(x['exact_ordered_work']for x in records),comparisons=records)
(out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
flat=[{k:v for k,v in x.items()if k not in ['HC_kernel_records','work_differences']}for x in records]
with(out/'comparison.csv').open('w')as f:
 writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
for x in flat:print(json.dumps(x),flush=True)
print('Actual HC kernel names retained in comparison.json; no performance adoption claim.')
