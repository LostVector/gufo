# Immediate target FFN HC fusion candidate

Source `74f385dc46e68e06be8975c6ab41682d7591add4`, parent `d038b2e8` (qualified production code `9c715720`). This isolated branch is not the maintained `tp2` branch and is not merged or published.

## Why this path

The single current-source, instrumented TP2 C3 capture in `../upstream-773a1641-cycle-gpu-http-v1/` measured 2,993 GPU dispatches for the first nine-row target pass and one final host stream synchronization. It does not support an assumption of millisecond host synchronization per layer. The steady three-row passes still contain many small HC operations. This candidate uses the existing scalar fused HC implementation for the immediate attention-output combine and FFN mixer pair at eligible target layers. It preserves the final/head combine, predictor path, all collectives and dependencies, and rows outside the existing fused geometry.

This is fusion **and reuse of the existing fused producer Q8 output**, not a pure launch-only intervention. It excludes the separate global batched Q8 draft PR14. No new GPU arithmetic or kernel is added.

## Direct evidence

- `../batched-hc-fusion-contract-v1/`: all48 exact arithmetic cases pass, rows1..8, injection on/off, small/ordinary/large inputs, eager and graph replay. Intermediate values, active quantized bytes and applicable padding contracts retained. This is an operator screen, not model quality by itself.
- `../batched-ffn-hc-state-v1/validation.json`:104 records,44 actual enabled target passes,32 complete post-replay snapshot state pairs **per rank**, short and actual32768 histories,65536 capacity. Full248320 logits, tokens, positions, external RNG and proposal work exact. Borrowed same/cross session, serialized cross and file roundtrip restore checked. The historical analyzer field `actual_Q8_enabled_batch_cycles_per_rank` names the inherited counter; here the instrumented counter is the **FFN fused branch**, not PR14. Immutable acquisition preserved.
- `../batched-ffn-hc-wide-state-v1/`:PASS1992records/498complete-statepairs/180eligiblecycles perrank;96pairedcases, C2..8, short/32K, greedy/sampled/mixed sampling, mixed AR, ragged9/12 fallback. Full logits/RNG/tokens/work/state exact and frozen runtime/counter/kernel/idle guards pass.
- `../batched-ffn-hc-http-smoke-v1/` and `../batched-ffn-hc-http-lifecycle-v1/`: PASS fresh candidate-only smoke12 against maintained9c output/prompt/cache-work identities, and four cached greedy/sampled keep/discard continuation cases plus nine live cancellation records covering both victim roles, exact live width2 survivors/solo/postcancel replay. All source/binary/settings/driver/kernel/idle gates pass; zero transport error deltas. Controller exec67913 observed terminal0. No timing qualification.

## Binary scope

`binary.json`, `build.json` and `member-proof.json` pin the source, exact executable and single changed host object. Every other archived HIP member is identical to the qualified9c production build. `--version` retains9c build metadata. This is not a full fresh candidate CMake release qualification. Runtime model tests must identify this binary by its SHA and candidate source, not the parent version string.

## Pending

Wider model/state and natural HTTP/cache/live cancellation correctness gates completed. Obtain an independent actual-kernel trace to verify the intended launch reduction, separately from unprofiled performance. Then run a fixed matched performance comparison covering C1 control and affected concurrent histories with per-request phase flags and actual MTP work retained. No end-to-end speed, latency equivalence or adoption claim exists yet. No system, driver or transport setting changed.


## Dispatch and first natural serving screen

Independent paired standardSDK traces prove384fewer actualGPUdispatches/48existing fusedcalls pereligible3/8rowtargetpass,8/8orderedworkcomparisons exact;9rowfallback unchanged. See `../batched-ffn-hc-cycle-gpu-build-v1/README.md`. Separate unprofiled9c/74f/9c60request screen passes all exact identities and runtimeguards,zero5%AND3ms phaseflags. C3clientwave85.858/86.179/85.864tok/s; C4 97.962/98.294/98.419. One candidate start is not significant gain/equivalence. One C3actor proposes85/84/85drafttokens, preserved. Next freshfullrelease/C8runtime/fixed randomized performance. Maintainedbranch unchanged.
