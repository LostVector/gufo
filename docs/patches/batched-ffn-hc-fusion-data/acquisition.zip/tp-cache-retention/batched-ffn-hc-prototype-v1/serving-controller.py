from pathlib import Path
import json,subprocess,time
r=Path('/home/rkuo/strix-dispatch-investigation');p=r/'tp-cache-retention';o=p/'batched-ffn-hc-prototype-v1'
watch=json.loads((o/'wide-process.json').read_text());proc=Path('/proc')/str(watch['pid'])
print('Waiting for verified wider controller',watch,flush=True)
while proc.exists():
 try:
  s=(proc/'stat').read_text();birth=s[s.rfind(')')+2:].split()[19]
  if birth!=watch['birth']:break
 except FileNotFoundError:break
 time.sleep(1)
wide=p/'batched-ffn-hc-wide-state-v1';assert(wide/'complete').exists(),'wider acquisition not complete'
subprocess.run(['python3',str(wide/'analyze.py')],cwd=r,check=True)
v=json.loads((wide/'validation.json').read_text());assert v['records_per_rank']==1992 and v['cross_rank_records_exact']
print('Wider validation PASS, starting prepared serving gates',flush=True)
for name,analyzer in [('batched-ffn-hc-http-smoke-v1','analyze.py'),('batched-ffn-hc-http-lifecycle-v1','validate.py')]:
 lab=p/name;assert not(lab/'protocol.json').exists(),'never restart prior acquisition'
 print(time.strftime('%F %T'),'START',name,flush=True)
 with(lab/'controller.log').open('w')as log:subprocess.run(['python3','-u',str(lab/'run.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 with(lab/'validate.log').open('w')as log:subprocess.run(['python3',str(lab/analyzer)],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(time.strftime('%F %T'),'PASS',name,flush=True)
(o/'serving-gates-complete').touch();print('Serving functional gates complete; no timing qualification',flush=True)
