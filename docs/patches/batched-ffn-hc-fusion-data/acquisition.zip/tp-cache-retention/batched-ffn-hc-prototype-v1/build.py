from pathlib import Path
import hashlib,json,shlex,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;build=r/'tp-cache-retention/tp2-upstream-773a1641-release-build';src=r/'tp-cache-retention/tp2-batched-ffn-hc-fusion-worktree';parent=r/'tp-cache-retention/tp2-upstream-773a1641-worktree'
head=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip();assert head.startswith('74f385dc')and not subprocess.check_output(['git','-C',str(src),'status','--porcelain'],text=True)
changed=subprocess.check_output(['git','-C',str(src),'diff','--name-only','d038b2e8',head],text=True).splitlines();path='src/models/qwen38_flash_next/kernels/rocm/batch.cpp';assert changed==[path]
entry=next(x for x in json.loads((build/'compile_commands.json').read_text())if x['file'].endswith('/'+path));compile=shlex.split(entry['command']);compile[compile.index('-o')+1]=str(out/'batch.cpp.o');compile[-1]=str(src/path)
assert '-DNDEBUG'in compile and '-UNDEBUG'not in compile
lib=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';assert lib.open('rb').read(8)==b'!<arch>\n';members=subprocess.check_output(['ar','t',str(lib)],text=True).splitlines();assert members.count('batch.cpp.o')==1
candidate=out/lib.name;assert not candidate.exists();shutil.copy2(lib,candidate)
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','gufo'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2]
if '-Xlinker'in link:
 i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
relative=str(lib.relative_to(build));assert relative in link;link=[str(candidate)if x==relative else x for x in link];binary=r/'instrumentation/bin/gufo-tp2-batched-ffn-hc-74f385dc';assert not binary.exists();link[link.index('-o')+1]=str(binary)
record=dict(source=head,parent='d038b2e84ce7659608cfb239b944086690baa849',compiled_parent='9c7157201e8aa30cbfc51ddf3595a3dea13b196a',changed_files=changed,changed_source_sha256=hashlib.sha256((src/path).read_bytes()).hexdigest(),compile=compile,link=link,parent_hip_archive_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),scope='One changed production host object in isolated copied regular archive. Compiled parent9c headers/GPUobjects/link/toolchain are production-code-identical to sourceparentd038; no other Q8 draft included. Existing fused scalar route includes its valid producer Q8 outputs; this is not a pure launch-only intervention. Diagnostic executable retains parent build metadata; exact binary SHA+source record identify candidate, not its --version commit. Not full-release CMake qualification or performance adoption.')
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(compile,cwd=build,check=True);subprocess.run(['ar','r',str(candidate),str(out/'batch.cpp.o')],check=True)
# Verify every untouched member is bit-identical to its parent.
member_checks={}
for name in members:
 a=subprocess.check_output(['ar','p',str(lib),name]);b=subprocess.check_output(['ar','p',str(candidate),name]);same=a==b;assert same==(name!='batch.cpp.o'),(name,same);member_checks[name]=dict(unchanged=same,parent_sha256=hashlib.sha256(a).hexdigest(),candidate_sha256=hashlib.sha256(b).hexdigest())
(out/'member-proof.json').write_text(json.dumps(member_checks,indent=2)+'\n')
subprocess.run(link,cwd=build,check=True)
result=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_commit=head,parent=record['parent'],parent_build_metadata=True,qualification='BUILT ONLY; engine numerical/state/lifecycle/activation/performance not qualified')
(out/'binary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
