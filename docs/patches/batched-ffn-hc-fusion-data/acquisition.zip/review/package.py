from pathlib import Path
import csv,hashlib,json,re,shutil,zipfile
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;p=r/'tp-cache-retention';repo=p/'batched-ffn-hc-review-worktree';dest=repo/'docs/patches/batched-ffn-hc-fusion-data';dest.mkdir(parents=True,exist_ok=False)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  while chunk:=f.read(4*1024*1024):h.update(chunk)
 return h.hexdigest()
def fields(line):return{k:int(v)if re.fullmatch(r'-?\d+',v)else v for k,v in re.findall(r'(\w+)=([^ ]+)',line)}
trace_manifest={};scoped={}
for arm in ['baseline','candidate']:
 lab=p/f'batched-ffn-hc-gpu-{arm}-v1';attribution=json.loads((lab/'gpu-attribution.json').read_text())
 for rank in [0,1]:
  parent=r/'results/model-scaling';parent=parent/'corsair'if rank else parent
  lines=(parent/f'{lab.name}-candidate-rank{rank}.stderr').read_text().splitlines();stages={}
  for line in lines:
   if line.startswith('C3_STAGE '):
    f=fields(line)
    if f['stage']=='target-forward':stages[f['cycle']]=f
  windows=[]
  for w in attribution['ranks'][rank]['windows']:
   st=stages[w['cycle']];a=st['begin_ns']+w['clock_offset_ns'];b=st['end_ns']+w['clock_offset_ns'];windows.append({'cycle':w['cycle'],'rows':w['rows'],'begin_sdk_ns':a,'end_sdk_ns':b})
  for name in ['trace_kernel_trace.csv','trace_hip_api_trace.csv','trace_memory_copy_trace.csv']:
   original=lab/'candidate'/f'trace-r{rank}'/'gpu'/name;target=out/'scoped-traces'/arm/f'r{rank}'/name;target.parent.mkdir(parents=True,exist_ok=True);total=selected=0
   with original.open(newline='')as source,target.open('w',newline='')as target_file:
    reader=csv.DictReader(source);writer=csv.DictWriter(target_file,fieldnames=reader.fieldnames);writer.writeheader()
    for row in reader:
     total+=1;a=int(row['Start_Timestamp']);b=int(row['End_Timestamp'])
     if any(a<w['end_sdk_ns']and b>w['begin_sdk_ns']for w in windows):writer.writerow(row);selected+=1
   relative=str(target.relative_to(out));scoped[relative]=target;trace_manifest[relative]={'parent_relative_path':str(original.relative_to(r)),'parent_bytes':original.stat().st_size,'parent_sha256':digest(original),'parent_record_count':total,'selected_record_count':selected,'windows':windows,'scope':'Exact CSV fields for every row overlapping any of4samehosttargetwindows, selected without timestamp clipping. Full original preserved locally, not in Git. Derivative does not establish SDKlosslessness; no independentloss counter. Sourcealgorithm+parenthash+allwindowrecords disclosed.'}
   print('Scoped',arm,rank,name,total,'->',selected,flush=True)
(out/'full-trace-manifest.json').write_text(json.dumps(trace_manifest,indent=2)+'\n')
allowed={'.py','.cpp','.sh','.md','.json','.jsonl','.log','.txt','.csv','.stderr','.stdout','.pid','.xml'}
names=['batched-hc-fusion-contract-v1','batched-ffn-hc-prototype-v1','batched-ffn-hc-state-v1','batched-ffn-hc-wide-state-v1','batched-ffn-hc-http-smoke-v1','batched-ffn-hc-http-lifecycle-v1','batched-ffn-hc-cycle-gpu-build-v1','batched-ffn-hc-gpu-baseline-v1','batched-ffn-hc-gpu-candidate-v1','batched-ffn-hc-wider-http-v1','batched-ffn-hc-release-v1','batched-ffn-hc-c8-http-v1','batched-ffn-hc-release-study-v1','batched-ffn-hc-review-prep-v1','batched-ffn-hc-review-operator-v1']
files={}
for name in names:
 base=p/name
 for f in base.rglob('*'):
  if not f.is_file()or f.suffix not in allowed or '__pycache__'in f.parts:continue
  if f.name.startswith('trace_')and f.suffix=='.csv'and 'gpu'in f.parts:continue
  assert f.stat().st_size<20*1024*1024,('unexpected large nontrace',f)
  files[str(f.relative_to(r))]=f
 for prefix in [r/'results/model-scaling',r/'results/model-scaling/corsair']:
  for f in prefix.glob(name+'-*'):
   if f.is_file()and f.suffix in allowed:files[str(f.relative_to(r))]=f
for name,f in scoped.items():files[name]=f
files['scoped-traces/full-trace-manifest.json']=out/'full-trace-manifest.json'
for n in ['native-rdma/env.sh','cable-prep/env.sh','tp-cache-retention/driver-parent-timing-v1/inventory.py','reference/gufo-rdma/tools/gufo/serving_bench.py','prefill-scaling/results/prompts.json']:files[n]=r/n
files['review/hc_mix_ops_test.cpp']=repo/'tests/models/qwen38_flash_next/hc_mix_ops_test.cpp';files['review/package.py']=Path(__file__)
# Runtime credentials are not benchmark evidence. Reject concrete credential values.
secrets=re.compile(rb'(?:--tp-control-token[\s"\x27,:]+[a-f0-9]{64}|gh[opsu]_[A-Za-z0-9]{30,}|Authorization[\s"\x27:]+Bearer [A-Za-z0-9._-]{20,})')
for name,f in files.items():assert not secrets.search(f.read_bytes()),'Possible credential in '+name
manifest={name:{'bytes':f.stat().st_size,'sha256':digest(f)}for name,f in sorted(files.items())}
with zipfile.ZipFile(dest/'acquisition.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,f in sorted(files.items()):z.write(f,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
record={'entries':len(files),'uncompressed_bytes':sum(x['bytes']for x in manifest.values()),'zip_bytes':(dest/'acquisition.zip').stat().st_size,'zip_sha256':digest(dest/'acquisition.zip'),'production_source':'74f385dc46e68e06be8975c6ab41682d7591add4','baseline_source':'9c7157201e8aa30cbfc51ddf3595a3dea13b196a','test_head':'4749d941f44a03a2fb8351f16bea63e739de15ff','scope':'Complete624servingrecords/allphaseflags/work, earlierstrictstate/operator/runtime qualification and failures, exact source/harness/commands. GPU CSVs are explicitlyscoped targetwindow derivatives withfullparent hashes/counts retained; nofull1.3GBprofilerstreams inGit. No models/binaries/objects/controltokens/multiGBstatefiles. Offlineaudit cannot rerunGPU/livePID/kernel/NVMechecks. No significantservinggain/equivalence/defaultadoption.'}
(dest/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['paired-performance.png','paired-performance.pdf']:shutil.copy2(p/'batched-ffn-hc-review-prep-v1'/name,dest/name)
(out/'package.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
