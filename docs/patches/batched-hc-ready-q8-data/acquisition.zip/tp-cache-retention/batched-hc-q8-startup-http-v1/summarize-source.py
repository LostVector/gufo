from pathlib import Path
import collections,json,re
out=Path(__file__).resolve().parent;r=out.parents[1];assert json.loads((out/'validation.json').read_text())['all_prompt_output_cachework_identities_exact']
report=dict(phases=[],scope='Same-host source/client monotonic spans, no cross-host clock subtraction. Snapshot worker includes waits/GPU/transport, not pure copy. HC epoch markers show first call after100msgap and may show wide/ineligible rows; they do NOT count all eligible producer invocations. Pointer links filtered to actual request lifetime; no pooling into unprofiled study.')
def fields(line):
 return {k:int(v)if re.fullmatch(r'-?\d+',v)else v for k,v in re.findall(r'(\w+)=([^ ]+)',line)}
for phase,role in json.loads((out/'design.json').read_text())['sequence']:
 label=out.name+'-'+phase;rows=[json.loads(x)for x in(r/'results/model-scaling'/f'{label}.jsonl').read_text().splitlines()]
 lines=(r/'results/model-scaling'/f'{label}-rank0.stderr').read_text().splitlines();events=[];snaps=[];links=[];epochs=[]
 for line in lines:
  if line.startswith('STARTUP_PATH '):events.append(dict(stage=line.split()[1],**fields(line)))
  elif line.startswith('SNAPSHOT_PATH '):snaps.append(dict(stage=line.split()[1],**fields(line)))
  elif line.startswith('SNAPSHOT_LINK '):links.append(fields(line))
  elif line.startswith('HC_EPOCH enter '):epochs.append(fields(line))
 groups=collections.defaultdict(list)
 for e in events:groups[e['id']].append(e)
 # Server request sequence is independent of HTTP token-count queries.
 # Match by actual start time and admission ordering, never client IP string.
 server=sorted(groups.values(),key=lambda es:es[0]['request_start_ns']);public=sorted([x for x in rows if x['case']=='pp2048-tg128'or x['concurrency']==2],key=lambda x:x['started_at'])
 assert len(server)==len(public)==6,(phase,len(server),len(public))
 records=[]
 for es,row in zip(server,public):
  req=es[0];start=req['request_start_ns'];finish=int(row['finished_at']*1e9);assert int(row['started_at']*1e9)<=start<=finish
  assert req['limit']==(128 if row['case']!='coding-c2' else 256)
  runner=req['runner'];matched=[x for x in links if x['runner']==runner and start<=x['time_ns']<=finish];impls={x['impl']for x in matched};assert len(impls)==1,(phase,req['id'],impls)
  impl=impls.pop();owned=[x for x in snaps if x['impl']==impl and start<=x['begin_ns']<=x['end_ns']<=finish]
  launches=sorted([x for x in owned if x['stage']=='snapshot-launch'],key=lambda x:x['begin_ns']);workers=[x for x in owned if x['stage']=='snapshot-worker'];gets=sorted([x for x in owned if x['stage']=='snapshot-get-return'],key=lambda x:x['end_ns']);jobs=[]
  for launch in launches:
   ww=[x for x in workers if x['state']==launch['state']and x['tokens']==launch['tokens']and x['bytes']==launch['bytes']and x['begin_ns']>=launch['begin_ns']];assert len(ww)==1,(phase,req['id'],launch,ww)
   worker=ww[0];gg=[x for x in gets if x['tokens']==launch['tokens']and x['begin_ns']>=worker['end_ns']];assert len(gg)==1,(phase,req['id'],launch,gg)
   get=gg[0];jobs.append(dict(tokens=launch['tokens'],bytes=launch['bytes'],worker_wall_ms=(worker['end_ns']-worker['begin_ns'])/1e6,launch_to_consumption_ms=(get['end_ns']-launch['begin_ns'])/1e6,worker_done_to_consumption_ms=(get['end_ns']-worker['end_ns'])/1e6))
  pubs=sorted([x for x in es if x['stage']=='publish'],key=lambda x:x['end_ns']);prefill=[x for x in es if x['stage']=='prefill-call-done'];asm=[x for x in es if x['stage']=='initial-assembly'];hc=[x for x in epochs if start<=x['time_ns']<=finish]
  ce=row['content_events'];second_ms=(ce[1]['perf_counter_ns']-int(row['started_at']*1e9))/1e6 if len(ce)>1 else None
  item=dict(case=row['case'],actor=row['request_index'],repetition=row['repetition'],request_id=req['id'],client_TTFT_ms=row['client_ttft_ms'],first_followup_gap_ms=row['first_followup_content_gap_ms'],second_content_from_client_start_ms=second_ms,reported_snapshot_ms=row['raw_gufo']['cache_snapshot_ms'],snapshot_jobs=jobs,worker_sum_ms=sum(x['worker_wall_ms']for x in jobs),completed_workers_to_consumption_sum_ms=sum(x['worker_done_to_consumption_ms']for x in jobs),assembly_events=asm,prefill_calls=prefill,first_publish=pubs[0]if pubs else None,HC_epoch_markers=hc)
  if pubs and prefill:item['final_prefill_to_first_publish_ms']=(pubs[0]['end_ns']-max(x['end_ns']for x in prefill))/1e6
  records.append(item)
 report['phases'].append(dict(phase=phase,role=role,requests=records))
(out/'source-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
for p in report['phases']:
 print(p['phase'])
 for x in p['requests']:
  if x['actor']==0 and x['case']in('short-c2','coding-c2'):print(x['case'],{k:x[k]for k in('client_TTFT_ms','first_followup_gap_ms','second_content_from_client_start_ms','reported_snapshot_ms','worker_sum_ms','completed_workers_to_consumption_sum_ms','final_prefill_to_first_publish_ms')},'assembly',[e['work']for e in x['assembly_events']])
