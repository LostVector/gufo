# Batched HC ready-Q8 producer component

Current94 HcMixBatch drops producer readiness and calls HcMixEpilogue without
its already-supported Q8 output. DenseBatch routes up to8rows through
Dense/Quantize, which can consume exact ready-Q8 data. An isolated producer
probe therefore compares the production epilogue plus separate MMQ quantization
against that same production epilogue with its optional Q8 output enabled.
No GPU kernel source, flags or mathematical expression is changed.

All30conditions pass **exact FP32 mixed outputs, injection outputs and Q8
bytes**, including prefix/suffix and inactive-output guards, before and after
timing. Conditions: rows1/2/4/7/8, FP32 injection enabled/disabled, amplitudes
0.0001/1/10000. The independent reference is a separate existing MMQ
quantization kernel; it is not an external full-model mathematical teacher.

One fresh local process runs16warmup pairs and120retained pairs per condition,
alternating order. Across the30separate condition medians, fused producer GPU
saving is **2.279–2.519us**. Raw7200records retain CPU enqueue, completed wall and
GPU-event duration; analysis.json gives each condition's p50/p95/p99 separately.
There is no pooling across amplitudes, independent-start confidence interval,
model throughput, quality parity or adoption claim. Activation scratch is small
as in this producer; no weights are scanned and component time must not be
multiplied into a claimed whole-model gain.

build.json pins the exact production OFF94 libraries/toolchain. Only the host
harness was compiled; the existing GPU/MMQ objects are used. The full build
warning about an ignored hipFree return is retained; it did not fail execution.
No model cache warming, services, driver/kernel/ROCm or boot settings changed.

## Prototype and gates

Local branch `perf/batched-hc-ready-q8` at **f5e9290cabf48dfeca521847dd60f3692b3c2927**
changes only HcMixBatch in batch.cpp: enable optional producer for<=8rows with
an explicitly unpadded Q8_1 layout and publish its ReadyRows descriptor. Wider
batches retain the old route; no extra allocation, stream wait or collective.
895-file format check passes on exactf5e after correcting the tool PATH.
The initial missing-tool attempt is retained in format-missing-tool.log;
format-verification.json records the corrected standalone check. The shared mixed-Q8 buffer is separate from
alternating per-projection quantization slots; row-view/pointer/shape readiness
and cancellation/scratch changes still need actual model state checks.

`../batched-hc-ready-q8-prototype-v1` builds one host object into an isolated
copied regular HIP archive. Every other member is bit-identical. GPU/headers/
transport and link flags are unchanged. The diagnostic binary retains parent94
build metadata, so use its recorded SHA and source commit, not its --version
commit, to identify it. It is not a full candidate CMake-release qualification.

Fresh `../batched-hc-ready-q8-http-smoke-v1` passes all12 canonical outputs,
prompt/cache work, actual MTP, exact source/binary/PID/options and native
counter/kernel/boot/topology/final-idle checks. That is startup/serving smoke,
**not full-score/RNG/snapshot/lifecycle/performance qualification**. The template
validator's old parent94 scope label is preserved; candidate-qualification.json
records the actual f5e source and diagnostic build boundary.

Next: current-header full-score/state/RNG/snapshot checks for true batched MTP,
ragged rows2–8 and wider fallbacks, then cached continuation/live cancellation,
actual producer/cache-consumer activation and quantization launch removal.
Only after these gates use a separately declared unprofiled baseline/candidate
study with matching model/history/work, retaining every phase/work flag.
No size cutoff is used to accept or reject this measured component difference.
The maintained public tp2 branch remains qualified94; f5e is not pushed/adopted.
