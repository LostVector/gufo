#include <hip/hip_runtime.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <vector>
#include "qfn_mmq.h"
#include "src/models/qwen38_flash_next/kernels/rocm/kernels.hpp"
namespace q=gufo::models::qwen38_flash_next::rocm;
void ck(hipError_t r){if(r!=hipSuccess)throw std::runtime_error(hipGetErrorString(r));}
using Clock=std::chrono::steady_clock;
long long ns(Clock::time_point a,Clock::time_point b){return std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();}
struct Buffer{void* p=nullptr;size_t n;Buffer(size_t n):n(n){ck(hipMalloc(&p,n));}~Buffer(){if(p)hipFree(p);}float* f(){return static_cast<float*>(p);}};
struct Output{
 Buffer mixed,inject,quant;size_t m,i,b;
 Output(size_t m,size_t i,size_t b):mixed(m*4+512),inject(i*4+512),quant(b+512),m(m),i(i),b(b){}
 float* mf(){return mixed.f()+64;}float* inf(){return inject.f()+64;}void* qb(){return static_cast<char*>(quant.p)+256;}
 void clear(hipStream_t s){ck(hipMemsetAsync(mixed.p,0xa5,mixed.n,s));ck(hipMemsetAsync(inject.p,0xa5,inject.n,s));ck(hipMemsetAsync(quant.p,0xa5,quant.n,s));}
};
std::vector<unsigned char> download(Buffer& b){std::vector<unsigned char> r(b.n);ck(hipMemcpy(r.data(),b.p,b.n,hipMemcpyDeviceToHost));return r;}
void compare(Buffer& a,Buffer& b,size_t used,bool live){auto x=download(a),y=download(b);if(x!=y)throw std::runtime_error("exact producer output mismatch");for(size_t j=0;j<x.size();++j)if((!live||j<256||j>=256+used)&&x[j]!=0xa5)throw std::runtime_error("guard or inactive output overwritten");}
int main(){try{
 ck(hipSetDevice(0));hipStream_t s;ck(hipStreamCreateWithFlags(&s,hipStreamNonBlocking));hipEvent_t a,z;ck(hipEventCreate(&a));ck(hipEventCreate(&z));
 constexpr unsigned H=2560,S=4;uint32_t rng=0x8371031;auto rnd=[&]{rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return(float(int(rng%20001)-10000)/10000.f);};
 std::cout<<"rows,inject,amplitude,iteration,mode,enqueue_ns,completed_ns,gpu_ns\n";
 for(unsigned n:{1u,2u,4u,7u,8u})for(bool inj:{false,true})for(float scale:{0.0001f,1.f,10000.f}){
  const size_t dim=size_t(n)*H*S;std::vector<float> hx(dim),hg(dim),hw(size_t(S)*H*S);for(auto&v:hx)v=rnd()*scale;for(auto&v:hg)v=rnd()*2;for(auto&v:hw)v=rnd()*.01f;
  Buffer x(dim*4),g(dim*4),w(hw.size()*4);ck(hipMemcpy(x.p,hx.data(),x.n,hipMemcpyHostToDevice));ck(hipMemcpy(g.p,hg.data(),g.n,hipMemcpyHostToDevice));ck(hipMemcpy(w.p,hw.data(),w.n,hipMemcpyHostToDevice));
  const size_t bytes=qfn_mmq_q8_1_bytes(n,H);Output ref(size_t(n)*H,size_t(n)*H*S,bytes),out(size_t(n)*H,size_t(n)*H*S,bytes);
  auto launch=[&](Output& o,bool fused){q::HcMixEpilogue(x.f(),g.f(),inj?w.f():nullptr,o.mf(),o.inf(),n,H,S,s,fused?o.qb():nullptr);if(!fused&&qfn_mmq_quantize_q8_1(o.mf(),o.qb(),n,H,s)!=0)throw std::runtime_error("quantization API failed");ck(hipPeekAtLastError());};
  ref.clear(s);out.clear(s);launch(ref,false);launch(out,true);ck(hipStreamSynchronize(s));compare(ref.mixed,out.mixed,ref.m*4,true);compare(ref.inject,out.inject,ref.i*4,inj);compare(ref.quant,out.quant,bytes,true);
  for(int it=-16;it<120;++it)for(int order=0;order<2;++order){const bool fused=(order+(it&1))%2;auto&o=fused?out:ref;auto t0=Clock::now();ck(hipEventRecord(a,s));auto e0=Clock::now();launch(o,fused);auto e1=Clock::now();ck(hipEventRecord(z,s));ck(hipStreamSynchronize(s));auto t1=Clock::now();float ms;ck(hipEventElapsedTime(&ms,a,z));if(it>=0)std::cout<<n<<','<<inj<<','<<scale<<','<<it<<','<<(fused?"fused":"unfused")<<','<<ns(e0,e1)<<','<<ns(t0,t1)<<','<<static_cast<long long>(ms*1.e6f)<<'\n';}
  compare(ref.mixed,out.mixed,ref.m*4,true);compare(ref.inject,out.inject,ref.i*4,inj);compare(ref.quant,out.quant,bytes,true);std::cerr<<"PASS rows="<<n<<" inject="<<inj<<" amplitude="<<scale<<"\n";
 }
 ck(hipEventDestroy(a));ck(hipEventDestroy(z));ck(hipStreamDestroy(s));return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
