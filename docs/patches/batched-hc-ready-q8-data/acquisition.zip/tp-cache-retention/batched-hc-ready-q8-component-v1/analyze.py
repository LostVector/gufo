from pathlib import Path
import collections,csv,json,statistics
out=Path(__file__).resolve().parent;rows=list(csv.DictReader((out/'raw-r0.csv').open()));assert len(rows)==7200
pairs=collections.defaultdict(dict)
for x in rows:pairs[(int(x['rows']),int(x['inject']),x['amplitude'],int(x['iteration']))][x['mode']]=x
assert len(pairs)==3600 and all(set(x)=={'fused','unfused'}for x in pairs.values())
def q(values,p):
 a=sorted(values);k=(len(a)-1)*p;i=int(k);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(k-i)
result=[]
for n,inj,amp in sorted({k[:3]for k in pairs}):
 group=[v for k,v in pairs.items()if k[:3]==(n,inj,amp)];assert len(group)==120
 for metric in('enqueue_ns','completed_ns','gpu_ns'):
  entry=dict(rows=n,inject=inj,amplitude=amp,metric=metric,pairs=120)
  for mode in('unfused','fused'):
   vals=[int(v[mode][metric])/1000 for v in group];entry[mode+'_us']={key:q(vals,p)for key,p in(('p50',.5),('p95',.95),('p99',.99))}
  delta=[(int(v['unfused'][metric])-int(v['fused'][metric]))/1000 for v in group];entry['paired_saving_us']={key:q(delta,p)for key,p in(('p50',.5),('p95',.95),('p99',.99))};result.append(entry)
assert len((out/'stderr-r0.log').read_text().splitlines())==30
report=dict(conditions=30,all_exact_F32_inject_Q8_and_guards=True,timing_records=7200,summaries=result,scope='Single fresh local component process,30fixedconditions. Descriptive per-condition latency percentiles only; no independent-start CI, pooling across amplitudes, full-model quality, TP throughput or adoption claim.')
(out/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
gpu=[x['paired_saving_us']['p50']for x in result if x['metric']=='gpu_ns'];print('Per-condition median GPU savings range (us)',min(gpu),max(gpu))
