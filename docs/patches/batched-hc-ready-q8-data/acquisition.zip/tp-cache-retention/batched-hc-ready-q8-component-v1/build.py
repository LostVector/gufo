from pathlib import Path
import hashlib,json,shlex,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;test=r/'tp-cache-retention/tp2-upstream-c32136f8-gpu-build';build=r/'tp-cache-retention/tp2-upstream-c32136f8-release-build';src=r/'tp-cache-retention/tp2-upstream-c32136f8-worktree'
assert subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()=='94f1232d4b28b2f4cec4ecc4505492283c6e2b54'
assert 'BUILD_TESTING:BOOL=OFF'in(build/'CMakeCache.txt').read_text()
entry=next(x for x in json.loads((test/'compile_commands.json').read_text())if x['file'].endswith('/tests/models/qwen38_flash_next/hc_mix_ops_test.cpp'))
cmd=shlex.split(entry['command']);cmd.remove('-UNDEBUG');cmd[cmd.index('-o')+1]=str(out/'probe.o');cmd[-1]=str(out/'probe.cpp')
link=shlex.split(subprocess.check_output(['ninja','-C',str(test),'-t','commands','tests/models/qwen38_flash_next/qwen38_flash_next_hc_mix_ops_test'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2]
# Keep production libraries and link flags, omit only test dependency-file bookkeeping.
i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
oldobj=entry['output'].removeprefix(str(test)+'/');link[link.index(oldobj)]=str(out/'probe.o');link[link.index('-o')+1]=str(out/'probe')
libs=[build/x for x in link if x.endswith('.a')and not x.startswith('/')]
record=dict(source='94f1232d4b28b2f4cec4ecc4505492283c6e2b54',compile=cmd,link=link,library_sha256={str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest()for p in libs},scope='Existing production OFF HIP/MMQ objects; only isolated host harness compiled. Exact F32/inject/Q8 bytes+guards before/after timing. No model change, actual-end-to-end speedup or independent external numerical parity claim.')
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(cmd,cwd=build,check=True);subprocess.run(link,cwd=build,check=True)
(out/'binary.json').write_text(json.dumps(dict(sha256=hashlib.sha256((out/'probe').read_bytes()).hexdigest()),indent=2)+'\n')
