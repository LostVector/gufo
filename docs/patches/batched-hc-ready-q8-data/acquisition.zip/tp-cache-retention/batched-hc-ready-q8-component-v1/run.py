from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(out/'protocol.json').exists()
record=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=[1,2,4,7,8],injection=[False,True],amplitudes=[.0001,1.,10000.],warmup_per_mode=16,retained_per_mode=120,order='alternate fused/unfused by iteration',maximum_processes_per_host=1,source='94f1232d',benchmark_scope='Existing production HcMixEpilogue optionalQ8 producer vs same epilogue followed by qfn quantization. Host enqueue/GPU event/completed latency separated. Same small activations as producer, no weight-scan/model/TP throughput claim.',probe_sha256=hashlib.sha256((out/'probe').read_bytes()).hexdigest())
(out/'protocol.json').write_text(json.dumps(record,indent=2)+'\n')
for tag in('before','after'):
 if tag=='before':
  with(out/'raw-r0.csv').open('x')as csv,(out/'stderr-r0.log').open('x')as log:subprocess.run([str(out/'probe')],stdout=csv,stderr=log,check=True)
print('PASS local component exactness and timings')
