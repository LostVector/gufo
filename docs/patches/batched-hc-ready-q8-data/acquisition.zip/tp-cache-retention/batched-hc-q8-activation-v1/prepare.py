from pathlib import Path
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;src=r/'tp-cache-retention/tp2-batched-hc-q8-worktree'
b=(src/'src/models/qwen38_flash_next/kernels/rocm/batch.cpp').read_text().replace('#include <algorithm>','#include <algorithm>\n#include <atomic>\n#include <cstdio>',1)
ns='namespace gufo::models::qwen38_flash_next::rocm {\n';assert b.count(ns)==1
b=b.replace(ns,ns+'''namespace {
struct Q8ProducerIdentity { const void* executor{}; const float* src{}; const void* data{}; unsigned n{}, k{}; };
thread_local Q8ProducerIdentity hc_q8_identity;
std::array<std::atomic<unsigned long long>, 65> hc_q8_produced{};
std::array<std::atomic<unsigned long long>, 65> hc_q8_matches{};
struct Q8ProbeReport {
  ~Q8ProbeReport() {
    for (unsigned n=0;n<65;++n) {
      auto p=hc_q8_produced[n].load(), h=hc_q8_matches[n].load();
      if(p||h)std::fprintf(stderr,"hc_q8_activation rows=%u produced=%llu matched=%llu\\n",n,p,h);
    }
  }
} hc_q8_probe_report;
}
void HcQ8RecordReady(const void* e,const float* x,const void* d,unsigned n,unsigned k) {
 hc_q8_identity={e,x,d,n,k};hc_q8_produced[n].fetch_add(1,std::memory_order_relaxed);
}
void HcQ8ClearReady(const void* e) {
 if(hc_q8_identity.executor==e)hc_q8_identity={};
}
void HcQ8MatchReady(const void* e,const float* x,const void* d,unsigned n,unsigned k) {
 const auto& p=hc_q8_identity;
 if(p.executor==e&&p.src==x&&p.data==d&&p.n==n&&p.k==k)
  hc_q8_matches[n].fetch_add(1,std::memory_order_relaxed);
}
''',1)
needle='''  if (q8)
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};''';assert b.count(needle)==1
b=b.replace(needle,'''  if (q8) {
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};
    HcQ8RecordReady(this,mixed,s_.mixed_q8_1,rows,c.hidden_size);
  }''',1)
(out/'diagnostic-batch.cpp').write_text(b)
e=(src/'src/models/qwen38_flash_next/kernels/rocm/executor.cpp').read_text();assert e.count(ns)==1
e=e.replace(ns,ns+'''void HcQ8ClearReady(const void*);
void HcQ8MatchReady(const void*,const float*,const void*,unsigned,unsigned);
''',1)
a=e.index('const void* Executor::ReadyQ8(');z=e.index('void Executor::DropReadyQ8()',a);part=e[a:z];assert part.count('return r->data;')==1
part=part.replace('return r->data;','HcQ8MatchReady(this,x,r->data,n_tokens,k);\n      return r->data;');e=e[:a]+part+e[z:]
e=e.replace('void Executor::DropReadyQ8() const {','void Executor::DropReadyQ8() const {\n  HcQ8ClearReady(this);',1)
(out/'diagnostic-executor.cpp').write_text(e)
print('Prepared observer-only producer/ready-match identity instrumentation; no GPU/internal-layout reads')
