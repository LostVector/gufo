from pathlib import Path
import fcntl,hashlib,json,shlex,shutil,subprocess
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;build=r/'tp-cache-retention/tp2-upstream-c32136f8-release-build';src=r/'tp-cache-retention/tp2-batched-hc-q8-worktree'
lock=(r/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'build.json').exists()
entries=json.loads((build/'compile_commands.json').read_text());commands=[]
for name in('batch','executor'):
 e=next(e for e in entries if e['file'].endswith(f'/src/models/qwen38_flash_next/kernels/rocm/{name}.cpp'));c=shlex.split(e['command']);c[-1]=str(out/f'diagnostic-{name}.cpp');c[c.index('-o')+1]=str(out/f'{name}.cpp.o');commands.append(c)
archive=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';copy=out/archive.name;assert not copy.exists();shutil.copy2(archive,copy)
commands.append(['ar','r',str(copy),str(out/'batch.cpp.o'),str(out/'executor.cpp.o')])
link=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','gufo'],text=True).splitlines()[-1]);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2];link=[str(copy)if x==str(archive.relative_to(build))else x for x in link]
i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
binary=r/'instrumentation/bin/gufo-tp2-batched-hc-q8-activation-f5e9290c';assert not binary.exists();link[link.index('-o')+1]=str(binary);commands.append(link)
record=dict(commands=commands,cwd=str(build),base='94f1232d',candidate='f5e9290cabf48dfeca521847dd60f3692b3c2927',diagnostic_source_sha256={n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in('diagnostic-batch.cpp','diagnostic-executor.cpp')},scope='Observer-only TLS producer identity + actual ReadyQ8 matches, cleared by DropReadyQ8. Two hostobjects modified, existing f5e math/producer behavior and allGPU/header/transport objects unchanged. No raw private-layout reads, no performance claim; binary retains parent build metadata.')
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
with(out/'build.log').open('w')as log:
 for c in commands:subprocess.run(c,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
changes=[]
for n in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines():
 if subprocess.check_output(['ar','p',str(archive),n])!=subprocess.check_output(['ar','p',str(copy),n]):changes.append(n)
assert sorted(changes)==['batch.cpp.o','executor.cpp.o'],changes
(out/'binary.json').write_text(json.dumps(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),changed_members=changes,scope=record['scope']),indent=2)+'\n')
print('Activation observer built')
