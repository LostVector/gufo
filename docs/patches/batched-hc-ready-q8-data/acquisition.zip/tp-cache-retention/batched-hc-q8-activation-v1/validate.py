from pathlib import Path
import hashlib,json,re
r=Path('/home/rkuo/strix-dispatch-investigation');lab=Path(__file__).resolve().parent;out=r/'tp-cache-retention/batched-hc-q8-activation-http-v1'
native=json.loads((out/'validation.json').read_text());assert native['all_prompt_output_cachework_identities_exact']and native['driver_error_kernel_idle_source_harness_checks_pass']
report=dict(ranks=[],scope='Observer-only f5e producer/executor-input/shape/Q8bufferidentity is matched inside actual ReadyQ8 before returningdata; identityclearedonDropReadyQ8. Demonstrates realproduction-route cachematching;sourceQuantize/DensePair bypassesrepeatMMQquantizationonreadydata. NotanindependentGPUkernelcounterorunprofiledthroughputclaim;otherGPU/header/transportobjectsunchanged.')
label=out.name+'-candidate'
for rank in(0,1):
 p=r/'results/model-scaling'/f'{label}-rank{rank}.stderr'
 if rank:p=r/'results/model-scaling/corsair'/f'{label}-rank{rank}.stderr'
 text=p.read_text();rows={}
 for n,produced,matched in re.findall(r'^hc_q8_activation rows=(\d+) produced=(\d+) matched=(\d+)$',text,re.M):
  n,pn,hn=map(int,(n,produced,matched));assert n not in rows and 1<=n<=8 and pn>0 and hn>=0;rows[n]=dict(produced=pn,matched=hn)
 assert rows and sum(x['matched']for x in rows.values())>0
 report['ranks'].append(dict(rank=rank,rows=rows,total_produced=sum(x['produced']for x in rows.values()),total_ready_matches=sum(x['matched']for x in rows.values()),stderr_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
a,b=[x['rows']for x in report['ranks']];report['per_rank_counts_equal']=a==b
# Retain all observed adaptive-work differences versus the exact uninstru­mented candidate smoke.
def load(name):return[json.loads(s)for s in(r/'results/model-scaling'/f'{name}-candidate.jsonl').read_text().splitlines()]
control=load('batched-hc-ready-q8-http-smoke-v1');observed=load(out.name);changes=[]
for a,b in zip(control,observed):
 assert all(a[k]==b[k]for k in('case','repetition','request_index','completion_sha256','prompt_sha256','completion_tokens','prompt_tokens','prefill_tokens','cached_prompt_tokens'))
 fields={}
 for k in('draft_tokens','draft_accepted_tokens','physical_execution_width'):
  if a[k]!=b[k]:fields[k]=dict(control=a[k],observed=b[k])
 for k in set(a['raw_gufo'])|set(b['raw_gufo']):
  if re.search(r'draft|accept|proposal|execution_width|rollback',k)and not re.search(r'_ms$|_us$|_seconds|_per_second',k)and a['raw_gufo'].get(k)!=b['raw_gufo'].get(k):fields['raw.'+k]=dict(control=a['raw_gufo'].get(k),observed=b['raw_gufo'].get(k))
 if fields:changes.append(dict(case=a['case'],repetition=a['repetition'],actor=a['request_index'],fields=fields))
report['adaptive_work_changes']=changes;report['native_validation']=native
(lab/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
