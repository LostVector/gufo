from pathlib import Path
import csv,hashlib,json,math,re,shlex,subprocess
out=Path(__file__).resolve().parent;root=out.parents[1];assert(out/'complete').exists(),'No interim analysis'
p=json.loads((out/'protocol.json').read_text());assert not json.loads((out/'cleanup.json').read_text())['errors']
for n,h in p['harness_sha256'].items():assert hashlib.sha256((out/n).read_bytes()).hexdigest()==h,n
for n,h in p['external_harness_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
for role,meta in json.loads((out/'source-preflight.json').read_text()).items():
 for n,h in meta['source_sha256'].items():assert hashlib.sha256((Path(meta['path'])/n).read_bytes()).hexdigest()==h,n
identity=('case','repetition','request_index','concurrency','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256')
data={};reference=None
for tag,entry in json.loads((out/'reference.json').read_text()).items():
 f=Path(entry['path']);assert hashlib.sha256(f.read_bytes()).hexdigest()==entry['sha256'];rr=[json.loads(s)for s in f.read_text().splitlines()if s.strip()];ids=[{k:x[k]for k in identity}for x in rr]
 if reference is None:reference=ids
 assert ids==reference

for phase,role in p['sequence']:
 assert(out/f'{phase}-complete').exists();rows=[json.loads(s)for s in(root/'results/model-scaling'/f'{out.name}-{phase}.jsonl').read_text().splitlines()if s.strip()];assert len(rows)==12
 ids=[{k:r[k]for k in identity}for r in rows]
 if reference is None:reference=ids
 assert ids==reference;assert all(r['cached_prompt_tokens']==0 and r['prefill_tokens']==r['prompt_tokens']and r['draft_tokens']>0 for r in rows)
 data[phase]=rows
 for rank in (0,1):
  def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(out/f'{phase}-{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());errors={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)};assert not errors,(phase,rank,errors)
  inv=json.loads((out/f'{phase}-final-inventory-r{rank}.json').read_text());assert inv['module']=='81C6FF2FBAC473C7AB21844'and inv['refcnt']==0 and len(inv['devices'])==4
  assert all(inv[k]==p['initial'][rank][k]for k in ('boot_id','cmdline','routers'))
  ident=json.loads((out/f'{out.name}-{phase}-identity-r{rank}.json').read_text());assert ident['binary_sha256']==p['binaries'][role]['sha256']and ident['selected_safe_options']['--tp-rdma-device']=='usb4_rdma0'
  args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',str(ident['pid'])]
  if rank:args=['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]
  subprocess.run(args,check=True,timeout=15)
for rank in(0,1):
 assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout',(out/f'kernel-window-r{rank}.txt').read_text(),re.I)
 final=json.loads((out/f'final-inventory-r{rank}.json').read_text());assert final['refcnt']==0 and all(final[k]==p['initial'][rank][k]for k in ['module','boot_id','cmdline','routers'])
report=dict(diagnostic_variants=list(p['binaries']),records_per_variant=12,all_prompt_output_cachework_identities_exact=True,actual_MTP_and_live_binary_settings_verified=True,driver_error_kernel_idle_source_harness_checks_pass=True,scope='Combined PLE/earlyEnd94f1232d/canonicalc32136f8 provider startup and standard twelve-request TP2 smoke; exact outputs/cache work. One fresh pair; no speed or equivalence claim.')
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'validated-reference.json').write_text(json.dumps({role:dict(path=str(root/'results/model-scaling'/f'{out.name}-{phase}.jsonl'),sha256=hashlib.sha256((root/'results/model-scaling'/f'{out.name}-{phase}.jsonl').read_bytes()).hexdigest())for phase,role in p['sequence']},indent=2)+'\n')
print(json.dumps(report,indent=2))
