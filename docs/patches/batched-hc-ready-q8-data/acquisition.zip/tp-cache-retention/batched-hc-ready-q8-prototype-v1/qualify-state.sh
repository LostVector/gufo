#!/bin/bash
set -euo pipefail
cd /home/rkuo/strix-dispatch-investigation
source cable-prep/env.sh
source native-rdma/env.sh
export LD_LIBRARY_PATH="$PWD/tp-cache-retention/fork-integration-v1/runtime/lib:$LD_LIBRARY_PATH"
unset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_READ_OUTPUT STRIX_FINISH_TRACE GUFO_TP_TRACE_PREFIX
for name in batched-hc-q8-state-v2 batched-hc-q8-wide-state-v1; do
 out="tp-cache-retention/$name"
 python3 -u "$out/run.py" > "$out/controller.log" 2>&1
 python3 "$out/analyze.py" > "$out/validate.log" 2>&1
 echo "$(date -Is) PASS $name"
done
