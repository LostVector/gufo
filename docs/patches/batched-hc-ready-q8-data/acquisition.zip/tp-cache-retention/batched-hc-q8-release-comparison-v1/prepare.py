from pathlib import Path
import hashlib,json,py_compile,random
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;old=r/'tp-cache-retention/cooperative-ple-release-comparison-v2'
for n in('run.py','requests.py','analyze.py','engine.py','server-rank.sh','reference.json','paired_statistics.py','statistical-summary.py','summarize.py'):
 s=(old/n).read_text().replace(str(old),str(out))
 if n=='analyze.py':s=s.replace('published replicated-PLE TP2 versus cooperative PLE owner reads','current94 TP2 versus isolated f5e batched HC ready-Q8 producer')
 if n=='statistical-summary.py':
  s=s.replace('cooperative PLE','batched HC ready-Q8')
  s=s.replace("['C1-first-server-decode', 'C2-short-client-wave',\n            'C1-repeat-server-decode', 'C2-coding-client-wave']", "['C2-coding-client-wave', 'C2-short-client-wave',\n            'C1-first-server-decode', 'C1-repeat-server-decode']")
  s=s.replace('202611011540 + index','202611020520 + index')
 (out/n).write_text(s)
(out/'server-rank.sh').chmod(0o755)
base=json.loads((r/'tp-cache-retention/fork-integration-v1/upstream-c32136f8-release-binary.json').read_text());candidate=json.loads((r/'tp-cache-retention/batched-hc-ready-q8-prototype-v1/binary.json').read_text())
(out/'binaries.json').write_text(json.dumps({role:dict(name=Path(meta['path']).name,sha256=meta['sha256'])for role,meta in(('baseline',base),('candidate',candidate))},indent=2)+'\n')
(out/'release-build-provenance.json').write_text(json.dumps(dict(baseline=base,candidate=candidate,scope='Candidate onehostobjectisolatedlink of productionOFF94libraries; parentbuildmetadataretained. BothbinarySHAs/sourcecomposition explicit. This is not fullcandidateCMake-release qualification.'),indent=2)+'\n')
pre={}
for role,dirname in(('baseline','tp2-upstream-c32136f8-worktree'),('candidate','tp2-batched-hc-q8-worktree')):
 src=r/'tp-cache-retention'/dirname
 pre[role]=dict(path=str(src),source_sha256={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest()for n in('src','include','cmake')for p in(src/n).rglob('*')if p.is_file()and '__pycache__'not in p.parts})
(out/'source-preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
seed=202611020518;first=set(random.Random(seed).sample(range(1,11),5));sequence=[]
for i in range(1,11):
 for role in(('baseline','candidate')if i in first else('candidate','baseline')):sequence.append([f'pair{i:02d}-{role}',role])
design=dict(sequence=sequence,requests_per_start=12,randomization=dict(seed=seed,baseline_first_pairs=sorted(first)),co_primaries=['C2-coding-client-wave','C2-short-client-wave'],scope='Prospective fixed10balancedrandomizedpairs/20freshstarts/240canonicalrequests, noexclusions/replacements/interimsignificancetesting/poolingwithpriorstudies. Co-primaryC2codingandshortcompleteclient-wave throughput;Holm2/20kpairedbootstrap/balancedassignment sensitivity. SecondaryC1first/repeatnegativecontrol,prefill/TTFT/tail/gaps/perrequestphases. Exactoutputs/prompt/cache/C1specwork;retainallC2adaptiveworkand5%+3msflags. SameQ4/sharedQ8MTP/65K/2slots/chunk2048/cache1GiB/81C6TX32/crossed40+20. No profiling/adminsampler/parallelbuild/tablewarm. RunONLYafterstate/wide/cachecancel/activation/source gates; current prepare isnot execution. No magnitudecutoff, no default/equivalence frominconclusive estimates.')
(out/'design.json').write_text(json.dumps(design,indent=2)+'\n')
for p in out.glob('*.py'):py_compile.compile(str(p),doraise=True)
print('Prospective comparison prepared; functional-gates.json intentionally absent until all gates pass')
