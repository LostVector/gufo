from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path(__file__).resolve().parent;d=json.loads((out/'statistical-summary.json').read_text());fig,axes=plt.subplots(2,2,figsize=(11,8))
for ax,item in zip(axes.flat,d['metrics']):
 a,b=item['baseline_values'],item['candidate_values']
 for x,y in zip(a,b):ax.plot([0,1],[x,y],color='#97a2af',alpha=.65,linewidth=.9)
 ax.scatter([0]*10,a,s=25,color='#2465a5',label='baseline');ax.scatter([1]*10,b,s=25,color='#b25b28',label='candidate')
 ax.scatter([0,1],[item['baseline_geometric_mean'],item['candidate_geometric_mean']],marker='_',s=350,color='black',linewidths=2.5)
 ax.set_xticks([0,1],['94 baseline','f5e candidate']);ax.set_xlim(-.25,1.25);ax.set_ylabel('Output tokens/s ('+('whole client wave'if 'C2-'in item['metric']else'server decode')+')')
 lo,hi=item['marginal_bootstrap95_throughput_increase_pct'];change=item['paired_geometric_throughput_increase_pct'];title=item['metric']+(' — co-primary'if item['primary']else' — secondary')
 ax.set_title(title,fontsize=10);adj=item.get('holm_adjusted_p');extra=f'; Holm p={adj:.3f}'if adj is not None else'; exploratory'
 ax.text(.5,-.21,f'{change:+.3f}%  [95% marginal CI {lo:+.3f}, {hi:+.3f}]'+extra,transform=ax.transAxes,ha='center',fontsize=8)
 ax.grid(axis='y',alpha=.15)
fig.suptitle('Batched HC Q8 reuse: ten fixed paired starts — throughput inconclusive',fontsize=13)
fig.text(.5,.015,'All 240 identities exact. No exclusions. 33 phase flags and 21 C2 work comparisons retained.\nLines join matched starts; black marks are geometric means. Component saving is not a model-speed claim.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.075,1,.95]);fig.savefig(out/'before-after.png',dpi=180);fig.savefig(out/'before-after.pdf');plt.close(fig)
