from pathlib import Path
import json,hashlib,re,csv,subprocess,shlex
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent;assert(o/'complete').exists();p=json.loads((o/'protocol.json').read_text())
for n,h in p['harness_sha256'].items():assert hashlib.sha256((o/n).read_bytes()).hexdigest()==h,n
for n,h in p['external_harness_sha256'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
pre=json.loads((o/'source-preflight.json').read_text())
for n,h in pre['source_sha256'].items():assert hashlib.sha256((Path(pre['path'])/n).read_bytes()).hexdigest()==h,n
assert hashlib.sha256((o/'probe').read_bytes()).hexdigest()==p['probe_sha256']['candidate'];data=[]
for rank in[0,1]:
 xs=[json.loads(s)for s in(o/f'candidate-r{rank}.jsonl').read_text().splitlines()];assert len(xs)==104
 assert 'PASS records=104 actual_q8_enabled_batches=44 full_state_pairs=32' in(o/f'candidate-r{rank}.stdout').read_text()
 keys={}
 for x in xs:
  key=tuple(x[k]for k in ['depth','sampled','phase','step','actor']);assert key not in keys;keys[key]=x
  assert len(x['scores_sha256'])==64 and x['tokens'] and x['position']>x['depth']
 for depth in [0,32768]:
  for sampled in [0,1]:
   for phase,count in [('warm',3),('full-reference',2),('borrowed-same',2),('borrowed-cross',2),('serialized-cross',2),('file-cross',2)]:
    for step in range(count):
     for actor in [0,1]:
      x=keys[(depth,sampled,phase,step,actor)]
      assert x['rows']==2+(0 if step%2 else 1)
      assert x['fused_q8']==int(phase!='full-reference')
      if phase not in ['warm','full-reference']:
       expected=keys[(depth,sampled,'full-reference',step,actor)]
       assert all(x[k]==expected[k]for k in ['rows','position','rng','drafted','accepted','scores_sha256','tokens'])
 assert sum(x['fused_q8']for x in xs if x['actor']==0)==44
 pid=(o/f'candidate-r{rank}.pid').read_text().strip();args=['python3','-c','from pathlib import Path;import sys;assert not Path("/proc",sys.argv[1]).exists()',pid];subprocess.run(['ssh','rk-corsair-ai',shlex.join(args)]if rank else args,check=True)
 def counters(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(o/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
 a,b=counters('candidate-before'),counters('candidate-after');assert a and a.keys()==b.keys()and all(b[k]>=v for k,v in a.items());assert not{k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
 initial=p['initial'][rank];final=json.loads((o/f'final-inventory-r{rank}.json').read_text());assert final['refcnt']==0 and len(final['devices'])==4 and all(initial[k]==final[k]for k in ['module','boot_id','cmdline','routers']);assert not re.search(r'BUG:|Oops:|kernel panic|soft lockup|hard LOCKUP|general protection fault|frame_length_invalid|RING_DESC_CRC|reorder timeout',(o/f'kernel-window-r{rank}.txt').read_text(),re.I);data.append(xs)
assert data[0]==data[1]
report=dict(records_per_rank=104,actual_Q8_enabled_batch_cycles_per_rank=44,complete_postreplay_state_pairs_per_rank=32,contexts=["short",32768],borrowed_same_and_cross_session_replay_exact=True,serialized_cross_and_file_roundtrip_cross_replay_exact=True,external_RNG_full_logits_tokens_positions_proposal_work_exact=True,cross_rank_JSON_records_exact=True,frozen_sources_harness_binary_PIDs_counters_kernel_boot_topology_idle_pass=True,scope=p['scope'],limits='File roundtrip in same model process, not fresh HTTP diskcache restart. Exact materialized state bytes compared within rank. No throughput, physical fault or default claim.')
(o/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
