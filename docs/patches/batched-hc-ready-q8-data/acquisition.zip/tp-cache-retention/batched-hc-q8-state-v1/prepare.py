from pathlib import Path
import py_compile
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;src=r/'tp-cache-retention/tp2-batched-hc-q8-worktree';old=r/'tp-cache-retention/cooperative-ple-snapshot-candidate-v2'
s=(src/'src/models/qwen38_flash_next/kernels/rocm/batch.cpp').read_text();s=s.replace('#include <algorithm>','#include <algorithm>\n#include <atomic>',1)
needle='namespace gufo::models::qwen38_flash_next::rocm {\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''namespace {
std::atomic<bool> hc_q8_probe_enabled{false};
std::array<std::atomic<std::uint64_t>, 65> hc_q8_probe_heads{};
std::array<std::atomic<std::uint64_t>, 65> hc_q8_probe_produced{};
}
void HcQ8ProbeReset(bool enabled) {
  hc_q8_probe_enabled.store(enabled, std::memory_order_relaxed);
  for (auto& value : hc_q8_probe_heads) value.store(0, std::memory_order_relaxed);
  for (auto& value : hc_q8_probe_produced) value.store(0, std::memory_order_relaxed);
}
std::uint64_t HcQ8ProbeHeads(unsigned rows) {
  return rows <= 64 ? hc_q8_probe_heads[rows].load(std::memory_order_relaxed) : 0;
}
std::uint64_t HcQ8ProbeProduced(unsigned rows) {
  return rows <= 64 ? hc_q8_probe_produced[rows].load(std::memory_order_relaxed) : 0;
}
''',1)
s=s.replace('const bool q8 = rows <= kDecodeRows', 'const bool q8 = hc_q8_probe_enabled.load(std::memory_order_relaxed) &&\n                  rows <= kDecodeRows',1)
s=s.replace('''  if (q8)
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};''','''  if (q8) {
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};
    hc_q8_probe_produced[rows].fetch_add(1, std::memory_order_relaxed);
  }''',1)
s=s.replace('    const auto& output = model_->output();','    const auto& output = model_->output();\n    hc_q8_probe_heads[rows].fetch_add(1, std::memory_order_relaxed);',1)
assert 'gather_head =\n        rows >='in s # The existing gather path is NOT toggled by this test.
(out/'diagnostic-batch.cpp').write_text(s)
s=(old/'probe.cpp').read_text().replace('BatchedHeadProbeReset','HcQ8ProbeReset').replace('BatchedHeadProbeHeads','HcQ8ProbeHeads').replace('BatchedHeadProbeGathers','HcQ8ProbeProduced')
s=s.replace('''gc == unsigned(enabled) &&
                     q::rocm::HcQ8ProbeProduced(rows) ==
                         unsigned(enabled)''','''(enabled ? gc > 0 : gc == 0) &&
                     (enabled ? q::rocm::HcQ8ProbeProduced(rows) > 0 :
                                q::rocm::HcQ8ProbeProduced(rows) == 0)''')
s=s.replace('"exact actual batch gather activation"','"actual target batch shape and optional Q8 producer activation"').replace('gathers += gc;','gathers += unsigned(enabled);')
s=s.replace('actual_batch_gathers=44','actual_q8_enabled_batches=44').replace('paired full-projection','paired unfused quantization')
s=s.replace('\\\"gather\\\":','\\\"fused_q8\\\":')
(out/'probe.cpp').write_text(s)
# Preserve the established owned two-host lifecycle/counter/runtime harness.
for n in('run.py','analyze.py'):
 s=(old/n).read_text()
 if n=='run.py':
  s=s.replace('104records/44gathers/32fullstatepairs','104records/44Q8enabledcycles/32fullstatepairs').replace('paired full-projection reference','paired optionalQ8 disabled/enabled reference, existing head gather unchanged')
  s=s.replace('Fresh production Release/OFF PLE candidate numerical/state control','Diagnostic f5e batched-HC optionalQ8 numerical/state control, current production OFF objects')
 if n=='analyze.py':
  s=s.replace('actual_batch_gathers=44','actual_q8_enabled_batches=44').replace("'gather'","'fused_q8'").replace('actual_new_batch_gathers_per_rank=44','actual_Q8_enabled_batch_cycles_per_rank=44')
 (out/n).write_text(s)
for p in out.glob('*.py'):py_compile.compile(str(p),doraise=True)
