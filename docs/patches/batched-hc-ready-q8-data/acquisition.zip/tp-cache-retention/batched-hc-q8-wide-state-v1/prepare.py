from pathlib import Path
import py_compile
r=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent;old=r/'tp-cache-retention/batched-target-head-wide-quality-v1';state=r/'tp-cache-retention/batched-hc-q8-state-v2'
(out/'diagnostic-batch.cpp').write_bytes((state/'diagnostic-batch.cpp').read_bytes());(out/'build.py').write_bytes((state/'build.py').read_bytes())
s=(old/'probe.cpp').read_text().replace('src/models/qwen/chat_template.hpp','src/families/qwen/text/chat_template.hpp').replace('BatchedHeadProbeReset','HcQ8ProbeReset').replace('BatchedHeadProbeHeads','HcQ8ProbeHeads').replace('BatchedHeadProbeGathers','HcQ8ProbeProduced')
needle='''        Case{"C4-n4", 4, 0, 4, 0},''';assert needle in s
s=s.replace(needle,'''        Case{"C2-n2", 2, 0, 2, 0}, Case{"C3-n3", 3, 0, 3, 0},
        Case{"C5-n5", 5, 0, 5, 0}, Case{"C7-n7", 7, 0, 7, 0},
        Case{"C8-fallback9", 8, 1, 9, 0}, Case{"C8-fallback12", 8, 4, 12, 0},
'''+needle)
s=s.replace('''const bool eligible = enabled && test.kind == 0 &&
                                    target_rows >= 2 && target_rows <= 7;''','''const bool eligible = enabled && target_rows >= 1 && target_rows <= 8;''')
s=s.replace('''q::rocm::HcQ8ProbeProduced(target_rows) ==
                       unsigned(eligible)''','''(eligible ? q::rocm::HcQ8ProbeProduced(target_rows) > 0 :
                          q::rocm::HcQ8ProbeProduced(target_rows) == 0)''')
s=s.replace('''Need(gather_total == unsigned(eligible),
                   "unexpected extra gather");''','''Need(enabled || gather_total == 0,
                   "disabled optional producer emitted Q8");''')
s=s.replace('actual new batch gather/fallback activation','actual optional Q8 producer/fallback activation')
s=s.replace('records == 1200 && gathers == 72 && state_pairs == 300','records == 1992 && gathers == 180 && state_pairs == 498')
s=s.replace('records=1200 actual_batch_gathers=72 full_state_pairs=300','records=1992 actual_q8_head_batches=180 full_state_pairs=498')
s=s.replace('(enabled ? "gather" : "full")','(enabled ? "fused" : "unfused")').replace('\\\"gather\\\":','\\\"q8_head_eligible\\\":')
(out/'probe.cpp').write_text(s)
s=(state/'run.py').read_text().replace('len(data)==104','len(data)==1992')
s=s.replace("'sessions':2", "'sessions':8")
a=s.index("'scope':");b=s.index("},indent=2)",a)
s=s[:a]+"'scope':'Currentf5eoptionalHCQ8disabled/enabled samebinary, productionOFF94GPU/headers/wireunchanged;1992pairedoutputrecordsrank/498fullstatepairs/180Q8eligibleheadcycles. Actualshort/32K; greedy,sampled,mixedsampler; widths2/3/4/5/6/7/8,raggedpacked2..9/12,mixedAR; targetheadgatherunchanged. Diagnosticnotperformance; snapshotcachevarietylivesinseparatestateprobe.'"+s[b:]
(out/'run.py').write_text(s)
s=(old/'analyze.py').read_text().replace('1200','1992').replace('actual_batch_gathers=72 full_state_pairs=300','actual_q8_head_batches=180 full_state_pairs=498')
s=s.replace("cases={'C4-n4'", "cases={'C2-n2':(2,2),'C3-n3':(3,3),'C5-n5':(5,5),'C7-n7':(7,7),'C8-fallback9':(8,9),'C8-fallback12':(8,12),'C4-n4'")
s=s.replace("['full','gather']","['unfused','fused']").replace("'gather'","'q8_head_eligible'")
s=s.replace("int('mixedAR' not in case and expected_rows<=7)","int(expected_rows<=8)").replace('==72','==180')
s=s.replace('paired_cases_per_rank=60','paired_cases_per_rank=96').replace('actual_new_batch_gathers_per_rank=72','actual_Q8_eligible_head_cycles_per_rank=180').replace('complete_materialized_state_pairs_per_rank=300','complete_materialized_state_pairs_per_rank=498').replace('actual_concurrencies=[4,6,8]','actual_concurrencies=[2,3,4,5,6,7,8]')
(out/'analyze.py').write_text(s)
for p in out.glob('*.py'):py_compile.compile(str(p),doraise=True)
