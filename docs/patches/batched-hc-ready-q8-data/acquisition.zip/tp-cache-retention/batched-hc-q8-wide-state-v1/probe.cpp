#include "src/core/crypto/sha256.hpp"
#include "src/families/qwen/text/chat_template.hpp"
#include "src/models/qwen38_flash_next/engine.hpp"
#include "src/models/qwen38_flash_next/kernels/rocm/verbs.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace q = gufo::models::qwen38_flash_next;
namespace gufo::models::qwen38_flash_next::rocm {
void HcQ8ProbeReset(bool);
std::uint64_t HcQ8ProbeHeads(unsigned);
std::uint64_t HcQ8ProbeProduced(unsigned);
} // namespace gufo::models::qwen38_flash_next::rocm
void Need(bool ok, const std::string &message) {
  if (!ok)
    throw std::runtime_error(message);
}
std::string Scores(const q::Session &session) {
  auto scores = session.Logits();
  Need(scores.size() == 248320 &&
           std::all_of(scores.begin(), scores.end(),
                       [](float x) { return std::isfinite(x); }),
       "complete finite target scores");
  return gufo::crypto::Sha256Hex(
      {reinterpret_cast<const std::uint8_t *>(scores.data()),
       scores.size_bytes()});
}
struct Record {
  std::vector<std::int32_t> tokens;
  std::string scores;
  std::uint32_t position;
  std::uint64_t rng, drafted, accepted;
  bool operator==(const Record &) const = default;
};
struct Case {
  const char *name;
  unsigned width, drafts, rows, kind;
};
int main(int argc, char **argv) {
  std::shared_ptr<q::rocm::Communicator> comm;
  try {
    Need(argc == 7, "rank host device target mtp output");
    const unsigned rank = std::stoul(argv[1]);
    Need(rank < 2, "rank");
    q::rocm::IbrverbsConfig transport;
    transport.rank = rank;
    transport.bootstrap_host = argv[2];
    transport.rdma_device = argv[3];
    transport.bootstrap_port = 29659;
    std::string error;
    comm = q::rocm::CreateIbrverbsCommunicator(transport, &error);
    Need(bool(comm) && comm->SupportsTargetHeadGather(), error);
    q::ModelOptions options;
    options.tp_world_size = 2;
    options.tp_rank = rank;
    options.communicator = comm;
    options.max_context = 65536;
    options.decode_concurrency = 8;
    options.max_draft_tokens = 7;
    options.mtp_model_path = argv[5];
    auto model = q::Model::Load(argv[4], options, &error);
    Need(bool(model), error);
    std::vector<std::unique_ptr<q::Session>> owned;
    std::vector<q::Session *> sessions;
    for (unsigned i = 0; i < 9; ++i) {
      owned.push_back(
          model->CreateSession(i == 8 ? gufo::core::SessionMode::kAutoregressive
                                      : gufo::core::SessionMode::kSpeculative,
                               65536, &error));
      Need(bool(owned.back()), error);
      sessions.push_back(owned.back().get());
    }
    gufo::ReasoningOptions reason;
    reason.enabled = false;
    auto chat = gufo::tokenization::ResolveQwenChatOptions(reason);
    chat.max_output_bytes = gufo::tokenization::RenderedPromptBoundBytes(65536);
    auto prompt = [&](const char *text) {
      const std::array messages{gufo::tokenization::ChatMessage{
          gufo::tokenization::ChatRole::kUser, text}};
      auto ids = gufo::tokenization::QwenChatTemplate::RenderAndTokenize(
          model->tokenizer(), messages, chat, &error);
      Need(bool(ids), error);
      return std::vector<std::int32_t>(ids->begin(), ids->end());
    };
    std::vector<std::vector<std::int32_t>> short_prefixes;
    for (unsigned i = 0; i < 8; ++i) {
      const auto text = "Implement a robust timestamp parser; actor " +
                        std::to_string(i) +
                        " should explain unique edge cases and tests.";
      short_prefixes.push_back(prompt(text.c_str()));
    }
    short_prefixes.push_back(short_prefixes[0]);
    auto pattern = model->Tokenize(
        "Explain how independent requests keep separate context and sampling "
        "state during distributed inference. ");
    Need(!pattern.empty(), "long prefix pattern");
    const std::array cases{
        Case{"C2-n2", 2, 0, 2, 0}, Case{"C3-n3", 3, 0, 3, 0},
        Case{"C5-n5", 5, 0, 5, 0}, Case{"C7-n7", 7, 0, 7, 0},
        Case{"C8-fallback9", 8, 1, 9, 0}, Case{"C8-fallback12", 8, 4, 12, 0},
        Case{"C4-n4", 4, 0, 4, 0},         Case{"C4-n5", 4, 1, 5, 0},
        Case{"C4-n7", 4, 3, 7, 0},         Case{"C4-fallback8", 4, 4, 8, 0},
        Case{"C6-n6", 6, 0, 6, 0},         Case{"C6-n7", 6, 1, 7, 0},
        Case{"C6-fallback8", 6, 2, 8, 0},  Case{"C8-fallback8", 8, 0, 8, 0},
        Case{"C4-mixedAR-n4", 4, 0, 4, 1}, Case{"C4-mixedAR-n5", 4, 1, 5, 1}};
    std::ofstream output(argv[6]);
    Need(bool(output), "output");
    Need(comm->BeginOperation(72415, &error), error);
    std::size_t records = 0, gathers = 0, state_pairs = 0;
    for (unsigned depth : {0U, 32768U}) {
      std::cout << "START depth=" << depth << std::endl;
      auto prefixes = short_prefixes;
      if (depth) {
        for (unsigned i = 0; i < 9; ++i) {
          const auto ending = prefixes[i];
          prefixes[i].resize(depth - ending.size());
          for (std::size_t j = 0; j < prefixes[i].size(); ++j)
            prefixes[i][j] = pattern[j % pattern.size()];
          prefixes[i].insert(prefixes[i].end(), ending.begin(), ending.end());
          Need(prefixes[i].size() == depth, "actual 32K prefix");
        }
      }
      q::rocm::HcQ8ProbeReset(false);
      std::vector<std::unique_ptr<q::SessionSnapshot>> initial(9);
      for (unsigned i = 0; i < 9; ++i) {
        sessions[i]->Reset();
        Need(sessions[i]->Sync(prefixes[i], &error), error);
        initial[i] = sessions[i]->SaveSnapshot(
            &error, q::Session::SnapshotMode::kMaterialized);
        Need(bool(initial[i]), error);
      }
      Need(Scores(*sessions[0]) == Scores(*sessions[8]),
           "AR prefill frontier parity");
      for (unsigned i = 1; i < 8; ++i)
        Need(Scores(*sessions[0]) != Scores(*sessions[i]),
             "distinct actor frontiers");
      for (unsigned mode = 0; mode < 3; ++mode) {
        const char *mode_name = mode == 0   ? "greedy"
                                : mode == 1 ? "sampled"
                                            : "mixed-sampler";
        for (const auto &test : cases) {
          std::vector<unsigned> indices(test.width);
          for (unsigned i = 0; i < test.width; ++i)
            indices[i] = i;
          if (test.kind)
            indices.back() = 8;
          std::vector<std::unique_ptr<q::SessionSnapshot>> baseline_state(
              test.width);
          std::vector<Record> expected;
          for (bool enabled : {false, true}) {
            for (auto i : indices)
              Need(sessions[i]->RestoreSnapshot(*initial[i], &error), error);
            std::vector<gufo::sampling::SamplerState> rng;
            rng.reserve(test.width);
            for (unsigned actor = 0; actor < test.width; ++actor) {
              gufo::sampling::SamplingConfig config{};
              config.temperature =
                  mode == 1 || (mode == 2 && actor % 2) ? .7F : 0.F;
              config.top_k = 40;
              config.top_p = .9F;
              config.seed = 73 + 18 * actor;
              rng.emplace_back(config);
            }
            unsigned record_index = 0;
            for (unsigned stage = 0; stage < 2; ++stage) {
              const unsigned target_rows = stage == 0 ? test.rows : test.width;
              q::rocm::HcQ8ProbeReset(enabled);
              std::vector<q::Session::DecodeResult> result(test.width);
              std::vector<q::Session::BatchOutcome> outcome(test.width);
              std::vector<q::Session::SpeculativeStats> before;
              std::vector<q::Session::DecodeRequest> requests;
              for (unsigned actor = 0; actor < test.width; ++actor) {
                before.push_back(sessions[indices[actor]]->Statistics());
                requests.push_back(
                    {sessions[indices[actor]], 16, &rng[actor], &result[actor],
                     false, &outcome[actor],
                     stage == 0 && actor == 0 ? test.drafts : 0});
              }
              // An explicit empty shared plan keeps timing-based batch-policy
              // learning out; each supported per-request forced plan stands.
              const std::optional<std::uint32_t> shared_plan{};
              Need(q::Session::DecodeBatch(requests, &error, &shared_plan),
                   error);
              std::uint64_t head_total = 0, gather_total = 0;
              for (unsigned row = 0; row <= 64; ++row) {
                head_total += q::rocm::HcQ8ProbeHeads(row);
                gather_total += q::rocm::HcQ8ProbeProduced(row);
              }
              Need(head_total == 1, "exactly one target batch required");
              Need(q::rocm::HcQ8ProbeHeads(target_rows) == 1,
                   "actual packed head row count differs from the declared "
                   "case");
              const bool eligible = enabled && target_rows >= 1 && target_rows <= 8;
              Need((eligible ? q::rocm::HcQ8ProbeProduced(target_rows) > 0 :
                          q::rocm::HcQ8ProbeProduced(target_rows) == 0),
                   "actual optional Q8 producer/fallback activation");
              Need(enabled || gather_total == 0,
                   "disabled optional producer emitted Q8");
              if (eligible)
                ++gathers;
              for (unsigned actor = 0; actor < test.width; ++actor) {
                auto &session = *sessions[indices[actor]];
                Need(outcome[actor].completed && !result[actor].tokens.empty(),
                     "both actors must progress");
                const auto after = session.Statistics();
                Record record{result[actor].tokens,
                              Scores(session),
                              session.Position(),
                              rng[actor].rng_state(),
                              after.drafted - before[actor].drafted,
                              after.accepted - before[actor].accepted};
                if (!enabled)
                  expected.push_back(record);
                else
                  Need(record == expected.at(record_index),
                       "paired tokens/full logits/position/RNG/proposal work "
                       "differ");
                ++record_index;
                output << "{\"depth\":" << depth << ",\"mode\":\"" << mode_name
                       << "\",\"case\":\"" << test.name << "\",\"arm\":\""
                       << (enabled ? "fused" : "unfused")
                       << "\",\"stage\":" << stage << ",\"actor\":" << actor
                       << ",\"rows\":" << target_rows
                       << ",\"q8_head_eligible\":" << unsigned(eligible)
                       << ",\"position\":" << record.position
                       << ",\"rng\":" << record.rng
                       << ",\"drafted\":" << record.drafted
                       << ",\"accepted\":" << record.accepted
                       << ",\"scores_sha256\":\"" << record.scores
                       << "\",\"tokens\":[";
                for (std::size_t j = 0; j < record.tokens.size(); ++j) {
                  if (j)
                    output << ',';
                  output << record.tokens[j];
                }
                output << "]}\n";
                output.flush();
                ++records;
              }
            }
            for (unsigned actor = 0; actor < test.width; ++actor) {
              auto state = sessions[indices[actor]]->SaveSnapshot(
                  &error, q::Session::SnapshotMode::kMaterialized);
              Need(bool(state), error);
              if (!enabled) {
                baseline_state[actor] = std::move(state);
              } else {
                const auto reference = baseline_state[actor]->bytes();
                const auto actual = state->bytes();
                if (reference.size() != actual.size() ||
                    !std::equal(reference.begin(), reference.end(),
                                actual.begin())) {
                  const std::string stem = std::string(argv[6]) + ".state-" +
                                           std::to_string(depth) + "-" +
                                           mode_name + "-" + test.name +
                                           "-actor" + std::to_string(actor);
                  auto save = [&](auto bytes, const char *suffix) {
                    std::ofstream file(stem + suffix, std::ios::binary);
                    file.write(reinterpret_cast<const char *>(bytes.data()),
                               bytes.size());
                    Need(bool(file), "save state mismatch artifact");
                  };
                  save(reference, "-full.bin");
                  save(actual, "-gather.bin");
                  std::size_t offset = 0;
                  while (offset < std::min(reference.size(), actual.size()) &&
                         reference[offset] == actual[offset])
                    ++offset;
                  throw std::runtime_error(
                      "paired complete materialized state bytes differ; " +
                      stem + " first_offset=" + std::to_string(offset) +
                      " sizes=" + std::to_string(reference.size()) + "," +
                      std::to_string(actual.size()));
                }
                ++state_pairs;
              }
            }
          }
          std::cout << "PASS depth=" << depth << " mode=" << mode_name
                    << " case=" << test.name << std::endl;
        }
      }
    }
    Need(records == 1992 && gathers == 180 && state_pairs == 498,
         "total fixture coverage");
    Need(comm->EndOperation(72415, &error), error);
    std::cout
        << "PASS records=1992 actual_q8_head_batches=180 full_state_pairs=498 "
           "full_logits_tokens_positions_RNG_work_exact=true\n";
    return 0;
  } catch (const std::exception &exception) {
    if (comm)
      comm->Abort(exception.what());
    std::cerr << exception.what() << '\n';
    return 1;
  }
}
