from pathlib import Path
import fcntl,hashlib,json,os,shlex,signal,subprocess,time
root=Path('/home/rkuo/strix-dispatch-investigation');out=Path(__file__).resolve().parent
lock=(root/'overnight/results/model-matrix.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not(out/'protocol.json').exists()
def cmd(rank,args):return ['ssh','-o','BatchMode=yes','rk-corsair-ai',shlex.join(args)]if rank else args
def call(rank,args):return subprocess.check_output(cmd(rank,args),text=True,stderr=subprocess.STDOUT,timeout=60)
def snapshot(tag):
 for rank in(0,1):(out/f'{tag}-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
call(1,['mkdir','-p',str(out)])
initial=[]
for rank in (0,1):
 inv=json.loads(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']));initial.append(inv)
 (out/f'initial-inventory-r{rank}.json').write_text(json.dumps(inv,indent=2)+'\n')

builds={}
for mode in('candidate',):
 probe=out/'probe';builds[mode]=hashlib.sha256(probe.read_bytes()).hexdigest();subprocess.run(['rsync','-rt',str(probe),f'rk-corsair-ai:{probe}'],check=True)
 assert call(1,['sha256sum',str(probe)]).split()[0]==builds[mode]
 for rank in (0,1):
  script='source '+shlex.quote(str(root/'native-rdma/env.sh'))+'\nexport LD_LIBRARY_PATH='+shlex.quote(str(root/'tp-cache-retention/fork-integration-v1/runtime/lib'))+':"$LD_LIBRARY_PATH"\nldd '+shlex.quote(str(probe))
  dependencies=call(rank,['bash','-c',script]);(out/f'ldd-r{rank}.txt').write_text(dependencies);assert 'not found' not in dependencies
pre=json.loads((out/'source-preflight.json').read_text())
for n,h in pre['source_sha256'].items():assert hashlib.sha256((Path(pre['path'])/n).read_bytes()).hexdigest()==h,n
(out/'protocol.json').write_text(json.dumps({'initial':initial,'harness_sha256':{n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in ['probe.cpp','diagnostic-batch.cpp','build.py','build-commands.json','run.py','analyze.py','source-preflight.json','post-build.json']},'external_harness_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in ['native-rdma/env.sh','cable-prep/env.sh','tp-cache-retention/driver-parent-timing-v1/inventory.py']},'sequence':['candidate'],'probe_sha256':builds,'context_capacity':65536,'sessions':8,'scope':'Currentf5eoptionalHCQ8disabled/enabled samebinary, productionOFF94GPU/headers/wireunchanged;1992pairedoutputrecordsrank/498fullstatepairs/180Q8eligibleheadcycles. Actualshort/32K; greedy,sampled,mixedsampler; widths2/3/4/5/6/7/8,raggedpacked2..9/12,mixedAR; targetheadgatherunchanged. Diagnosticnotperformance; snapshotcachevarietylivesinseparatestateprobe.'},indent=2)+'\n')
start=int(time.time())-5
try:
 for mode in('candidate',):
  jobs=[];probe=out/'probe'
  for rank in(0,1):
   inv=json.loads(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']));assert inv['refcnt']==0 and inv['module']=='81C6FF2FBAC473C7AB21844'
   (out/f'{mode}-inventory-r{rank}.json').write_text(json.dumps(inv,indent=2)+'\n')
  snapshot(mode+'-before');print(time.strftime('%F %T'),'START',mode,flush=True)
  try:
   for rank in(0,1):
    args=[str(probe),str(rank),'192.168.64.125','usb4_rdma0','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf',str(out/f'{mode}-r{rank}.jsonl')]
    script='cd '+shlex.quote(str(root))+'\nsource native-rdma/env.sh\nexport LD_LIBRARY_PATH=/home/rkuo/strix-dispatch-investigation/tp-cache-retention/fork-integration-v1/runtime/lib:"$LD_LIBRARY_PATH"\nunset LD_PRELOAD ROCP_TOOL_ATTACH STRIX_OCCUPY_OLD_RDMA\necho $$ > '+shlex.quote(str(out/f'{mode}-r{rank}.pid'))+'\nexec '+shlex.join(args)+' > '+shlex.quote(str(out/f'{mode}-r{rank}.stdout'))+' 2> '+shlex.quote(str(out/f'{mode}-r{rank}.stderr'))
    jobs.append(subprocess.Popen(cmd(rank,['bash','-c',script])))
   began=time.monotonic()
   while True:
    codes=[p.poll() for p in jobs]
    if all(code is not None for code in codes): break
    assert not[p.returncode for p in jobs if p.returncode not in(None,0)],'Probe failure; inspect both rank logs'
    assert time.monotonic()-began<900,'Numerical probe deadline';time.sleep(.2)
   assert all(p.returncode==0 for p in jobs)
  finally:
   for rank,job in enumerate(jobs):
    if job.poll()is None:
     try:
      pid=call(rank,['cat',str(out/f'{mode}-r{rank}.pid')]).strip();exe=call(rank,['readlink','-f','/proc/'+pid+'/exe']).strip();assert exe==str(probe);call(rank,['kill','-INT',pid])
     except subprocess.CalledProcessError:pass
     try:job.wait(timeout=15)
     except subprocess.TimeoutExpired:call(rank,['kill','-TERM',pid]);job.wait(timeout=15)
   snapshot(mode+'-after')
   for suffix in ('stdout','stderr','pid','jsonl'):
    subprocess.run(['rsync','-rt',f'rk-corsair-ai:{out}/{mode}-r1.{suffix}',str(out)+'/'],check=False)
  subprocess.run(['rsync','-rt',f'rk-corsair-ai:{out}/{mode}-r1.jsonl',str(out)+'/',],check=True)
  for suffix in('stdout','stderr'):subprocess.run(['rsync','-rt',f'rk-corsair-ai:{out}/{mode}-r1.{suffix}',str(out)+'/',],check=True)
  for rank in(0,1):
   for suffix in ('pid',):
    if rank:subprocess.run(['rsync','-rt',f'rk-corsair-ai:{out}/{mode}-r1.{suffix}',str(out)+'/'],check=True)
   data=[json.loads(s)for s in(out/f'{mode}-r{rank}.jsonl').read_text().splitlines()];assert len(data)==1992 and all(x['scores_sha256']for x in data)
  (out/f'{mode}-complete').touch();print(time.strftime('%F %T'),'COMPLETE',mode,flush=True)
 (out/'complete').touch()
finally:
 for rank in(0,1):
  (out/f'final-inventory-r{rank}.json').write_text(call(rank,['python3',str(root/'tp-cache-retention/driver-parent-timing-v1/inventory.py'),'baseline']))
  (out/f'kernel-window-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-driver-lab','run','fork-integration/hardware/kernel-window.py',str(start)]))
