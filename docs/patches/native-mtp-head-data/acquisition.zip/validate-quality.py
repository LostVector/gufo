from pathlib import Path
import json,re,collections
p=Path(__file__).resolve().parent/'candidate';assert(p/'complete').exists()and(p/'component-complete').exists()
reports=[];rows=[]
for rank in(0,1):
 a=[json.loads(x)for x in(p/f'rank{rank}.jsonl').read_text().splitlines()];assert len(a)==294
 log=(p/f'rank{rank}.log').read_text();states=re.findall(r'^STATE .+$',log,re.M);assert len(states)==28
 assert 'PASS cases=7 records=294 full_state_pairs=28' in log
 shapes=sorted(set(n for r in a for n in r['rows']));assert shapes==list(range(1,9)),shapes
 depths=sorted(set(r['depth']for r in a));assert depths==[0,16384,32768]
 reports.append({'rank':rank,'records':len(a),'full_state_comparisons':len(states),'actual_target_rows':shapes,'actual_depths':depths,'row_counts':dict(collections.Counter(n for r in a for n in r['rows'])),'final_coverage':next(x for x in log.splitlines() if x.startswith('PASS cases='))});rows.append(a)
assert all((a['rows'],a['verification_sha256'],a['logits_sha256'])==(b['rows'],b['verification_sha256'],b['logits_sha256'])for a,b in zip(*rows))
result={'pass':True,'ranks':reports,'full_verification_frontier_hashes_match_across_ranks':True,'scope':'Exact candidate vs baseline logits/tokens/RNG/work/full serialized state in probe. Borrowed snapshots materialized before mutation; added diagnostic synchronization not async lifetime or performance proof.'}
(p/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
