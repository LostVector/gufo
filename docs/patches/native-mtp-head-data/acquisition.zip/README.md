# Native MTP TP2 optimization — November 9, 2026

Status: numerical/state/serving qualification, the ABBA pilot and the fixed
confirmation study are complete. C1 decode gain is +1.487%, 95% CI
[1.298, 1.684]%, exact p=0.007937. The C2 screen is complete but its performance remains inconclusive. See RESULTS.md.
No deployment or PR publication. Original native MTP is restored by each test wrapper.

## Mechanism

The existing native MTP vocabulary-head gather covered only two verification
rows. The adaptive controller also uses widths 3–8, which duplicated the full
248,320 × 2,560 Q8_0 vocabulary projection on both ranks. The isolated candidate
uses the existing lossless rank-half gather for those native verification rows,
under the same world/type/capacity guards. AR, prefill, two-row native MTP and
external DFlash routes retain their behavior. No new kernel, allocation, public
flag, arithmetic, sampler, controller or driver change.

Base: fork `tp2` at ff485f1792364b48b73e200db6deb03f49c22623. Candidate source:
`candidate/executor.cpp`; review checkout: `source/`, local branch
`review/native-mtp-head-sharing`. `production-provenance.json` pins source and
binary hashes and all 338 normalized compiler commands, identical apart from
revision metadata. The uninstrumented baseline reuses the preceding qualified
binary: its production source is byte-identical to the merged base. Its compiled
revision string predates the squash merge; this is explicitly a source-equivalent
artifact, not a claim it was rebuilt from that commit.

## Direct observations and qualification

The separate bounded source observer adds CPU timestamps only, with no GPU waits
or work. Target forwards account for about 86–91% of measured decode-cycle wall
time, including real GPU work, communication and synchronization. Nested phases
are not additive. Per-case decode classification starts at the first
`PrepareDecode` scope, excluding small prefill tails. Three-row verification is
common: 66 of 120 decode passes in the prose request. These phases are diagnostic,
not production timing evidence or pure CPU overhead.

The candidate passes 64 independent real-weight head component cases and
71,516,160 finite bitwise logits with allocation guards **per node**, across
all row counts 1–8. Actual engine replay covers 294 records and 28 complete
serialized post-replay state comparisons **per node**, short/16K/32K depths,
greedy/compact sampled/noncompact sampled execution, rejection, rollback,
borrowed-object/serialized/file restores and all target widths 1–8. Full
verification/frontier logits, tokens, RNG, history, work and state match.
Borrowed snapshots are materialized before mutation. Additional diagnostic
synchronization means this is not asynchronous copy-on-write lifetime evidence.

Unmodified HTTP fixtures pass stops, actual long-context histories, state edges,
cancellation/resume, isolated cache spacing and disk persistence/restarts.
`functional/` retains reports and timings. Cache spacing owns a separate cache,
avoiding the previously identified foreign-conversation aggregate contamination;
no assertions or thresholds were changed.

The fixed four-start ABBA production pilot preserves all 24 outputs and work
counters. Its descriptive five-task decode change is +1.315%, with individual
changes +0.754% to +2.098%. No phase flags or recovered transport errors occur
in that pilot. It is not significance evidence and is excluded from confirmation.

## Timing protocol and reproduction

Two Strix Halo nodes, approved B6 driver, existing dual cables, target
UD-Q4_K_XL/shared-Q8_0 native MTP, 65,536 context capacity, chunk 2,048, thinking
off, no prompt cache/persistence or full-table warming. C1 uses one slot; C2 uses
eight slots with two active clients. Greedy and sampled tasks use neutral target
penalties. This is not directly comparable to earlier prose tasks with different
penalties, prompts or seeds. Natural EOS is retained.

Exact commands used, from `/home/rkuo/strix-dispatch-investigation`:

```sh
bash dflash-upstream-2026-11-07/build.sh python3 tp-cache-retention/native-mtp-optimization-2026-11-09/prepare.py
bash dflash-upstream-2026-11-07/build.sh python3 tp-cache-retention/native-mtp-optimization-2026-11-09/build.py
bash tp-cache-retention/native-mtp-optimization-2026-11-09/run-locked.sh
python3 tp-cache-retention/native-mtp-optimization-2026-11-09/analyze.py
bash dflash-upstream-2026-11-07/build.sh python3 tp-cache-retention/native-mtp-optimization-2026-11-09/prepare-candidate.py
bash dflash-upstream-2026-11-07/build.sh python3 tp-cache-retention/native-mtp-optimization-2026-11-09/candidate/build.py
bash dflash-upstream-2026-11-07/build.sh python3 tp-cache-retention/native-mtp-optimization-2026-11-09/candidate/build-quality.py
bash tp-cache-retention/native-mtp-optimization-2026-11-09/candidate/run-quality-locked.sh
python3 tp-cache-retention/native-mtp-optimization-2026-11-09/validate-quality.py
bash tp-cache-retention/native-mtp-optimization-2026-11-09/pilot/run-locked.sh
python3 tp-cache-retention/native-mtp-optimization-2026-11-09/pilot/analyze.py
bash tp-cache-retention/native-mtp-optimization-2026-11-09/functional/run-locked.sh
bash tp-cache-retention/native-mtp-optimization-2026-11-09/confirmation/run-locked.sh
python3 tp-cache-retention/native-mtp-optimization-2026-11-09/confirmation/analyze.py
```

Scripts are pinned to the recorded local model files, toolchain and prior build
artifacts; use fresh isolation paths, never overwrite existing evidence. The
preparation script pins the base and refuses unexpected branch state. Build the
production candidate before the diagnostic archive, so observer objects cannot
contaminate quality/performance attribution. Two initial diagnostic compile
failures (a scope-variable collision and a private helper accessor) are retained;
only the harness was corrected. All final binaries are separately hashed.

All GPU experiments own the shared model-matrix lock. Their wrappers pause the
existing service and restore it on exit; management Ethernet remains active.
No driver reload or kernel/ROCm/boot modification is part of this task.

`confirmation/DESIGN.json` fixes 20 starts / ten balanced process pairs / 120
requests, five tasks clustered within each process pair and fresh sampled seeds
2001–2010. Primary inference is mean paired log decode-rate change, with a
20,000-draw order-stratified bootstrap and all 252 balanced-order assignments.
Client wall throughput is secondary. Preserve all phase flags and transport
errors; no pilot pooling, optional stopping, exclusions or replacement.

## Next hypotheses, not measured gains

One-row native AR fallback still duplicates its target head. Extending that route
needs a separate measured comparison and quality gate. Local native draft/catch-up
GPU graphs may be possible where the body has no host communication, but TP2's
current blanket eager rule also protects paths with host collectives. It must
not be removed globally. Neither is part of this candidate.

C2 reproduction: `bash tp-cache-retention/native-mtp-optimization-2026-11-09/c2/run-locked.sh`, then `python3 tp-cache-retention/native-mtp-optimization-2026-11-09/c2/analyze.py`. Requires a fresh output directory.
