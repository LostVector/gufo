from pathlib import Path
import subprocess,shutil,json,hashlib
p=Path(__file__).resolve().parent
root=p.parents[1]; src=root/'tp-cache-retention/dflash2-flash-next-worktree'
base='ff485f1792364b48b73e200db6deb03f49c22623'
subprocess.run(['git','fetch','fork','tp2'],cwd=src,check=True)
assert subprocess.check_output(['git','rev-parse','fork/tp2'],cwd=src,text=True).strip()==base
for name in ('engine.cpp','kernels/rocm/executor.cpp'):
 data=subprocess.check_output(['git','show',base+':src/models/qwen38_flash_next/'+name],cwd=src)
 (p/('baseline-'+Path(name).name)).write_bytes(data)
old=root/'tp-cache-retention/dflash-head-qualification-2026-11-09'
assert (old/'production-source.cpp').read_bytes()==(p/'baseline-executor.cpp').read_bytes()
header=(old/'correlation/observer.hpp').read_text().replace('8192','32768')
(p/'observer.hpp').write_text(header)

def scope(text,signature,stage,owner,pos,rows):
 i=text.index(signature); j=text.index('{',i)+1
 return text[:j]+f'\n  dcost::Scope cost_scope("{stage}", {owner}, {pos}, {rows});'+text[j:]
e=(p/'baseline-engine.cpp').read_text()
e='#include "'+str(p/'observer.hpp')+'"\n'+e
for sig,stage in [('bool Session::PrepareDecode(', 'prepare'),('bool Session::FinishDecode(', 'finish'),('bool Session::DraftCatchUp(', 'catch-up')]:
 e=scope(e,sig,stage,'this','Position()','0')
(p/'observer-engine.cpp').write_text(e)
e=(p/'baseline-executor.cpp').read_text();e='#include "'+str(p/'observer.hpp')+'"\n'+e
for sig,stage,pos,rows in [
 ('bool Executor::Forward(', 'target-forward','session.position_','tokens.size()'),
 ('bool Executor::MtpForward(', 'mtp-forward','session.mtp_.position','tokens.size()'),
 ('bool Executor::Rollback(', 'rollback','session.position_','keep'),
 ('bool Executor::GreedyMtpPredictions(', 'greedy-verify','0','predictions.size()'),
 ('bool Executor::SampledMtpCandidates(', 'sampled-verify','0','rows.size()')]:
 # Sampled output span is called candidates, inspect signature before use.
 if stage=='sampled-verify':rows='output.size()'
 e=scope(e,sig,stage,'&session' if stage not in ('greedy-verify','sampled-verify') else 'this',pos,rows)
(p/'observer-executor.cpp').write_text(e)
print(e[e.index('bool Executor::SampledMtpCandidates('):e.index('bool Executor::SampledMtpCandidates(')+330])
