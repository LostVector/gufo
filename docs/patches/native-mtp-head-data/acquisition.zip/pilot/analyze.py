from pathlib import Path
import json,statistics,math,re
p=Path(__file__).resolve().parent;assert(p/'complete').exists();labels=['baseline-b1','candidate-c1','candidate-c2','baseline-b2'];data=[json.loads((p/k/'rows.json').read_text())for k in labels]
assert all(r['output_match']and r['work_match']for a in data for r in a)
cases=[];flags=[];errors={}
for label in labels:
 for rank in(0,1):
  def count(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/label/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=count('before'),count('after');diff={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors[label+'-r'+str(rank)]=diff
for i in range(1,6):
 b=statistics.geometric_mean(data[j][i]['timings']['predicted_per_second']for j in(0,3));c=statistics.geometric_mean(data[j][i]['timings']['predicted_per_second']for j in(1,2));cases.append({'case':data[0][i]['case'],'baseline_tps':b,'candidate_tps':c,'change_percent':100*(c/b-1)})
 for pair,(bi,ci)in enumerate(((0,1),(3,2)),1):
  x,y=data[bi][i],data[ci][i]
  for metric in('queue_ms','shared_prefix_wait_ms','prefill_ms','decode_ms','ttft_ms','mean_inter_token_ms','max_inter_token_ms','cache_snapshot_ms'):
   a=x['usage']['gufo'].get(metric);b=y['usage']['gufo'].get(metric)
   if a is not None and b is not None and b-a>max(3,a*.05):flags.append({'pair':pair,'case':x['case'],'metric':metric,'baseline_ms':a,'candidate_ms':b,'delta_ms':b-a})
report={'all24_output_work_identities_match':True,'cases':cases,'overall_decode_change_percent':100*math.expm1(statistics.mean(math.log(1+r['change_percent']/100)for r in cases)),'phase_flags':flags,'errors':errors,'scope':'Fixed four-start ABBA pilot, no significance inference or pooling into heldout study.'}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
