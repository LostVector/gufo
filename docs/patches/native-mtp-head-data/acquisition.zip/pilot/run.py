from pathlib import Path
import hashlib,json,os,shlex,signal,socket,subprocess,sys,time,urllib.request
p=Path(__file__).resolve().parent;root=Path('/home/rkuo/strix-dispatch-investigation');peer='rkuo@rk-corsair-ai';old=root/'tp-cache-retention/dflash-head-qualification-2026-11-09/correlation'
assert not(p/'protocol.json').exists();meta=json.loads((p.parent/'candidate-binary.json').read_text())
pp=json.loads((root/'prefill-scaling/results/prompts.json').read_text())['2048']
short='Implement a Python asynchronous work queue with bounded concurrency, fair scheduling and cancellation. Provide code and explain the invariants.'
cases=[('warmup',short,0.,43,64),('short-greedy',short,0.,43,128),('short-sampled',short,.8,1001,128),('pp2048-greedy',pp,0.,43,128),('pp2048-sampled',pp,.8,1001,128),('prose-sampled','Explain how a CPU cache works to a curious teenager. Use an analogy and a concrete example.',.8,513,256)]
def call(rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',peer,shlex.join(args)]if rank else args,text=True,timeout=60)
def canon(x):
 if isinstance(x,dict):return{k:canon(v)for k,v in x.items()if not k.endswith('_ms')and not k.endswith('_per_second')}
 if isinstance(x,list):return[canon(v)for v in x]
 return x
for role,m in meta.items():
 assert hashlib.sha256(Path(m['binary']).read_bytes()).hexdigest()==m['sha256'];call(1,['mkdir','-p',str(Path(m['binary']).parent)]);subprocess.run(['rsync','-a',m['binary'],peer+':'+m['binary']],check=True)
call(1,['mkdir','-p',str(p)]);subprocess.run(['rsync','-a',str(p/'run-rank.py'),peer+':'+str(p)+'/'],check=True)
(p/'protocol.json').write_text(json.dumps({'sequence':['baseline-b1','candidate-c1','candidate-c2','baseline-b2'],'cases':cases,'binaries':meta,'context':65536,'sessions':1,'prefill_chunk':2048,'mode':'native MTP adaptive max7, targetQ4XL/sharedQ8, neutralpenalties, topk40/topp.95, thinkingoff, no promptcache/persist','scope':'Fixed four-start ABBA exploratory production pilot, not significance evidence. All phases/work/errors retained.'},indent=2)+'\n')
reference={}
for label,role in [('baseline-b1','baseline'),('candidate-c1','candidate'),('candidate-c2','candidate'),('baseline-b2','baseline')]:
 out=p/label;out.mkdir(exist_ok=False)
 for rank in(0,1):
  assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/srcversion']).strip()=='B6C332F34D27E163651EE38';assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/refcnt']).strip()=='0'
  (out/f'before-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
 with socket.socket()as s:s.bind(('127.0.0.1',0));port=str(s.getsockname()[1])
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(Path(meta[role]['binary']).parents[1]);env['DFLASH_TP_LAUNCH_RECORDS']=str(out/'launch')
 for k in('ROCP_TOOL_ATTACH','LD_PRELOAD','GUFO_DFLASH_COST_PATH'):env.pop(k,None)
 cmd=[sys.executable,str(p/'launcher.py'),'serve','llm','--model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','--served-model-name','mtp-cost','--speculative','mtp','--mtp-model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf','--draft-tokens','7','--context','65536','--sessions','1','--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off','--host','127.0.0.1','--port',port]
 (out/'launch.json').write_text(json.dumps({'command':cmd,'sha256':meta[role]['sha256']},indent=2)+'\n')
 print('START',role,flush=True);rows=[]
 with(out/'server.log').open('w')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+240
   while True:
    assert proc.poll()is None,'server exit'
    try:
     with urllib.request.urlopen('http://127.0.0.1:'+port+'/health',timeout=1)as r:
      if r.status==200:break
    except OSError:pass
    assert time.monotonic()<deadline;time.sleep(.2)
   for i,(name,prompt,temp,seed,limit)in enumerate(cases):
    body={'model':'mtp-cost','messages':[{'role':'user','content':prompt}],'max_tokens':limit,'temperature':temp,'top_p':.95,'top_k':40,'seed':seed,'presence_penalty':0,'frequency_penalty':0,'repeat_penalty':1,'cache_prompt':False,'cache_persist':False,'chat_template_kwargs':{'enable_thinking':False}}
    (out/f'{i}-{name}-request.json').write_text(json.dumps(body,indent=2)+'\n');begin=time.monotonic_ns();req=urllib.request.Request('http://127.0.0.1:'+port+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=240)as response:reply=json.load(response)
    end=time.monotonic_ns();(out/f'{i}-{name}-response.json').write_text(json.dumps(reply,indent=2)+'\n')
    identity={'choices':reply['choices'],'work':canon(reply['usage'])}
    if label=='baseline-b1':reference[name]=identity
    row={'case':name,'warmup':i==0,'begin_ns':begin,'end_ns':end,'usage':reply['usage'],'timings':reply['timings'],'output_match':label=='baseline-b1'or reply['choices']==reference[name]['choices'],'work_match':label=='baseline-b1'or canon(reply['usage'])==reference[name]['work']}
    rows.append(row);(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');print(role,name,round(reply['timings']['predicted_per_second'],2),row['output_match'],row['work_match'],flush=True)
  finally:
   if proc.poll()is None:
    proc.send_signal(signal.SIGINT)
    try:proc.wait(timeout=40)
    except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=20)
 if False:subprocess.run(['rsync','-a','--include=*/','--include=*-cost.csv','--exclude=*',peer+':'+str(out/'launch')+'/',str(out/'launch')+'/'],check=True)
 for rank in(0,1):
  assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/refcnt']).strip()=='0';(out/f'after-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
 (out/'complete').touch()
(p/'complete').touch();print('MTP PRODUCTION PILOT COMPLETE',flush=True)
