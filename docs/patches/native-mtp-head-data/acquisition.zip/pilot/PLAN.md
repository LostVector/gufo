# Fixed production pilot

Four starts in ABBA order, same six requests as diagnostic. Greedy and sampled
short/actual2048 plus prose. Natural EOS, no sampler/profiler, no promptcache.
All outputs and non-timing usage/work identities compared to first baseline,
all errors and phases retained. This pilot does not establish significance.
Do not start until full-row/state/component gates finish. C2 and behavioral
qualification follow only if this isolated mechanism warrants advancement.
