from pathlib import Path
import csv,collections,json,statistics,re
p=Path(__file__).resolve().parent;assert(p/'complete').exists()
requests=json.loads((p/'observer/rows.json').read_text());reports={}
for rank in(0,1):
 paths=list((p/'observer/launch').rglob(f'rank{rank}-pid-cost.csv'));assert len(paths)==1
 lines=paths[0].read_text().splitlines();assert 'overflow=0' in lines[0]
 rows=list(csv.DictReader(lines[1:]));assert rows
 for r in rows:
  for k in('position','rows','begin_ns','end_ns'):r[k]=int(r[k])
  r['ms']=(r['end_ns']-r['begin_ns'])/1e6;assert r['ms']>=0
 stages={}
 for stage in sorted(set(r['stage']for r in rows)):
  a=[r for r in rows if r['stage']==stage]
  stages[stage]={'count':len(a),'total_ms':sum(r['ms']for r in a),'median_ms':statistics.median(r['ms']for r in a),'row_histogram':dict(collections.Counter(r['rows']for r in a))}
 report={'source_records':len(rows),'stages':stages}
 if rank==0:
  cases=[]
  for q in requests:
   a=[r for r in rows if q['begin_ns']<=r['begin_ns']<=r['end_ns']<=q['end_ns']]
   first_prepare=min(r['begin_ns']for r in a if r['stage']=='prepare')
   prefill=[r for r in a if r['stage']=='target-forward'and r['begin_ns']<first_prepare]
   a=[r for r in a if r['begin_ns']>=first_prepare]
   f=[r for r in a if r['stage']=='target-forward']
   h=collections.defaultdict(list)
   for r in f:h[r['rows']].append(r['ms'])
   cases.append({'case':q['case'],'warmup':q['warmup'],'output_match':q['output_match'],'work_match':q['work_match'],'tps':q['timings']['predicted_per_second'],'prefill_forward_ms':sum(r['ms']for r in prefill),'target_decode_shapes':{str(k):{'count':len(v),'median_ms':statistics.median(v),'total_ms':sum(v)}for k,v in sorted(h.items())},'phase_totals_ms':{s:sum(r['ms']for r in a if r['stage']==s)for s in stages},'usage':q['usage']})
  report['cases']=cases
 reports[str(rank)]=report
errors={}
for role in('baseline','observer'):
 for rank in(0,1):
  def count(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/role/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=count('before'),count('after');diff={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors[role+'-r'+str(rank)]=diff
out={'scope':'Host wall phases including GPU/transport/synchronization, nested totals not additive; per-case decode starts at first PrepareDecode scope so small prefill tails are excluded; observer not throughput evidence. Node-local timing only.','ranks':reports,'errors':errors}
(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'cases':[{k:v for k,v in r.items()if k!='usage'}for r in reports['0']['cases']],'errors':errors},indent=2))
