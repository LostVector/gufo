from pathlib import Path
import shutil,json,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];old=root/'tp-cache-retention/dflash-head-qualification-2026-11-09';candidate=p/'candidate';candidate.mkdir(exist_ok=False)
s=(p/'baseline-executor.cpp').read_text()
a='''(speculative && session.target_feature_capture_ &&
          (n_logits == 4 || n_logits == 8) &&'''
b='''(speculative &&
          ((session.mtp_enabled_ && n_logits >= 3 && n_logits <= 8) ||
           (session.target_feature_capture_ &&
            (n_logits == 4 || n_logits == 8))) &&'''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('''// Share the existing Q8 output rows for native two-row MTP or guarded
    // four/eight-row external verification. The latter fits the transport
    // capacity already required for max_batch hidden rows at model setup.''','''// Share the existing Q8 output rows for native MTP verification rows
    // two through eight, or guarded four/eight-row external verification.
    // Wider native rows fit the capacity required at model setup.''')
(candidate/'executor.cpp').write_text(s)
# Diagnostic retains native two-row behavior in both arms; toggle only new rows.
d=(old/'state/executor-diagnostic.cpp').read_text()
a='''(dflash_head_probe::enabled && speculative && session.target_feature_capture_ &&
          (n_logits == 4 || n_logits == 8) &&'''
b='''(speculative &&
          ((dflash_head_probe::enabled && session.mtp_enabled_ &&
            n_logits >= 3 && n_logits <= 8) ||
           (session.target_feature_capture_ &&
            (n_logits == 4 || n_logits == 8))) &&'''
assert d.count(a)==1;d=d.replace(a,b).replace('if (target_head_decode && session.target_feature_capture_) {','if (target_head_decode && session.mtp_enabled_) {')
(candidate/'executor-diagnostic.cpp').write_text(d)
# Expand existing independent real-weight component check to every row1..8.
s=(root/'tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost/head-experiment/component.cpp').read_text().replace('for(int n:{1,2,4,8})','for(int n:{1,2,3,4,5,6,7,8})')
(candidate/'component.cpp').write_text(s)
# Native replay probe, strict equality vs unchanged full-head path.
s=(old/'state/probe.cpp').read_text().replace('opt.dflash_model_path=argv[5];','opt.mtp_model_path=argv[5];')
s=s.replace('auto draft=model->LoadDFlashDraft(argv[5],&error);Need(bool(draft),error);','')
s=s.replace('gufo::core::SessionMode::kAutoregressive,65536,&error,draft','gufo::core::SessionMode::kSpeculative,65536,&error').replace('a->DFlashEnabled()','model->HasMtp()').replace('b->DFlashEnabled()','model->HasMtp()')
s=s.replace('const std::array<unsigned,8> budgets{4,8,1,2,3,7,4,8};','const std::array<unsigned,8> budgets{3,4,5,6,7,8,1,2};')
s=s.replace('session.DecodeDFlashStep(budget,rng,&decoded,&error,false,budget-1)','session.DecodeStep(budget,rng,&decoded,&error,false,1,budget-1)')
s=s.replace('bool expected=enabled&&(rows[i]==4||rows[i]==8);','bool expected=rows[i]==2||(enabled&&rows[i]>=3&&rows[i]<=8);')
s=s.replace('Need(std::find(rows.begin(),rows.end(),budget)!=rows.end(),"requested target shape not exercised");','Need(std::all_of(rows.begin(),rows.end(),[&](auto n){return n>=1&&n<=budget;}),"invalid target shape");')
s=s.replace('eligible>=126','eligible>0')
(candidate/'probe.cpp').write_text(s)
# Build candidate production via same cached ordinary CMake; engine must be restored.
build=(p/'build.py').read_text()
build=build.replace("assert not(p/'binaries.json').exists();records={}","assert not(p/'candidate-binary.json').exists();records={}")
start=build.index(' for name,source in zip(');end=build.index(' with(p/',start)
build=build[:start]+" shutil.copyfile(p/'candidate/executor.cpp',src/names[1]);(src/names[1]).touch()\n"+build[end:]
build=build.replace("for name in names:assert name+'.o' in text","assert names[1]+'.o' in text")
build=build.replace("'observer-runtime/bin/gufo'","'candidate/runtime/bin/gufo'").replace("records['observer']","records['candidate']")
build=build.replace("ff485f17-native-mtp-observer","ff485f17-native-mtp-head3-8").replace("'build-observer.log'","'candidate/production-build.log'")
build=build.replace("(p/'binaries.json').write_text","(p/'candidate-binary.json').write_text")
build=build.replace('Bounded CPU source scopes only, no GPU work/waits; not throughput evidence.','Uninstrumented production candidate, only native verify3..8 head gather route; exact source archived.')
(candidate/'build.py').write_text(build.replace('p=Path(__file__).resolve().parent;','p=Path(__file__).resolve().parent.parent;'))
