from pathlib import Path
import json,statistics,re
p=Path(__file__).resolve().parent;assert(p/'complete').exists();labels=['baseline-b1','candidate-c1','candidate-c2','baseline-b2'];data={k:[json.loads(x)for x in(p/k/'rows.jsonl').read_text().splitlines()]for k in labels};flags=[];work=[];errors={};waves=[]
for label in labels:
 assert len(data[label])==13
 for rank in(0,1):
  def counts(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/label/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counts('before'),counts('after');diff={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors[label+'-r'+str(rank)]=diff
for n in(1,2):
 a,b=data[f'baseline-b{n}'],data[f'candidate-c{n}']
 for x,y in zip(a,b):
  for key in('case','rep','actor','width','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256'):assert x[key]==y[key],(n,key,x['case'])
  if x['warmup']:continue
  for key in('wall_ms','queue_ms','prefill_ms','decode_ms','client_ttft_ms','server_ttft_ms','first_followup_ms','second_content_ms','server_max_inter_token_ms'):
   aa,bb=x.get(key),y.get(key)
   if aa is not None and bb is not None and bb-aa>max(3,aa*.05):flags.append({'pair':n,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'metric':key,'baseline':aa,'candidate':bb,'delta_ms':bb-aa})
  for key in('draft_tokens','draft_accepted_tokens'):
   if x[key]!=y[key]:work.append({'pair':n,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'field':key,'baseline':x[key],'candidate':y[key]})
  if x['raw_gufo'].get('draft_rounds')!=y['raw_gufo'].get('draft_rounds'):work.append({'pair':n,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'field':'draft_rounds','baseline':x['raw_gufo'].get('draft_rounds'),'candidate':y['raw_gufo'].get('draft_rounds')})
 for case in('natural-c2','coding-c2'):
  for rep in range(2):
   rates=[]
   for role,d in [('baseline',a),('candidate',b)]:
    r=[x for x in d if x['case']==case and x['rep']==rep];assert len(r)==2
    rates.append({'role':role,'sum_decode_tps':sum(x['decode_tokens_per_second']for x in r),'wave_wall_tps':sum(x['completion_tokens']for x in r)/(max(x['finished_at']for x in r)-min(x['started_at']for x in r))})
   waves.append({'pair':n,'case':case,'rep':rep,'rates':rates})
report={'requests':sum(map(len,data.values())),'all_output_prompt_cache_identities_match':True,'phase_flags':flags,'adaptive_work_differences':work,'errors':errors,'waves':waves,'scope':'Four-start ABBA C2 descriptive screen, two process pairs. Not confidence/equivalence; all phase flags and work/error differences retained.'}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
