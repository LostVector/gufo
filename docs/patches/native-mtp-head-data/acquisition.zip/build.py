from pathlib import Path
import hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];src=p.parent/'dflash2-flash-next-worktree';base='ff485f1792364b48b73e200db6deb03f49c22623'
names=['src/models/qwen38_flash_next/engine.cpp','src/models/qwen38_flash_next/kernels/rocm/executor.cpp']
def git(*a):return subprocess.check_output(['git',*a],cwd=src,text=True).strip()
def run(a,log=None):subprocess.run(a,cwd=src,check=True,stdout=log,stderr=subprocess.STDOUT if log else None)
assert not git('status','--porcelain');original=git('branch','--show-current');assert original=='review/flash-next-dflash2'
assert not(p/'binaries.json').exists();records={}
# Exact merged production sources are already qualified; avoid rebuilding unchanged units.
old=root/'tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost/head-experiment/runtime/bin/gufo'
records['baseline']={'binary':str(old),'sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'source_revision':base,'scope':'Uninstrumented qualified artifact. executor source byte-identical to ff485f17; engine unchanged from0733. Original build/source provenance in preceding study.'}
assert git('diff','0733d3f2',base,'--',names[0])==''
try:
 run(['git','switch','--detach',base])
 for name,source in zip(names,['observer-engine.cpp','observer-executor.cpp']):shutil.copyfile(p/source,src/name);(src/name).touch()
 with(p/'build-observer.log').open('w')as log:
  run(['cmake','--preset','release','-DGUFO_ENABLE_TP2_RDMA=ON','-DGUFO_BUILD_TOOLS=OFF','-DGUFO_REVISION=ff485f17-native-mtp-observer'],log)
  run(['cmake','--build','--preset','release','--parallel','4','--target','gufo'],log)
 text=(p/'build-observer.log').read_text()
 for name in names:assert name+'.o' in text
 binary=p/'observer-runtime/bin/gufo';binary.parent.mkdir(parents=True,exist_ok=False);shutil.copyfile(src/'build/release/gufo',binary);binary.chmod(0o755)
 records['observer']={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_revision':base,'scope':'Bounded CPU source scopes only, no GPU work/waits; not throughput evidence.'}
 (p/'binaries.json').write_text(json.dumps(records,indent=2)+'\n');print('Frozen MTP observer',flush=True)
finally:
 run(['git','restore','--',*names]);run(['git','switch',original])
