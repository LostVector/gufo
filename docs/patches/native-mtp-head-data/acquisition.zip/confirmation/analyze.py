from pathlib import Path
import collections,csv,itertools,json,math,random,re,statistics
p=Path(__file__).resolve().parent;assert(p/'complete').exists();design=json.loads((p/'DESIGN.json').read_text());pairs=[];cases=[];flags=[];errors={};data={}
def canon(x):
 if isinstance(x,dict):return{k:canon(v)for k,v in x.items()if not k.endswith('_ms')and not k.endswith('_per_second')}
 if isinstance(x,list):return[canon(v)for v in x]
 return x
for role,label,n in design['sequence']:
 out=p/(role+'-'+label);rows=json.loads((out/'rows.json').read_text());assert len(rows)==6;data[role,label]=rows
 for rank in(0,1):
  def count(tag):return{k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(out/f'{tag}-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=count('before'),count('after');assert a.keys()==b.keys()and len(a)>100
  diff={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors.setdefault(role+'-'+label,{})[str(rank)]=diff
for n,order in enumerate(design['orders'],1):
 label=f'p{n:02}';logs=[];walls=[]
 for i,(a,b)in enumerate(zip(data['baseline',label],data['candidate',label])):
  assert a['case']==b['case'];name=a['case']
  ref=json.loads((p/('baseline-'+label)/f'{i}-{name}-response.json').read_text());other=json.loads((p/('candidate-'+label)/f'{i}-{name}-response.json').read_text())
  assert ref['choices']==other['choices']and canon(a['usage'])==canon(b['usage']),(label,name,'output/work identity')
  if a['warmup']:continue
  log=math.log(b['timings']['predicted_per_second']/a['timings']['predicted_per_second']);logs.append(log)
  aw=(a['end_ns']-a['begin_ns'])/1e6;bw=(b['end_ns']-b['begin_ns'])/1e6;walls.append(math.log(aw/bw))
  cases.append({'pair':n,'case':name,'baseline_tps':a['timings']['predicted_per_second'],'candidate_tps':b['timings']['predicted_per_second'],'log_ratio':log})
  for metric in('queue_ms','shared_prefix_wait_ms','prefill_ms','decode_ms','ttft_ms','mean_inter_token_ms','max_inter_token_ms','cache_snapshot_ms','client_wall_ms'):
   x=aw if metric=='client_wall_ms'else a['usage']['gufo'].get(metric);y=bw if metric=='client_wall_ms'else b['usage']['gufo'].get(metric)
   if x is not None and y is not None and y-x>max(3,x*.05):flags.append({'pair':n,'case':name,'metric':metric,'baseline_ms':x,'candidate_ms':y,'delta_ms':y-x,'also_over_10ms':y-x>10,'baseline_transport_errors':('baseline-'+label)in errors,'candidate_transport_errors':('candidate-'+label)in errors})
 assert len(logs)==5
 pairs.append({'pair':n,'order':order,'mean_log_decode_ratio':statistics.mean(logs),'mean_log_wall_ratio':statistics.mean(walls)})
obs=statistics.mean(r['mean_log_decode_ratio']for r in pairs);chron=[r['mean_log_decode_ratio']*(1 if r['order']=='BC'else-1)for r in pairs];null=[]
for bc in itertools.combinations(range(10),5):
 selected=set(bc);null.append(statistics.mean(v*(1 if i in selected else-1)for i,v in enumerate(chron)))
exact=sum(abs(v)>=abs(obs)-1e-15 for v in null)/len(null);rng=random.Random(20261110);strata=[[r for r in pairs if r['order']==o]for o in('BC','CB')];boot=[];wallboot=[]
for _ in range(20000):
 a=[rng.choice(s)for s in strata for __ in range(5)];boot.append(statistics.mean(r['mean_log_decode_ratio']for r in a));wallboot.append(statistics.mean(r['mean_log_wall_ratio']for r in a))
def quantile(a,q):
 a=sorted(a);i=(len(a)-1)*q;n=int(i);f=i-n;return a[n]*(1-f)+a[min(n+1,len(a)-1)]*f
percent=lambda v:100*math.expm1(v)
bycase=[]
for name in dict.fromkeys(r['case']for r in cases):
 a=[r for r in cases if r['case']==name];bycase.append({'case':name,'baseline_tps_geomean':statistics.geometric_mean(r['baseline_tps']for r in a),'candidate_tps_geomean':statistics.geometric_mean(r['candidate_tps']for r in a),'paired_change_percent':percent(statistics.mean(r['log_ratio']for r in a))})
report={'requests':sum(len(a)for a in data.values()),'all_output_work_identities_match':True,'decode_change_percent':percent(obs),'95CI_percent':[percent(quantile(boot,q))for q in(.025,.975)],'exact_balanced_order_two_sided_p':exact,'randomization_assignments':len(null),'positive_pairs':sum(r['mean_log_decode_ratio']>0 for r in pairs),'wall_throughput_change_percent':percent(statistics.mean(r['mean_log_wall_ratio']for r in pairs)),'wall_95CI_percent':[percent(quantile(wallboot,q))for q in(.025,.975)],'cases':bycase,'pairs':pairs,'phase_flags':flags,'transport_errors':errors,'scope':'Single predeclared primary decode hypothesis. Five fixed task outcomes clustered within ten processpairs; heldout sampledseeds2001..2010. Bootstrap20kBC/CBstratified, exact252balancedorder assignments. No pilot pooling/exclusion/replacement. Secondary wall-throughput. All phase flags/errors retained.'}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
with(p/'phase-flags.csv').open('w')as f:
 if flags:w=csv.DictWriter(f,fieldnames=list(flags[0]));w.writeheader();w.writerows(flags)
print(json.dumps({k:v for k,v in report.items()if k not in('pairs','phase_flags','transport_errors')},indent=2));print('phase flags',len(flags),'error starts',len(errors))
