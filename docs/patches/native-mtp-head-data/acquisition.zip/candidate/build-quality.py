from pathlib import Path
import json,subprocess,shutil
p=Path(__file__).resolve().parent;root=p.parents[2];old=root/'tp-cache-retention/dflash-head-qualification-2026-11-09/state'
assert (p.parent/'candidate-binary.json').exists()
s=(old/'build.py').read_text().replace("assert not (p/'build.json').exists();", "assert not (p/'build.json').exists();")
s=s.replace("'parent_candidate':'9a5a9d43becbb0dd9aaf8930477e647b010efd169650da1318db02dfd776942c'", "'parent_candidate':json.loads((p.parent/'candidate-binary.json').read_text())['candidate']['sha256']")
s=s.replace("p/'build.log'","p/'build-state.log'")
s=s.replace('OFF=0733external path, ON=exact isolated guard','OFF=ff485f17 native path, ON=native rows3..8 candidate')
(p/'build-state.py').write_text(s)
subprocess.run(['python3',str(p/'build-state.py')],check=True)
# Component uses the same immutable production MMQ archive as the last check.
a=root/'tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost/head-experiment'
d=json.loads((a/'component-build.json').read_text());cmd=d['command'];cmd=[str(p/'component.cpp')if x==str(a/'component.cpp')else str(p/'component')if x==str(a/'component')else x for x in cmd]
with(p/'component-build.log').open('w')as f:subprocess.run(cmd,check=True,stdout=f,stderr=subprocess.STDOUT)
(p/'component-build.json').write_text(json.dumps({'command':cmd,'scope':'All rows1..8, eight inputs, real Q8weights, finite/bitwise/guards. Component timings not serving evidence.'},indent=2)+'\n')
meta=json.loads((a/'component-weights.json').read_text());meta={k:meta[k]for k in('model_file','offset','weight_bytes','shape','type')};meta.update(repetitions=100,source_sha256=__import__('hashlib').sha256((p/'component.cpp').read_bytes()).hexdigest(),binary_sha256=__import__('hashlib').sha256((p/'component').read_bytes()).hexdigest());(p/'component-weights.json').write_text(json.dumps(meta,indent=2)+'\n')
s=(a/'component-run.py').read_text().replace('bitwise_cases=32','bitwise_cases=64');(p/'component-run.py').write_text(s)
s=(old/'run.py').read_text().replace('Qwen3.8-Flash-Next-DFlash2-GGUF/Qwen3.8-Flash-Next-DFlash2-Q8_0.gguf','Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf').replace("str(p.parent/'PROTOCOL.md')","str(p.parent/'PLAN.md')")
(p/'run-state.py').write_text(s)
s=(old/'run-locked.sh').read_text().replace(str(old),str(p)).replace('python3 "$lab/run.py"','python3 "$lab/component-run.py"\nbash /home/rkuo/strix-dispatch-investigation/dflash-upstream-2026-11-07/build.sh python3 "$lab/run-state.py"')
(p/'run-quality-locked.sh').write_text(s)
