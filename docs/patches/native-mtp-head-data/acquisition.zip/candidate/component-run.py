from pathlib import Path
import hashlib,json,subprocess,shlex
p=Path(__file__).resolve().parent;m=json.loads((p/'component-weights.json').read_text());assert not(p/'component-complete').exists()
peer='rkuo@rk-corsair-ai'
subprocess.run(['ssh',peer,shlex.join(['mkdir','-p',str(p)])],check=True)
subprocess.run(['rsync','-a',str(p/'component'),peer+':'+str(p)+'/'],check=True)
records=[]
for rank in (0,1):
 args=[str(p/'component'),m['model_file'],str(m['offset']),str(p/f'component-r{rank}.csv'),'100']
 if rank:args=['ssh',peer,shlex.join(args)]
 with(p/f'component-r{rank}.log').open('w')as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=180,check=True)
 if rank:subprocess.run(['rsync','-a',peer+':'+str(p/f'component-r{rank}.csv'),str(p)+'/'],check=True)
 text=(p/f'component-r{rank}.log').read_text();assert 'bitwise_cases=64' in text and 'guards=pass status=pass' in text,text
 records.append({'rank':rank,'log':text.strip(),'binary_sha256':hashlib.sha256((p/'component').read_bytes()).hexdigest()});print('Component PASS rank',rank,flush=True)
(p/'component-result.json').write_text(json.dumps(records,indent=2)+'\n');(p/'component-complete').touch()
