#include <hip/hip_runtime.h>
#include "src/models/qwen38_flash_next/kernels/rocm/mmq/qfn_mmq.h"
#include <chrono>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <array>
#include <algorithm>
#include <string>
using Clock=std::chrono::steady_clock;
static void check(hipError_t e){if(e!=hipSuccess)throw std::runtime_error(hipGetErrorString(e));}
static void require(bool v,const char*s){if(!v)throw std::runtime_error(s);}
constexpr int M=248320,K=2560,H=M/2;
constexpr size_t ROW_BYTES=K/32*34, GUARD=16;
constexpr uint32_t SENTINEL=0x7fc12345;
struct Buffer {
 uint32_t* base{};size_t count{};
 explicit Buffer(size_t n):count(n){check(hipMalloc((void**)&base,(n+2*GUARD)*4));}
 ~Buffer(){if(base)hipFree(base);}
 float* ptr(){return reinterpret_cast<float*>(base+GUARD);}
 void poison(){std::vector<uint32_t>x(count+2*GUARD,SENTINEL);check(hipMemcpy(base,x.data(),x.size()*4,hipMemcpyHostToDevice));}
 std::vector<uint32_t> read(){std::vector<uint32_t>x(count+2*GUARD);check(hipMemcpy(x.data(),base,x.size()*4,hipMemcpyDeviceToHost));for(size_t i=0;i<GUARD;i++)require(x[i]==SENTINEL&&x[count+GUARD+i]==SENTINEL,"output guard overwritten");return {x.begin()+GUARD,x.end()-GUARD};}
};
static uint32_t bits(float x){uint32_t b;std::memcpy(&b,&x,4);return b;}
static float value(uint32_t seed,size_t i){if(seed==0)return 0;uint32_t x=uint32_t(i+1)*0x9e3779b9u+seed*0x85ebca6bu;x^=x>>16;x*=0x7feb352du;x^=x>>15;return float(int(x%4097)-2048)/1024.f;}
int main(int argc,char**argv){try{
 require(argc==5,"usage: component GGUF OFFSET CSV REPS");size_t offset=std::stoull(argv[2]);int reps=std::stoi(argv[4]);require(reps>=100,"need >=100 samples");
 check(hipSetDevice(0));require(qfn_mmq_init(0)==0,"qfn init");
 std::vector<uint8_t>weights(size_t(M)*ROW_BYTES);std::ifstream f(argv[1],std::ios::binary);require(bool(f),"open weights");f.seekg(offset);f.read((char*)weights.data(),weights.size());require(size_t(f.gcount())==weights.size(),"short output weight read");
 void* w{};check(hipMalloc(&w,weights.size()));check(hipMemcpy(w,weights.data(),weights.size(),hipMemcpyHostToDevice));weights.clear();weights.shrink_to_fit();
 hipStream_t stream{};check(hipStreamCreateWithFlags(&stream,hipStreamNonBlocking));hipEvent_t begin{},end{};check(hipEventCreate(&begin));check(hipEventCreate(&end));
 std::ofstream csv(argv[3]);require(bool(csv),"open csv");csv<<"rows,variant,iteration,cpu_enqueue_us,completion_us,gpu_event_us\n";
 size_t compared=0;int cases=0;
 for(int n:{1,2,3,4,5,6,7,8}){
  float*x{};void*q{};check(hipMalloc((void**)&x,size_t(n)*K*4));check(hipMalloc(&q,qfn_mmq_q8_1_bytes(n,K)));
  Buffer full(size_t(n)*M),left(size_t(n)*H),right(size_t(n)*H);
  auto launch=[&](int v){const void* wp=v==2?(char*)w+size_t(H)*ROW_BYTES:w;float*out=v==0?full.ptr():v==1?left.ptr():right.ptr();require(qfn_mmq_q8_0_dense_vec_preq(wp,nullptr,q,out,v==0?M:H,n,K,stream)==0,"dense launch");};
  auto input=[&](int seed){std::vector<float>host(size_t(n)*K);for(size_t i=0;i<host.size();i++)host[i]=value(seed,i);check(hipMemcpyAsync(x,host.data(),host.size()*4,hipMemcpyHostToDevice,stream));require(qfn_mmq_quantize_q8_1(x,q,n,K,stream)==0,"quantize");check(hipStreamSynchronize(stream));};
  for(int seed=0;seed<8;seed++){
   input(seed);full.poison();left.poison();right.poison();for(int v=0;v<3;v++)launch(v);check(hipStreamSynchronize(stream));auto a=full.read(),b=left.read(),c=right.read();
   for(int row=0;row<n;row++)for(int col=0;col<M;col++){
    uint32_t expected=a[size_t(row)*M+col],actual=col<H?b[size_t(row)*H+col]:c[size_t(row)*H+col-H];float fp;std::memcpy(&fp,&expected,4);require(std::isfinite(fp),"nonfinite full output/unwritten output");require(actual==expected,"half reconstruction differs from full bits");++compared;
   }
   ++cases;
  }
  input(7);for(int i=0;i<20;i++)for(int v=0;v<3;v++)launch(v);check(hipStreamSynchronize(stream));
  for(int i=0;i<reps;i++)for(int j=0;j<3;j++){
   int v=(i+j)%3;check(hipEventRecord(begin,stream));auto a=Clock::now();launch(v);auto b=Clock::now();check(hipEventRecord(end,stream));check(hipEventSynchronize(end));auto c=Clock::now();float ms;check(hipEventElapsedTime(&ms,begin,end));csv<<n<<','<<(v==0?"full":v==1?"left":"right")<<','<<i<<','<<std::chrono::duration<double,std::micro>(b-a).count()<<','<<std::chrono::duration<double,std::micro>(c-a).count()<<','<<ms*1000<<'\n';
  }
  check(hipFree(x));check(hipFree(q));
 }
 check(hipEventDestroy(begin));check(hipEventDestroy(end));qfn_mmq_release_stream(stream);check(hipStreamDestroy(stream));check(hipFree(w));
 std::cout<<"bitwise_cases="<<cases<<" compared_logits="<<compared<<" guards=pass status=pass\n";return 0;
}catch(const std::exception&e){std::cerr<<"ERROR "<<e.what()<<'\n';return 2;}}
