from pathlib import Path
import hashlib,json,os,shlex,signal,socket,subprocess,time
p=Path(__file__).resolve().parent;root=p.parents[2];peer='rkuo@rk-corsair-ai'
assert not(p/'protocol.json').exists();probe=p/'probe';meta=json.loads((p/'build.json').read_text());assert hashlib.sha256(probe.read_bytes()).hexdigest()==meta['binary_sha256']
helper=root/'tp-cache-retention/dflash2-flash-next-port-v1/run-rank.py'
def cmd(rank,args):return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(args)]if rank else args
def call(rank,args):return subprocess.check_output(cmd(rank,args),text=True,stderr=subprocess.STDOUT,timeout=60)
def inventory(tag):
 code="from pathlib import Path;import json,platform;r=Path('/sys/module/thunderbolt_ibverbs');print(json.dumps({'host':platform.node(),'boot':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'cmdline':Path('/proc/cmdline').read_text().strip(),'module':(r/'srcversion').read_text().strip(),'refcnt':(r/'refcnt').read_text().strip(),'links':{str(f):f.read_text().strip() for n in ('rx_speed','tx_speed','rx_lanes','tx_lanes') for f in Path('/sys/bus/thunderbolt/devices').glob('*/'+n)}}))"
 rows=[]
 for rank in (0,1):
  d=json.loads(call(rank,['python3','-c',code]));assert d['module']=='B6C332F34D27E163651EE38' and d['refcnt']=='0',d;rows.append(d);(p/f'{tag}-inventory-r{rank}.json').write_text(json.dumps(d,indent=2)+'\n');(p/f'{tag}-snapshot-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
 return rows
initial=inventory('before');call(1,['mkdir','-p',str(p)]);subprocess.run(['rsync','-a',str(probe),peer+':'+str(probe)],check=True);assert call(1,['sha256sum',str(probe)]).split()[0]==meta['binary_sha256']
with socket.socket()as s:s.bind(('0.0.0.0',0));port=str(s.getsockname()[1])
(p/'protocol.json').write_text(json.dumps({'binary':meta,'bootstrap_port':port,'source_design':str(p.parent/'PLAN.md'),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'scope':'Quality-only full verification matrices/frontier/RNG/history/work and complete state bytes; synchronization observer not performance. Both TP2 ranks, current B6.'},indent=2)+'\n')
jobs=[];logs=[]
try:
 for rank in (0,1):
  cfg={'binary':str(probe),'args':[str(rank),'192.168.64.125','usb4_rdma0'if rank==0 else'usb4_rdma5','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf',str(p/f'rank{rank}.jsonl'),port]};path=p/f'rank{rank}-config.json';path.write_text(json.dumps(cfg)+'\n')
  if rank:subprocess.run(['rsync','-a',str(path),peer+':'+str(path)],check=True)
  log=(p/f'rank{rank}.log').open('w');logs.append(log);jobs.append(subprocess.Popen(cmd(rank,['python3',str(helper),str(path),str(p/f'rank{rank}-pid.json')]),stdout=log,stderr=subprocess.STDOUT))
 deadline=time.monotonic()+1800
 while any(j.poll()is None for j in jobs):
  assert not any(j.poll()not in(None,0)for j in jobs),'numerical probe failed; inspect both logs'
  assert time.monotonic()<deadline,'numerical deadline';time.sleep(.5)
 assert all(j.returncode==0 for j in jobs)
finally:
 for rank,j in enumerate(jobs):
  if j.poll()is None:
   try:
    m=json.loads(call(rank,['cat',str(p/f'rank{rank}-pid.json')]))
    code="from pathlib import Path;import os,signal,json,sys;m=json.loads(sys.argv[1]);p=Path('/proc')/str(m['pid']);assert p.exists() and (p/'exe').resolve()==Path(m['binary']) and p.joinpath('stat').read_text().rsplit(')',1)[1].split()[19]==m['start_ticks'];os.kill(m['pid'],signal.SIGTERM)"
    call(rank,['python3','-c',code,json.dumps(m)])
   except subprocess.CalledProcessError:pass
   try:j.wait(timeout=20)
   except subprocess.TimeoutExpired:j.kill();j.wait()
 for f in logs:f.close()
 subprocess.run(['rsync','-a',peer+':'+str(p/'rank1.jsonl'),str(p)+'/'],check=False)
 subprocess.run(['rsync','-a',peer+':'+str(p/'rank1-pid.json'),str(p)+'/'],check=False)
 final=inventory('after');assert all(all(a[k]==b[k]for k in('boot','cmdline','module','links'))for a,b in zip(initial,final))
for rank in(0,1):
 text=(p/f'rank{rank}.log').read_text();assert 'PASS cases=7 records=294 full_state_pairs=28' in text,text[-2000:]
 rows=[json.loads(x)for x in(p/f'rank{rank}.jsonl').read_text().splitlines()];assert len(rows)==294
(p/'complete').touch();print('PASS full-row/frontier/state/RNG/snapshot quality both nodes',flush=True)
