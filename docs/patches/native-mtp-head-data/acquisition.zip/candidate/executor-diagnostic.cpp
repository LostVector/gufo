#include "src/models/qwen38_flash_next/kernels/rocm/executor.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <gufo/ext/experimental/managed_alloc.hpp>
#include <gufo/ext/experimental/snapshot_transfer.hpp>
#include <gufo/ext/platform/pages.hpp>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string_view>
#include <thread>
#include <tuple>
#include <type_traits>
#include <vector>

#include "qfn_mmq.h"
#include "src/models/qwen38_flash_next/draft_vocab.hpp"
#include "src/models/qwen38_flash_next/kernels/rocm/kernels.hpp"

namespace gufo::models::qwen38_flash_next::rocm {
namespace dflash_head_probe {
thread_local bool enabled = false;
thread_local std::vector<std::vector<float>> values;
thread_local std::vector<std::uint32_t> rows;
thread_local std::vector<unsigned> gathered;
}
void DFlashHeadProbeReset(bool enabled) {
  dflash_head_probe::enabled = enabled;
  dflash_head_probe::values.clear(); dflash_head_probe::rows.clear();
  dflash_head_probe::gathered.clear();
}
const std::vector<std::vector<float>>& DFlashHeadProbeValues() { return dflash_head_probe::values; }
const std::vector<std::uint32_t>& DFlashHeadProbeRows() { return dflash_head_probe::rows; }
const std::vector<unsigned>& DFlashHeadProbeGathered() { return dflash_head_probe::gathered; }

namespace {

using core::GgmlType;

void AssignError(std::string* error_msg, const std::string& message) {
  if (error_msg != nullptr) {
    *error_msg = message;
  }
}

bool Check(hipError_t err, const char* what, std::string* error_msg) {
  if (err == hipSuccess) {
    return true;
  }
  AssignError(error_msg, std::string(what) + ": " + hipGetErrorString(err));
  return false;
}

/// Allocates `count` elements of T and records the allocation.
template<typename T>
T* Alloc(std::vector<void*>& allocations, std::size_t count,
         std::string* error_msg, std::size_t* allocated_bytes = nullptr) {
  void* p = nullptr;
  const std::size_t bytes = std::max<std::size_t>(1, count) * sizeof(T);
  if (hip::AllocateDevice(&p, bytes) != hipSuccess) {
    AssignError(error_msg,
                "allocation of " + std::to_string(bytes) + " bytes failed");
    allocations.push_back(nullptr);
    return nullptr;
  }
  (void)hipMemset(p, 0, bytes);
  allocations.push_back(p);
  if (allocated_bytes)
    *allocated_bytes += bytes;
  return static_cast<T*>(p);
}

WeightType SmallType(GgmlType type) {
  switch (type) {
    case GgmlType::kBF16:
      return WeightType::kBF16;
    case GgmlType::kF16:
      return WeightType::kF16;
    case GgmlType::kQ8_0:
      return WeightType::kQ8_0;
    case GgmlType::kF32:
      return WeightType::kF32;
    default:
      throw std::logic_error("unsupported Flash-Next matrix format");
  }
}

// The tier's tiled kernels compute whole column tiles; below this width the
// matrix-vector kernels read each weight once per row and win outright.
constexpr std::uint32_t kVecBatch = 8;
// Keep prompt arithmetic independent of chunk width. A scoped, per-thread
// policy also lets the output head retain its existing logits-row arithmetic.
thread_local bool prefill_phase = false;
struct PrefillPhase {
  bool previous;
  explicit PrefillPhase(bool enabled) : previous(prefill_phase) {
    prefill_phase = enabled;
  }
  ~PrefillPhase() { prefill_phase = previous; }
};
bool MatrixRows(std::uint32_t rows) {
  return prefill_phase || rows > kVecBatch;
}
bool ExpertMatrixRows(std::uint32_t rows) {
  return prefill_phase || rows > 4 * kVecBatch;
}
/// Prefill passes wider than a vector batch take the fused projections and
/// the paired routed expert tiles: they win from 9 rows up to the full chunk.
/// Decode and verification batches keep their single-token arithmetic.
bool WidePrefill(std::uint32_t rows) {
  return prefill_phase && rows > kVecBatch;
}

/// Whether mmq's Q8_1 rows of width k carry no padding, so a producer's
/// contiguous element order is the layout.
bool UnpaddedQ8(std::uint32_t k) {
  return k % 32 == 0 &&
         qfn_mmq_q8_1_bytes(1, static_cast<int>(k)) == k / 32 * 36;
}

/// Key-tile splits per row of a narrow attention batch (decode at depth).
constexpr std::uint32_t kAttnSplits = 8;
/// Wide dense Q8_0 projections take the F16 WMMA GEMM (F16 activation
/// rows, weights dequantized as they are staged, no per-block scaling) when
/// its 256-row tiles fill the device and the K sweep is short enough that
/// the F16 rows stay cache-resident: measured per shape at 2048 tokens
/// (W8A8 -> F16 ms): 16384x2560 5.7 -> 4.6, 13312x2560 4.3 -> 3.9,
/// 10240x320 1.02 -> 0.79, 2560x2560 0.81 -> 0.74, 2560x640 0.24 -> 0.21;
/// against 2560x6144 1.8 -> 2.1+, 640x2560 0.19 -> 0.23 and 320x10240
/// 0.40 -> 1.3, which keep the int8 route.
constexpr std::uint32_t kDenseF16MinRows = 2048;
constexpr std::uint32_t kDenseF16MaxCols = 2560;

/// Token rows per routed F16 expert GEMM tile: the narrow tile for batches
/// whose buckets pad to one or two 16-row tiles, the wide one when the
/// mean bucket fills most of it (the weight dequantization is per tile).
constexpr std::uint32_t kRoutedTileRowsNarrow = 16;
constexpr std::uint32_t kRoutedTileRowsWide = 48;

std::uint32_t RoutedTileRows(std::size_t slots, std::uint32_t n_experts) {
  return slots >= static_cast<std::size_t>(16) * n_experts
             ? kRoutedTileRowsWide
             : kRoutedTileRowsNarrow;
}

/// Upper bound on launched routed tiles: every 16-padded bucket contributes
/// at most one partial tile beyond its rows.
std::size_t RoutedTileCapacity(std::size_t slots, std::uint32_t n_experts) {
  return (slots + static_cast<std::size_t>(n_experts) * 15) /
             kRoutedTileRowsNarrow +
         n_experts + 1;
}

std::uint32_t IndexerCapacity(const Config& c, std::uint32_t batch,
                              std::uint32_t context) {
  return static_cast<std::uint32_t>(std::bit_ceil(std::min<std::uint64_t>(
      context, std::uint64_t{c.indexer_top_k} + batch)));
}

void PopulateSnapshotPrefix(std::uint8_t* data, std::uint64_t bytes,
                            std::uint64_t worker_limit = 4) {
  platform::PopulateWritablePages(data, static_cast<std::size_t>(bytes),
                                  static_cast<std::size_t>(worker_limit));
}

}  // namespace

namespace {
constexpr std::uint64_t kSnapshotReuseBytes = 8ULL << 20;
// Device memory kept free beyond the executor's own lazy scratch, for the
// runtime and driver. Snapshot storage never grows into it.
constexpr std::uint64_t kSnapshotDeviceSlackBytes = 512ULL << 20;

/// Snapshot storage would leave too little device memory. Callers keep the
/// checkpoint in its host payload instead; the request continues.
class SnapshotDeviceExhausted : public std::runtime_error {
public:
  using std::runtime_error::runtime_error;
};
}  // namespace
// Legacy hipFree synchronizes unrelated inference streams. Pool allocations
// have stream-ordered release, so evicting a checkpoint cannot stall a peer.
// Every transfer finishes before dropping its last storage reference.
class SnapshotAllocator
    : public std::enable_shared_from_this<SnapshotAllocator> {
public:
  // Every capture freezes the same mutable state size. Keep this many released
  // blocks of it committed for the next captures: ROCm commits pool pages on
  // each allocation (about 25 GB/s here), and an allocation also stalls other
  // HIP calls, so a background refill would land in a peer's decode instead.
  static constexpr std::size_t kSpareBlocks = 2;

  /// `reserve` is the device memory every commit leaves free.
  explicit SnapshotAllocator(std::uint64_t reserve) : reserve_(reserve) {
    hipMemPoolProps properties{};
    properties.allocType = hipMemAllocationTypePinned;
    properties.handleTypes = hipMemHandleTypeNone;
    properties.location.type = hipMemLocationTypeDevice;
    CheckStatus(hipGetDevice(&properties.location.id), "snapshot pool device");
    CheckStatus(hipMemPoolCreate(&pool_, &properties), "snapshot pool");
    const auto created =
        hipStreamCreateWithFlags(&stream_, hipStreamNonBlocking);
    if (created != hipSuccess) {
      (void)hipMemPoolDestroy(pool_);
      CheckStatus(created, "snapshot allocator stream");
    }
  }
  ~SnapshotAllocator() {
    for (void* spare : spares_)
      (void)hipFree(spare);
    (void)hipStreamSynchronize(stream_);
    (void)hipStreamDestroy(stream_);
    for (hipStream_t stream : free_streams_)
      (void)hipStreamDestroy(stream);
    (void)hipMemPoolDestroy(pool_);
  }
  std::shared_ptr<void> Allocate(std::uint64_t bytes) {
    std::lock_guard lock(mutex_);
    return Own(Commit(bytes), bytes);
  }
  /// Allocates storage the reserve already counts (the checkpoint arena): it
  /// needs the reserve free only beyond its own bytes.
  std::shared_ptr<void> AllocateReserved(std::uint64_t bytes) {
    std::lock_guard lock(mutex_);
    return Own(Commit(bytes, bytes), bytes);
  }
  /// Allocates the recurring mutable-state size, from a released block when
  /// one is kept.
  std::shared_ptr<void> AllocateSpare(std::uint64_t bytes) {
    std::lock_guard lock(mutex_);
    if (spare_bytes_ != bytes) {
      for (void* spare : spares_)
        (void)hipFree(spare);
      spares_.clear();
      spare_bytes_ = bytes;
    }
    if (spares_.empty())
      return Own(Commit(bytes), bytes);
    void* data = spares_.back();
    spares_.pop_back();
    return Own(data, bytes);
  }
  /// Bytes the spare blocks may hold, for scratch accounting.
  [[nodiscard]] static std::uint64_t SpareBytes(std::uint64_t block) {
    return kSpareBlocks * block;
  }
  /// Whether committing `bytes` keeps the reserve free. The snapshot budget
  /// counts host payloads, but on an APU the device limit can be lower than
  /// host RAM. ROCm 7.2's VM pool corrupts its heap when a page commit
  /// fails, so storage is never requested beyond the device headroom.
  [[nodiscard]] bool Fits(std::uint64_t bytes,
                          std::uint64_t reserved = 0) const {
    std::size_t free = 0;
    std::size_t total = 0;
    if (hipMemGetInfo(&free, &total) != hipSuccess)
      return false;
    return free >= bytes && free - bytes + reserved >= reserve_;
  }
  /// A transfer on a stream of its own, reused across transfers: creating a
  /// stream can stall for milliseconds, and a shared stream would make a
  /// capture wait for a peer's bulk materialization.
  [[nodiscard]] std::unique_ptr<gufo::hip::SnapshotTransfer> Transfer() {
    hipStream_t stream = nullptr;
    {
      std::lock_guard lock(streams_mutex_);
      if (!free_streams_.empty()) {
        stream = free_streams_.back();
        free_streams_.pop_back();
      }
    }
    if (stream == nullptr)
      CheckStatus(hipStreamCreateWithFlags(&stream, hipStreamNonBlocking),
                  "snapshot transfer stream");
    return std::make_unique<gufo::hip::SnapshotTransfer>(
        stream, [owner = shared_from_this()](hipStream_t done) {
          std::lock_guard lock(owner->streams_mutex_);
          owner->free_streams_.push_back(done);
        });
  }

private:
  static void CheckStatus(hipError_t error, const char* operation) {
    if (error != hipSuccess)
      throw std::runtime_error(std::string(operation) + ": " +
                               hipGetErrorString(error));
  }
  void* Commit(std::uint64_t bytes, std::uint64_t reserved = 0) {
    if (!Fits(bytes, reserved))
      throw SnapshotDeviceExhausted("snapshot storage exceeds device headroom");
    void* data = nullptr;
    CheckStatus(hipMallocFromPoolAsync(&data, bytes, pool_, stream_),
                "snapshot allocate");
    const auto ready = hipStreamSynchronize(stream_);
    if (ready != hipSuccess) {
      (void)hipFree(data);
      (void)hipStreamSynchronize(stream_);
      CheckStatus(ready, "snapshot allocation ready");
    }
    return data;
  }
  std::shared_ptr<void> Own(void* data, std::uint64_t bytes) {
    return {data, [owner = shared_from_this(), bytes](void* pointer) {
              owner->Release(pointer, bytes);
            }};
  }
  void Release(void* pointer, std::uint64_t bytes) {
    std::lock_guard lock(mutex_);
    if (bytes == spare_bytes_ && spares_.size() < kSpareBlocks) {
      spares_.push_back(pointer);
      return;
    }
    // In ROCm, hipFree recognizes pool allocations and bypasses SyncAllStreams.
    // Unlike hipFreeAsync, it also permits a peer blocking-stream capture.
    (void)hipFree(pointer);
    // Keep physical memory bounded by retained checkpoints and the spares,
    // including when their source session has already been destroyed.
    (void)hipStreamSynchronize(stream_);
  }
  std::uint64_t reserve_;
  std::mutex mutex_;
  std::vector<void*> spares_;
  std::uint64_t spare_bytes_{0};
  hipStream_t stream_{nullptr};
  std::mutex streams_mutex_;
  std::vector<hipStream_t> free_streams_;
  hipMemPool_t pool_{nullptr};
};

std::shared_ptr<SnapshotAllocator> Executor::GetSnapshotAllocator() const {
  std::call_once(snapshot_allocator_once_, [&] {
    // Admission reserved the lazy scratch; snapshots must not consume it.
    snapshot_allocator_ = std::make_shared<SnapshotAllocator>(
        DeferredScratchBytes() + kSnapshotDeviceSlackBytes);
  });
  return snapshot_allocator_;
}

// Provenance describes rows actually copied by a restore, rather than token
// equality: different prefill shapes can produce different KV for the same
// tokens. A branch shares its parent's rows only below its restored frontier.
// These nodes retain metadata alone, never snapshot payloads or device storage.
struct SnapshotLineage {
  using Rows = std::array<std::uint32_t, 4>;
  std::shared_ptr<const SnapshotLineage> parent;
  Rows prefix{};
  std::size_t depth = 0;
  explicit SnapshotLineage(
      std::shared_ptr<const SnapshotLineage> source = nullptr, Rows rows = {})
      : parent(std::move(source)),
        prefix(rows),
        depth(parent ? parent->depth + 1 : 0) {}

  static Rows Common(std::shared_ptr<const SnapshotLineage> left,
                     std::shared_ptr<const SnapshotLineage> right,
                     Rows bounds) {
    const auto ascend = [&](auto& node) {
      for (std::size_t i = 0; i < bounds.size(); ++i)
        bounds[i] = std::min(bounds[i], node->prefix[i]);
      node = node->parent;
    };
    if (!left || !right)
      return {};
    while (left->depth > right->depth)
      ascend(left);
    while (right->depth > left->depth)
      ascend(right);
    while (left != right) {
      if (!left->parent || !right->parent)
        return {};
      ascend(left);
      ascend(right);
    }
    return bounds;
  }
};

struct SnapshotBlock {
  SnapshotBlock(const std::shared_ptr<SnapshotAllocator>& allocator,
                std::uint64_t bytes)
      : storage(allocator->Allocate(bytes)), capacity(bytes) {}
  std::shared_ptr<void> storage;
  std::uint64_t capacity;
  std::atomic<std::uint32_t> chunks{0};
  std::uint64_t used = 0;
};
struct SnapshotChunk {
  std::shared_ptr<SnapshotBlock> block;
  std::uint8_t* device;
  ~SnapshotChunk() { --block->chunks; }
};
struct SnapshotRegistry {
  explicit SnapshotRegistry(std::shared_ptr<SnapshotAllocator> allocator)
      : allocator(std::move(allocator)) {}
  std::shared_ptr<SnapshotAllocator> allocator;
  std::mutex mutex;
  std::vector<std::weak_ptr<SnapshotState>> pending;
  std::vector<std::weak_ptr<SnapshotBlock>> reserve;
  std::exception_ptr failure;
  void Preserve(std::uint32_t position, std::uint32_t mtp_position,
                std::uint32_t blocks, std::uint32_t mtp_blocks);
};

void SnapshotState::Preserve(std::uint32_t position, std::uint32_t mtp_position,
                             std::uint32_t blocks, std::uint32_t mtp_blocks,
                             bool detach) const {
  std::unique_ptr<gufo::hip::SnapshotTransfer> transfer;
  for (auto& region : regions_) {
    auto rows = region.draft ? mtp_position : position;
    if (region.pooled)
      rows = region.draft ? mtp_blocks : blocks;
    const auto keep = std::uint64_t{rows} * region.row_bytes;
    if (keep < region.pending_bytes) {
      if (!transfer)
        transfer = registry_->allocator->Transfer();
      transfer->Copy(region.host + keep,
                     static_cast<const std::uint8_t*>(region.device) + keep,
                     region.pending_bytes - keep);
      region.pending_bytes = keep;
    }
    if (detach)
      region.live_bytes = std::min(region.live_bytes, keep);
  }
}

void SnapshotState::Materialize() const {
  std::lock_guard lock(registry_->mutex);
  if (registry_->failure)
    std::rethrow_exception(registry_->failure);
  MaterializeLocked();
}

void SnapshotState::MaterializeLocked() const {
  const auto transfer = registry_->allocator->Transfer();
  for (const auto& region : regions_) {
    PopulateSnapshotPrefix(region.host, region.bytes);
    for (const auto& saved : region.saved)
      transfer->Enqueue(region.host + saved.offset, saved.chunk->device,
                        saved.bytes);
  }
  transfer->Finish();
  Preserve(0, 0, 0, 0, false);
  if (mutable_storage_) {
    PopulateSnapshotPrefix(payload_ + mutable_offset_, mutable_bytes_);
    transfer->Copy(payload_ + mutable_offset_, mutable_device_, mutable_bytes_);
    mutable_storage_.reset();
  }
  if (extra_storage_) {
    for (const auto& extra : extras_)
      transfer->Enqueue(payload_ + extra.offset, extra.device, extra.bytes);
    transfer->Finish();
    extras_.clear();
    extra_storage_.reset();
  }
  for (auto& region : regions_)
    region.saved.clear();
}

std::uint64_t SnapshotState::DeviceBytes() const {
  std::lock_guard lock(registry_->mutex);
  std::uint64_t bytes = (mutable_storage_ ? mutable_bytes_ : 0) +
                        (extra_storage_ ? extra_bytes_ : 0);
  std::vector<const SnapshotBlock*> blocks;
  for (const auto& region : regions_)
    for (const auto& saved : region.saved) {
      const auto* block = saved.chunk->block.get();
      if (std::find(blocks.begin(), blocks.end(), block) == blocks.end()) {
        blocks.push_back(block);
        bytes += block->capacity;
      }
    }
  return bytes;
}

void SnapshotRegistry::Preserve(std::uint32_t position,
                                std::uint32_t mtp_position,
                                std::uint32_t blocks,
                                std::uint32_t mtp_blocks) {
  struct Group {
    void* device;
    std::uint64_t keep;
    std::uint64_t end;
    std::vector<std::pair<SnapshotState::Region*, std::size_t>> regions;
  };
  std::vector<std::shared_ptr<SnapshotState>> snapshots;
  std::vector<Group> groups;
  std::vector<std::shared_ptr<SnapshotBlock>> available;
  // Only overwritten rows need backing storage. Appending borrows K/V in
  // place and does not allocate another context's worth of device pages.
  for (auto it = reserve.begin(); it != reserve.end();) {
    if (auto block = it->lock()) {
      if (block->chunks == 0)
        block->used = 0;
      if (block->used < block->capacity &&
          block->capacity - block->used <= kSnapshotReuseBytes)
        available.push_back(std::move(block));
      ++it;
    } else {
      it = reserve.erase(it);
    }
  }
  for (auto it = pending.begin(); it != pending.end();) {
    if (auto snapshot = it->lock()) {
      for (auto& region : snapshot->regions_) {
        auto rows = region.draft ? mtp_position : position;
        if (region.pooled)
          rows = region.draft ? mtp_blocks : blocks;
        const auto keep = std::uint64_t{rows} * region.row_bytes;
        if (keep < region.pending_bytes) {
          auto group = std::find_if(
              groups.begin(), groups.end(),
              [&](const auto& entry) { return entry.device == region.device; });
          if (group == groups.end()) {
            groups.push_back({region.device,
                              keep,
                              region.pending_bytes,
                              {{&region, snapshots.size()}}});
          } else {
            group->end = std::max(group->end, region.pending_bytes);
            group->regions.emplace_back(&region, snapshots.size());
          }
        }
      }
      snapshots.push_back(std::move(snapshot));
      ++it;
    } else {
      it = pending.erase(it);
    }
  }
  struct Copy {
    void* device;
    std::uint64_t begin;
    std::uint64_t end;
    std::vector<SnapshotState::Region*> regions;
    std::vector<std::size_t> owners;
  };
  std::vector<Copy> copies;
  for (const auto& group : groups) {
    std::vector<std::uint64_t> ends{group.keep};
    for (const auto& [region, owner] : group.regions) {
      (void)owner;
      ends.push_back(region->pending_bytes);
    }
    std::sort(ends.begin(), ends.end());
    ends.erase(std::unique(ends.begin(), ends.end()), ends.end());
    for (std::size_t index = 1; index < ends.size(); ++index) {
      Copy copy{group.device, ends[index - 1], ends[index], {}, {}};
      for (const auto& [region, owner] : group.regions)
        if (region->pending_bytes >= copy.end) {
          copy.regions.push_back(region);
          copy.owners.push_back(owner);
        }
      copies.push_back(std::move(copy));
    }
  }
  // Pack rows with the same consumers together across layers. Each consumer
  // set gets one allocation, so protecting a deep prefix avoids dozens of
  // small allocations. A short checkpoint retains only its own rows and at
  // most bounded slack from a reused block belonging to other consumers.
  std::stable_sort(copies.begin(), copies.end(),
                   [](const auto& left, const auto& right) {
                     return left.owners < right.owners;
                   });
  std::uint64_t capacity = 0;
  for (const auto& block : available)
    capacity += block->capacity - block->used;
  // Allocate before enqueuing any copy or changing a checkpoint. Allocation
  // failure then leaves the source and every retained checkpoint intact.
  std::vector<std::uint64_t> commits;
  std::uint64_t needed = 0;
  for (std::size_t first = 0; first < copies.size();) {
    auto last = first;
    std::uint64_t bytes = 0;
    while (last < copies.size() &&
           copies[last].owners == copies[first].owners) {
      bytes += copies[last].end - copies[last].begin;
      ++last;
    }
    const auto reused = std::min(capacity, bytes);
    capacity -= reused;
    bytes -= reused;
    if (bytes != 0) {
      commits.push_back(bytes);
      needed += bytes;
    }
    first = last;
  }
  bool device = needed == 0 || allocator->Fits(needed);
  if (device) {
    try {
      for (const auto bytes : commits) {
        auto block = std::make_shared<SnapshotBlock>(allocator, bytes);
        reserve.push_back(block);
        available.push_back(std::move(block));
      }
    } catch (const SnapshotDeviceExhausted&) {
      device = false;
    }
  }
  if (!device) {
    // No device room for the overwritten rows: move each affected checkpoint
    // into its host payload, which the snapshot budget already charges. This
    // also releases the device copies it held from earlier rewinds.
    std::vector<bool> affected(snapshots.size());
    for (const auto& copy : copies)
      for (const auto owner : copy.owners)
        affected[owner] = true;
    for (std::size_t index = 0; index < snapshots.size(); ++index)
      if (affected[index])
        snapshots[index]->MaterializeLocked();
    copies.clear();
    available.clear();
  }
  std::size_t block_index = 0;
  std::unique_ptr<gufo::hip::SnapshotTransfer> transfer;
  for (auto& copy : copies) {
    for (auto begin = copy.begin; begin < copy.end;) {
      if (block_index < available.size() &&
          available[block_index]->used == available[block_index]->capacity)
        ++block_index;
      if (block_index >= available.size())
        throw std::logic_error(
            "snapshot protection exceeded allocated storage");
      auto& used = available[block_index]->used;
      const auto bytes =
          std::min(available[block_index]->capacity - used, copy.end - begin);
      auto chunk = std::make_shared<SnapshotChunk>();
      chunk->block = available[block_index];
      ++chunk->block->chunks;
      chunk->device =
          static_cast<std::uint8_t*>(chunk->block->storage.get()) + used;
      if (!transfer)
        transfer = allocator->Transfer();
      transfer->Enqueue(chunk->device,
                        static_cast<const std::uint8_t*>(copy.device) + begin,
                        bytes, hipMemcpyDeviceToDevice);
      for (auto* region : copy.regions)
        region->saved.push_back({begin, bytes, chunk});
      used += bytes;
      begin += bytes;
    }
  }
  if (transfer)
    transfer->Finish();
  for (const auto& snapshot : snapshots) {
    for (auto& region : snapshot->regions_) {
      auto rows = region.draft ? mtp_position : position;
      if (region.pooled)
        rows = region.draft ? mtp_blocks : blocks;
      const auto keep = std::uint64_t{rows} * region.row_bytes;
      region.pending_bytes = std::min(region.pending_bytes, keep);
      region.live_bytes = std::min(region.live_bytes, keep);
    }
  }
}

void Session::PreserveSnapshots(std::uint32_t position,
                                std::uint32_t mtp_position) const {
  if (!snapshots_ || (position >= snapshot_position_ &&
                      mtp_position >= snapshot_mtp_position_))
    return;
  std::lock_guard lock(snapshots_->mutex);
  if (snapshots_->failure)
    std::rethrow_exception(snapshots_->failure);
  const auto ratio = owner_->config().compress_ratio;
  snapshots_->Preserve(position, mtp_position,
                       ratio ? std::min(blocks_, position / ratio) : 0,
                       ratio ? std::min(mtp_.blocks, mtp_position / ratio) : 0);
  snapshot_position_ = std::min(snapshot_position_, position);
  snapshot_mtp_position_ = std::min(snapshot_mtp_position_, mtp_position);
}

Session::~Session() {
  try {
    PreserveSnapshots(0, 0);
  } catch (...) {
    // The backing device may be lost. Leave retained checkpoints readable as
    // failures instead of allowing a later reader to touch freed allocations.
    std::lock_guard lock(snapshots_->mutex);
    snapshots_->failure = std::current_exception();
  }
  TrimRollback(0);
  for (auto& [key, exec] : graphs_) {
    (void)hipGraphExecDestroy(exec);
  }
  for (void* p : allocations_) {
    (void)hipFree(p);
  }
}

void Session::RestoreVisionLayout(const qwen::vision::RopeLayout& layout,
                                  hipStream_t stream) {
  layout.Validate(max_context_);
  const auto* previous = vision_input_.rope();
  vision_input_.RestoreLayout(layout, stream);
  for (auto& attention : attention_)
    attention.rope = vision_input_.rope();
  if (previous != vision_input_.rope()) {
    for (const auto& [key, graph] : graphs_)
      (void)hipGraphExecDestroy(graph);
    graphs_.clear();
    warmed_.clear();
  }
}

void Session::PrepareVision(hipStream_t stream) {
  vision_input_.PrepareRope(stream);
  for (auto& attention : attention_)
    attention.rope = vision_input_.rope();
}

void Session::ConfigureVision(
    std::shared_ptr<const qwen::vision::Prompt> prompt,
    std::shared_ptr<qwen::vision::Encoder> encoder, hipStream_t stream) {
  if (prompt)
    prompt->rope.Validate(max_context_);
  const auto* previous = vision_input_.rope();
  vision_input_.Configure(std::move(prompt), std::move(encoder), stream);
  for (auto& attention : attention_)
    attention.rope = vision_input_.rope();
  if (previous != vision_input_.rope()) {
    for (const auto& [key, graph] : graphs_)
      (void)hipGraphExecDestroy(graph);
    graphs_.clear();
    warmed_.clear();
  }
}

void Session::SetCancellationCheck(std::function<bool()> check) {
  cancelled_ = false;
  is_cancelled_ = std::move(check);
  vision_input_.SetCancellationCheck(is_cancelled_);
}

bool Session::CheckCancellation(std::string* error) const {
  try {
    cancelled_ = cancelled_ || (is_cancelled_ && is_cancelled_());
  } catch (...) {
    cancelled_ = true;
  }
  if (cancelled_) {
    AssignError(error, "generation cancelled");
    return false;
  }
  return true;
}

std::size_t Session::AllocatedBytes() const noexcept {
  return allocated_bytes_ + rollback_bytes_ + vision_input_.Bytes();
}

PrefillCheckpoint::~PrefillCheckpoint() {
  if (!state)
    return;
  source->snapshot_position_ =
      std::max(source->snapshot_position_, state->snapshot_position_);
  source->snapshot_mtp_position_ =
      std::max(source->snapshot_mtp_position_, state->snapshot_mtp_position_);
  // The view owns no cache allocations. Its borrowed rows belong to source.
  state->snapshots_.reset();
}

bool Executor::ReservePrefillCheckpoint(const Session& session) const {
  // Both TP ranks must split at the same boundary. In-pass checkpoint views
  // are local-only; do not let per-rank device headroom choose the schedule.
  if (model_->tp_world_size() > 1)
    return false;
  if (checkpoint_storage_)
    return true;
  const auto& c = config();
  std::size_t floats =
      has_mtp() ? std::size_t{options_.max_speculative} * c.HcDim() : 0;
  for (const auto& linear : session.linear_)
    if (linear.state)
      floats +=
          std::size_t{c.ssm_conv_kernel - 1} * c.SsmConvChannels() +
          std::size_t{c.ssm_num_v_heads} * c.ssm_head_dim * c.ssm_head_dim;
  if (c.ple_layer >= 0)
    floats += std::size_t{c.PleConvHistory()} * c.HcDim();
  try {
    // Forward scratch is shared by the executor. The checkpoint is frozen
    // into private snapshot storage before another session can reuse it.
    // DeferredScratchBytes reserved it, so it may take its own reservation.
    checkpoint_storage_ =
        GetSnapshotAllocator()->AllocateReserved(floats * sizeof(float));
  } catch (const SnapshotDeviceExhausted&) {
    return false;
  }
  return true;
}

std::unique_ptr<PrefillCheckpoint> Executor::MakePrefillCheckpoint(
    Session& source, std::span<const std::int32_t> tokens, std::uint32_t prefix,
    std::string* error_msg) const {
  if (model_->tp_world_size() > 1) {
    AssignError(error_msg,
                "TP prefill captures use a separate mirrored snapshot");
    return nullptr;
  }
  if (source.owner_ != this || prefix == 0 || prefix > tokens.size() ||
      tokens.size() - prefix > kVecBatch ||
      !source.VisionLayout().images.empty()) {
    AssignError(error_msg, "prefill checkpoint must be in the text tail");
    return nullptr;
  }
  const auto& c = config();
  auto checkpoint = std::make_unique<PrefillCheckpoint>();
  checkpoint->source = &source;
  checkpoint->tokens = prefix;
  checkpoint->hidden_rows =
      source.mtp_enabled_ ? std::min(prefix, options_.max_speculative) : 0;
  checkpoint->logits.resize(c.vocab_size);
  checkpoint->state.reset(new Session);
  auto& view = *checkpoint->state;
  view.owner_ = this;
  view.max_context_ = source.max_context_;
  view.index_capacity_ = source.index_capacity_;
  view.position_ = source.position_ + prefix;
  view.mtp_enabled_ = source.mtp_enabled_;
  view.attention_ = source.attention_;
  view.linear_.resize(source.linear_.size());
  view.blocks_ = c.compress_ratio > 0 && view.position_ > c.indexer_top_k
                     ? view.position_ / c.compress_ratio
                     : source.blocks_;
  view.mtp_ = source.mtp_;
  if (source.mtp_enabled_) {
    view.mtp_.position = view.position_ - 1;
    view.mtp_.blocks = view.mtp_.position > c.indexer_top_k
                           ? view.mtp_.position / c.compress_ratio
                           : source.mtp_.blocks;
    if (prefix > 1)
      view.mtp_.residual_valid = false;
  }
  view.ngram_ = source.ngram_;
  std::vector<std::uint32_t> rows(std::size_t{prefix} * c.ple_heads);
  if (c.ple_layer >= 0)
    HashNgramRows(c, view.ngram_, tokens.first(prefix), rows);
  if (!source.snapshots_)
    source.snapshots_ =
        std::make_shared<SnapshotRegistry>(GetSnapshotAllocator());
  if (!source.snapshot_lineage_)
    source.snapshot_lineage_ = std::make_shared<SnapshotLineage>();
  view.snapshots_ = source.snapshots_;
  view.snapshot_lineage_ = source.snapshot_lineage_;
  // This rank's heads: all of them on one host, half under TP2.
  const MixerHeads& heads = trunk_heads();
  const auto conv =
      std::size_t{c.ssm_conv_kernel - 1} * heads.SsmConvChannels();
  const auto recurrent =
      std::size_t{heads.ssm_v} * heads.ssm_dim * heads.ssm_dim;
  if (!checkpoint_storage_) {
    AssignError(error_msg, "prefill checkpoint arena is not reserved");
    return nullptr;
  }
  auto* storage = static_cast<float*>(checkpoint_storage_.get());
  for (std::size_t il = 0; il < source.linear_.size(); ++il) {
    if (!source.linear_[il].state)
      continue;
    view.linear_[il].conv_state = storage;
    storage += conv;
    view.linear_[il].state = storage;
    storage += recurrent;
  }
  if (c.ple_layer >= 0) {
    view.ple_history_ = storage;
    storage += std::size_t{c.PleConvHistory()} * c.HcDim();
  }
  if (source.mtp_enabled_)
    view.mtp_.target_hidden = storage;
  return checkpoint;
}

void Session::TrimRollback(std::uint32_t depth) noexcept {
  if (depth >= rollback_depth_)
    return;
  // Keep graphs whose rows still exist. Deeper verifier graphs capture
  // discarded pointers; ordinary decode and MTP graphs do not.
  for (auto it = graphs_.begin(); it != graphs_.end();) {
    if ((it->first & (std::uint64_t{1} << 32)) != 0 &&
        (it->first & (std::uint64_t{1} << 40)) == 0 &&
        (it->first & 0xFFFFU) > depth + 1) {
      (void)hipGraphExecDestroy(it->second);
      it = graphs_.erase(it);
    } else {
      ++it;
    }
  }
  for (auto row = depth; row < rollback_depth_; ++row) {
    (void)hipFree(rollback_allocations_[row]);
    for (auto& layer : linear_) {
      layer.conv_snapshots.rows[row] = nullptr;
      layer.state_snapshots.rows[row] = nullptr;
    }
    ple_snapshots_.rows[row] = nullptr;
  }
  rollback_allocations_.resize(depth);
  rollback_depth_ = depth;
  rollback_bytes_ =
      owner_->SessionBytes(core::SessionMode::kAutoregressive, max_context_,
                           depth) -
      owner_->SessionBytes(core::SessionMode::kAutoregressive, max_context_, 0);
  ngram_snapshots_.resize(depth);
}

void Session::Reset(bool reuse_mtp) {
  // Reset leaves append-only rows intact. Preserve them at the first write
  // that would overwrite them, allowing cancellation to resume by rewind.
  // Scratch is overwritten by the next verification. Retaining its stable
  // addresses also retains the graphs; freeing it at every cache reassignment
  // makes later MTP requests allocate and record those shapes again. Its full
  // bound is already included in speculative SessionBytes and AllocatedBytes.
  if (!reuse_mtp || !mtp_enabled_)
    TrimRollback(0);
  snapshot_lineage_.reset();
  position_ = 0;
  spec_tokens_ = 0;
  ngram_.Reset();
  mtp_.position = 0;
  mtp_.residual_valid = false;
  mtp_.blocks = 0;
  const Config& c = owner_->config();
  const auto zero = [&](void* pointer, std::size_t bytes) {
    const auto result = hipMemsetAsync(pointer, 0, bytes, owner_->stream());
    // Adapter invalidation may report success only after every zero fill was
    // submitted and completed. Keep legacy cleanup's error policy unchanged.
    if (result != hipSuccess && continuation_hooks_)
      throw std::runtime_error(hipGetErrorString(result));
  };
  const MixerHeads& heads = owner_->trunk_heads();
  for (auto& l : linear_) {
    if (l.state != nullptr) {
      zero(l.conv_state, static_cast<std::size_t>(c.ssm_conv_kernel - 1) *
                             heads.SsmConvChannels() * sizeof(float));
      zero(l.state, static_cast<std::size_t>(heads.ssm_v) * heads.ssm_dim *
                        heads.ssm_dim * sizeof(float));
    }
  }
  blocks_ = 0;
  if (ple_history_ != nullptr) {
    zero(ple_history_, static_cast<std::size_t>(c.PleConvHistory()) *
                           c.HcDim() * sizeof(float));
  }
}

Executor::~Executor() {
  // Readers write pinned staging memory; drain them before freeing it,
  // including when a forward failed before reaching PLE.
  if (ple_pending_ || prefetch_.pending) {
    (void)ngram_->WaitRead();
  }
  (void)hipFree(batch_logits_);
  (void)hipFree(verification_penalties_);
  for (void* p : allocations_) {
    (void)hipFree(p);
  }
  host_allocations_.Reset();
  if (blas_ != nullptr) {
    (void)hipblasDestroy(blas_);
  }
  if (counts_ready_ != nullptr) {
    (void)hipEventDestroy(counts_ready_);
  }
  for (hipEvent_t event : {side_start_, side_done_}) {
    if (event != nullptr)
      (void)hipEventDestroy(event);
  }
  if (side_stream_ != nullptr)
    (void)hipStreamDestroy(side_stream_);
  if (stream_ != nullptr) {
    qfn_mmq_release_stream(stream_);
    (void)hipStreamDestroy(stream_);
  }
}

std::unique_ptr<Executor> Executor::Create(const DeviceModel& model,
                                           NgramTable* ngram, Options options,
                                           std::string* error_msg) {
  std::unique_ptr<Executor> e(new Executor());
  e->model_ = &model;
  e->ngram_ = ngram;
  e->options_ = options;
  if (model.tp_world_size() > 1 &&
      (!options.all_reduce || !options.reduce_status)) {
    AssignError(error_msg,
                "distributed Flash-Next execution requires an all-reduce "
                "communicator");
    return nullptr;
  }
  if (static_cast<bool>(options.split_reduce.start) !=
          static_cast<bool>(options.split_reduce.finish) ||
      (options.split_reduce.start && model.tp_world_size() == 1)) {
    AssignError(error_msg,
                "a split reduce needs both halves and distributed execution");
    return nullptr;
  }
  e->options_.max_batch = std::max<std::uint32_t>(1, options.max_batch);
  e->options_.max_logit_rows = std::clamp<std::uint32_t>(
      options.max_logit_rows, 1, e->options_.max_batch);
  e->options_.max_speculative = std::clamp<std::uint32_t>(
      options.max_speculative, 1, e->options_.max_logit_rows);
  if (hipSetDevice(e->options_.device_index) != hipSuccess) {
    AssignError(error_msg, "HIP device selection failed");
    return nullptr;
  }
  if (qfn_mmq_init(e->options_.device_index) != 0) {
    AssignError(error_msg, "quantized GEMM tier initialization failed");
    return nullptr;
  }
  if (!Check(PrepareW8A8GemmWave64(), "wide Q8 GEMM preparation", error_msg))
    return nullptr;
  // The first greedy verification otherwise resolves the shared argmax
  // module on the decode path. Preparation launches no trial kernels.
  if (e->has_mtp() && !Check(gufo::hip::PrepareBatchedGPUArgmax(),
                             "MTP argmax preparation", error_msg))
    return nullptr;
  if (!Check(hipStreamCreate(&e->stream_), "hipStreamCreate", error_msg)) {
    return nullptr;
  }
  if (!Check(hipEventCreateWithFlags(&e->counts_ready_, hipEventDisableTiming),
             "expert counts event", error_msg) ||
      !Check(hipStreamCreate(&e->side_stream_), "side stream", error_msg) ||
      !Check(hipEventCreateWithFlags(&e->side_start_, hipEventDisableTiming),
             "side stream fork event", error_msg) ||
      !Check(hipEventCreateWithFlags(&e->side_done_, hipEventDisableTiming),
             "side stream join event", error_msg)) {
    return nullptr;
  }
  if (hipblasCreate(&e->blas_) != HIPBLAS_STATUS_SUCCESS ||
      hipblasSetStream(e->blas_, e->stream_) != HIPBLAS_STATUS_SUCCESS) {
    AssignError(error_msg, "hipblasCreate failed");
    return nullptr;
  }
  const Config& c = model.config();
  if (options.max_context > c.MaxContextLength()) {
    AssignError(error_msg, "executor context exceeds the model context");
    return nullptr;
  }
  e->context_capacity_ = std::max(c.context_length, options.max_context);
  e->yarn_ = MakeYarnRope(c.rope_scaling, c.rotary_dim, c.rope_theta);
  const std::size_t T = e->options_.max_batch;
  e->blaslt_ = BlasLt::Create(e->stream_, error_msg);
  if (e->blaslt_ == nullptr) {
    return nullptr;
  }
  if (MatrixRows(T)) {
    // The first indexer heuristic query also loads the library's code object.
    // Do that before readiness instead of leaving a ~100 ms GPU idle gap in
    // the first prefill. Exact geometry still determines every plan; no trial
    // GEMM runs and no model activations or session state are touched.
    for (const auto& layer : model.layers()) {
      for (const auto* tensor : {&layer.indexer_k, &layer.indexer_q}) {
        if (!tensor->empty() &&
            (tensor->type == GgmlType::kBF16 ||
             tensor->type == GgmlType::kF16) &&
            !e->blaslt_->Prepare(
                tensor->type == GgmlType::kBF16 ? HIP_R_16BF : HIP_R_16F,
                tensor->rows, T, tensor->cols, error_msg)) {
          return nullptr;
        }
      }
    }
  }
  const std::size_t hc_dim = c.HcDim();
  const std::size_t hidden = c.hidden_size;
  const std::size_t slots = T * c.num_experts_used;
  // Token and n-gram staging hold a whole prefill chunk.
  const std::size_t chunk = e->PrefillChunk();
  auto& a = e->allocations_;
  Scratch& s = e->s_;
  auto f32 = [&](std::size_t n) { return Alloc<float>(a, n, error_msg); };
  s.tokens = Alloc<std::int32_t>(a, chunk, error_msg);
  s.x_half = Alloc<std::uint16_t>(a, T * model.max_half_cols(), error_msg);
  for (void*& slot : s.x_q8) {
    slot = Alloc<std::uint8_t>(
        a,
        qfn_mmq_q8_1_bytes(static_cast<int>(kVecBatch),
                           static_cast<int>(model.max_q8_cols())),
        error_msg);
  }
  const auto q8_1 = [&](std::size_t k) {
    return Alloc<std::uint8_t>(
        a, qfn_mmq_q8_1_bytes(static_cast<int>(kVecBatch), static_cast<int>(k)),
        error_msg);
  };
  s.xn_q8_1 = q8_1(hc_dim);
  s.lo_q8_1 = q8_1(c.hc_low_rank);
  s.mixed_q8_1 = q8_1(hidden);
  s.gdn_q8_1 = q8_1(c.SsmValueDim());
  s.ctx_q8_1 = q8_1(c.AttentionQDim());
  s.x_q8t =
      Alloc<std::uint8_t>(a, Q8TiledBytes(T, model.max_q8_cols()), error_msg);
  s.res = f32(T * hc_dim);
  s.xn = f32(T * hc_dim);
  s.xn_half = Alloc<__half>(a, T * hc_dim, error_msg);
  s.xn_q8t = Alloc<std::uint8_t>(a, Q8TiledBytes(T, hc_dim), error_msg);
  s.lo = f32(T * c.hc_low_rank);
  s.mixed = f32(T * hidden);
  s.inject = f32(T * c.hc_count * HcInjectParts(hidden));
  s.block_out = f32(T * hidden);
  s.hc_defer_w = f32(T * c.hc_count);
  e->hc_fused_state_ =
      Alloc<std::uint8_t>(a, HcMixQ8FusedStateBytes(), error_msg);
  e->mask_words_ = c.SparseMaskWords(e->context_capacity_);
  const std::size_t linear_projection = std::max<std::size_t>(
      c.SsmConvChannels() + c.SsmValueDim(), c.ple_layer >= 0 ? hc_dim : 0);
  const std::size_t linear_floats =
      T * (linear_projection + 2 * c.ssm_num_v_heads + 2 * c.SsmKeyDim() +
           2 * c.SsmValueDim()) +
      (T + c.ssm_conv_kernel) * c.SsmConvChannels();
  const std::size_t attention_floats =
      T * (5 * c.AttentionQDim() + 4 * c.AttentionKvDim() +
           c.indexer_heads * c.indexer_head_dim + c.indexer_head_dim +
           e->mask_words_);
  const std::size_t expert_floats = slots * (2 * c.expert_ff + hidden);
  // Linear/full attention and routed experts run sequentially on stream_.
  // Their intermediates die before the next stage, including batched rows,
  // MTP catch-up and the deferred MoE epilogue consumed by Combine. Keep
  // stable addresses for graph replay without reserving all three stages.
  float* const stage =
      f32(std::max({linear_floats, attention_floats, expert_floats,
                    T * (linear_projection + hc_dim)}));
  if (stage == nullptr) {
    return nullptr;
  }
  // Mixer gates die before attention/experts start. PLE also uses this
  // buffer as its key, so keep it beyond PLE's gated output at stage.
  s.hc_gate = stage + T * linear_projection;
  float* cursor = stage;
  const auto take = [&](std::size_t count) {
    float* result = cursor;
    cursor += count;
    return result;
  };
  // Stacked and separate SSM projections are mutually exclusive. MTP's
  // projected embedding is consumed before attention and reuses this space.
  s.qkvz = take(T * linear_projection);
  s.qkv = s.qkvz;
  s.z = s.qkvz != nullptr ? s.qkvz + T * c.SsmConvChannels() : nullptr;
  s.alpha_beta = take(T * 2 * c.ssm_num_v_heads);
  s.conv_scratch = take((T + c.ssm_conv_kernel) * c.SsmConvChannels());
  s.qn = take(T * c.SsmKeyDim());
  s.kn = take(T * c.SsmKeyDim());
  s.gdn_raw = take(T * c.SsmValueDim());
  s.gdn_out = take(T * c.SsmValueDim());
  cursor = stage;
  s.qg = take(T * (2 * c.AttentionQDim() + 2 * c.AttentionKvDim()));
  s.q = take(T * c.AttentionQDim());
  s.attn_gate = take(T * c.AttentionQDim());
  s.k = take(T * c.AttentionKvDim());
  s.v = take(T * c.AttentionKvDim());
  s.iq = take(T * c.indexer_heads * c.indexer_head_dim);
  s.ik = take(T * c.indexer_head_dim);
  s.mask = reinterpret_cast<std::uint32_t*>(take(T * e->mask_words_));
  s.ctx = take(T * c.AttentionQDim());
  // Keep score/selection traffic near the device cache size. Captured
  // verification still needs all its rows at the maximum context.
  const std::size_t score_stride = std::size_t{e->mask_words_} * 32;
  e->select_score_floats_ =
      std::max(kVecBatch * score_stride,
               std::min(std::size_t{5 * 1024 * 1024}, 512 * score_stride));
  s.scores = f32(e->select_score_floats_);
  s.attn_partials = f32(static_cast<std::size_t>(kVecBatch) * c.num_heads *
                        kAttnSplits * (c.head_dim + 2));
  s.attn_lists = Alloc<std::uint32_t>(
      a, std::size_t{kVecBatch} * (c.indexer_top_k / c.compress_ratio),
      error_msg);
  s.attn_counts = Alloc<std::uint32_t>(a, kVecBatch, error_msg);
  if (c.ple_layer >= 0) {
    // PLE finishes before this layer's mixer/SSM. Its gate consumes key
    // and query before normalization/convolution reuse those two buffers.
    // The gated input stays separate until PleInject consumes both outputs.
    s.ple_key = s.hc_gate;
    s.ple_value = s.block_out;
    s.ple_query = s.xn;
    s.ple_gated = s.qkvz;
    s.ple_norm = s.hc_gate;
    s.ple_conv = s.xn;
    s.ple_history_scratch =
        f32(static_cast<std::size_t>(c.PleConvHistory()) * hc_dim);
    // The quantizer reads each n-gram row once. On this UMA target it can
    // consume the coherent reader buffer directly, without another device
    // allocation or upload. Its address stays fixed for graph replay; the
    // next-chunk prefetch uses separate storage until this forward finishes.
    void* pinned = nullptr;
    if (!Check(e->host_allocations_.Allocate(
                   &pinned, chunk * c.PleEmbeddingDim() * sizeof(float),
                   hipHostMallocMapped | hipHostMallocCoherent),
               "pinned n-gram buffer", error_msg)) {
      return nullptr;
    }
    e->host_emb_ = static_cast<float*>(pinned);
    if (!Check(hipHostGetDevicePointer(reinterpret_cast<void**>(&s.ple_emb),
                                       pinned, 0),
               "mapped n-gram buffer", error_msg)) {
      return nullptr;
    }
    e->host_rows_.resize(chunk * c.ple_heads);
    if (ngram)
      ngram->ReserveGather(chunk * c.ple_heads);
  }
  s.router = f32(T * (c.num_experts + 1));
  s.ids = Alloc<std::int32_t>(a, slots, error_msg);
  s.expert_counts = Alloc<std::uint32_t>(a, c.num_experts, error_msg);
  {
    const std::size_t compact = RoutedCompactRows(slots, c.num_experts);
    s.routed_bounds = Alloc<std::int32_t>(a, c.num_experts + 1, error_msg);
    s.routed_cursors = Alloc<std::int32_t>(a, c.num_experts, error_msg);
    s.rows_token = Alloc<std::int32_t>(a, compact, error_msg);
    s.rows_slot = Alloc<std::int32_t>(a, compact, error_msg);
    s.routed_tiles = Alloc<std::int32_t>(
        a, 3 * RoutedTileCapacity(slots, c.num_experts), error_msg);
  }
  s.weights = f32(slots);
  cursor = stage;
  s.gate_e = take(slots * c.expert_ff);
  s.up_e = take(slots * c.expert_ff);
  s.down_e = take(slots * hidden);
  s.shexp_gate = f32(T * c.shared_expert_ff);
  s.shexp_up = f32(T * c.shared_expert_ff);
  s.shexp_out = f32(T * hidden);
  s.shexp_half = Alloc<__half>(a, T * c.shared_expert_ff, error_msg);
  s.logits =
      f32(static_cast<std::size_t>(e->options_.max_logit_rows) * c.vocab_size);
  if (chunk > T) {
    e->pair_res_ = f32(T * hc_dim);
    e->pair_block_out_ = f32(T * hidden);
    e->pair_inject_ = f32(T * c.hc_count * HcInjectParts(hidden));
    e->pair_control_ = Alloc<Session::Control>(a, 1, error_msg);
  }
  {
    void* control = nullptr;
    void* tokens = nullptr;
    void* logits = nullptr;
    if (!Check(e->host_allocations_.Allocate(&control,
                                             2 * sizeof(Session::Control)),
               "pinned control buffer", error_msg) ||
        !Check(e->host_allocations_.Allocate(&tokens,
                                             chunk * sizeof(std::int32_t)),
               "pinned token buffer", error_msg) ||
        !Check(
            e->host_allocations_.Allocate(
                &logits, static_cast<std::size_t>(e->options_.max_logit_rows) *
                             c.vocab_size * sizeof(float)),
            "pinned logits buffer", error_msg)) {
      return nullptr;
    }
    void* counts = nullptr;
    if (!Check(e->host_allocations_.Allocate(
                   &counts, c.num_experts * sizeof(std::uint32_t)),
               "pinned expert counts", error_msg)) {
      return nullptr;
    }
    e->counts_host_ = static_cast<std::uint32_t*>(counts);
    void* tiles = nullptr;
    if (!Check(e->host_allocations_.Allocate(
                   &tiles, 3 * RoutedTileCapacity(slots, c.num_experts) *
                               sizeof(std::int32_t)),
               "pinned routed tile map", error_msg)) {
      return nullptr;
    }
    e->tiles_host_ = static_cast<std::int32_t*>(tiles);
    e->control_host_ = static_cast<Session::Control*>(control);
    e->tokens_host_ = static_cast<std::int32_t*>(tokens);
    e->logits_host_ = static_cast<float*>(logits);
  }
  // The wide mixer route (F16 norm for the epilogue, tiled Q8 norm for the
  // W8A8 down projection) needs the four-stream geometry, 32-wide blocks and
  // a Q8_0 down projection.
  e->wide_mixer_ = c.hc_count == 4 && c.hidden_size % 32 == 0 &&
                   !model.layers().empty() &&
                   model.layers()[0].hc_ffn.down.type == GgmlType::kQ8_0;
  // External drafters also use the target's multirow verification selector.
  // Its scratch must not depend on loading the native MTP predictor weights.
  if (model.has_mtp() || e->options_.max_speculative > 1) {
    // The trunk's kept rows are session-owned. Its transient residual and
    // mixer buffers are free while MTP constructs its input. The split
    // projections consume h/embd before the first mixer rewrites xn/mixed.
    s.mtp_h = s.xn;
    s.mtp_embd = s.mixed;
    s.mtp_eproj = s.qkvz;
    s.mtp_res = s.res;
    s.mtp_argmax = Alloc<ArgmaxCandidate>(a, kArgmaxParts, error_msg);
    // The draft token and its confidence (float bits), one host transfer.
    s.mtp_token = Alloc<std::int32_t>(a, 2, error_msg);
    const auto candidate_ids = std::max<std::size_t>(
        MtpCandidateWorkspaceSize(c.vocab_size),
        e->options_.max_speculative * kArgmaxParts *
            sizeof(PenaltyArgmaxCandidate) / sizeof(std::uint32_t));
    s.mtp_ids = Alloc<std::uint32_t>(a, candidate_ids, error_msg);
    s.mtp_scratch_ids = Alloc<std::uint32_t>(a, candidate_ids, error_msg);
    // Final selection consumes intermediate IDs before writing its scores.
    // Pack those scores behind the 64 returned IDs for one host transfer.
    s.mtp_scores = reinterpret_cast<float*>(s.mtp_ids + kMtpCandidates);
    if (!Check(e->host_allocations_.Allocate(&e->mtp_token_host_,
                                             2 * sizeof(std::int32_t)),
               "pinned draft token", error_msg) ||
        !Check(e->host_allocations_.Allocate(&e->mtp_candidates_host_,
                                             sizeof(MtpCandidateLogits)),
               "pinned draft candidates", error_msg)) {
      return nullptr;
    }
    std::construct_at(e->mtp_candidates_host_);
    e->mtp_candidates_host_->size =
        std::min<std::size_t>(c.vocab_size, kMtpCandidates);
    const auto rows = std::min<std::size_t>(7, e->options_.max_speculative - 1);
    if (rows != 0) {
      e->verification_ids_ = Alloc<std::uint32_t>(
          a, rows * MtpCandidateWorkspaceSize(c.vocab_size), error_msg);
      e->verification_scratch_ids_ = Alloc<std::uint32_t>(
          a, rows * MtpCandidateWorkspaceSize(c.vocab_size), error_msg);
      const auto candidates = rows * (kMtpCandidates + kCompactPenaltyLimit);
      e->verification_candidates_ =
          Alloc<sampling::LogitCandidate>(a, candidates, error_msg);
      if (!Check(e->host_allocations_.Allocate(
                     &e->verification_candidates_host_,
                     candidates * sizeof(sampling::LogitCandidate)),
                 "pinned verification candidates", error_msg) ||
          !Check(hip::AllocateDevice(&e->verification_penalties_,
                                     rows * kCompactPenaltyLimit *
                                         sizeof(sampling::TokenPenalty)),
                 "verification penalties", error_msg))
        return nullptr;
      e->verification_penalty_capacity_ = rows * kCompactPenaltyLimit;
      e->verification_penalty_host_.reserve(e->verification_penalty_capacity_);
    }
  }
  for (void* p : a) {
    if (p == nullptr) {
      return nullptr;
    }
  }
  return e;
}

std::unique_ptr<Session> Executor::CreateSession(core::SessionMode mode,
                                                 std::uint32_t max_context,
                                                 std::string* error_msg) const {
  std::unique_ptr<Session> s(new Session());
  s->owner_ = this;
  s->mtp_enabled_ = mode == core::SessionMode::kSpeculative;
  if (s->mtp_enabled_ && !has_mtp()) {
    AssignError(error_msg, "MTP session requires a loaded predictor");
    return nullptr;
  }
  const Config& c = config();
  if (max_context == 0 || max_context > context_capacity_) {
    AssignError(error_msg, "session context exceeds the model context");
    return nullptr;
  }
  s->max_context_ = max_context;
  // Before sparse attention starts, pooling can lag by indexer_top_k
  // rows. Afterwards only an incomplete block precedes the current batch.
  // Completed block keys remain in block_k; their raw rows are dead.
  s->index_capacity_ = IndexerCapacity(c, options_.max_batch, max_context);
  s->linear_.resize(c.num_layers);
  s->attention_.resize(c.num_layers);
  auto& a = s->allocations_;
  // The trunk's state holds this rank's heads; the draft block's all of them.
  const MixerHeads& heads = model_->trunk_heads();
  const std::size_t kv_row = heads.AttentionKvDim();
  const std::size_t conv_elems =
      static_cast<std::size_t>(c.ssm_conv_kernel - 1) * heads.SsmConvChannels();
  const std::size_t state_elems =
      static_cast<std::size_t>(heads.ssm_v) * heads.ssm_dim * heads.ssm_dim;
  for (std::uint32_t il = 0; il < c.num_layers; ++il) {
    if (c.IsLinearLayer(il)) {
      auto& l = s->linear_[il];
      l.conv_state =
          Alloc<float>(a, conv_elems, error_msg, &s->allocated_bytes_);
      l.state = Alloc<float>(a, state_elems, error_msg, &s->allocated_bytes_);
    } else {
      auto& at = s->attention_[il];
      at.k_cache =
          Alloc<__half>(a, static_cast<std::size_t>(max_context) * kv_row,
                        error_msg, &s->allocated_bytes_);
      at.v_cache =
          Alloc<__half>(a, static_cast<std::size_t>(max_context) * kv_row,
                        error_msg, &s->allocated_bytes_);
      at.index_k = Alloc<float>(
          a, static_cast<std::size_t>(s->index_capacity_) * c.indexer_head_dim,
          error_msg, &s->allocated_bytes_);
      at.block_k = Alloc<__half>(
          a,
          static_cast<std::size_t>(max_context / c.compress_ratio + 1) *
              c.indexer_head_dim,
          error_msg, &s->allocated_bytes_);
    }
  }
  if (c.ple_layer >= 0) {
    const std::size_t hist =
        static_cast<std::size_t>(c.PleConvHistory()) * c.HcDim();
    s->ple_history_ = Alloc<float>(a, hist, error_msg, &s->allocated_bytes_);
  }
  s->control_ = Alloc<Session::Control>(a, 1, error_msg, &s->allocated_bytes_);
  if (s->mtp_enabled_) {
    const std::size_t mtp_kv_row = model_->mtp().heads.AttentionKvDim();
    s->mtp_.target_hidden = Alloc<float>(
        a, static_cast<std::size_t>(options_.max_speculative) * c.HcDim(),
        error_msg, &s->allocated_bytes_);
    s->mtp_.k_cache =
        Alloc<__half>(a, static_cast<std::size_t>(max_context) * mtp_kv_row,
                      error_msg, &s->allocated_bytes_);
    s->mtp_.v_cache =
        Alloc<__half>(a, static_cast<std::size_t>(max_context) * mtp_kv_row,
                      error_msg, &s->allocated_bytes_);
    s->mtp_.index_k =
        Alloc<float>(a, std::size_t{s->index_capacity_} * c.indexer_head_dim,
                     error_msg, &s->allocated_bytes_);
    s->mtp_.block_k = Alloc<__half>(
        a, std::size_t{max_context / c.compress_ratio + 1} * c.indexer_head_dim,
        error_msg, &s->allocated_bytes_);
    s->mtp_.h = Alloc<float>(a, c.HcDim(), error_msg, &s->allocated_bytes_);
    if (!model_->draft_output().empty()) {
      s->mtp_.draft_rows = Alloc<std::uint8_t>(
          a,
          std::size_t{kMtpDraftExtraRows} * model_->output_row_bytes() + 4096,
          error_msg, &s->allocated_bytes_);
      s->mtp_.draft_ids = Alloc<std::int32_t>(a, kMtpDraftExtraRows, error_msg,
                                              &s->allocated_bytes_);
    }
  }
  for (void* p : a) {
    if (p == nullptr) {
      return nullptr;
    }
  }
  // The zero fills above run on the null stream; nothing may read the new
  // buffers until they have landed.
  if (!Check(hipDeviceSynchronize(), "session init", error_msg)) {
    return nullptr;
  }
  // The table starts with the special tokens; every other slot is empty.
  if (s->mtp_.draft_rows != nullptr &&
      (!ClearDraftRows(*s, 0, error_msg) ||
       !AppendDraftRows(*s, 0, model_->draft_specials(), error_msg) ||
       !Check(hipStreamSynchronize(stream_), "draft table init", error_msg))) {
    return nullptr;
  }
  return s;
}

bool Executor::AppendDraftRows(Session& session, std::uint32_t first,
                               std::span<const std::int32_t> ids,
                               std::string* error_msg) const {
  if (ids.empty())
    return true;
  if (session.owner_ != this || session.mtp_.draft_rows == nullptr ||
      first > kMtpDraftExtraRows || ids.size() > kMtpDraftExtraRows - first) {
    AssignError(error_msg, "invalid draft table append");
    return false;
  }
  const auto& output = model_->output();
  const std::size_t row_bytes = model_->output_row_bytes();
  for (std::size_t i = 0; i < ids.size(); ++i) {
    if (ids[i] < 0 || static_cast<std::uint32_t>(ids[i]) >= output.rows) {
      AssignError(error_msg, "draft table token out of range");
      return false;
    }
    // The ID goes by value, so no host buffer has to outlive the call.
    if (!Check(hipMemcpyAsync(session.mtp_.draft_rows + (first + i) * row_bytes,
                              static_cast<const std::uint8_t*>(output.data) +
                                  static_cast<std::size_t>(ids[i]) * row_bytes,
                              row_bytes, hipMemcpyDeviceToDevice, stream_),
               "draft table row", error_msg) ||
        !Check(hipMemsetD32Async(reinterpret_cast<hipDeviceptr_t>(
                                     session.mtp_.draft_ids + first + i),
                                 ids[i], 1, stream_),
               "draft table id", error_msg))
      return false;
  }
  return true;
}

bool Executor::ClearDraftRows(Session& session, std::uint32_t first,
                              std::string* error_msg) const {
  if (session.owner_ != this || session.mtp_.draft_ids == nullptr ||
      first > kMtpDraftExtraRows) {
    AssignError(error_msg, "invalid draft table clear");
    return false;
  }
  // Stale rows stay; an ID of -1 masks the slot.
  return first == kMtpDraftExtraRows ||
         Check(
             hipMemsetAsync(session.mtp_.draft_ids + first, 0xFF,
                            (kMtpDraftExtraRows - first) * sizeof(std::int32_t),
                            stream_),
             "draft table clear", error_msg);
}

DeviceTensor Executor::DraftTable(const Session& session) const noexcept {
  DeviceTensor table = model_->output();
  table.data = session.mtp_.draft_rows;
  table.rows = kMtpDraftExtraRows;
  return table;
}

bool Executor::DraftLogits(const Session& session, const float* x,
                           float* logits, std::string* error_msg) const {
  const auto& prefix = model_->draft_output();
  if (!Dense(prefix, x, logits, 1, error_msg) ||
      !Dense(DraftTable(session), x, logits + prefix.rows, 1, error_msg))
    return false;
  MaskDraftLogits(logits + prefix.rows, session.mtp_.draft_ids,
                  kMtpDraftExtraRows, stream_);
  return true;
}

bool Executor::EnsureRollback(Session& session, std::uint32_t depth,
                              std::string* error_msg) const {
  if (depth <= session.rollback_depth_)
    return true;
  if (depth >= options_.max_speculative ||
      depth > std::size(session.ple_snapshots_.rows) ||
      session.spec_tokens_ != 0) {
    AssignError(error_msg, "invalid rollback allocation depth");
    return false;
  }
  const auto& c = config();
  const MixerHeads& heads = model_->trunk_heads();
  const std::size_t conv =
      std::size_t{c.ssm_conv_kernel - 1} * heads.SsmConvChannels();
  const std::size_t linear =
      c.num_layers - c.num_layers / c.full_attention_interval;
  const std::size_t ple =
      c.ple_layer >= 0 ? std::size_t{c.PleConvHistory()} * c.HcDim() : 0;
  session.rollback_allocations_.reserve(depth);
  session.ngram_snapshots_.resize(depth);
  for (auto row = session.rollback_depth_; row < depth; ++row) {
    const auto state =
        GdnRollbackRowFloats(row, heads.ssm_k, heads.ssm_v, heads.ssm_dim);
    const auto bytes = (linear * (conv + state) + ple) * sizeof(float);
    float* allocation = nullptr;
    if (!Check(hip::AllocateDevice(&allocation, bytes), "rollback allocation",
               error_msg))
      return false;
    session.rollback_allocations_.push_back(allocation);
    session.rollback_bytes_ += bytes;
    auto* next = allocation;
    for (std::uint32_t il = 0; il < c.num_layers; ++il) {
      if (!c.IsLinearLayer(il))
        continue;
      session.linear_[il].conv_snapshots.rows[row] = next;
      next += conv;
      session.linear_[il].state_snapshots.rows[row] = next;
      next += state;
    }
    if (ple != 0) {
      session.ple_snapshots_.rows[row] = next;
    }
    session.rollback_depth_ = row + 1;
  }
  return true;
}

std::size_t Executor::SessionBytes(
    core::SessionMode mode, std::uint32_t max_context,
    std::uint32_t rollback_depth) const noexcept {
  const auto& c = config();
  const MixerHeads& heads = model_->trunk_heads();
  const std::size_t attention = c.num_layers / c.full_attention_interval;
  const std::size_t linear = c.num_layers - attention;
  const std::size_t conv =
      std::size_t{c.ssm_conv_kernel - 1} * heads.SsmConvChannels();
  const std::size_t state =
      std::size_t{heads.ssm_v} * heads.ssm_dim * heads.ssm_dim;
  const std::size_t ple =
      c.ple_layer >= 0 ? std::size_t{c.PleConvHistory()} * c.HcDim() : 0;
  const std::size_t kv =
      2 * std::size_t{max_context} * heads.AttentionKvDim() * sizeof(__half);
  const std::size_t mtp_kv = 2 * std::size_t{max_context} *
                             model_->mtp().heads.AttentionKvDim() *
                             sizeof(__half);
  const std::size_t index =
      std::size_t{IndexerCapacity(c, options_.max_batch, max_context)} *
          c.indexer_head_dim * sizeof(float) +
      std::size_t{max_context / c.compress_ratio + 1} * c.indexer_head_dim *
          sizeof(__half);
  const auto rollback_state =
      rollback_depth == 0
          ? 0
          : state + (rollback_depth - 1) * GdnRollbackRowFloats(1, heads.ssm_k,
                                                                heads.ssm_v,
                                                                heads.ssm_dim);
  return ((linear * conv + ple) * (rollback_depth + 1) +
          linear * (state + rollback_state)) *
             sizeof(float) +
         attention * (kv + index) + sizeof(Session::Control) +
         (mode == core::SessionMode::kSpeculative
              ? mtp_kv + index +
                    std::size_t{options_.max_speculative + 1} * c.HcDim() *
                        sizeof(float) +
                    (model_->draft_output().empty()
                         ? 0
                         : std::size_t{kMtpDraftExtraRows} *
                                   (model_->output_row_bytes() +
                                    sizeof(std::int32_t)) +
                               4096)
              : 0);
}

std::size_t Executor::DeferredScratchBytes() const {
  const auto& c = config();
  const auto& heads = model_->trunk_heads();
  std::size_t bytes = batch_logits_ == nullptr
                          ? std::size_t{8} *
                                std::min(8U, options_.max_logit_rows) *
                                c.vocab_size * sizeof(float)
                          : 0;
  const auto linear = c.num_layers - c.num_layers / c.full_attention_interval;
  const auto conv =
      std::size_t{c.ssm_conv_kernel - 1} * heads.SsmConvChannels();
  const auto state = std::size_t{heads.ssm_v} * heads.ssm_dim * heads.ssm_dim;
  const auto ple =
      c.ple_layer >= 0 ? std::size_t{c.PleConvHistory()} * c.HcDim() : 0;
  const auto mutable_bytes = (linear * (conv + state) + ple) * sizeof(float);
  if (!checkpoint_storage_) {
    bytes +=
        mutable_bytes + (has_mtp() ? std::size_t{options_.max_speculative} *
                                         c.HcDim() * sizeof(float)
                                   : 0);
  }
  // Committed spare blocks for captures, whether or not they exist yet.
  return bytes + SnapshotAllocator::SpareBytes(mutable_bytes);
}

/// Column-tile width for the routed expert GEMMs: the tile at or above twice
/// the mean bucket, so most experts fit one tile with little padding.
int RoutedTileCols(std::uint32_t n_tokens, std::uint32_t n_used,
                   std::uint32_t n_experts) {
  const std::uint32_t mean =
      std::max<std::uint32_t>(1, n_tokens * n_used / std::max(n_experts, 1u));
  for (int cols = 16; cols < 80; cols += 16) {
    if (static_cast<std::uint32_t>(cols) >= 2 * mean) {
      return cols;
    }
  }
  return 80;
}

const void* Executor::ReadyQ8(const float* x, std::uint32_t n_tokens,
                              std::uint32_t k) const {
  for (const ReadyRows* r : {&xn_q8_ready_, &mixed_q8_ready_}) {
    if (r->src != nullptr && r->src == x && r->n == n_tokens && r->k == k) {
      return r->data;
    }
  }
  return nullptr;
}

void Executor::DropReadyQ8() const {
  xn_q8_ready_ = {};
  mixed_q8_ready_ = {};
  pending_combine_ = {};  // a cancelled pass may have left one
}

bool Executor::Quantize(const float* x, std::uint32_t n_tokens, std::uint32_t k,
                        Q8Input* q, std::string* error_msg) const {
  q->x = x;
  q->data = nullptr;
  q->n = n_tokens;
  q->k = k;
  if (MatrixRows(n_tokens)) {
    return true;  // the tiled path quantizes per call
  }
  if (const void* ready = ReadyQ8(x, n_tokens, k)) {
    q->data = ready;
    return true;
  }
  // Two slots alternate, so an input stays valid across one other
  // quantization; captured graphs replay the same alternation.
  void* slot = s_.x_q8[q8_slot_];
  q8_slot_ ^= 1u;
  if (qfn_mmq_quantize_q8_1(x, slot, static_cast<int>(n_tokens),
                            static_cast<int>(k), stream_) != 0) {
    AssignError(error_msg, "activation quantization failed");
    return false;
  }
  q->data = slot;
  return true;
}

bool Executor::Dense(const DeviceTensor& w, const Q8Input& q, float* out,
                     std::string* error_msg) const {
  if (w.type == GgmlType::kQ8_0 && q.data != nullptr) {
    if (w.cols != q.k) {
      AssignError(error_msg, "quantized input width mismatch");
      return false;
    }
    if (qfn_mmq_q8_0_dense_vec_preq(
            w.data, nullptr, q.data, out, static_cast<int>(w.rows),
            static_cast<int>(q.n), static_cast<int>(w.cols), stream_) != 0) {
      AssignError(error_msg, "Q8_0 GEMV failed");
      return false;
    }
    return true;
  }
  return Dense(w, q.x, out, q.n, error_msg);
}

bool Executor::GatedDense(const DeviceTensor& up, const DeviceTensor& gate,
                          const float* x, float* out, std::uint32_t n_tokens,
                          const DeviceTensor* down,
                          std::string* error_msg) const {
  // Decode and verification use the same fused projections and activation.
  // A different SwiGLU rounding can change later activation quantization.
  if (!MatrixRows(n_tokens) && up.type == GgmlType::kQ8_0 &&
      gate.type == GgmlType::kQ8_0 && up.rows == gate.rows &&
      up.cols == gate.cols) {
    Q8Input xq;
    if (!Quantize(x, n_tokens, up.cols, &xq, error_msg)) {
      return false;
    }
    if (qfn_mmq_q8_0_dense_vec_preq(up.data, gate.data, xq.data, out,
                                    static_cast<int>(up.rows),
                                    static_cast<int>(n_tokens),
                                    static_cast<int>(up.cols), stream_) != 0) {
      AssignError(error_msg, "gated Q8_0 GEMV failed");
      return false;
    }
    return true;
  }
  // Swiglu is in place over its first operand.
  if (!Dense(gate, x, out, n_tokens, error_msg) ||
      !Dense(up, x, s_.shexp_gate, n_tokens, error_msg)) {
    return false;
  }
  // A wide batch writes the down projection's staged input directly (the
  // F32 rows are read by nothing else): F16 rows for the F16 route, else
  // the tiled Q8 layout; the cache lets Dense skip its activation pass.
  if (down != nullptr && down->cols == up.rows && MatrixRows(n_tokens) &&
      n_tokens <= options_.max_batch) {
    if (DenseF16Route(*down, n_tokens)) {
      // A private F16 buffer: s_.x_half keeps the narrowed token rows the
      // router left there, which the routed experts read next.
      SwigluHalf(out, s_.shexp_gate, s_.shexp_half,
                 static_cast<std::size_t>(n_tokens) * up.rows, stream_);
      shexp_half_ready_ = true;
      return true;
    }
    if (down->type == GgmlType::kQ8_0 &&
        SwigluQ8Tiled(out, s_.shexp_gate, s_.x_q8t, n_tokens, up.rows,
                      stream_)) {
      q8t_src_ = out;
      q8t_rows_ = n_tokens;
      q8t_cols_ = up.rows;
      return true;
    }
  }
  Swiglu(out, s_.shexp_gate, static_cast<std::size_t>(n_tokens) * up.rows,
         stream_);
  return true;
}

void Executor::PrepareHalfInput(const float* x, std::uint32_t rows,
                                std::uint32_t cols) const {
  if (half_src_ == x && half_rows_ == rows && half_cols_ == cols &&
      !half_bf16_) {
    return;
  }
  NarrowActivations(x, s_.x_half, false, static_cast<std::size_t>(rows) * cols,
                    stream_);
  half_src_ = x;
  half_rows_ = rows;
  half_cols_ = cols;
  half_bf16_ = false;
}

bool Executor::DenseF16Route(const DeviceTensor& w,
                             std::uint32_t n_tokens) const {
  return w.type == GgmlType::kQ8_0 && MatrixRows(n_tokens) &&
         w.rows >= kDenseF16MinRows && w.cols <= kDenseF16MaxCols &&
         w.cols <= model_->max_half_cols();
}

bool Executor::Dense(const DeviceTensor& w, const float* x, float* out,
                     std::uint32_t n_tokens, std::string* error_msg) const {
  if (w.type == GgmlType::kQ8_0) {
    if (!MatrixRows(n_tokens)) {
      Q8Input q;
      return Quantize(x, n_tokens, w.cols, &q, error_msg) &&
             Dense(w, q, out, error_msg);
    }
    // Wide batches: the F16 route for the shapes it wins (F16 rows in
    // s_.x_half, often left there by a producer), else activations
    // quantized per 32-wide block into the tiled layout and the int8 WMMA
    // GEMM. Both staging buffers hold max_batch rows; a wider call (the
    // draft block folds its streams into rows) runs in pieces.
    const bool f16 = DenseF16Route(w, n_tokens);
    const std::uint32_t piece = static_cast<std::uint32_t>(options_.max_batch);
    for (std::uint32_t r0 = 0; r0 < n_tokens; r0 += piece) {
      const std::uint32_t rows = std::min(piece, n_tokens - r0);
      // The staging buffer may already hold this input (a producer wrote
      // it, or the previous projection read the same rows).
      const float* src = x + static_cast<std::size_t>(r0) * w.cols;
      if (f16) {
        PrepareHalfInput(src, rows, w.cols);
        if (!DenseF16Gemm(w.data, static_cast<const __half*>(s_.x_half),
                          out + static_cast<std::size_t>(r0) * w.rows, rows,
                          w.rows, w.cols, stream_)) {
          AssignError(error_msg, "dense F16 GEMM failed");
          return false;
        }
        continue;
      }
      if (!(q8t_src_ == src && q8t_rows_ == rows && q8t_cols_ == w.cols)) {
        QuantizeQ8Tiled(src, s_.x_q8t, rows, w.cols, stream_);
        q8t_src_ = src;
        q8t_rows_ = rows;
        q8t_cols_ = w.cols;
      }
      if (!W8A8Gemm(w.data, s_.x_q8t,
                    out + static_cast<std::size_t>(r0) * w.rows, rows, w.rows,
                    w.cols, stream_)) {
        AssignError(error_msg, "W8A8 GEMM failed");
        return false;
      }
    }
    return true;
  }
  if (!MatrixRows(n_tokens)) {
    SmallGemm(w.data, SmallType(w.type), x, out, n_tokens, w.rows, w.cols,
              stream_);
    return true;
  }
  // Wide batches of the unquantized projections (router, alpha/beta,
  // indexer): out[t][m] = sum_k w[m][k] x[t][k].
  const int m = static_cast<int>(w.rows);
  const int k = static_cast<int>(w.cols);
  const int n = static_cast<int>(n_tokens);
  if (w.type == GgmlType::kF32) {
    const float alpha = 1.0F;
    const float beta = 0.0F;
    if (hipblasSgemm(blas_, HIPBLAS_OP_T, HIPBLAS_OP_N, m, n, k, &alpha,
                     static_cast<const float*>(w.data), k, x, k, &beta, out,
                     m) != HIPBLAS_STATUS_SUCCESS) {
      AssignError(error_msg, "hipBLAS GEMM failed");
      return false;
    }
    return true;
  }
  const bool bf16 = w.type == GgmlType::kBF16;
  const hipDataType type = bf16 ? HIP_R_16BF : HIP_R_16F;
  if (!(half_src_ == x && half_rows_ == n_tokens && half_cols_ == w.cols &&
        half_bf16_ == bf16)) {
    NarrowActivations(x, s_.x_half, bf16, static_cast<std::size_t>(n) * k,
                      stream_);
    half_src_ = x;
    half_rows_ = n_tokens;
    half_cols_ = w.cols;
    half_bf16_ = bf16;
  }
  return blaslt_->Gemm(w.data, s_.x_half, out, type, m, n, k, error_msg);
}

void Executor::RoutedHints(const DeviceTensor& w,
                           std::uint32_t n_tokens) const {
  // The column grid is bounded by the largest expert bucket and the tile
  // width fitted to the whole distribution (see RouteHints); the fallback
  // bound is the token count with a tile near twice the mean bucket.
  if (routed_max_rows_ > 0) {
    qfn_mmq_set_routed_max_expert_rows(static_cast<int>(routed_max_rows_));
    qfn_mmq_set_routed_tile_cols(routed_tile_cols_);
    return;
  }
  qfn_mmq_set_routed_max_expert_rows(static_cast<int>(n_tokens));
  qfn_mmq_set_routed_tile_cols(
      RoutedTileCols(n_tokens, config().num_experts_used, w.experts));
}

bool Executor::RouteHints(std::uint32_t n_tokens,
                          std::string* error_msg) const {
  // Every column tile past an expert's bucket still costs a dispatch and a
  // full shared-memory reservation, so the grid is cut to the real largest
  // bucket. Counts are downloaded before the shared expert; wait only for
  // that download while the shared expert continues (on the side stream in
  // overlapped passes, joined by JoinSide).
  const Config& c = config();
  routed_max_rows_ = 0;
  routed_n_tiles_ = 0;
  routed_wide_tiles_ = 0;
  if (!ExpertMatrixRows(n_tokens)) {
    return true;
  }
  if (!Check(hipEventSynchronize(counts_ready_), "expert counts", error_msg)) {
    return false;
  }
  // The F16 expert GEMM launches one block per (expert, row tile of its
  // 16-padded bucket): the map is built here and uploaded ahead of the
  // launches on the same stream. Tile heights are multiples of 16, so a
  // bucket's tile count follows from its unpadded rows.
  std::uint32_t max_rows = 0;
  std::uint32_t n_tiles = 0;
  routed_tile_rows_ = RoutedTileRows(
      static_cast<std::size_t>(n_tokens) * c.num_experts_used, c.num_experts);
  for (std::uint32_t e = 0; e < c.num_experts; ++e) {
    max_rows = std::max(max_rows, counts_host_[e]);
  }
  routed_max_rows_ = std::max<std::uint32_t>(1, max_rows);
  const auto append = [&](std::uint32_t tile_rows) {
    for (std::uint32_t e = 0; e < c.num_experts; ++e) {
      for (std::uint32_t j = 0;
           j < (counts_host_[e] + tile_rows - 1) / tile_rows; ++j) {
        tiles_host_[n_tiles++] = static_cast<std::int32_t>(e | (j << 16));
      }
    }
  };
  if (WidePrefill(n_tokens)) {
    // Prefill batches: one map of 128-token tiles serves the paired gate/up
    // and the down projections.
    append(128);
    routed_wide_tiles_ = n_tiles;
  } else {
    append(routed_tile_rows_);
    routed_n_tiles_ = n_tiles;
  }
  routed_tile_cols_ = qfn_mmq_routed_tile_cols_for_counts(
      counts_host_, static_cast<int>(c.num_experts));
  return n_tiles == 0 || Check(hipMemcpyAsync(s_.routed_tiles, tiles_host_,
                                              n_tiles * sizeof(std::int32_t),
                                              hipMemcpyHostToDevice, stream_),
                               "routed tile map upload", error_msg);
}

bool Executor::Experts(const DeviceTensor& w, const float* x,
                       const std::int32_t* ids, float* out,
                       std::uint32_t n_rows, std::uint32_t n_used,
                       std::uint32_t n_tokens, std::string* error_msg) const {
  const int M = static_cast<int>(w.rows);
  const int K = static_cast<int>(w.cols);
  const int E = static_cast<int>(w.experts);
  const int T = static_cast<int>(n_rows);
  const int U = static_cast<int>(n_used);
  // The vector entries loop over column chunks, so the decode-time down
  // projection (top-k rows, one expert each) stays on them as well.
  // Verification keeps the same quantization and reduction as single-token
  // decoding even when top-k expansion produces more than 32 slot rows.
  const bool tiled =
      (prefill_phase || n_rows > 4 * kVecBatch) && MatrixRows(n_tokens);
  if (tiled) {
    RoutedHints(w, n_tokens);
  }
  int rc = -1;
  if (!tiled) {
    rc = qfn_mmq_moe_vec(static_cast<int>(w.type), w.data, x, ids, out, M, K, T,
                         E, U, stream_);
  } else {
    switch (w.type) {
      case GgmlType::kQ4_K:
        rc = qfn_mmq_q4_K_moe_raw(w.data, x, ids, out, M, K, T, E, U, stream_);
        break;
      case GgmlType::kQ5_K:
        rc = qfn_mmq_q5_K_moe_raw(w.data, x, ids, out, M, K, T, E, U, stream_);
        break;
      case GgmlType::kQ5_1:
        rc = qfn_mmq_q5_1_moe_raw(w.data, x, ids, out, M, K, T, E, U, stream_);
        break;
      case GgmlType::kQ8_0:
        rc = qfn_mmq_q8_0_moe_raw(w.data, x, ids, out, M, K, T, E, U, stream_);
        break;
      default:
        break;
    }
  }
  if (rc != 0) {
    AssignError(error_msg, "expert GEMM failed");
    return false;
  }
  return true;
}

bool Executor::GatedExperts(const DeviceTensor& a, const DeviceTensor& b,
                            const float* x, const std::int32_t* ids, float* out,
                            std::uint32_t n_tokens, std::uint32_t n_used,
                            std::string* error_msg) const {
  const bool same_shape = a.type == b.type && a.rows == b.rows &&
                          a.cols == b.cols && a.experts == b.experts;
  if (!MatrixRows(n_tokens) && n_used <= 32 && same_shape &&
      (a.type == GgmlType::kQ4_K || a.type == GgmlType::kQ5_K ||
       a.type == GgmlType::kQ8_0)) {
    // The shared expert quantized the same rows (or their producer did).
    const void* ready = ReadyQ8(x, n_tokens, a.cols);
    if ((ready != nullptr
             ? qfn_mmq_moe_gated_vec_preq(
                   static_cast<int>(a.type), a.data, b.data, ready, ids, out,
                   static_cast<int>(a.rows), static_cast<int>(a.cols),
                   static_cast<int>(n_tokens), static_cast<int>(a.experts),
                   static_cast<int>(n_used), stream_)
             : qfn_mmq_moe_gated_vec(
                   static_cast<int>(a.type), a.data, b.data, x, ids, out,
                   static_cast<int>(a.rows), static_cast<int>(a.cols),
                   static_cast<int>(n_tokens), static_cast<int>(a.experts),
                   static_cast<int>(n_used), stream_)) != 0) {
      AssignError(error_msg, "gated expert vector projection failed");
      return false;
    }
    return true;
  }
  if (!ExpertMatrixRows(n_tokens) && same_shape) {
    if (qfn_mmq_moe_vec(static_cast<int>(a.type), a.data, x, ids, out,
                        static_cast<int>(a.rows), static_cast<int>(a.cols),
                        static_cast<int>(n_tokens), static_cast<int>(a.experts),
                        static_cast<int>(n_used), stream_, b.data,
                        s_.up_e) != 0) {
      AssignError(error_msg, "expert vector pair GEMM failed");
      return false;
    }
  } else if (same_shape && a.type == GgmlType::kQ4_K) {
    // The wide Q4_K path shares its gather and tiled quantization as well.
    RoutedHints(a, n_tokens);
    if (qfn_mmq_q4_K_moe_pair_unique(
            a.data, b.data, x, ids, out, s_.up_e, static_cast<int>(a.rows),
            static_cast<int>(a.cols), static_cast<int>(n_tokens),
            static_cast<int>(a.experts), static_cast<int>(n_used),
            stream_) != 0) {
      AssignError(error_msg, "expert pair GEMM failed");
      return false;
    }
  } else if (!Experts(a, x, ids, out, n_tokens, n_used, n_tokens, error_msg) ||
             !Experts(b, x, ids, s_.up_e, n_tokens, n_used, n_tokens,
                      error_msg)) {
    return false;
  }
  Swiglu(out, s_.up_e, static_cast<std::size_t>(n_tokens) * n_used * a.rows,
         stream_);
  return true;
}

namespace {

/// A mixer's F32 inject weights, which its combine can apply (see Combine).
const float* InjectWeights(const DeviceMixer& m) {
  return !m.inject.empty() && m.inject.type == GgmlType::kF32 ? m.inject.f32()
                                                              : nullptr;
}

}  // namespace

bool Executor::FusedMixer(const DeviceMixer& m, std::uint32_t n_tokens) const {
  // Model geometry and Q8_0 projections only: a mixer in another format
  // keeps the separate kernels.
  const Config& c = config();
  return hc_fused_state_ != nullptr && !MatrixRows(n_tokens) &&
         n_tokens <= kVecBatch && c.hc_count == 4 && c.hidden_size == 2560 &&
         c.hc_low_rank == 320 && m.down.type == GgmlType::kQ8_0 &&
         m.down.rows == c.hc_low_rank && m.down.cols == c.HcDim() &&
         m.up.type == GgmlType::kQ8_0 && m.up.rows == c.HcDim() &&
         m.up.cols == c.hc_low_rank;
}

void Executor::Combine(float* res, const float* gamma, std::uint32_t n_tokens,
                       const float* inject_w, const DeviceMixer* next) const {
  const Config& c = config();
  inject_fused_ = nullptr;
  // Wide batches hand the next mixer an F16 norm for its epilogue and the
  // same norm quantized into the tiled Q8 layout for its W8A8 down
  // projection: half the bytes for the combine and the epilogue, and no
  // separate activation pass for the projection.
  xn_half_ = wide_mixer_ && MatrixRows(n_tokens) && gamma != nullptr;
  xn_q8_ready_ = {};  // s_.xn is rewritten (or left stale) below
  // The next mixer's inject pass reads only the F16 norm written here.
  const float* fused_inject = xn_half_ && n_tokens >= 96 ? inject_w : nullptr;
  const bool defer = defer_residual_;
  defer_residual_ = false;
  const bool deferred = res_deferred_;
  res_deferred_ = false;
  if (moe_pending_) {
    // The MoE epilogue was deferred to this combine (see Moe), and with it
    // the previous combine's residual update when that was deferred too.
    moe_pending_ = false;
    const auto* down = reinterpret_cast<const __half*>(s_.down_e);
    const float* fused_w = deferred ? fused_inject : nullptr;
    if (wide_mixer_ && MatrixRows(n_tokens) &&
        HcCombineMoeF16(
            res, down, s_.weights, s_.shexp_out, s_.router + c.num_experts,
            c.num_experts + 1, c.num_experts_used, s_.inject, inject_parts_,
            gamma, s_.xn_half, s_.xn_q8t, n_tokens, c.hidden_size, c.hc_count,
            c.rms_eps, stream_, deferred ? s_.block_out : nullptr,
            deferred ? s_.hc_defer_w : nullptr, s_.inject, fused_w)) {
      inject_fused_ = fused_w;
      return;
    }
    if (deferred) {
      HcApplyDeferred(res, s_.block_out, s_.hc_defer_w, n_tokens, c.hidden_size,
                      stream_);
    }
    MoeEpilogueVec4F16(down, s_.weights, s_.shexp_out,
                       s_.router + c.num_experts, c.num_experts + 1,
                       s_.block_out, n_tokens, c.num_experts_used,
                       c.hidden_size, stream_);
  }
  if (deferred) {
    // Only a fused MoE combine follows a deferring one; settle the update
    // before anything else reads the residual.
    HcApplyDeferred(res, s_.block_out, s_.hc_defer_w, n_tokens, c.hidden_size,
                    stream_);
  }
  if (xn_half_) {
    // The FFN combine that follows rereads this block output (42 MB at
    // 4,096 tokens) instead of this combine writing the residual and the
    // next reading it back (168 MB each).
    const bool defer_now = defer && c.hc_count == 4;
    res_deferred_ =
        HcCombineF16(res, s_.block_out, s_.inject, inject_parts_, gamma,
                     s_.xn_half, s_.xn_q8t, n_tokens, c.hidden_size, c.hc_count,
                     c.rms_eps, stream_, defer_now ? s_.hc_defer_w : nullptr,
                     s_.inject, defer_now ? fused_inject : nullptr);
    if (res_deferred_)
      inject_fused_ = fused_inject;
    return;
  }
  // A decode batch's next mixer quantizes xn for its down projection: the
  // combine writes those rows as well, or joins that mixer's single launch.
  if (next != nullptr && gamma != nullptr && FusedMixer(*next, n_tokens)) {
    pending_combine_ = {next,         res,        gamma,
                        s_.block_out, s_.inject,  inject_parts_,
                        s_.xn,        s_.xn_q8_1, n_tokens};
    xn_q8_ready_ = {s_.xn, s_.xn_q8_1, n_tokens, c.HcDim()};
    return;
  }
  if (!MatrixRows(n_tokens) && UnpaddedQ8(c.HcDim()) &&
      HcCombineQ8_1(res, s_.block_out, s_.inject, inject_parts_, gamma, s_.xn,
                    s_.xn_q8_1, n_tokens, c.hidden_size, c.hc_count, c.rms_eps,
                    stream_)) {
    xn_q8_ready_ = {s_.xn, s_.xn_q8_1, n_tokens, c.HcDim()};
    return;
  }
  HcCombine(res, s_.block_out, s_.inject, inject_parts_, gamma, s_.xn, n_tokens,
            c.hidden_size, c.hc_count, c.rms_eps, stream_);
}

bool Executor::HcMix(const DeviceMixer& m, const float* res, bool normed,
                     float* mixed, float* inject, std::uint32_t n_tokens,
                     std::string* error_msg, bool half_only,
                     bool no_f32) const {
  const Config& c = config();
  mixed_q8_ready_ = {};  // `mixed` is rewritten below
  if (pending_combine_.mixer != nullptr) {
    const PendingCombine p = pending_combine_;
    pending_combine_ = {};
    const bool fused_inject = inject != nullptr && !m.inject.empty() &&
                              m.inject.type == GgmlType::kF32;
    if (normed && p.mixer == &m && p.res == res && p.n == n_tokens &&
        !half_only && !no_f32) {
      // The combine, both projections, SiLU and the epilogue in one launch,
      // with the outputs and producer-written Q8_1 rows of the kernels below.
      const HcFusedMix mix{
          m.down.data,
          m.up.data,
          p.res,
          p.block_out,
          p.inject,
          p.inject_parts,
          p.gamma,
          p.xn,
          p.xn_q8,
          s_.lo,
          s_.lo_q8_1,
          static_cast<std::uint32_t>(
              qfn_mmq_q8_1_bytes(1, static_cast<int>(c.hc_low_rank)) / 36 * 32),
          fused_inject ? m.inject.f32() : nullptr,
          mixed,
          s_.mixed_q8_1,
          fused_inject ? inject : nullptr,
          c.hidden_size,
          c.hc_count,
          c.hc_low_rank,
          c.rms_eps,
          1.0F / static_cast<float>(c.hc_count)};
      if (!HcMixQ8Fused(hc_fused_state_, mix, n_tokens, stream_)) {
        AssignError(error_msg, "fused HC mixer failed");
        return false;
      }
      inject_fused_ = nullptr;
      q8t_src_ = nullptr;
      half_src_ = nullptr;
      mixed_q8_ready_ = {mixed, s_.mixed_q8_1, n_tokens, c.hidden_size};
      inject_parts_ = fused_inject ? HcInjectParts(c.hidden_size) : 1;
      return inject == nullptr || m.inject.empty() || fused_inject ||
             Dense(m.inject, s_.xn, inject, n_tokens, error_msg);
    }
    // Another mixer follows after all: run the combine Combine left.
    HcCombineQ8_1(p.res, p.block_out, p.inject, p.inject_parts, p.gamma, p.xn,
                  p.xn_q8, p.n, c.hidden_size, c.hc_count, c.rms_eps, stream_);
  }
  // Without `normed` this mixer's grouped norm of res is computed here (F32);
  // otherwise the previous combine produced it, as F16 plus tiled Q8 on the
  // wide route or as F32 in s_.xn (with its Q8_1 rows on a decode batch).
  if (!normed) {
    xn_half_ = false;
    xn_q8_ready_ = {};
    RmsNormRows(res, m.norm.f32(), s_.xn, n_tokens, c.HcDim(), c.hc_count,
                c.rms_eps, stream_);
  }
  const bool extras = n_tokens <= options_.max_batch &&
                      c.hidden_size <= model_->max_half_cols();
  const bool fused_projection =
      xn_half_ && n_tokens >= 96 && extras && c.hc_count == 4 &&
      c.hidden_size == 2560 && c.hc_low_rank == 320 &&
      m.up.type == GgmlType::kQ8_0 && m.up.rows == c.HcDim() &&
      m.up.cols == c.hc_low_rank;
  if (fused_projection) {
    // The up projection writes x_half; keep its input in the gate buffer.
    if (!HcDownF16Gemm(m.down.data, s_.xn_q8t,
                       reinterpret_cast<__half*>(s_.hc_gate), n_tokens,
                       stream_)) {
      AssignError(error_msg, "fused HC down projection failed");
      return false;
    }
  } else {
    if (xn_half_) {
      if (!W8A8Gemm(m.down.data, s_.xn_q8t, s_.lo, n_tokens, m.down.rows,
                    m.down.cols, stream_)) {
        AssignError(error_msg, "W8A8 mixer down projection failed");
        return false;
      }
    } else if (!Dense(m.down, s_.xn, s_.lo, n_tokens, error_msg)) {
      return false;
    }
    const float scale = 1.0F / static_cast<float>(c.hc_count);
    const std::uint32_t lo_q8_cols = static_cast<std::uint32_t>(
        qfn_mmq_q8_1_bytes(1, static_cast<int>(c.hc_low_rank)) / 36 * 32);
    if (!MatrixRows(n_tokens) && m.up.type == GgmlType::kQ8_0 &&
        m.up.cols == c.hc_low_rank &&
        SiluScaleQ8_1(s_.lo, scale, n_tokens, c.hc_low_rank, lo_q8_cols,
                      s_.lo_q8_1, stream_)) {
      const Q8Input lo{s_.lo, s_.lo_q8_1, n_tokens, c.hc_low_rank};
      if (!Dense(m.up, lo, s_.hc_gate, error_msg)) {
        return false;
      }
    } else {
      SiluScale(s_.lo, scale,
                static_cast<std::size_t>(n_tokens) * c.hc_low_rank, stream_);
      if (!Dense(m.up, s_.lo, s_.hc_gate, n_tokens, error_msg)) {
        return false;
      }
    }
  }
  const bool fused_inject =
      inject != nullptr && !m.inject.empty() && m.inject.type == GgmlType::kF32;
  // The previous combine already wrote these partials from the same norm.
  const bool inject_done = fused_inject && inject == s_.inject &&
                           inject_fused_ != nullptr &&
                           inject_fused_ == m.inject.f32();
  inject_fused_ = nullptr;
  // A separate inject projection can overwrite the cached half input. Keep
  // the full mixed row available for the following projection in that case.
  half_only =
      half_only && (inject == nullptr || m.inject.empty() || fused_inject);
  const float* xn = s_.xn;
  const bool vectorized =
      xn_half_ ||
      (MatrixRows(n_tokens) && c.hc_count == 4 && c.hidden_size % 4 == 0);
  // `mixed` is being rewritten: whatever the input caches held of it is
  // stale. The wide F16 route also emits the F16 and tiled Q8 copies the
  // projections that follow read.
  q8t_src_ = nullptr;
  half_src_ = nullptr;
  if (xn_half_) {
    if (fused_projection) {
      if (!HcMixF16Gemm(m.up.data, reinterpret_cast<const __half*>(s_.hc_gate),
                        s_.xn_half,
                        fused_inject && !inject_done ? m.inject.f32() : nullptr,
                        half_only || no_f32 ? nullptr : mixed,
                        static_cast<__half*>(s_.x_half),
                        half_only ? nullptr : s_.x_q8t, inject, n_tokens,
                        c.hidden_size, c.hc_low_rank, stream_)) {
        AssignError(error_msg, "fused HC projection failed");
        return false;
      }
    } else {
      HcMixEpilogueVec4F16(s_.xn_half, s_.hc_gate,
                           fused_inject ? m.inject.f32() : nullptr, mixed,
                           extras ? static_cast<__half*>(s_.x_half) : nullptr,
                           extras ? s_.x_q8t : nullptr, inject, n_tokens,
                           c.hidden_size, stream_);
    }
    if (extras) {
      half_src_ = mixed;
      half_rows_ = n_tokens;
      half_cols_ = c.hidden_size;
      half_bf16_ = false;
      if (!half_only || !fused_projection) {
        q8t_src_ = mixed;
        q8t_rows_ = n_tokens;
        q8t_cols_ = c.hidden_size;
      }
    }
  } else if (vectorized) {
    HcMixEpilogueVec4(xn, s_.hc_gate, fused_inject ? m.inject.f32() : nullptr,
                      mixed, inject, n_tokens, c.hidden_size, c.hc_count,
                      stream_);
  } else {
    // A decode batch's projections of `mixed` share its Q8_1 rows, which
    // the epilogue writes as it stores them.
    const bool q8 = !MatrixRows(n_tokens) && UnpaddedQ8(c.hidden_size);
    HcMixEpilogue(xn, s_.hc_gate, fused_inject ? m.inject.f32() : nullptr,
                  mixed, inject, n_tokens, c.hidden_size, c.hc_count, stream_,
                  q8 ? s_.mixed_q8_1 : nullptr);
    if (q8) {
      mixed_q8_ready_ = {mixed, s_.mixed_q8_1, n_tokens, c.hidden_size};
    }
  }
  inject_parts_ = fused_inject ? (vectorized ? HcInjectPartsVec4(c.hidden_size)
                                             : HcInjectParts(c.hidden_size))
                               : 1;
  if (inject != nullptr && !m.inject.empty() && !fused_inject) {
    // A quantized inject projection (the draft block's) reads an F32 norm;
    // on the wide route the combine only produced F16, so norm again.
    if (xn_half_) {
      xn_q8_ready_ = {};
      RmsNormRows(res, m.norm.f32(), s_.xn, n_tokens, c.HcDim(), c.hc_count,
                  c.rms_eps, stream_);
    }
    if (!Dense(m.inject, xn, inject, n_tokens, error_msg)) {
      return false;
    }
  }
  return true;
}

bool Executor::PleFetch(Session& session, std::span<const std::int32_t> tokens,
                        bool speculative, std::string* error_msg) const {
  if (ple_pending_ && !WaitPle(error_msg))
    return false;
  if (!options_.ple_gather.CanGather(tokens.size(), speculative))
    return LocalPleFetch(session, tokens, speculative, error_msg);
  cooperative_tokens_ = tokens.size();
  cooperative_rows_.resize(tokens.size() * config().ple_heads);
  auto history = session.ngram_;
  if (speculative) {
    // A rejected draft restores any proper prefix, not just the whole chain.
    // The owner records these through LocalPleFetch; the receiver must keep
    // exactly the same n-gram rollback boundaries without reading the table.
    for (std::size_t i = 0; i < tokens.size(); ++i) {
      HashNgramRows(config(), history, tokens.subspan(i, 1),
                    std::span(cooperative_rows_)
                        .subspan(i * config().ple_heads, config().ple_heads));
      if (!options_.ple_gather.local_owner && i + 1 < tokens.size())
        session.ngram_snapshots_[i] = history;
    }
  } else {
    HashNgramRows(config(), history, tokens, cooperative_rows_);
  }
  if (options_.ple_gather.local_owner) {
    std::string local_error;
    cooperative_local_ok_ =
        LocalPleFetch(session, tokens, speculative, &local_error);
  } else {
    FinishPrefetch();
    prefetch_.ready = false;
    prefetch_.claimed = 0;
    prefetch_.tail = false;
    session.ngram_ = history;
    cooperative_local_ok_ = true;
  }
  cooperative_pending_ = true;
  ple_pending_ = true;
  return true;
}

bool Executor::WaitPle(std::string* error_msg) const {
  if (!cooperative_pending_)
    return LocalWaitPle(error_msg);
  bool ok = cooperative_local_ok_;
  if (options_.ple_gather.local_owner && ok)
    ok = LocalWaitPle(nullptr);
  cooperative_pending_ = false;
  ple_pending_ = false;
  return options_.ple_gather.exchange(
      cooperative_rows_, host_emb_, s_.ple_emb,
      cooperative_tokens_ * config().PleEmbeddingDim(), ok, stream_, error_msg);
}

void Executor::DiscardPle() const {
  if (ple_pending_ &&
      (!cooperative_pending_ || options_.ple_gather.local_owner))
    (void)LocalWaitPle(nullptr);
  cooperative_pending_ = false;
  ple_pending_ = false;
}

bool Executor::LocalPleFetch(Session& session,
                             std::span<const std::int32_t> tokens,
                             bool speculative, std::string* error_msg) const {
  if (ple_pending_ && !WaitPle(error_msg)) {
    return false;
  }
  const Config& c = config();
  const auto n = static_cast<std::uint32_t>(tokens.size());
  if ((prefetch_.pending || prefetch_.ready) && !speculative &&
      session.ngram_ == prefetch_.before) {
    // A cache checkpoint or another step budget can end this chunk before
    // or after the hinted one. Rows are per token, so a common prefix still
    // serves every token both cover.
    const auto shared = static_cast<std::size_t>(
        std::ranges::mismatch(tokens, prefetch_.tokens).in1 - tokens.begin());
    if (shared == tokens.size() || shared == prefetch_.tokens.size()) {
      prefetch_.claimed = shared;
      ple_pending_ = true;
      if (shared == prefetch_.tokens.size()) {
        session.ngram_ = prefetch_.after;
      } else {
        HashNgramRows(
            c, session.ngram_, tokens,
            std::span<std::uint32_t>(host_rows_.data(), n * c.ple_heads));
      }
      if (shared == tokens.size())
        return true;
      // Only one table read runs at a time: finish the prefetch, which had a
      // whole chunk to complete, then read the rows past it.
      FinishPrefetch();
      const auto rest = tokens.subspan(shared);
      const auto rows = rest.size() * c.ple_heads;
      HashNgramRows(c, session.ngram_, rest,
                    std::span<std::uint32_t>(host_rows_.data(), rows));
      const NgramGatherOwner owner{rows, &session.ngram_counters_};
      prefetch_.tail = ngram_->StartRead(
          std::span<const std::uint32_t>(host_rows_.data(), rows),
          std::span<float>(host_emb_ + shared * c.PleEmbeddingDim(),
                           rest.size() * c.PleEmbeddingDim()),
          std::span(&owner, 1));
      if (!prefetch_.tail) {
        prefetch_.claimed = 0;
        prefetch_.ready = false;
        ple_pending_ = false;
        AssignError(error_msg, "n-gram table read could not start");
      }
      return prefetch_.tail;
    }
  }
  FinishPrefetch();
  // Only proper prefixes need snapshots; the full batch keeps its live state.
  if (speculative) {
    for (std::uint32_t i = 0; i < n; ++i) {
      HashNgramRows(c, session.ngram_, tokens.subspan(i, 1),
                    std::span<std::uint32_t>(
                        host_rows_.data() + i * c.ple_heads, c.ple_heads));
      if (i + 1 < n) {
        session.ngram_snapshots_[i] = session.ngram_;
      }
    }
  } else {
    HashNgramRows(c, session.ngram_, tokens,
                  std::span<std::uint32_t>(host_rows_.data(), n * c.ple_heads));
  }
  const NgramGatherOwner owner{n * c.ple_heads, &session.ngram_counters_};
  ple_pending_ = ngram_->StartRead(
      std::span<const std::uint32_t>(host_rows_.data(), n * c.ple_heads),
      std::span<float>(host_emb_,
                       static_cast<std::size_t>(n) * c.PleEmbeddingDim()),
      std::span(&owner, 1));
  if (!ple_pending_) {
    AssignError(error_msg, "n-gram table read could not start");
  }
  return ple_pending_;
}

bool Executor::LocalWaitPle(std::string* error_msg) const {
  bool ok = ple_pending_;
  if (ok && prefetch_.claimed != 0) {
    FinishPrefetch();
    ok = prefetch_.ready;
    if (ok) {
      std::copy_n(prefetch_.rows.data(),
                  prefetch_.claimed * config().PleEmbeddingDim(), host_emb_);
    }
    if (prefetch_.tail)
      ok = ngram_->WaitRead() && ok;
    prefetch_.ready = false;
    prefetch_.claimed = 0;
    prefetch_.tail = false;
  } else if (ok) {
    ok = ngram_->WaitRead();
  }
  ple_pending_ = false;
  if (!ok) {
    AssignError(error_msg, "n-gram table read failed");
  }
  return ok;
}

void Executor::PrefetchPle(const Session& session,
                           std::span<const std::int32_t> next) const {
  const Config& c = config();
  // A paired prefill chunk (PrefillChunk) is the widest batch PleFetch reads.
  if (ple_pending_ || prefetch_.pending || next.empty() ||
      next.size() > PrefillChunk() ||
      (!options_.ple_gather.local_owner &&
       options_.ple_gather.CanGather(next.size(), false))) {
    return;
  }
  // Hashed from the history after this batch, which PleFetch already
  // advanced; the session keeps it until the next batch claims the rows.
  prefetch_.ready = false;
  prefetch_.before = session.ngram_;
  prefetch_.after = session.ngram_;
  const std::span<std::uint32_t> rows(host_rows_.data(),
                                      next.size() * c.ple_heads);
  HashNgramRows(c, prefetch_.after, next, rows);
  prefetch_.tokens.assign(next.begin(), next.end());
  const std::size_t count = next.size() * c.PleEmbeddingDim();
  if (prefetch_.rows.size() < count) {
    prefetch_.rows.resize(count);
  }
  const NgramGatherOwner owner{rows.size(), &session.ngram_counters_};
  prefetch_.pending =
      ngram_->StartRead(rows, std::span<float>(prefetch_.rows.data(), count),
                        std::span(&owner, 1));
}

void Executor::FinishPrefetch() const {
  if (prefetch_.pending) {
    prefetch_.ready = ngram_->WaitRead();
    prefetch_.pending = false;
  }
}

bool Executor::Ple(const DeviceLayer& l, Session& session, std::uint32_t n,
                   float* res, bool speculative, std::string* error_msg,
                   bool embeddings_ready, PrefillCheckpoint* checkpoint,
                   std::uint32_t emb_row) const {
  const Config& c = config();
  if (!embeddings_ready && emb_row == 0 && !WaitPle(error_msg)) {
    return false;
  }
  if (!embeddings_ready && !prefetch_next_.empty()) {
    PrefetchPle(session, prefetch_next_);
    prefetch_next_ = {};
  }
  const std::uint32_t hc_dim = c.HcDim();
  Q8Input emb;
  if (!Quantize(s_.ple_emb + std::size_t{emb_row} * c.PleEmbeddingDim(), n,
                c.PleEmbeddingDim(), &emb, error_msg) ||
      !Dense(l.ple_key, emb, s_.ple_key, error_msg) ||
      !Dense(l.ple_value, emb, s_.ple_value, error_msg)) {
    return false;
  }
  RmsNormRows(s_.ple_key, l.ple_norm_key.f32(), s_.ple_key, n, hc_dim,
              c.hc_count, c.rms_eps, stream_);
  RmsNormRows(res, l.ple_norm_query.f32(), s_.ple_query, n, hc_dim, c.hc_count,
              c.rms_eps, stream_);
  PleGate(s_.ple_key, s_.ple_query, s_.ple_value, s_.ple_gated, n,
          c.hidden_size, c.hc_count, stream_);
  RmsNormRows(s_.ple_gated, l.ple_norm_conv.f32(), s_.ple_norm, n, hc_dim,
              c.hc_count, c.rms_eps, stream_);
  if (checkpoint)
    HistoryPrefix(s_.ple_norm, hc_dim, session.ple_history_,
                  checkpoint->state->ple_history_, checkpoint->tokens, hc_dim,
                  c.PleConvHistory(), stream_);
  PleConv(s_.ple_norm, l.ple_conv1d.f32(), session.ple_history_,
          s_.ple_history_scratch, s_.ple_conv,
          speculative ? session.ple_snapshots_ : RollbackRows{}, n, hc_dim,
          c.ple_conv_kernel, c.ple_ngram_size, stream_);
  PleInject(res, s_.ple_gated, s_.ple_conv,
            static_cast<std::size_t>(n) * hc_dim, stream_);
  return true;
}

bool Executor::LinearAttention(const DeviceLayer& l, Session::LinearState& s,
                               const float* x, float* out,
                               std::uint32_t n_tokens, bool speculative,
                               std::string* error_msg, bool projections_ready,
                               bool project_output,
                               GdnCheckpoint checkpoint) const {
  const Config& c = config();
  const MixerHeads& heads = l.heads;
  const std::uint32_t channels = heads.SsmConvChannels();
  const float* qkv = s_.qkv;
  const float* z = s_.z;
  std::uint32_t qkv_stride = channels;
  std::uint32_t z_stride = heads.SsmValueDim();
  bool convolved = false;
  hipEvent_t z_ready = nullptr;
  // Until GatedDeltaNet queues its wait for the Z rows, every exit orders
  // the main stream after them: the side stream still writes s_.qkvz.
  struct ZJoin {
    hipStream_t stream;
    hipEvent_t event = nullptr;
    ~ZJoin() {
      if (event != nullptr)
        (void)hipStreamWaitEvent(stream, event, 0);
    }
  } z_join{stream_};
  if (!l.ssm_in.empty()) {
    // Wide prefill convolves QKV in the projection's LDS tile. The raw
    // boundary rows remain available for the rolling history update.
    if (!projections_ready && !speculative && WidePrefill(n_tokens) &&
        n_tokens <= options_.max_batch && DenseF16Route(l.ssm_in, n_tokens)) {
      PrepareHalfInput(x, n_tokens, l.ssm_in.cols);
      // The Z rows feed only the output norm: the side stream computes them
      // beside the convolution boundary, the alpha/beta GEMM and the
      // recurrence; the epilogue waits for them before it reads z. With the
      // shared-expert overlap on ROCm 10.1: pp512 1,287 -> 1,330 tok/s,
      // pp2048 and pp4096 within 1 %.
      convolved = DenseF16SsmGemm(
          l.ssm_in.data, static_cast<const __half*>(s_.x_half),
          l.ssm_conv1d.f32(), s.conv_state, s_.qkvz, s_.conv_scratch, n_tokens,
          l.ssm_in.rows, l.ssm_in.cols, channels, c.ssm_conv_kernel, stream_,
          checkpoint.tokens, side_stream_, side_start_);
      if (convolved) {
        if (!Check(hipEventRecord(side_done_, side_stream_), "side stream join",
                   error_msg)) {
          (void)hipStreamSynchronize(side_stream_);
          return false;
        }
        z_ready = side_done_;
        z_join.event = side_done_;
      }
    }
    if (!projections_ready && !convolved &&
        !Dense(l.ssm_in, x, s_.qkvz, n_tokens, error_msg)) {
      return false;
    }
    qkv = s_.qkvz;
    z = s_.qkvz + channels;
    qkv_stride = z_stride = l.ssm_in.rows;
  } else if (!projections_ready) {
    Q8Input xq;
    if (!Quantize(x, n_tokens, c.hidden_size, &xq, error_msg) ||
        !Dense(l.ssm_qkv, xq, s_.qkv, error_msg) ||
        !Dense(l.ssm_gate, xq, s_.z, error_msg)) {
      return false;
    }
  }
  if (!projections_ready &&
      !Dense(l.ssm_alpha_beta, x, s_.alpha_beta, n_tokens, error_msg)) {
    return false;
  }
  // Keep the same activation precision across prefill chunk boundaries.
  // The F16 epilogue reuses the F32 output allocation. Switching this
  // projection to Q8 for a short tail changes every subsequent layer.
  const bool tiled = MatrixRows(n_tokens) &&
                     l.ssm_out.type == GgmlType::kQ8_0 &&
                     n_tokens <= options_.max_batch;
  // All value heads, or a TP rank's half.
  const bool half_output = tiled && l.ssm_out.rows == 2560 &&
                           (l.ssm_out.cols == 6144 || l.ssm_out.cols == 3072);
  auto* out_half =
      half_output ? reinterpret_cast<__half*>(s_.gdn_out) : nullptr;
  // Shift successive rows off the 12 KiB pitch while retaining every half.
  // The existing F32 scratch has room for these slightly padded F16 rows.
  const std::uint32_t half_stride =
      half_output && n_tokens >= 1024 ? l.ssm_out.cols + 32 : 0;
  // A decode batch's output projection reads the epilogue's Q8_1 rows.
  const std::uint32_t value_dim = heads.SsmValueDim();
  const bool out_q8_1 = project_output && !tiled && !MatrixRows(n_tokens) &&
                        c.ssm_head_dim == 128 &&
                        l.ssm_out.type == GgmlType::kQ8_0 &&
                        l.ssm_out.cols == value_dim && UnpaddedQ8(value_dim);
  if (!GatedDeltaNet(qkv, qkv_stride, z, z_stride, s_.alpha_beta,
                     l.ssm_conv1d.f32(), l.ssm_a.f32(), l.ssm_dt.f32(),
                     l.ssm_norm.f32(), s.conv_state, s_.conv_scratch, s_.qn,
                     s_.kn, s_.gdn_raw, s.state, s_.gdn_out,
                     tiled && !half_output ? s_.x_q8t : nullptr,
                     speculative ? s.state_snapshots : RollbackRows{},
                     speculative ? s.conv_snapshots : RollbackRows{}, n_tokens,
                     heads.ssm_k, heads.ssm_v, heads.ssm_dim, c.ssm_conv_kernel,
                     MatrixRows(n_tokens) && !speculative, convolved, c.rms_eps,
                     stream_, out_half, checkpoint, half_stride,
                     out_q8_1 ? s_.gdn_q8_1 : nullptr, z_ready)) {
    AssignError(error_msg, "DeltaNet launch failed");
    return false;
  }
  z_join.event = nullptr;  // GatedDeltaNet waited for the Z rows
  if (!project_output) {
    return true;
  }
  if (half_output) {
    if (!DenseF16Gemm(l.ssm_out.data, out_half, out, n_tokens, l.ssm_out.rows,
                      l.ssm_out.cols, stream_, half_stride)) {
      AssignError(error_msg, "SSM output F16 GEMM failed");
      return false;
    }
    return true;
  }
  if (tiled) {
    q8t_src_ = nullptr;
    if (!W8A8Gemm(l.ssm_out.data, s_.x_q8t, out, n_tokens, l.ssm_out.rows,
                  l.ssm_out.cols, stream_)) {
      AssignError(error_msg, "W8A8 GEMM failed");
      return false;
    }
    return true;
  }
  if (out_q8_1) {
    return Dense(l.ssm_out,
                 Q8Input{s_.gdn_out, s_.gdn_q8_1, n_tokens, value_dim}, out,
                 error_msg);
  }
  return Dense(l.ssm_out, s_.gdn_out, out, n_tokens, error_msg);
}

bool Executor::Attention(const DeviceLayer& l, Session::AttentionState& s,
                         const float* x, float* out, std::uint32_t n_tokens,
                         const std::uint32_t* pos,
                         const std::uint32_t* first_block,
                         std::uint32_t start_pos, std::uint32_t pool_grid,
                         std::uint32_t max_context, bool sparse,
                         std::string* error_msg, bool last_only,
                         bool projections_ready, bool project_output,
                         std::uint32_t checkpoint_tokens) const {
  const Config& c = config();
  const MixerHeads& heads = l.heads;
  const std::uint32_t kv_row = heads.AttentionKvDim();
  const std::uint32_t index_capacity =
      IndexerCapacity(c, options_.max_batch, max_context);
  bool prepared = false;
  if (!l.attn_qkv.empty()) {
    const bool fused_projection =
        !projections_ready && WidePrefill(n_tokens) &&
        n_tokens <= options_.max_batch && DenseF16Route(l.attn_qkv, n_tokens) &&
        l.attn_qkv.rows == 2 * (heads.attn + heads.attn_kv) * 256 &&
        l.attn_qkv.cols == 2560 && heads.attn == 12 * heads.attn_kv &&
        heads.attn_dim == 256 && c.rotary_dim == 64;
    if (fused_projection) {
      PrepareHalfInput(x, n_tokens, l.attn_qkv.cols);
      prepared = AttentionF16Gemm(
          l.attn_qkv.data, static_cast<const __half*>(s_.x_half),
          l.attn_q_norm.f32(), l.attn_k_norm.f32(), s_.q, s_.attn_gate,
          s.k_cache, s.v_cache, n_tokens, heads.attn, heads.attn_kv, pos,
          c.rope_theta, c.rms_eps, stream_, s.rope, yarn_);
      if (!prepared) {
        AssignError(error_msg, "fused attention projection failed");
        return false;
      }
    } else {
      if (!projections_ready &&
          !Dense(l.attn_qkv, x, s_.qg, n_tokens, error_msg)) {
        return false;
      }
      prepared = PrepareAttention(
          s_.qg, l.attn_qkv.rows, l.attn_q_norm.f32(), l.attn_k_norm.f32(),
          s_.q, s_.attn_gate, s.k_cache, s.v_cache, n_tokens, heads.attn,
          heads.attn_kv, heads.attn_dim, c.rotary_dim, pos, c.rope_theta,
          c.rms_eps, stream_, s.rope, prefill_phase, yarn_);
      if (!prepared) {
        UnpackQGate(s_.qg, l.attn_qkv.rows, s_.q, s_.attn_gate, s_.k, s_.v,
                    n_tokens, heads.attn, heads.attn_dim, kv_row, stream_);
      }
    }
  } else {
    Q8Input xq;
    if (!projections_ready &&
        (!Quantize(x, n_tokens, c.hidden_size, &xq, error_msg) ||
         !Dense(l.attn_q, xq, s_.qg, error_msg) ||
         !Dense(l.attn_k, xq, s_.k, error_msg) ||
         !Dense(l.attn_v, xq, s_.v, error_msg))) {
      return false;
    }
    UnpackQGate(s_.qg, 2 * heads.AttentionQDim(), s_.q, s_.attn_gate, nullptr,
                nullptr, n_tokens, heads.attn, heads.attn_dim, 0, stream_);
  }
  if (!prepared) {
    RmsNormRows(s_.q, l.attn_q_norm.f32(), s_.q, n_tokens * heads.attn,
                heads.attn_dim, 1, c.rms_eps, stream_);
    RmsNormRows(s_.k, l.attn_k_norm.f32(), s_.k, n_tokens * heads.attn_kv,
                heads.attn_dim, 1, c.rms_eps, stream_);
    Rope(s_.q, n_tokens, heads.attn, heads.attn_dim, c.rotary_dim, pos,
         c.rope_theta, stream_, s.rope, yarn_);
    Rope(s_.k, n_tokens, heads.attn_kv, heads.attn_dim, c.rotary_dim, pos,
         c.rope_theta, stream_, s.rope, yarn_);
    StoreKv(s_.k, s.k_cache, n_tokens, kv_row, pos, stream_);
    StoreKv(s_.v, s.v_cache, n_tokens, kv_row, pos, stream_);
  }

  // Raw keys survive only until pooling. The ring holds the initial
  // pre-budget backlog and a batch, independently for trunk and predictor.
  if (s.index_k != nullptr) {
    if (!(projections_ready
              ? DenseBatch(l.indexer_k, x, s_.ik, n_tokens, error_msg)
              : Dense(l.indexer_k, x, s_.ik, n_tokens, error_msg))) {
      return false;
    }
    StoreRows(s_.ik, s.index_k, n_tokens, c.indexer_head_dim, pos,
              index_capacity, stream_);
  }
  const std::uint32_t* mask = nullptr;
  if (sparse) {
    if (!Dense(l.indexer_q, x, s_.iq, n_tokens, error_msg)) {
      return false;
    }
    RmsNormRows(s_.iq, l.indexer_q_norm.f32(), s_.iq,
                n_tokens * c.indexer_heads, c.indexer_head_dim, 1, c.rms_eps,
                stream_);
    Rope(s_.iq, n_tokens, c.indexer_heads, c.indexer_head_dim, c.rotary_dim,
         pos, c.rope_theta, stream_, s.rope, yarn_);
    PoolIndexerBlocks(s.index_k, l.indexer_k_norm.f32(), s.block_k, first_block,
                      pos, n_tokens, pool_grid, c.compress_ratio,
                      c.indexer_head_dim, c.rotary_dim, c.rope_theta, c.rms_eps,
                      index_capacity, stream_, s.rope, yarn_);
    // Align score rows to full cache lines. The selector still considers
    // only complete causal blocks, so padding cannot change the ranking.
    // Wide prefill is never captured: compact score rows to the populated
    // context. Graphs retain the maximum stride for replay at later positions.
    const auto score_context =
        n_tokens > kVecBatch ? start_pos + n_tokens : max_context;
    const std::uint32_t blocks =
        (score_context + c.compress_ratio - 1) / c.compress_ratio;
    const std::uint32_t max_blocks = (blocks + 31) / 32 * 32;
    // Query rows are independent; rounding down to a power of two wasted
    // up to half the bounded scratch and doubled launches above 160K.
    const auto select_chunk = static_cast<std::uint32_t>(
        std::min(std::size_t{512}, select_score_floats_ / max_blocks));
    // Catch-up consumes only the final attention tile. Cover its masks even
    // when the dense/sparse boundary shifts the four-query sparse groups.
    const auto first_query = last_only && n_tokens > 16 ? n_tokens - 16 : 0U;
    for (std::uint32_t t0 = first_query; t0 < n_tokens; t0 += select_chunk) {
      const std::uint32_t n = std::min(select_chunk, n_tokens - t0);
      // Batches wider than kVecBatch are never captured, so the host
      // position bounds the scored range (a replayed graph must cover
      // max_blocks).
      const std::uint32_t live =
          n_tokens > kVecBatch ? (start_pos + t0 + n) / c.compress_ratio : 0;
      SelectBlocks(s_.iq + static_cast<std::size_t>(t0) * c.indexer_heads *
                               c.indexer_head_dim,
                   s.block_k,
                   s_.mask + static_cast<std::size_t>(t0) * mask_words_,
                   s_.scores, n, pos, t0, c.indexer_heads, c.indexer_head_dim,
                   c.compress_ratio, c.indexer_top_k / c.compress_ratio,
                   mask_words_, max_blocks, stream_, live);
    }
    mask = s_.mask;
  }
  // Wide batches run the fused WMMA kernel (never inside a graph: the kv
  // extent is a host value), output gate included, skipping the key tiles
  // no query of a block selected; the per-token kernel covers the rest.
  if (last_only &&
      !Check(hipMemsetAsync(s_.ctx, 0,
                            static_cast<std::size_t>(n_tokens) *
                                heads.AttentionQDim() * sizeof(float),
                            stream_),
             "partial attention output initialization", error_msg)) {
    return false;
  }
  // Queries before the token budget always take the dense tiles, also in a
  // batch that crosses it, so each position's key sweep (and its rounding)
  // does not depend on where the prefill chunks fall. The sparse part goes
  // first: it is the launch that can be refused.
  const auto attend = [&](std::uint32_t first, std::uint32_t rows, bool last) {
    const std::uint32_t pos = start_pos + first;
    const std::uint32_t dense_rows = mask != nullptr && pos < c.indexer_top_k
                                         ? std::min(rows, c.indexer_top_k - pos)
                                         : 0;
    const auto at = [&](std::uint32_t row) {
      return std::size_t{first + row} * heads.AttentionQDim();
    };
    return (dense_rows == rows ||
            WmmaCausalAttention(
                s_.q + at(dense_rows), s_.attn_gate + at(dense_rows), s.k_cache,
                s.v_cache,
                mask ? mask + std::size_t{first + dense_rows} * mask_words_
                     : nullptr,
                mask_words_, s_.ctx + at(dense_rows), rows - dense_rows,
                pos + dense_rows, heads.attn, heads.attn_kv, heads.attn_dim,
                c.compress_ratio, stream_, last)) &&
           (dense_rows == 0 || (last && dense_rows != rows) ||
            WmmaCausalAttention(s_.q + at(0), s_.attn_gate + at(0), s.k_cache,
                                s.v_cache, nullptr, mask_words_, s_.ctx + at(0),
                                dense_rows, pos, heads.attn, heads.attn_kv,
                                heads.attn_dim, c.compress_ratio, stream_,
                                false));
  };
  if (checkpoint_tokens != 0 && checkpoint_tokens < n_tokens) {
    // Sparse tiles compact the union of their queries' selected keys.
    // Keep the checkpoint's query grouping identical to a pass ending there.
    if (!attend(0, checkpoint_tokens, false) ||
        !attend(checkpoint_tokens, n_tokens - checkpoint_tokens, false)) {
      AssignError(error_msg, "checkpoint attention geometry is unsupported");
      return false;
    }
    return !project_output ||
           Dense(l.attn_out, s_.ctx, out, n_tokens, error_msg);
  }
  if (MatrixRows(n_tokens) && attend(0, n_tokens, last_only)) {
    return !project_output ||
           Dense(l.attn_out, s_.ctx, out, n_tokens, error_msg);
  }
  // Narrow batches split each row's key tiles over kAttnSplits blocks so a
  // decode step at depth fills the device.
  const bool split = !MatrixRows(n_tokens);
  rocm::Attention(s_.q, s.k_cache, s.v_cache, mask, mask_words_, s_.ctx,
                  split ? s_.attn_partials : nullptr, kAttnSplits, n_tokens,
                  pos, heads.attn, heads.attn_kv, heads.attn_dim,
                  c.compress_ratio, stream_, split ? s_.attn_lists : nullptr,
                  split ? s_.attn_counts : nullptr,
                  c.compress_ratio > 0 ? c.indexer_top_k / c.compress_ratio : 0,
                  c.indexer_top_k);
  const std::uint32_t q_dim = heads.AttentionQDim();
  const std::size_t ctx_count = static_cast<std::size_t>(n_tokens) * q_dim;
  // A decode batch's output projection reads the gate's Q8_1 rows.
  if (project_output && split && l.attn_out.type == GgmlType::kQ8_0 &&
      l.attn_out.cols == q_dim && UnpaddedQ8(q_dim) &&
      SigmoidMulQ8_1(s_.ctx, s_.attn_gate, ctx_count, s_.ctx_q8_1, stream_)) {
    return Dense(l.attn_out, Q8Input{s_.ctx, s_.ctx_q8_1, n_tokens, q_dim}, out,
                 error_msg);
  }
  SigmoidMul(s_.ctx, s_.attn_gate, ctx_count, stream_);
  return !project_output || Dense(l.attn_out, s_.ctx, out, n_tokens, error_msg);
}

std::function<bool(float*, std::size_t, hipStream_t, std::string*)>
Executor::TwoRankAllReduce(std::shared_ptr<Communicator> communicator,
                           std::uint32_t hidden) {
  return [communicator = std::move(communicator), hidden](
             float* data, std::size_t bytes, hipStream_t stream,
             std::string* error) {
    Communicator::QueuedPartial queued;
    if (!communicator->QueuePartial(bytes, &queued, error)) {
      return false;
    }
    StagePartial(data, queued.send, bytes / sizeof(float), queued.arrivals,
                 queued.ready, queued.value, stream);
    WaitValue(queued.arrived, queued.value, queued.wait_ticks, queued.timed_out,
              stream);
    const std::size_t rows = bytes / (sizeof(float) * hidden);
    if (rows != 0) {
      AddRowsBroadcast(queued.peer, data, static_cast<std::uint32_t>(rows),
                       hidden, 1, stream);
    }
    return true;
  };
}

std::function<bool(float*, std::size_t, std::uint32_t, hipStream_t,
                   std::string*)>
Executor::TwoRankTargetHeadGather(std::shared_ptr<Communicator> communicator) {
  return [communicator = std::move(communicator)](
             float* data, std::size_t half_values, std::uint32_t rows,
             hipStream_t stream, std::string* error) {
    const auto rank = communicator->rank();
    if (rank > 1 || rows == 0 || half_values == 0 ||
        half_values > std::numeric_limits<std::size_t>::max() /
                          (sizeof(float) * std::size_t{rows} * 2)) {
      AssignError(error, "invalid head gather shape or rank");
      return false;
    }
    const std::size_t half_pitch = half_values * sizeof(float);
    Communicator::QueuedPartial queued;
    if (!communicator->QueuePartial(half_pitch * rows, &queued, error))
      return false;
    StagePartial(data, queued.send, half_values * rows, queued.arrivals,
                 queued.ready, queued.value, stream);
    WaitValue(queued.arrived, queued.value, queued.wait_ticks, queued.timed_out,
              stream);
    // Staging consumes the packed local rows before any expansion. Expand
    // all local rows first so a peer copy cannot overwrite unread sources.
    for (std::uint32_t row = rows; row-- > 0;) {
      float* src = data + std::size_t{row} * half_values;
      float* dst = data + (std::size_t{row} * 2 + rank) * half_values;
      if (src != dst && !Check(hipMemcpyAsync(dst, src, half_pitch,
                                              hipMemcpyDeviceToDevice, stream),
                               "head gather local row placement", error))
        return false;
    }
    // Existing queued-window lifetime and Drain/CheckQueued failure handling
    // apply. Copying, rather than adding, retains the original logit bits.
    return Check(
        hipMemcpy2DAsync(data + std::size_t{1 - rank} * half_values,
                         half_pitch * 2, queued.peer, half_pitch, half_pitch,
                         rows, hipMemcpyDeviceToDevice, stream),
        "head gather peer row placement", error);
  };
}

std::function<bool(std::string*)> Executor::TwoRankReduceStatus(
    std::shared_ptr<Communicator> communicator) {
  return [communicator = std::move(communicator)](std::string* error) {
    return communicator->CheckQueued(error);
  };
}

bool Executor::Drain(const char* what, std::string* error_msg) const {
  return Check(hipStreamSynchronize(stream_), what, error_msg) &&
         (!options_.reduce_status || options_.reduce_status(error_msg));
}

Executor::SplitReduce Executor::TwoRankSplitReduce(
    std::shared_ptr<Communicator> communicator, std::uint32_t hidden) {
  SplitReduce reduce;
  reduce.start = [communicator](const float* data, std::size_t bytes,
                                hipStream_t stream, std::string* error) {
    return communicator->StartPartial(data, bytes, stream, error);
  };
  reduce.finish = [communicator = std::move(communicator), hidden](
                      float* data, std::size_t bytes, hipStream_t stream,
                      std::string* error) {
    const float* peer = communicator->FinishPartial(bytes, error);
    if (peer == nullptr) {
      return false;
    }
    const std::size_t rows = bytes / (sizeof(float) * hidden);
    if (rows != 0) {
      AddRowsBroadcast(peer, data, static_cast<std::uint32_t>(rows), hidden, 1,
                       stream);
    }
    return true;
  };
  return reduce;
}

bool Executor::AllReduce(float* data, std::size_t rows, std::string* error_msg,
                         bool observe) const {
  if (model_->tp_world_size() == 1) {
    return true;
  }
  const std::size_t hidden = config().hidden_size;
  if (rows > std::numeric_limits<std::size_t>::max() / hidden ||
      rows * hidden > std::numeric_limits<std::size_t>::max() / sizeof(float)) {
    if (error_msg != nullptr) {
      *error_msg = "Flash-Next all-reduce byte count overflows";
    }
    return false;
  }
  const std::size_t bytes = rows * hidden * sizeof(float);
  if (!options_.all_reduce ||
      !options_.all_reduce(data, bytes, stream_, error_msg)) {
    if (error_msg != nullptr && error_msg->empty()) {
      *error_msg = "Flash-Next all-reduce failed";
    }
    return false;
  }
  if (observe && options_.moe_observer) {
    options_.moe_observer(data, bytes, stream_);
  }
  return true;
}

bool Executor::Moe(const DeviceLayer& l, const float* x, float* out,
                   std::uint32_t n_tokens, std::string* error_msg,
                   bool last_only, bool reduce) const {
  const Config& c = config();
  const std::uint32_t used = c.num_experts_used;
  if (options_.moe_observer) {
    options_.moe_observer(
        x, static_cast<std::size_t>(n_tokens) * c.hidden_size * sizeof(float),
        stream_);
  }
  // Router logits and the shared-expert gate come out of one GEMM.
  if (!Dense(l.router, x, s_.router, n_tokens, error_msg)) {
    return false;
  }
  RouterTopK(s_.router, c.num_experts + 1, s_.ids, s_.weights, n_tokens,
             c.num_experts, used, stream_);
  if (ExpertMatrixRows(n_tokens)) {
    ExpertCounts(s_.ids, s_.expert_counts, n_tokens, c.num_experts, used,
                 stream_);
    if (!Check(hipMemcpyAsync(counts_host_, s_.expert_counts,
                              c.num_experts * sizeof(std::uint32_t),
                              hipMemcpyDeviceToHost, stream_),
               "expert counts download", error_msg) ||
        !Check(hipEventRecord(counts_ready_, stream_), "expert counts event",
               error_msg)) {
      return false;
    }
  }
  // The shared expert (gated by the last router row) does not depend on
  // routing. Queue its GEMMs after the count download, then prepare the
  // routed dispatch on the CPU without waiting for these GEMMs to finish.
  // A wide batch runs them on the side stream beside the routed experts,
  // which leave compute idle while they stream expert weights. The shared
  // expert writes its own scratch and may quantize x into s_.x_q8t, so no
  // main-stream work may use s_.x_q8t before JoinSide.
  // Only the Q8_0 shared expert overlaps: its kernels take stream_, while
  // the BF16, F16 and F32 routes go through BLAS handles bound to the main
  // stream.
  const bool overlap = ExpertMatrixRows(n_tokens) && !last_only &&
                       l.shexp_gate.type == GgmlType::kQ8_0 &&
                       l.shexp_up.type == GgmlType::kQ8_0 &&
                       l.shexp_down.type == GgmlType::kQ8_0;
  const hipStream_t main = stream_;
  if (overlap) {
    if (!Check(hipEventRecord(side_start_, main), "side stream fork",
               error_msg) ||
        !Check(hipStreamWaitEvent(side_stream_, side_start_, 0),
               "side stream wait", error_msg)) {
      return false;
    }
    stream_ = side_stream_;
  }
  const auto shared_expert = [&] {
    shexp_half_ready_ = false;
    if (!GatedDense(l.shexp_up, l.shexp_gate, x, s_.shexp_up, n_tokens,
                    &l.shexp_down, error_msg)) {
      return false;
    }
    if (shexp_half_ready_) {
      shexp_half_ready_ = false;
      if (!DenseF16Gemm(l.shexp_down.data, s_.shexp_half, s_.shexp_out,
                        n_tokens, l.shexp_down.rows, l.shexp_down.cols,
                        stream_)) {
        AssignError(error_msg, "shared expert F16 GEMM failed");
        return false;
      }
      return true;
    }
    return Dense(l.shexp_down, s_.shexp_up, s_.shexp_out, n_tokens, error_msg);
  };
  bool shared_ok = shared_expert();
  // A split shared expert leaves each rank a partial that the all-reduce
  // completes. A whole one belongs to rank zero, so peers must not add a
  // second copy. Peers still run the projections above: they rewrite the
  // activation staging caches, and skipping them would leave a peer's later
  // projections reusing a different staged copy than rank zero's, so the
  // replicated state would drift apart (seen with full Q8).
  if (shared_ok && model_->tp_rank() != 0 && !l.shexp_split) {
    shared_ok = Check(hipMemsetAsync(s_.shexp_out, 0,
                                     static_cast<std::size_t>(n_tokens) *
                                         c.hidden_size * sizeof(float),
                                     stream_),
                      "non-owner shared expert clear", error_msg);
  }
  stream_ = main;
  if (overlap) {
    if (!Check(hipEventRecord(side_done_, side_stream_), "side stream join",
               error_msg)) {
      // Nothing to join: wait for the whole side stream instead.
      (void)hipStreamSynchronize(side_stream_);
      return false;
    }
    side_pending_ = true;
  }
  // Every exit, including errors, orders the main stream after the shared
  // expert: its side-stream writes must not race the next pass.
  struct JoinGuard {
    const Executor* executor;
    ~JoinGuard() { (void)executor->JoinSide(nullptr); }
  } join_guard{this};
  if (!shared_ok) {
    return false;
  }
  if (last_only && l.ffn_gate_exps.type == GgmlType::kQ8_0 &&
      l.ffn_up_exps.type == GgmlType::kQ8_0 &&
      l.ffn_down_exps.type == GgmlType::kQ8_0) {
    // Catch-up retains only the final predictor residual. Keep the router
    // and shared-expert shapes, then run its routed experts with the same
    // tiled F16 route and accumulation as the complete prompt batch.
    const auto base = s_;
    UseScratch(RowScratch(base, n_tokens - 1));
    PrefillPhase phase(true);
    try {
      const std::size_t offset =
          static_cast<std::size_t>(n_tokens - 1) * c.hidden_size;
      // The routed tiles cover this row's slots alone, so count them alone.
      ExpertCounts(s_.ids, s_.expert_counts, 1, c.num_experts, used, stream_);
      if (!Check(hipMemcpyAsync(counts_host_, s_.expert_counts,
                                c.num_experts * sizeof(std::uint32_t),
                                hipMemcpyDeviceToHost, stream_),
                 "expert counts download", error_msg) ||
          !Check(hipEventRecord(counts_ready_, stream_), "expert counts event",
                 error_msg)) {
        UseScratch(base);
        return false;
      }
      const bool ok = MoeExperts(l, x + offset, out + offset, 1, error_msg);
      // A deferred epilogue runs in the combine over all rows, which reads
      // F16 expert rows at their F16 offsets; the row scratch placed this
      // row at its F32 offset.
      const bool pending = ok && moe_pending_;
      UseScratch(base);
      if (pending) {
        const std::size_t row = static_cast<std::size_t>(used) * c.hidden_size;
        auto* down = reinterpret_cast<__half*>(base.down_e);
        if (n_tokens > 1 &&
            !Check(hipMemcpyAsync(down + (n_tokens - 1) * row,
                                  down + 2 * (n_tokens - 1) * row,
                                  row * sizeof(__half), hipMemcpyDeviceToDevice,
                                  stream_),
                   "final expert row", error_msg)) {
          return false;
        }
        moe_pending_ = true;
      }
      return ok && JoinSide(error_msg) &&
             (!reduce || AllReduce(out + offset, 1, error_msg));
    } catch (...) {
      UseScratch(base);
      throw;
    }
  }
  return MoeExperts(l, x, out, n_tokens, error_msg) && JoinSide(error_msg) &&
         (!reduce || AllReduce(out, n_tokens, error_msg));
}

bool Executor::JoinSide(std::string* error_msg) const {
  if (!side_pending_)
    return true;
  side_pending_ = false;
  return Check(hipStreamWaitEvent(stream_, side_done_, 0),
               "side stream join wait", error_msg);
}

bool Executor::WmmaExperts(const DeviceLayer& l, std::uint32_t n_tokens) const {
  const Config& c = config();
  return ExpertMatrixRows(n_tokens) &&
         (l.ffn_gate_exps.type == GgmlType::kQ4_K ||
          l.ffn_gate_exps.type == GgmlType::kQ5_K ||
          l.ffn_gate_exps.type == GgmlType::kQ8_0) &&
         l.ffn_up_exps.type == l.ffn_gate_exps.type &&
         (l.ffn_down_exps.type == GgmlType::kQ5_1 ||
          l.ffn_down_exps.type == GgmlType::kQ8_0) &&
         c.hidden_size % 256 == 0 && c.expert_ff % 64 == 0;
}

bool Executor::MoeExperts(const DeviceLayer& l, const float* x, float* out,
                          std::uint32_t n_tokens,
                          std::string* error_msg) const {
  const Config& c = config();
  const std::uint32_t used = c.num_experts_used;
  const std::uint32_t slots = n_tokens * used;
  // One host holds each expert's full intermediate width; a TP2 rank holds its
  // share of every expert.
  const std::uint32_t expert_ff = l.ffn_gate_exps.rows;
  if (!RouteHints(n_tokens, error_msg)) {
    return false;
  }
  // Tiled batches take the WMMA route: assignments compacted by expert
  // into 16-row padded buckets, token rows narrowed to F16 once, then the
  // F16 matrix-core GEMM per (expert, row tile).
  const bool wmma_experts = WmmaExperts(l, n_tokens);
  if (wmma_experts) {
    RoutedCompact(s_.ids, s_.expert_counts, s_.routed_bounds, s_.routed_cursors,
                  s_.rows_token, s_.rows_slot, n_tokens, used, c.num_experts,
                  stream_);
    // The GEMMs read F16 token rows: the router's F16 GEMM (or the mix)
    // usually left them in s_.x_half already.
    if (!(half_src_ == x && half_rows_ == n_tokens &&
          half_cols_ == c.hidden_size && !half_bf16_)) {
      NarrowActivations(x, s_.x_half, false,
                        static_cast<std::size_t>(n_tokens) * c.hidden_size,
                        stream_);
      half_src_ = x;
      half_rows_ = n_tokens;
      half_cols_ = c.hidden_size;
      half_bf16_ = false;
    }
    const auto* x_half = static_cast<const __half*>(s_.x_half);
    // Prefill pairs the gate/up projections and applies SwiGLU without
    // materializing the gate; decode-time batches keep separate projections.
    auto* up_half = reinterpret_cast<__half*>(s_.up_e);
    const WeightType gate_type =
        l.ffn_gate_exps.type == GgmlType::kQ5_K   ? WeightType::kQ5_K
        : l.ffn_gate_exps.type == GgmlType::kQ8_0 ? WeightType::kQ8_0
                                                  : WeightType::kQ4_K;
    const bool gated_ok =
        routed_wide_tiles_ != 0
            ? RoutedGatedF16Gemm(l.ffn_gate_exps.data, l.ffn_up_exps.data,
                                 gate_type, x_half, s_.routed_tiles,
                                 routed_wide_tiles_, 128, s_.routed_bounds,
                                 s_.rows_token, s_.rows_slot, up_half,
                                 expert_ff, c.hidden_size, stream_)
            : (RoutedF16Gemm(l.ffn_gate_exps.data, gate_type, x_half,
                             s_.routed_tiles, routed_n_tiles_,
                             routed_tile_rows_, s_.routed_bounds, s_.rows_token,
                             s_.rows_slot, nullptr, s_.gate_e, nullptr,
                             expert_ff, c.hidden_size, stream_) &&
               RoutedF16Gemm(l.ffn_up_exps.data, gate_type, x_half,
                             s_.routed_tiles, routed_n_tiles_,
                             routed_tile_rows_, s_.routed_bounds, s_.rows_token,
                             s_.rows_slot, s_.gate_e, nullptr, up_half,
                             expert_ff, c.hidden_size, stream_));
    if (!gated_ok) {
      AssignError(
          error_msg,
          "routed F16 gate/up GEMM failed: tokens=" + std::to_string(n_tokens) +
              " rows=" + std::to_string(expert_ff) +
              " cols=" + std::to_string(c.hidden_size) +
              " tiles=" + std::to_string(routed_n_tiles_) +
              " pair_tiles=" + std::to_string(routed_wide_tiles_) +
              " pair_rows=" + std::to_string(128) +
              " tile_rows=" + std::to_string(routed_tile_rows_));
      return false;
    }
    const WeightType down_type = l.ffn_down_exps.type == GgmlType::kQ8_0
                                     ? WeightType::kQ8_0
                                     : WeightType::kQ5_1;
    // Prefill takes the gate/up map's 128-token tiles: each wave decodes its
    // rows' weights once for up to 128 tokens.
    const bool wide_down = routed_wide_tiles_ != 0;
    // The down projection's rows are F16 too: the epilogue reads half the
    // bytes of the largest routed intermediate.
    if (!RoutedF16Gemm(l.ffn_down_exps.data, down_type, up_half,
                       s_.routed_tiles,
                       wide_down ? routed_wide_tiles_ : routed_n_tiles_,
                       wide_down ? 128 : routed_tile_rows_, s_.routed_bounds,
                       s_.rows_slot, s_.rows_slot, nullptr, nullptr,
                       reinterpret_cast<__half*>(s_.down_e), c.hidden_size,
                       expert_ff, stream_)) {
      AssignError(error_msg, "routed F16 down GEMM failed");
      return false;
    }
  } else {
    if (!GatedExperts(l.ffn_gate_exps, l.ffn_up_exps, x, s_.ids, s_.gate_e,
                      n_tokens, used, error_msg)) {
      return false;
    }
    // The down projection sees one (token, slot) row per expert id.
    if (!Experts(l.ffn_down_exps, s_.gate_e, s_.ids, s_.down_e, slots, 1,
                 n_tokens, error_msg)) {
      return false;
    }
  }
  // The epilogue reads the shared expert's output.
  if (!JoinSide(error_msg))
    return false;
  if (wmma_experts) {
    // The combine that follows folds this epilogue into its own pass when
    // it takes the F16 route (Combine); otherwise it runs here. Distributed TP
    // must materialize the epilogue before its output all-reduce.
    moe_pending_ = out == s_.block_out && model_->tp_world_size() == 1;
    if (!moe_pending_) {
      MoeEpilogueVec4F16(reinterpret_cast<const __half*>(s_.down_e), s_.weights,
                         s_.shexp_out, s_.router + c.num_experts,
                         c.num_experts + 1, out, n_tokens, used, c.hidden_size,
                         stream_);
    }
  } else if (MatrixRows(n_tokens)) {
    MoeEpilogueVec4(s_.down_e, s_.weights, s_.shexp_out,
                    s_.router + c.num_experts, c.num_experts + 1, out, n_tokens,
                    used, c.hidden_size, stream_);
  } else {
    MoeEpilogue(s_.down_e, s_.weights, s_.shexp_out, s_.router + c.num_experts,
                c.num_experts + 1, out, n_tokens, used, c.hidden_size, stream_);
  }
  return true;
}

bool Executor::CopyTrunkHidden(const Session& session, std::span<float> hidden,
                               std::string* error_msg) const {
  if (!session.mtp_enabled_ || session.owner_ != this ||
      session.position_ == 0 || hidden.empty() ||
      hidden.size() % config().HcDim() != 0 ||
      hidden.size() / config().HcDim() >
          std::min(session.position_, options_.max_speculative)) {
    AssignError(error_msg, "invalid trunk hidden diagnostic input");
    return false;
  }
  return Check(hipMemcpyAsync(hidden.data(), session.mtp_.target_hidden,
                              hidden.size_bytes(), hipMemcpyDeviceToHost,
                              stream_),
               "trunk hidden download", error_msg) &&
         Check(hipStreamSynchronize(stream_), "trunk hidden", error_msg);
}

bool Executor::MtpHead(const DeviceMixer& head, const float* res, bool token,
                       bool candidates, const Session* draft,
                       std::string* error_msg) const {
  const DeviceTensor& output = model_->output();
  const std::uint32_t prefix = model_->draft_output().rows;
  const std::uint32_t rows =
      draft != nullptr ? prefix + kMtpDraftExtraRows : output.rows;
  if (!HcMix(head, res, false, s_.mixed, nullptr, 1, error_msg)) {
    return false;
  }
  // A greedy draft returns its argmax and normalized confidence. Under TP
  // each rank scores half of the vocabulary and the two candidates cross in
  // one all-reduce row, held in the logits buffer's unused second half. A
  // request-vocabulary draft is scored whole on both ranks alike.
  const std::uint32_t half = output.rows / 2;
  const std::size_t width = config().hidden_size;
  if (draft == nullptr && token && !candidates &&
      model_->tp_world_size() == 2 && output.type == GgmlType::kQ8_0 &&
      output.cols % 32 == 0 && output.rows % 2 == 0 && half >= width) {
    const std::uint32_t rank = model_->tp_rank();
    DeviceTensor part = output;
    part.rows = half;
    part.data = static_cast<std::uint8_t*>(output.data) +
                static_cast<std::size_t>(rank) * half * (output.cols / 32) * 34;
    float* exchange = s_.logits + half;
    if (!Dense(part, s_.mixed, s_.logits, 1, error_msg)) {
      return false;
    }
    SplitArgmaxPart(s_.logits, s_.mtp_argmax, exchange,
                    static_cast<std::uint32_t>(width), half, rank * half, rank,
                    stream_);
    SplitArgmaxConfidencePart(s_.logits, exchange, half, rank, stream_);
    if (!AllReduce(exchange, 1, error_msg)) {
      return false;
    }
    SplitArgmaxConfidenceFinish(exchange, s_.mtp_token, stream_);
    return Check(
        hipMemcpyAsync(mtp_token_host_, s_.mtp_token, 2 * sizeof(std::int32_t),
                       hipMemcpyDeviceToHost, stream_),
        "draft token download", error_msg);
  }
  // Restore the original complete subset logits before selection. Copying
  // the two halves retains the ordinary confidence reduction order and bits;
  // exchanging only local softmax totals would change rounding at policy gates.
  const std::uint32_t subset_half = rows / 2;
  const bool gather_subset =
      draft != nullptr && token && !candidates && options_.draft_head_gather &&
      model_->tp_world_size() == 2 && output.type == GgmlType::kQ8_0 &&
      model_->draft_output().type == output.type &&
      model_->draft_output().cols == output.cols && output.cols % 32 == 0 &&
      rows % 2 == 0 && prefix > subset_half;
  if (gather_subset) {
    const std::uint32_t rank = model_->tp_rank();
    if (rank > 1) {
      AssignError(error_msg, "draft head gather rank out of range");
      return false;
    }
    DeviceTensor part = model_->draft_output();
    const std::uint32_t first = rank * subset_half;
    part.rows = std::min(subset_half, prefix - first);
    part.data = static_cast<std::uint8_t*>(part.data) +
                std::size_t{first} * (part.cols / 32) * 34;
    if (!Dense(part, s_.mixed, s_.logits, 1, error_msg)) {
      return false;
    }
    if (rank == 1) {
      if (!Dense(DraftTable(*draft), s_.mixed, s_.logits + part.rows, 1,
                 error_msg)) {
        return false;
      }
      MaskDraftLogits(s_.logits + part.rows, draft->mtp_.draft_ids,
                      kMtpDraftExtraRows, stream_);
    }
    if (!options_.draft_head_gather(s_.logits, subset_half, 1, stream_,
                                    error_msg)) {
      return false;
    }
  } else if (!(draft != nullptr
                   ? DraftLogits(*draft, s_.mixed, s_.logits, error_msg)
                   : Dense(output, s_.mixed, s_.logits, 1, error_msg))) {
    return false;
  }
  const auto count = std::min<std::uint32_t>(rows, kMtpCandidates);
  if (candidates) {
    MtpTopCandidates(s_.logits, s_.mtp_ids, s_.mtp_scratch_ids, s_.mtp_scores,
                     rows, stream_);
    if (draft != nullptr)
      RemapDraftIds(s_.mtp_ids, count, prefix, draft->mtp_.draft_ids,
                    kMtpDraftExtraRows, stream_);
  }
  if (token) {
    Argmax(s_.logits, s_.mtp_argmax, s_.mtp_token, 1, rows, stream_);
    ArgmaxConfidence(s_.logits, s_.mtp_token, rows, stream_);
    if (draft != nullptr)
      RemapDraftIds(reinterpret_cast<std::uint32_t*>(s_.mtp_token), 1, prefix,
                    draft->mtp_.draft_ids, kMtpDraftExtraRows, stream_);
    if (!Check(hipMemcpyAsync(mtp_token_host_, s_.mtp_token,
                              2 * sizeof(std::int32_t), hipMemcpyDeviceToHost,
                              stream_),
               "draft token download", error_msg)) {
      return false;
    }
  }
  if (candidates) {
    static_assert(offsetof(MtpCandidateLogits, logits) ==
                  kMtpCandidates * sizeof(std::uint32_t));
    const auto bytes =
        offsetof(MtpCandidateLogits, logits) + count * sizeof(float);
    if (!Check(hipMemcpyAsync(mtp_candidates_host_, s_.mtp_ids, bytes,
                              hipMemcpyDeviceToHost, stream_),
               "draft candidates download", error_msg)) {
      return false;
    }
  }
  return true;
}

bool Executor::Run(Session& session, std::uint64_t key, bool graph,
                   const std::function<bool()>& body, std::string* error_msg,
                   bool synchronize) const {
  // Host-driven communication is not graph-safe yet. Keep the distributed
  // path eager until the communicator has an explicit capture protocol.
  if (model_->tp_world_size() > 1) {
    bool ok = body();
    if (ok) {
      session.warmed_.insert(key);
      ok = !synchronize || Drain("forward", error_msg);
    }
    if (!ok && options_.abort) {
      options_.abort(error_msg != nullptr ? *error_msg : std::string{});
    }
    return ok;
  }
  // A batch shape runs eagerly once before it is captured: the first pass
  // grows the GEMM tier's arena, which capture forbids.
  if (graph && session.warmed_.contains(key)) {
    hipGraphExec_t exec = nullptr;
    bool enqueued = false;
    if (const auto it = session.graphs_.find(key);
        it != session.graphs_.end()) {
      exec = it->second;
    } else {
      // A warmed target shape may need its first graph or a replacement
      // after rollback storage was released. Queue this pass first, then
      // record identical commands while the GPU executes it. Short prefix
      // and draft graphs keep their existing route. No second pass is launched.
      if (synchronize && (key & (std::uint64_t{1} << 40)) == 0) {
        auto dispatch = std::tie(
            moe_pending_, defer_residual_, res_deferred_, shexp_half_ready_,
            q8t_src_, q8t_rows_, q8t_cols_, half_src_, half_rows_, half_cols_,
            half_bf16_, xn_half_, inject_parts_, inject_fused_, q8_slot_,
            xn_q8_ready_, mixed_q8_ready_, pending_combine_);
        const auto before = std::apply(
            [](const auto&... fields) { return std::make_tuple(fields...); },
            dispatch);
        if (!body())
          return false;
        // Producer readiness and alternating scratch addresses must match
        // the executed pass when the graph records its kernel arguments.
        dispatch = before;
        enqueued = true;
      }
      hipGraph_t captured = nullptr;
      // Frozen peer sessions can copy snapshots on independent nonblocking
      // streams while the scheduler records this session's decode graph.
      if (!Check(
              hipStreamBeginCapture(stream_, hipStreamCaptureModeThreadLocal),
              "graph capture", error_msg)) {
        return false;
      }
      const bool ok = body();
      if (!Check(hipStreamEndCapture(stream_, &captured), "graph capture end",
                 error_msg) ||
          !ok) {
        if (captured != nullptr) {
          (void)hipGraphDestroy(captured);
        }
        return false;
      }
      const bool instantiated =
          Check(hipGraphInstantiate(&exec, captured, nullptr, nullptr, 0),
                "graph instantiate", error_msg);
      (void)hipGraphDestroy(captured);
      if (!instantiated) {
        return false;
      }
      session.graphs_.emplace(key, exec);
    }
    if (!enqueued &&
        !Check(hipGraphLaunch(exec, stream_), "graph launch", error_msg)) {
      return false;
    }
  } else {
    if (!body()) {
      return false;
    }
    session.warmed_.insert(key);
  }
  return !synchronize || Drain("forward", error_msg);
}

bool Executor::Forward(Session& session, std::span<const std::int32_t> tokens,
                       std::uint32_t n_logits, float* logits, ForwardMode mode,
                       std::string* error_msg, PrefillCheckpoint* checkpoint,
                       std::span<const std::int32_t> next) const {
  // Only this call's PLE layer may start the prefetch of `next`.
  struct NextHint {
    std::span<const std::int32_t>& hint;
    ~NextHint() { hint = {}; }
  } next_hint{prefetch_next_};
  if (mode == ForwardMode::kPrefill) {
    prefetch_next_ = next;
  }
  const bool speculative = mode == ForwardMode::kVerify;
  PrefillPhase phase(mode == ForwardMode::kPrefill);
  selected_logits_ = nullptr;
  DropReadyQ8();
  const Config& c = config();
  const auto n = static_cast<std::uint32_t>(tokens.size());
  const bool prefill = mode == ForwardMode::kPrefill;
  // A capture currently owns one pass's feature buffer. Paired TP prefill
  // needs distinct lane offsets before it can use the same callback.
  const std::uint32_t lead =
      prefill && !session.target_feature_capture_ ? PairLead(n) : 0;
  const bool pair = lead != 0;
  if (checkpoint && (mode != ForwardMode::kPrefill ||
                     checkpoint->source != &session || checkpoint->tokens > n ||
                     checkpoint->state->position_ !=
                         session.position_ + checkpoint->tokens)) {
    AssignError(error_msg, "prefill checkpoint does not match this pass");
    return false;
  }
  if (checkpoint && pair) {
    AssignError(error_msg, "a paired prefill chunk takes no checkpoint");
    return false;
  }
  const auto prefill_limit =
      session.target_feature_capture_ ? options_.max_batch : PrefillChunk();
  if (n == 0 || n > (prefill ? prefill_limit : options_.max_batch) ||
      (speculative && n > options_.max_speculative)) {
    AssignError(error_msg, "token batch is empty or exceeds the batch limit");
    return false;
  }
  // A pair's logits come from its second batch.
  if (n_logits > (pair ? n - lead : n) || n_logits > options_.max_logit_rows) {
    AssignError(error_msg, "requested logit rows exceed the batch or limit");
    return false;
  }
  if (session.owner_ != this || session.position_ + n > session.max_context_) {
    AssignError(error_msg, "session context is full");
    return false;
  }
  for (auto t : tokens) {
    if (t < 0 || static_cast<std::uint32_t>(t) >= c.vocab_size) {
      AssignError(error_msg, "token out of range");
      return false;
    }
  }
  const std::uint32_t start_pos = session.position_;
  if (!session.CheckCancellation(error_msg))
    return false;
  if (session.mtp_enabled_ && prefill_phase &&
      session.mtp_.position != start_pos) {
    AssignError(error_msg,
                "MTP must consume the preceding frontier before prefill");
    return false;
  }
  if (speculative && !EnsureRollback(session, n - 1, error_msg))
    return false;
  // Failed eager/captured work can still be reading pinned inputs. Drain it
  // before another request reuses those buffers; successful forwards already
  // synchronize below and need no additional wait.
  struct PinnedInputGuard {
    hipStream_t stream;
    bool completed{false};
    std::function<void()> discard;
    ~PinnedInputGuard() {
      discard();
      if (!completed)
        (void)hipStreamSynchronize(stream);
    }
  } pinned_inputs{stream_, false, [this] { DiscardPle(); }};
  // Start the disk rows before protecting checkpoint rows, which can commit
  // device pages: layer 0 alone cannot hide the whole read.
  if (session.continuation_hooks_) {
    const auto end =
        session.position_ + static_cast<std::uint32_t>(tokens.size());
    session.continuation_hooks_->BeforeWrite(
        false, session.position_, end, session.blocks_,
        end > c.indexer_top_k ? end / c.compress_ratio : session.blocks_);
  }
  const auto ngram = session.ngram_;
  if (c.ple_layer >= 0) {
    if (ngram_ == nullptr) {
      AssignError(error_msg, "n-gram table is not open");
      return false;
    }
    if (!PleFetch(session, tokens, speculative, error_msg)) {
      return false;
    }
  }
  try {
    session.PreserveSnapshots(session.position_, session.mtp_.position);
  } catch (...) {
    // The forward never ran; leave the n-gram window where it was.
    DiscardPle();
    session.ngram_ = ngram;
    throw;
  }
  ++session.mutation_epoch_;
  session.spec_base_ = start_pos;
  session.spec_tokens_ = speculative ? n : 0;
  // Everything the launched work reads from the host sits in pinned
  // buffers the graph nodes point at: tokens, the control block (positions
  // the kernels read on the device) and the n-gram rows.
  std::copy(tokens.begin(), tokens.end(), tokens_host_);
  control_host_->position = start_pos;
  control_host_->blocks = session.blocks_;
  control_host_->mtp_position = session.mtp_.position;
  control_host_->mtp_blocks = session.mtp_.blocks;
  control_host_->hidden_row = -1;
  if (pair) {
    const bool ok =
        ForwardPair(session, tokens, lead, n_logits, logits, error_msg);
    pinned_inputs.completed = ok;
    return ok;
  }
  // Sparse selection only changes the result once a query can see more
  // than the token budget; every layer of this model shares one ratio.
  const bool sparse = c.compress_ratio > 0 && start_pos + n > c.indexer_top_k;
  const std::uint32_t complete =
      c.compress_ratio > 0 ? (start_pos + n) / c.compress_ratio : 0;
  const std::uint32_t pool_grid =
      sparse && complete > session.blocks_ ? complete - session.blocks_ : 0;
  // Decode-sized batches replay as graphs; a pooling backlog (the first
  // batch past the budget) needs the wider eager grid.
  const std::uint32_t graph_pool_grid = n / std::max(c.compress_ratio, 1u) + 1;
  const bool graph = !prefill_phase && n <= kVecBatch &&
                     pool_grid <= graph_pool_grid &&
                     session.position_ >= session.VisionLayout().PrefixLength();
  const std::uint64_t key = static_cast<std::uint64_t>(n) |
                            (static_cast<std::uint64_t>(n_logits) << 16) |
                            (static_cast<std::uint64_t>(speculative) << 32) |
                            (static_cast<std::uint64_t>(sparse) << 33) |
                            (std::uint64_t{logits != nullptr} << 34);
  // PLE first consumes the disk rows at its injection layer. Queue the
  // preceding layers before waiting, including on captured graph replay.
  // Both pieces use the same stream and arithmetic as the unsplit graph.
  // The distributed path never captures (see Run); its mixers wait for the
  // rows at the PLE layer themselves, so it neither splits nor waits here.
  const bool ple_split = graph && model_->tp_world_size() == 1;
  const std::uint32_t first_layer =
      ple_split && c.ple_layer > 0 ? static_cast<std::uint32_t>(c.ple_layer)
                                   : 0;
  if (first_layer > 0) {
    const auto prefix = [&] {
      return ForwardBody(session, n, 0, false, speculative, sparse, start_pos,
                         graph_pool_grid, 0, first_layer, error_msg);
    };
    constexpr std::uint64_t kPrefixKey = std::uint64_t{1} << 35;
    if (!Run(session, key | kPrefixKey, graph, prefix, error_msg, false)) {
      return false;
    }
  }
  const auto body = [&] {
    return ForwardBody(session, n, n_logits, logits != nullptr, speculative,
                       sparse, start_pos, graph ? graph_pool_grid : pool_grid,
                       first_layer, c.num_layers, error_msg, checkpoint,
                       ple_split);
  };
  // The prefix is already queued. Wait once before the suffix so recording
  // its graph can reuse these pinned rows while the eager pass executes.
  if (ple_split && ple_pending_ && !WaitPle(error_msg)) {
    return false;
  }
  if (!Run(session, key, graph, body, error_msg)) {
    return false;
  }
  if (n_logits > 0 && logits != nullptr) {
    std::copy_n(logits_host_, static_cast<std::size_t>(n_logits) * c.vocab_size,
                logits);
  }

  session.position_ += n;
  if (sparse) {
    session.blocks_ = complete;
  }
  if (session.mtp_enabled_ && prefill_phase && n > 1) {
    // Every successor except the last one is already known. Consume it while
    // the trunk residual is still in shared scratch. MtpBody reads that
    // residual into xn before reusing res for the predictor output.
    PrefillPhase draft_phase(false);
    if (!MtpForward(session, tokens.subspan(1), 0, {.kv_only = true}, error_msg,
                    s_.res))
      return false;
  }
  pinned_inputs.completed = true;
  return true;
}

bool Executor::ForwardBody(Session& session, std::uint32_t n,
                           std::uint32_t n_logits, bool download_logits,
                           bool speculative, bool sparse,
                           std::uint32_t start_pos, std::uint32_t pool_grid,
                           std::uint32_t first_layer, std::uint32_t end_layer,
                           std::string* error_msg,
                           PrefillCheckpoint* checkpoint,
                           bool embeddings_ready) const {
  const Config& c = config();
  if (first_layer == 0) {
    if (!Check(hipMemcpyAsync(session.control_, control_host_,
                              sizeof(Session::Control), hipMemcpyHostToDevice,
                              stream_),
               "control upload", error_msg) ||
        !Check(hipMemcpyAsync(s_.tokens, tokens_host_, n * sizeof(std::int32_t),
                              hipMemcpyHostToDevice, stream_),
               "token upload", error_msg)) {
      return false;
    }
    EmbedTokens(model_->token_embd().data, SmallType(model_->token_embd().type),
                s_.tokens, s_.res, n, c.hidden_size, c.hc_count, stream_);
    session.vision_input_.Inject(s_.res, start_pos, n, c.hidden_size,
                                 c.hc_count, stream_);
  }
  const TrunkBatch batch{.n = n,
                         .start_pos = start_pos,
                         .pool_grid = pool_grid,
                         .sparse = sparse,
                         .speculative = speculative,
                         .control = session.control_,
                         .emb_row = 0};
  bool normed = false;  ///< xn holds the next mixer's grouped norm of res
  for (std::uint32_t il = first_layer; il < end_layer; ++il) {
    if (!options_.all_reduce) {
      if (!session.CheckCancellation(error_msg))
        return false;
      const DeviceLayer& l = model_->layers()[il];
      if (c.IsPleLayer(il) && !Ple(l, session, n, s_.res, speculative,
                                   error_msg, embeddings_ready, checkpoint)) {
        return false;
      }
      // Both stacked SSM projections consume the same F16 input. Avoid writing
      // unused F32/Q8 copies when the wide mixer can supply that input
      // directly.
      const bool half_only = WidePrefill(n) && n <= options_.max_batch &&
                             l.linear && DenseF16Route(l.ssm_in, n) &&
                             l.ssm_alpha_beta.type == GgmlType::kF16 &&
                             l.ssm_alpha_beta.cols == l.ssm_in.cols;
      if (!HcMix(l.hc_attn, s_.res, normed, s_.mixed, s_.inject, n, error_msg,
                 half_only)) {
        return false;
      }
      // The last target layer's query outputs have no later cache consumer.
      // Preserve all K/V/indexer rows and the final query's original tile.
      const bool last_attention = WidePrefill(n) && !session.mtp_enabled_ &&
                                  il + 1 == c.num_layers && n_logits == 1 &&
                                  checkpoint == nullptr;
      if (l.linear) {
        const auto capture =
            checkpoint
                ? GdnCheckpoint{checkpoint->state->linear_[il].state,
                                checkpoint->state->linear_[il].conv_state,
                                checkpoint->tokens}
                : GdnCheckpoint{};
        if (!LinearAttention(l, session.linear_[il], s_.mixed, s_.block_out, n,
                             speculative, error_msg, false, true, capture)) {
          return false;
        }
      } else if (!Attention(l, session.attention_[il], s_.mixed, s_.block_out,
                            n, &session.control_->position,
                            &session.control_->blocks, start_pos, pool_grid,
                            session.max_context_, sparse, error_msg,
                            last_attention, false, true,
                            checkpoint ? checkpoint->tokens : 0)) {
        return false;
      }

      const float* next_norm =
          il + 1 < c.num_layers
              ? (c.IsPleLayer(il + 1)
                     ? nullptr
                     : model_->layers()[il + 1].hc_attn.norm.f32())
              : nullptr;
      const float* next_inject =
          next_norm != nullptr ? InjectWeights(model_->layers()[il + 1].hc_attn)
                               : nullptr;
      // Cache updates precede the FFN. Without MTP, only requested head rows
      // and the checkpoint frontier consume the final layer's residual.
      // Keep aligned tiles and at least 96 rows to retain the wide arithmetic.
      const auto needed = std::max(
          {96U, n_logits, checkpoint ? n - checkpoint->tokens + 1 : 0U});
      const auto skipped = prefill_phase && !session.mtp_enabled_ &&
                                   il + 1 == c.num_layers && n > needed
                               ? (n - needed) / 128 * 128
                               : 0U;
      const auto finish = [&](std::uint32_t rows) {
        defer_residual_ = WmmaExperts(l, rows);
        // The wide FFN reads the mix only through its F16 rows (router, routed
        // experts) and tiled Q8 rows (shared expert).
        const bool no_f32 = prefill_phase && defer_residual_ &&
                            rows <= options_.max_batch &&
                            l.router.type == GgmlType::kF16 &&
                            l.shexp_gate.type == GgmlType::kQ8_0 &&
                            l.shexp_up.type == GgmlType::kQ8_0;
        Combine(s_.res, l.hc_ffn.norm.f32(), rows, InjectWeights(l.hc_ffn));
        if (!HcMix(l.hc_ffn, s_.res, true, s_.mixed, s_.inject, rows, error_msg,
                   false, no_f32) ||
            !Moe(l, s_.mixed, s_.block_out, rows, error_msg))
          return false;
        Combine(s_.res, next_norm, rows, next_inject);
        return true;
      };
      if (skipped != 0) {
        struct RestoreScratch {
          const Executor* executor;
          Scratch scratch;
          ~RestoreScratch() { executor->UseScratch(scratch); }
        } restore{this, s_};
        auto tail = RowScratch(s_, skipped);
        tail.inject =
            s_.inject + std::size_t{skipped} * c.hc_count * inject_parts_;
        UseScratch(tail);
        if (!finish(n - skipped))
          return false;
      } else if (!finish(n)) {
        return false;
      }
      normed = next_norm != nullptr;
      if (session.target_feature_capture_)
        session.target_feature_capture_(il, s_.res, n, stream_);
      continue;
    }
    if (!session.CheckCancellation(error_msg)) {
      return false;
    }
    // The last target layer's query outputs have no later cache consumer.
    // Preserve all K/V/indexer rows and the final query's original tile.
    const bool last_attention = WidePrefill(n) && !session.mtp_enabled_ &&
                                il + 1 == c.num_layers && n_logits == 1 &&
                                checkpoint == nullptr;
    if (!MixerPart(session, il, batch, normed, true, error_msg, checkpoint,
                   last_attention)) {
      return false;
    }
    // Cache updates precede the FFN. Without MTP, only requested head rows
    // and the checkpoint frontier consume the final layer's residual.
    // Keep aligned tiles and at least 96 rows to retain the wide arithmetic.
    // Both TP ranks skip the same rows, so their sums stay aligned.
    const auto needed =
        std::max({96U, n_logits, checkpoint ? n - checkpoint->tokens + 1 : 0U});
    const auto skipped = prefill_phase && !session.mtp_enabled_ &&
                                 il + 1 == c.num_layers && n > needed
                             ? (n - needed) / 128 * 128
                             : 0U;
    if (skipped != 0) {
      struct RestoreScratch {
        const Executor* executor;
        Scratch scratch;
        ~RestoreScratch() { executor->UseScratch(scratch); }
      } restore{this, s_};
      auto tail = RowScratch(s_, skipped);
      tail.inject =
          s_.inject + std::size_t{skipped} * c.hc_count * inject_parts_;
      UseScratch(tail);
      if (!MoePart(il, n - skipped, true, error_msg)) {
        return false;
      }
      normed = LayerBack(il, n - skipped);
    } else {
      if (!MoePart(il, n, true, error_msg)) {
        return false;
      }
      normed = LayerBack(il, n);
    }
    if (session.target_feature_capture_)
      session.target_feature_capture_(il, s_.res, n, stream_);
  }
  if (end_layer < c.num_layers) {
    return true;
  }
  if (checkpoint) {
    if (checkpoint->hidden_rows != 0 &&
        !Check(hipMemcpyAsync(checkpoint->state->mtp_.target_hidden,
                              s_.res + std::size_t{checkpoint->tokens -
                                                   checkpoint->hidden_rows} *
                                           c.HcDim(),
                              std::size_t{checkpoint->hidden_rows} * c.HcDim() *
                                  sizeof(float),
                              hipMemcpyDeviceToDevice, stream_),
               "checkpoint hidden rows", error_msg))
      return false;
    PrefillPhase head_phase(false);
    if (!HcMix(model_->hc_head(),
               s_.res + std::size_t{checkpoint->tokens - 1} * c.HcDim(), false,
               s_.mixed, nullptr, 1, error_msg) ||
        !Dense(model_->output(), s_.mixed, s_.logits, 1, error_msg) ||
        !Check(hipMemcpyAsync(checkpoint->logits.data(), s_.logits,
                              std::size_t{c.vocab_size} * sizeof(float),
                              hipMemcpyDeviceToHost, stream_),
               "checkpoint logits", error_msg))
      return false;
  }
  // Prefill catches up immediately from shared scratch. Only the short tail
  // needed across calls belongs to this session.
  const auto kept = std::min(
      checkpoint && checkpoint->tokens < n ? n - checkpoint->tokens : n,
      options_.max_speculative);
  if (session.mtp_enabled_ &&
      !Check(hipMemcpyAsync(
                 session.mtp_.target_hidden,
                 s_.res + static_cast<std::size_t>(n - kept) * c.HcDim(),
                 static_cast<std::size_t>(kept) * c.HcDim() * sizeof(float),
                 hipMemcpyDeviceToDevice, stream_),
             "hidden keep", error_msg)) {
    return false;
  }
  if (n_logits > 0) {
    // Preserve the trunk mode before selecting decode arithmetic for its head.
    const bool target_head_decode = !prefill_phase;
    PrefillPhase head_phase(false);
    // Only the requested tail needs the head's normalization.
    const std::size_t skip = static_cast<std::size_t>(n - n_logits);
    const DeviceMixer& head = model_->hc_head();
    if (!HcMix(head, s_.res + skip * c.HcDim(), false, s_.mixed, nullptr,
               n_logits, error_msg)) {
      return false;
    }
    const auto& output = model_->output();
    // Share the existing Q8 output rows for native two-row MTP or guarded
    // four/eight-row external verification. The latter fits the transport
    // capacity already required for max_batch hidden rows at model setup.
    // AR, prefill and other shapes keep their route. Reconstruct every logit.
    const bool gather_head =
        target_head_decode &&
        ((session.mtp_enabled_ && n_logits == 2) ||
         (speculative &&
          ((dflash_head_probe::enabled && session.mtp_enabled_ &&
            n_logits >= 3 && n_logits <= 8) ||
           (session.target_feature_capture_ &&
            (n_logits == 4 || n_logits == 8))) &&
          std::size_t{output.rows / 2} * n_logits <=
              std::size_t{options_.max_batch} * c.hidden_size)) &&
        model_->tp_world_size() == 2 && options_.target_head_gather &&
        output.type == GgmlType::kQ8_0 && output.rows == 248320 &&
        output.cols == 2560 && c.hidden_size == 2560;
    if (gather_head) {
      auto part = output;
      part.rows /= 2;
      const auto rank = model_->tp_rank();
      if (rank >= 2) {
        AssignError(error_msg, "target head gather rank out of range");
        return false;
      }
      part.data = static_cast<std::uint8_t*>(part.data) +
                  std::size_t{rank} * part.rows * (part.cols / 32) * 34;
      if (!Dense(part, s_.mixed, s_.logits, n_logits, error_msg) ||
          !options_.target_head_gather(s_.logits, part.rows, n_logits, stream_,
                                       error_msg)) {
        return false;
      }
    } else if (!Dense(output, s_.mixed, s_.logits, n_logits, error_msg)) {
      return false;
    }
    if (target_head_decode && session.mtp_enabled_) {
      std::vector<float> full(std::size_t{n_logits} * c.vocab_size);
      if (hipMemcpyAsync(full.data(), s_.logits, full.size() * sizeof(float),
                         hipMemcpyDeviceToHost, stream_) != hipSuccess ||
          hipStreamSynchronize(stream_) != hipSuccess)
        throw std::runtime_error("diagnostic complete-head capture failed");
      dflash_head_probe::values.push_back(std::move(full));
      dflash_head_probe::rows.push_back(n_logits);
      dflash_head_probe::gathered.push_back(gather_head);
    }
    if (download_logits &&
        !Check(hipMemcpyAsync(logits_host_, s_.logits,
                              static_cast<std::size_t>(n_logits) *
                                  c.vocab_size * sizeof(float),
                              hipMemcpyDeviceToHost, stream_),
               "logits download", error_msg)) {
      return false;
    }
  }
  return true;
}

Executor::Scratch Executor::PairScratch(const Scratch& base) const {
  auto s = base;
  s.res = pair_res_;
  s.block_out = pair_block_out_;
  s.inject = pair_inject_;
  if (config().ple_layer >= 0) {
    s.ple_value = s.block_out;
  }
  if (has_mtp()) {
    s.mtp_res = s.res;
  }
  return s;
}

bool Executor::ForwardPair(Session& session,
                           std::span<const std::int32_t> tokens,
                           std::uint32_t lead, std::uint32_t n_logits,
                           float* logits, std::string* error_msg) const {
  // Forward validated the chunk, bumped the mutation epoch, staged the tokens
  // and the first batch's control, and started the n-gram fetch for both
  // batches. What follows computes what two Forward calls of `lead` rows and
  // the rest compute, with the draft block's catch-up between them.
  // Each batch runs every kernel the same way; only their order changes:
  //
  //   A0 B0 | A1 B1 | ... where Ai is batch A's layer i up to its MoE partial,
  //   then the sum of that partial and the layer's final combine.
  //
  // A's partial crosses the link while B computes the same layer, and B's
  // while A computes the next one. B's layer reads A's state of that layer
  // (KV rows, recurrent state, pooled blocks), which A has written by then.
  const Config& c = config();
  const auto n = static_cast<std::uint32_t>(tokens.size());
  const std::uint32_t n_a = lead;
  const std::uint32_t n_b = n - n_a;
  const std::uint32_t start_a = session.position_;
  const std::uint32_t start_b = start_a + n_a;
  const auto sparse_at = [&](std::uint32_t start, std::uint32_t rows) {
    return c.compress_ratio > 0 && start + rows > c.indexer_top_k;
  };
  const auto complete_at = [&](std::uint32_t start, std::uint32_t rows) {
    return c.compress_ratio > 0 ? (start + rows) / c.compress_ratio : 0;
  };
  const bool sparse_a = sparse_at(start_a, n_a);
  const bool sparse_b = sparse_at(start_b, n_b);
  const std::uint32_t complete_a = complete_at(start_a, n_a);
  const std::uint32_t complete_b = complete_at(start_b, n_b);
  const std::uint32_t blocks_a = session.blocks_;
  const std::uint32_t blocks_b = sparse_a ? complete_a : blocks_a;
  control_host_[1] = control_host_[0];
  control_host_[1].position = start_b;
  control_host_[1].blocks = blocks_b;

  // Each lane runs its layers as parts: a split layer's GDN or attention
  // block, then the rest of the layer to its MoE output. A part that ends in
  // a partial starts its sum and yields to the other lane.
  struct Lane {
    Scratch scratch;
    TrunkBatch batch;
    const std::int32_t* tokens;
    bool normed;
    std::uint32_t inject_parts;
    std::uint32_t part;  ///< the next part to run
    bool pending;        ///< its last part's sum is in flight
  };
  const Scratch base = s_;
  std::array<Lane, 2> lanes{
      Lane{.scratch = base,
           .batch = {.n = n_a,
                     .start_pos = start_a,
                     .pool_grid = sparse_a && complete_a > blocks_a
                                      ? complete_a - blocks_a
                                      : 0,
                     .sparse = sparse_a,
                     .speculative = false,
                     .control = session.control_,
                     .emb_row = 0},
           .tokens = s_.tokens,
           .normed = false,
           .inject_parts = inject_parts_,
           .part = 0,
           .pending = false},
      Lane{.scratch = PairScratch(base),
           .batch = {.n = n_b,
                     .start_pos = start_b,
                     .pool_grid = sparse_b && complete_b > blocks_b
                                      ? complete_b - blocks_b
                                      : 0,
                     .sparse = sparse_b,
                     .speculative = false,
                     .control = pair_control_,
                     .emb_row = n_a},
           .tokens = s_.tokens + n_a,
           .normed = false,
           .inject_parts = inject_parts_,
           .part = 0,
           .pending = false}};
  // Sums finish in the order they started. A failed forward still waits for
  // the exchanges it started, so both ranks' sequences stay aligned.
  std::array<const Lane*, 2> in_flight{};
  std::size_t flying = 0;
  struct Settle {
    const Executor* executor;
    const Scratch& base;
    std::array<const Lane*, 2>& in_flight;
    std::size_t& flying;
    ~Settle() {
      const auto& reduce = executor->options_.split_reduce;
      for (std::size_t i = 0; i < flying; ++i) {
        const Lane& lane = *in_flight[i];
        std::string ignored;
        (void)reduce.finish(lane.scratch.block_out,
                            static_cast<std::size_t>(lane.batch.n) *
                                executor->config().hidden_size * sizeof(float),
                            executor->stream_, &ignored);
      }
      executor->UseScratch(base);
    }
  } settle{this, base, in_flight, flying};
  const auto bytes = [&](const Lane& lane) {
    return static_cast<std::size_t>(lane.batch.n) * c.hidden_size *
           sizeof(float);
  };
  const auto enter = [&](const Lane& lane) {
    UseScratch(lane.scratch);
    inject_parts_ = lane.inject_parts;
  };
  const std::uint32_t parts = 2 * c.num_layers;
  // Runs the lane's parts until one ends in a partial, whose sum it starts.
  const auto advance = [&](Lane& lane) {
    while (lane.part < parts) {
      const std::uint32_t part = lane.part++;
      const std::uint32_t il = part / 2;
      if (part % 2 == 0) {
        if (!session.CheckCancellation(error_msg) ||
            !MixerPart(session, il, lane.batch, lane.normed, false,
                       error_msg)) {
          return false;
        }
        if (!model_->layers()[il].mixer_split) {
          continue;
        }
      } else if (!MoePart(il, lane.batch.n, false, error_msg)) {
        return false;
      }
      if (!options_.split_reduce.start(s_.block_out, bytes(lane), stream_,
                                       error_msg)) {
        return false;
      }
      in_flight[flying++] = &lane;
      lane.inject_parts = inject_parts_;
      lane.pending = true;
      return true;
    }
    return true;
  };
  // Adds the peer's partial of the lane's last part; after a MoE output, the
  // layer's final combine follows.
  const auto finish = [&](Lane& lane) {
    if (flying == 0 || in_flight[0] != &lane) {
      AssignError(error_msg, "prefill pair sums finished out of order");
      return false;
    }
    in_flight[0] = in_flight[1];
    --flying;
    lane.pending = false;
    if (!options_.split_reduce.finish(s_.block_out, bytes(lane), stream_,
                                      error_msg)) {
      return false;
    }
    const std::uint32_t part = lane.part - 1;
    if (part % 2 == 1) {
      if (options_.moe_observer) {
        options_.moe_observer(s_.block_out, bytes(lane), stream_);
      }
      lane.normed = LayerBack(part / 2, lane.batch.n);
    }
    return true;
  };

  if (!Check(hipMemcpyAsync(session.control_, &control_host_[0],
                            sizeof(Session::Control), hipMemcpyHostToDevice,
                            stream_),
             "control upload", error_msg) ||
      !Check(hipMemcpyAsync(pair_control_, &control_host_[1],
                            sizeof(Session::Control), hipMemcpyHostToDevice,
                            stream_),
             "control upload", error_msg) ||
      !Check(hipMemcpyAsync(s_.tokens, tokens_host_, n * sizeof(std::int32_t),
                            hipMemcpyHostToDevice, stream_),
             "token upload", error_msg)) {
    return false;
  }
  for (Lane& lane : lanes) {
    enter(lane);
    EmbedTokens(model_->token_embd().data, SmallType(model_->token_embd().type),
                lane.tokens, s_.res, lane.batch.n, c.hidden_size, c.hc_count,
                stream_);
    session.vision_input_.Inject(s_.res, lane.batch.start_pos, lane.batch.n,
                                 c.hidden_size, c.hc_count, stream_);
    if (!advance(lane)) {
      return false;
    }
  }
  while (lanes[0].pending || lanes[1].pending) {
    for (Lane& lane : lanes) {
      if (!lane.pending) {
        continue;
      }
      enter(lane);
      if (!finish(lane) || !advance(lane)) {
        return false;
      }
    }
  }

  // Batch B's logits, as its own Forward would compute them.
  const std::size_t hc_dim = c.HcDim();
  if (n_logits > 0) {
    PrefillPhase head_phase(false);
    enter(lanes[1]);
    const std::size_t skip = static_cast<std::size_t>(n_b - n_logits);
    if (!HcMix(model_->hc_head(), s_.res + skip * hc_dim, false, s_.mixed,
               nullptr, n_logits, error_msg) ||
        !Dense(model_->output(), s_.mixed, s_.logits, n_logits, error_msg) ||
        (logits != nullptr &&
         !Check(hipMemcpyAsync(logits_host_, s_.logits,
                               static_cast<std::size_t>(n_logits) *
                                   c.vocab_size * sizeof(float),
                               hipMemcpyDeviceToHost, stream_),
                "logits download", error_msg))) {
      return false;
    }
  }
  // The draft block keeps each batch's final rows in turn: A's for the
  // step that bridges the two batches, then B's.
  const auto keep = [&](const Lane& lane) {
    const std::uint32_t kept = std::min(lane.batch.n, options_.max_speculative);
    return Check(hipMemcpyAsync(
                     session.mtp_.target_hidden,
                     lane.scratch.res +
                         static_cast<std::size_t>(lane.batch.n - kept) * hc_dim,
                     static_cast<std::size_t>(kept) * hc_dim * sizeof(float),
                     hipMemcpyDeviceToDevice, stream_),
                 "hidden keep", error_msg);
  };
  if ((session.mtp_enabled_ && !keep(lanes[0])) ||
      !Drain("forward", error_msg)) {
    return false;
  }
  session.position_ = start_b;
  if (sparse_a) {
    session.blocks_ = complete_a;
  }
  if (session.mtp_enabled_) {
    // Catch up over A (hidden rows from A's residual), bridge to B's first
    // token from A's kept final row, keep B's rows, then catch up over B.
    PrefillPhase draft_phase(false);
    enter(lanes[0]);
    const std::uint32_t kept_a = std::min(n_a, options_.max_speculative);
    if (!MtpForward(session, tokens.subspan(1, n_a - 1), 0, {}, error_msg,
                    s_.res) ||
        !MtpForward(session, tokens.subspan(n_a, 1),
                    static_cast<std::int32_t>(kept_a - 1), {}, error_msg) ||
        !keep(lanes[1])) {
      return false;
    }
  }
  ++session.mutation_epoch_;
  session.spec_base_ = start_b;
  session.position_ = start_b + n_b;
  if (sparse_b) {
    session.blocks_ = complete_b;
  }
  if (session.mtp_enabled_ && n_b > 1) {
    PrefillPhase draft_phase(false);
    enter(lanes[1]);
    if (!MtpForward(session, tokens.subspan(n_a + 1), 0, {}, error_msg,
                    s_.res)) {
      return false;
    }
  }
  if (n_logits > 0 && logits != nullptr) {
    // The last MtpForward (or the forward itself) synchronized the stream.
    std::copy_n(logits_host_, static_cast<std::size_t>(n_logits) * c.vocab_size,
                logits);
  }
  return true;
}

bool Executor::MixerPart(Session& session, std::uint32_t il,
                         const TrunkBatch& batch, bool normed, bool reduce,
                         std::string* error_msg, PrefillCheckpoint* checkpoint,
                         bool last_only) const {
  const Config& c = config();
  const DeviceLayer& l = model_->layers()[il];
  const std::uint32_t n = batch.n;
  if (c.IsPleLayer(il) && !Ple(l, session, n, s_.res, batch.speculative,
                               error_msg, false, checkpoint, batch.emb_row)) {
    return false;
  }
  // The rank's stacked SSM projections share the F16 mix, just as in the
  // single-host path. Neither consumes its F32 or tiled Q8 copies.
  const bool half_only = WidePrefill(n) && n <= options_.max_batch &&
                         l.linear && DenseF16Route(l.ssm_in, n) &&
                         l.ssm_alpha_beta.type == GgmlType::kF16 &&
                         l.ssm_alpha_beta.cols == l.ssm_in.cols;
  if (!HcMix(l.hc_attn, s_.res, normed, s_.mixed, s_.inject, n, error_msg,
             half_only)) {
    return false;
  }
  if (l.linear) {
    const auto capture =
        checkpoint ? GdnCheckpoint{checkpoint->state->linear_[il].state,
                                   checkpoint->state->linear_[il].conv_state,
                                   checkpoint->tokens}
                   : GdnCheckpoint{};
    if (!LinearAttention(l, session.linear_[il], s_.mixed, s_.block_out, n,
                         batch.speculative, error_msg, false, true, capture)) {
      return false;
    }
  } else if (!Attention(l, session.attention_[il], s_.mixed, s_.block_out, n,
                        &batch.control->position, &batch.control->blocks,
                        batch.start_pos, batch.pool_grid, session.max_context_,
                        batch.sparse, error_msg, last_only, false, true,
                        checkpoint ? checkpoint->tokens : 0)) {
    return false;
  }
  return !reduce || !l.mixer_split ||
         AllReduce(s_.block_out, n, error_msg, false);
}

bool Executor::MoePart(std::uint32_t il, std::uint32_t n_tokens, bool reduce,
                       std::string* error_msg) const {
  const DeviceLayer& l = model_->layers()[il];
  // Each combine also norms the residual for the mixer that follows it,
  // unless PLE rewrites the residual first.
  Combine(s_.res, l.hc_ffn.norm.f32(), n_tokens, InjectWeights(l.hc_ffn));
  return HcMix(l.hc_ffn, s_.res, true, s_.mixed, s_.inject, n_tokens,
               error_msg) &&
         Moe(l, s_.mixed, s_.block_out, n_tokens, error_msg, false, reduce);
}

bool Executor::LayerBack(std::uint32_t il, std::uint32_t n_tokens) const {
  const Config& c = config();
  const float* next_norm =
      il + 1 < c.num_layers
          ? (c.IsPleLayer(il + 1) ? nullptr
                                  : model_->layers()[il + 1].hc_attn.norm.f32())
          : nullptr;  // the head norms the rows it reads itself
  Combine(
      s_.res, next_norm, n_tokens,
      next_norm ? InjectWeights(model_->layers()[il + 1].hc_attn) : nullptr);
  return next_norm != nullptr;
}

bool Executor::Rollback(Session& session, std::uint32_t keep,
                        std::string* error_msg, float* logits) const {
  const Config& c = config();
  const std::uint32_t n = session.spec_tokens_;
  if (n == 0 || keep == 0 || keep > n) {
    AssignError(error_msg, "rollback outside the pending speculative batch");
    return false;
  }
  if (session.continuation_hooks_ && keep < n) {
    const auto end = session.spec_base_ + keep;
    session.continuation_hooks_->BeforeWrite(
        false, end, session.position_,
        std::min(session.blocks_, end / c.compress_ratio), session.blocks_);
  }
  session.spec_tokens_ = 0;
  if (logits != nullptr &&
      !Check(hipMemcpyAsync(
                 logits_host_,
                 VerificationLogits() +
                     static_cast<std::size_t>(keep - 1) * c.vocab_size,
                 c.vocab_size * sizeof(float), hipMemcpyDeviceToHost, stream_),
             "frontier download", error_msg)) {
    return false;
  }
  if (keep == n && logits == nullptr) {
    return true;
  }
  if (keep < n) {
    const std::size_t conv_elems =
        static_cast<std::size_t>(c.ssm_conv_kernel - 1) *
        model_->trunk_heads().SsmConvChannels();
    const std::size_t slot = keep - 1;
    for (auto& l : session.linear_) {
      if (l.state == nullptr) {
        continue;
      }
      RestoreGdnState(l.state, l.state_snapshots, keep,
                      model_->trunk_heads().ssm_k, model_->trunk_heads().ssm_v,
                      stream_);
      if (!Check(hipGetLastError(), "state rollback", error_msg) ||
          !Check(hipMemcpyAsync(l.conv_state, l.conv_snapshots.rows[slot],
                                conv_elems * sizeof(float),
                                hipMemcpyDeviceToDevice, stream_),
                 "conv rollback", error_msg)) {
        return false;
      }
    }
    if (session.ple_history_ != nullptr) {
      const std::size_t hist =
          static_cast<std::size_t>(c.PleConvHistory()) * c.HcDim();
      if (!Check(hipMemcpyAsync(
                     session.ple_history_, session.ple_snapshots_.rows[slot],
                     hist * sizeof(float), hipMemcpyDeviceToDevice, stream_),
                 "PLE rollback", error_msg)) {
        return false;
      }
      session.ngram_ = session.ngram_snapshots_[slot];
    }
    session.position_ = session.spec_base_ + keep;
    // Pooled block keys past the kept prefix are stale; they are rebuilt
    // from the raw keys when needed.
    session.blocks_ =
        c.compress_ratio == 0
            ? 0
            : std::min(session.blocks_, session.position_ / c.compress_ratio);
  }
  if (!Check(hipStreamSynchronize(stream_), "rollback", error_msg)) {
    return false;
  }
  if (logits != nullptr) {
    std::copy_n(logits_host_, c.vocab_size, logits);
  }
  return true;
}

constexpr std::array<char, 8> kSnapshotMagic{'Q', 'F', 'N', 'S',
                                             'N', 'A', 'P', '6'};

/// Fixed header ahead of the section bytes. It carries every geometry
/// value the section sizes derive from, so a payload of another artifact
/// or executor configuration is rejected before anything is copied.
struct SnapshotHeader {
  std::array<char, 8> magic;
  std::uint32_t num_layers;
  std::uint32_t full_attention_interval;
  std::uint32_t conv_elems;
  std::uint32_t state_elems;
  std::uint32_t kv_row;
  std::uint32_t mtp_kv_row;
  std::uint32_t indexer_head_dim;
  std::uint32_t compress_ratio;
  std::uint32_t hc_dim;
  std::uint32_t ple_elems;
  std::uint32_t has_mtp;
  std::uint32_t position;
  std::uint32_t blocks;
  std::uint32_t mtp_position;
  std::uint32_t mtp_blocks;
  std::uint32_t mtp_residual_valid;
  std::uint32_t hidden_rows;
  std::uint32_t image_count;
  // Rotated K depends on the rope scaling at every position.
  float rope_factor;
  std::uint32_t rope_original_context;
  float rope_beta_fast;
  float rope_beta_slow;
  std::array<std::int32_t, Config::kMaxPleNgram - 1> ngram_prev;
  std::uint64_t payload_bytes;
};
static_assert(std::is_trivially_copyable_v<SnapshotHeader>);
// The four rope fields must not push payload_bytes off its 8-byte alignment.
static_assert(offsetof(SnapshotHeader, payload_bytes) == 104);

namespace {

/// `heads` are the trunk's on this rank, `mtp_heads` the draft block's.
SnapshotHeader MakeSnapshotHeader(const Config& c, const MixerHeads& heads,
                                  const MixerHeads& mtp_heads, bool has_mtp,
                                  const Session& session) {
  SnapshotHeader h{};
  h.magic = kSnapshotMagic;
  h.num_layers = c.num_layers;
  h.full_attention_interval = c.full_attention_interval;
  h.conv_elems = (c.ssm_conv_kernel - 1) * heads.SsmConvChannels();
  h.state_elems = heads.ssm_v * heads.ssm_dim * heads.ssm_dim;
  h.kv_row = heads.AttentionKvDim();
  h.mtp_kv_row = has_mtp ? mtp_heads.AttentionKvDim() : 0;
  h.indexer_head_dim = c.indexer_head_dim;
  h.compress_ratio = c.compress_ratio;
  h.hc_dim = c.HcDim();
  h.ple_elems = c.ple_layer >= 0 ? c.PleConvHistory() * c.HcDim() : 0;
  h.has_mtp = has_mtp ? 1 : 0;
  h.position = session.position();
  h.image_count = std::ranges::count_if(
      session.VisionLayout().images,
      [&](const auto& image) { return image.offset < h.position; });
  // Disabled scaling has one disk-cache identity ("absolute-v1" from
  // RopePositionPolicy) regardless of whatever original_context/beta the
  // config happens to carry, so the header must normalize to the same
  // defaults rather than echo them raw (else two "off" configs that differ
  // only in those unused fields would collide on identity but disagree on
  // SameGeometry, and neither could restore the other's snapshot).
  const RopeScaling rope = NormalizedRopeScaling(c.rope_scaling);
  h.rope_factor = rope.factor;
  h.rope_original_context = rope.original_context;
  h.rope_beta_fast = rope.beta_fast;
  h.rope_beta_slow = rope.beta_slow;
  return h;
}

/// Whether `h` describes this executor's geometry (positions aside).
bool SameGeometry(const SnapshotHeader& h, const SnapshotHeader& mine) {
  return h.magic == mine.magic && h.num_layers == mine.num_layers &&
         h.full_attention_interval == mine.full_attention_interval &&
         h.conv_elems == mine.conv_elems && h.state_elems == mine.state_elems &&
         h.kv_row == mine.kv_row && h.mtp_kv_row == mine.mtp_kv_row &&
         h.indexer_head_dim == mine.indexer_head_dim &&
         h.compress_ratio == mine.compress_ratio && h.hc_dim == mine.hc_dim &&
         h.ple_elems == mine.ple_elems && h.has_mtp == mine.has_mtp &&
         h.rope_factor == mine.rope_factor &&
         h.rope_original_context == mine.rope_original_context &&
         h.rope_beta_fast == mine.rope_beta_fast &&
         h.rope_beta_slow == mine.rope_beta_slow;
}

}  // namespace

template<typename Visit>
std::uint64_t Executor::WalkSnapshot(const SnapshotHeader& h,
                                     const Session* session, Visit&& visit) {
  std::uint64_t offset = sizeof(SnapshotHeader);
  const auto region = [&](void* device, std::uint64_t bytes, const char* what,
                          std::uint64_t row_bytes = 0, bool draft = false,
                          bool pooled = false) {
    if (bytes != 0 &&
        !visit(device, offset, bytes, what, row_bytes, draft, pooled)) {
      return false;
    }
    offset += bytes;
    return true;
  };
  const auto linear = [&](std::uint32_t il) -> const Session::LinearState* {
    return session != nullptr ? &session->linear_[il] : nullptr;
  };
  const auto attention =
      [&](std::uint32_t il) -> const Session::AttentionState* {
    return session != nullptr ? &session->attention_[il] : nullptr;
  };
  for (std::uint32_t il = 0; il < h.num_layers; ++il) {
    if (((il + 1) % h.full_attention_interval) != 0) {
      const auto* l = linear(il);
      if (!region(l != nullptr ? l->conv_state : nullptr,
                  std::uint64_t{h.conv_elems} * sizeof(float), "conv state") ||
          !region(l != nullptr ? l->state : nullptr,
                  std::uint64_t{h.state_elems} * sizeof(float),
                  "recurrent state")) {
        return 0;
      }
    }
  }
  if (!region(session != nullptr ? session->ple_history_ : nullptr,
              std::uint64_t{h.ple_elems} * sizeof(float), "PLE history")) {
    return 0;
  }
  const std::uint64_t kv_bytes =
      std::uint64_t{h.position} * h.kv_row * sizeof(__half);
  const std::uint64_t index_row_bytes =
      std::uint64_t{h.indexer_head_dim} * sizeof(float);
  const std::uint32_t index_begin = h.blocks * h.compress_ratio;
  const std::uint32_t index_rows = h.position - index_begin;
  const std::uint64_t block_bytes =
      std::uint64_t{h.blocks} * h.indexer_head_dim * sizeof(__half);
  for (std::uint32_t il = 0; il < h.num_layers; ++il) {
    if (((il + 1) % h.full_attention_interval) == 0) {
      const auto* at = attention(il);
      if (!region(at != nullptr ? at->k_cache : nullptr, kv_bytes, "K cache",
                  std::uint64_t{h.kv_row} * sizeof(__half)) ||
          !region(at != nullptr ? at->v_cache : nullptr, kv_bytes, "V cache",
                  std::uint64_t{h.kv_row} * sizeof(__half))) {
        return 0;
      }
      // Serialize only unpooled rows, in chronological order. The physical
      // ring may wrap, and a destination session may have another capacity.
      if (session == nullptr) {
        if (!region(nullptr, index_rows * index_row_bytes, "indexer keys"))
          return 0;
      } else {
        const auto first = index_begin & (session->index_capacity_ - 1);
        const auto tail =
            std::min(index_rows, session->index_capacity_ - first);
        if (!region(at->index_k + std::size_t{first} * h.indexer_head_dim,
                    tail * index_row_bytes, "indexer tail") ||
            !region(at->index_k, (index_rows - tail) * index_row_bytes,
                    "indexer wrap"))
          return 0;
      }
      if (!region(at != nullptr ? at->block_k : nullptr, block_bytes,
                  "pooled block keys",
                  std::uint64_t{h.indexer_head_dim} * sizeof(__half), false,
                  true))
        return 0;
    }
  }
  if (h.has_mtp != 0) {
    const auto* mtp = session != nullptr ? &session->mtp_ : nullptr;
    const std::uint32_t begin = h.mtp_blocks * h.compress_ratio;
    const std::uint32_t rows = h.mtp_position - begin;
    if (session == nullptr) {
      if (!region(nullptr, rows * index_row_bytes, "draft indexer keys"))
        return 0;
    } else {
      const auto first = begin & (session->index_capacity_ - 1);
      const auto tail = std::min(rows, session->index_capacity_ - first);
      if (!region(mtp->index_k + std::size_t{first} * h.indexer_head_dim,
                  tail * index_row_bytes, "draft indexer tail") ||
          !region(mtp->index_k, (rows - tail) * index_row_bytes,
                  "draft indexer wrap"))
        return 0;
    }
    if (!region(
            mtp ? mtp->block_k : nullptr,
            std::uint64_t{h.mtp_blocks} * h.indexer_head_dim * sizeof(__half),
            "draft pooled keys",
            std::uint64_t{h.indexer_head_dim} * sizeof(__half), true, true))
      return 0;
    const std::uint64_t mtp_kv_bytes =
        std::uint64_t{h.mtp_position} * h.mtp_kv_row * sizeof(__half);
    if (!region(mtp != nullptr ? mtp->k_cache : nullptr, mtp_kv_bytes,
                "draft K cache", std::uint64_t{h.kv_row} * sizeof(__half),
                true) ||
        !region(mtp != nullptr ? mtp->v_cache : nullptr, mtp_kv_bytes,
                "draft V cache", std::uint64_t{h.kv_row} * sizeof(__half),
                true) ||
        !region(
            mtp != nullptr ? mtp->h : nullptr,
            h.mtp_residual_valid ? std::uint64_t{h.hc_dim} * sizeof(float) : 0,
            "draft residual") ||
        !region(mtp != nullptr ? mtp->target_hidden : nullptr,
                std::uint64_t{h.hidden_rows} * h.hc_dim * sizeof(float),
                "kept trunk rows")) {
      return 0;
    }
  }
  return offset +
         std::uint64_t{h.image_count} * sizeof(qwen::vision::ImageGrid);
}

std::uint64_t Executor::SnapshotBytes(const Session& session,
                                      std::uint32_t hidden_rows) const {
  SnapshotHeader h =
      MakeSnapshotHeader(config(), model_->trunk_heads(), model_->mtp().heads,
                         session.mtp_enabled_, session);
  h.blocks = session.blocks_;
  h.mtp_blocks = session.mtp_.blocks;
  h.mtp_position = session.mtp_.position;
  h.mtp_residual_valid = session.mtp_.residual_valid;
  h.hidden_rows = hidden_rows;
  return WalkSnapshot(h, nullptr,
                      [](void*, std::uint64_t, std::uint64_t, const char*,
                         std::uint64_t, bool, bool) { return true; });
}

bool Executor::SaveSnapshot(const Session& session, std::uint32_t hidden_rows,
                            std::span<std::uint8_t> payload,
                            std::string* error_msg,
                            std::shared_ptr<SnapshotState>* deferred,
                            std::shared_ptr<void> storage) const {
  if (session.owner_ != this) {
    AssignError(error_msg, "session belongs to another executor");
    return false;
  }
  if (session.spec_tokens_ != 0) {
    AssignError(error_msg,
                "snapshot with a pending speculative batch; roll back first");
    return false;
  }
  if (hidden_rows > session.position_ ||
      hidden_rows > options_.max_speculative) {
    AssignError(error_msg, "kept trunk rows exceed the position or batch");
    return false;
  }
  SnapshotHeader h =
      MakeSnapshotHeader(config(), model_->trunk_heads(), model_->mtp().heads,
                         session.mtp_enabled_, session);
  h.blocks = session.blocks_;
  h.mtp_blocks = session.mtp_.blocks;
  h.mtp_position = session.mtp_.position;
  h.mtp_residual_valid = session.mtp_.residual_valid;
  h.hidden_rows = hidden_rows;
  h.ngram_prev = session.ngram_.prev;
  h.payload_bytes = SnapshotBytes(session, hidden_rows);
  if (payload.size() != h.payload_bytes) {
    AssignError(error_msg, "snapshot buffer size does not match the payload");
    return false;
  }
  std::shared_ptr<SnapshotState> pending;
  const auto transfer = GetSnapshotAllocator()->Transfer();
  if (deferred) {
    if (!storage) {
      AssignError(error_msg, "borrowed snapshot needs owned payload storage");
      return false;
    }
    if (!session.snapshots_)
      session.snapshots_ =
          std::make_shared<SnapshotRegistry>(GetSnapshotAllocator());
    pending = std::make_shared<SnapshotState>();
    pending->registry_ = session.snapshots_;
    if (!session.snapshot_lineage_)
      session.snapshot_lineage_ = std::make_shared<SnapshotLineage>();
    pending->lineage_ = session.snapshot_lineage_;
    pending->storage_ = std::move(storage);
    pending->payload_ = payload.data();
    std::uint64_t mutable_prefix = sizeof(SnapshotHeader);
    (void)WalkSnapshot(h, nullptr,
                       [&](void*, std::uint64_t offset, std::uint64_t bytes,
                           const char*, std::uint64_t row_bytes, bool, bool) {
                         if (row_bytes != 0)
                           return false;
                         mutable_prefix = offset + bytes;
                         return true;
                       });
    std::uint64_t extra_bytes = 0;
    (void)WalkSnapshot(h, nullptr,
                       [&](void*, std::uint64_t offset, std::uint64_t bytes,
                           const char*, std::uint64_t row_bytes, bool, bool) {
                         if (row_bytes == 0 && offset >= mutable_prefix)
                           extra_bytes += bytes;
                         return true;
                       });
    pending->mutable_offset_ = sizeof(SnapshotHeader);
    pending->mutable_bytes_ = mutable_prefix - sizeof(SnapshotHeader);
    try {
      pending->mutable_storage_ =
          session.snapshots_->allocator->AllocateSpare(pending->mutable_bytes_);
      pending->mutable_device_ =
          static_cast<std::uint8_t*>(pending->mutable_storage_.get());
      if (extra_bytes != 0) {
        pending->extra_storage_ =
            session.snapshots_->allocator->Allocate(extra_bytes);
        pending->extra_bytes_ = extra_bytes;
      }
    } catch (const SnapshotDeviceExhausted&) {
      // No device room to freeze this capture: copy it to its host payload.
      pending.reset();
    }
  }
  if (!pending)
    PopulateSnapshotPrefix(payload.data(), payload.size());
  std::memcpy(payload.data(), &h, sizeof(h));
  const auto grid_bytes =
      std::size_t{h.image_count} * sizeof(qwen::vision::ImageGrid);
  if (grid_bytes != 0) {
    std::memcpy(payload.data() + payload.size() - grid_bytes,
                session.VisionLayout().images.data(), grid_bytes);
  }
  std::uint64_t extra_used = 0;
  const bool saved =
      WalkSnapshot(
          h, &session,
          [&](void* device, std::uint64_t offset, std::uint64_t bytes,
              const char*, std::uint64_t row_bytes, bool draft, bool pooled) {
            if (!session.CheckCancellation(error_msg))
              return false;
            if (pending && row_bytes != 0) {
              pending->regions_.push_back({device,
                                           payload.data() + offset,
                                           bytes,
                                           bytes,
                                           bytes,
                                           row_bytes,
                                           draft,
                                           pooled,
                                           {}});
            } else {
              auto* destination = payload.data() + offset;
              auto kind = hipMemcpyDeviceToHost;
              if (pending && offset >= pending->mutable_offset_ &&
                  offset + bytes <=
                      pending->mutable_offset_ + pending->mutable_bytes_) {
                destination = pending->mutable_device_ + offset -
                              pending->mutable_offset_;
                kind = hipMemcpyDeviceToDevice;
              } else if (pending && pending->extra_storage_) {
                if (extra_used + bytes > pending->extra_bytes_)
                  throw std::logic_error("snapshot extra regions overflow");
                destination =
                    static_cast<std::uint8_t*>(pending->extra_storage_.get()) +
                    extra_used;
                kind = hipMemcpyDeviceToDevice;
                pending->extras_.push_back({offset, bytes, destination});
                extra_used += bytes;
              }
              if (pending)
                transfer->Enqueue(destination, device, bytes, kind);
              else
                transfer->Copy(destination, device, bytes);
            }
            return true;
          }) != 0;
  transfer->Finish();
  if (saved && pending) {
    std::lock_guard lock(session.snapshots_->mutex);
    std::erase_if(session.snapshots_->pending,
                  [](const auto& entry) { return entry.expired(); });
    session.snapshots_->pending.push_back(pending);
    session.snapshot_position_ =
        std::max(session.snapshot_position_, session.position_);
    session.snapshot_mtp_position_ =
        std::max(session.snapshot_mtp_position_, session.mtp_.position);
    *deferred = std::move(pending);
  }
  return saved;
}

std::uint64_t Executor::PrefillCheckpointBytes(const Session& session,
                                               std::uint32_t position) const {
  const auto& c = config();
  auto h = MakeSnapshotHeader(c, model_->trunk_heads(), model_->mtp().heads,
                              session.mtp_enabled_, session);
  h.position = position;
  h.blocks = c.compress_ratio > 0 && position > c.indexer_top_k
                 ? position / c.compress_ratio
                 : session.blocks_;
  if (session.mtp_enabled_) {
    h.mtp_position = position - 1;
    h.mtp_blocks = h.mtp_position > c.indexer_top_k
                       ? h.mtp_position / c.compress_ratio
                       : session.mtp_.blocks;
    h.hidden_rows =
        std::min(position - session.position_, options_.max_speculative);
  }
  return WalkSnapshot(h, nullptr,
                      [](void*, std::uint64_t, std::uint64_t, const char*,
                         std::uint64_t, bool, bool) { return true; });
}

bool Executor::RestoreSnapshot(Session& session,
                               std::span<const std::uint8_t> payload,
                               SnapshotInfo* info, std::string* error_msg,
                               std::uint32_t next_drafts,
                               const SnapshotState* deferred) const {
  if (session.owner_ != this) {
    AssignError(error_msg, "session belongs to another executor");
    return false;
  }
  if (payload.size() < sizeof(SnapshotHeader)) {
    AssignError(error_msg, "snapshot payload is truncated");
    return false;
  }
  SnapshotHeader h{};
  std::memcpy(&h, payload.data(), sizeof(h));
  const SnapshotHeader mine =
      MakeSnapshotHeader(config(), model_->trunk_heads(), model_->mtp().heads,
                         session.mtp_enabled_, session);
  if (!SameGeometry(h, mine)) {
    AssignError(error_msg, "snapshot was taken with another model geometry");
    return false;
  }
  const std::uint32_t max_blocks =
      h.compress_ratio == 0 ? 0 : h.position / h.compress_ratio;
  if (h.image_count > h.position || h.position == 0 ||
      h.position > session.max_context_ || h.blocks > max_blocks ||
      h.mtp_position > h.position ||
      h.mtp_blocks > h.mtp_position / h.compress_ratio ||
      h.mtp_position - h.mtp_blocks * h.compress_ratio >
          session.index_capacity_ ||
      h.hidden_rows > h.position || h.hidden_rows > options_.max_speculative ||
      h.mtp_residual_valid > 1 ||
      (h.mtp_residual_valid != 0 && h.mtp_position == 0) ||
      (h.has_mtp == 0 && (h.mtp_position != 0 || h.hidden_rows != 0 ||
                          h.mtp_residual_valid != 0))) {
    AssignError(error_msg, "snapshot positions do not fit this session");
    return false;
  }
  if (h.position - h.blocks * h.compress_ratio > session.index_capacity_) {
    AssignError(error_msg, "unpooled indexer rows exceed the ring capacity");
    return false;
  }
  if (h.payload_bytes != payload.size() ||
      WalkSnapshot(h, nullptr,
                   [](void*, std::uint64_t, std::uint64_t, const char*,
                      std::uint64_t, bool, bool) { return true; }) !=
          payload.size()) {
    AssignError(error_msg, "snapshot payload size does not match its header");
    return false;
  }
  qwen::vision::RopeLayout layout;
  layout.images.resize(h.image_count);
  const auto grid_bytes =
      layout.images.size() * sizeof(qwen::vision::ImageGrid);
  if (grid_bytes != 0) {
    std::memcpy(layout.images.data(),
                payload.data() + payload.size() - grid_bytes, grid_bytes);
  }
  try {
    layout.Validate(session.max_context_);
  } catch (const std::exception& e) {
    AssignError(error_msg, e.what());
    return false;
  }
  if (!layout.images.empty() &&
      layout.Prefix(h.position) != session.VisionLayout().Prefix(h.position)) {
    AssignError(error_msg,
                "image snapshot layout does not match its prompt attachment");
    return false;
  }
  if (layout.images.empty())
    session.ConfigureVision(nullptr, nullptr, stream_);
  // The session's queued work targets buffers the copies overwrite.
  if (!Check(hipStreamSynchronize(stream_), "restore drain", error_msg)) {
    return false;
  }
  const bool borrowed = deferred && deferred->registry_ == session.snapshots_;
  std::unique_lock<std::mutex> snapshot_lock;
  std::unique_lock<std::mutex> source_lock;
  if (session.snapshots_)
    snapshot_lock =
        std::unique_lock(session.snapshots_->mutex, std::defer_lock);
  if (deferred && !borrowed)
    source_lock = std::unique_lock(deferred->registry_->mutex, std::defer_lock);
  if (snapshot_lock.mutex() && source_lock.mutex())
    std::lock(snapshot_lock, source_lock);
  else if (snapshot_lock.mutex())
    snapshot_lock.lock();
  else if (source_lock.mutex())
    source_lock.lock();
  if (session.snapshots_ && session.snapshots_->failure)
    std::rethrow_exception(session.snapshots_->failure);
  if (deferred && deferred->registry_->failure)
    std::rethrow_exception(deferred->registry_->failure);
  // A same-session restore retains the still-live prefix. Only detached rows
  // are uploaded. Save other checkpoints' overwritten suffixes first.
  std::uint32_t trunk_keep = 0;
  std::uint32_t draft_keep = 0;
  std::uint32_t trunk_blocks = 0;
  std::uint32_t draft_blocks = 0;
  if (borrowed) {
    trunk_keep = h.position;
    draft_keep = h.mtp_position;
    trunk_blocks = h.blocks;
    draft_blocks = h.mtp_blocks;
    for (const auto& region : deferred->regions_) {
      const auto rows =
          static_cast<std::uint32_t>(region.live_bytes / region.row_bytes);
      if (region.pooled) {
        if (region.draft)
          draft_blocks = std::min(draft_blocks, rows);
        else
          trunk_blocks = std::min(trunk_blocks, rows);
      } else {
        if (region.draft)
          draft_keep = std::min(draft_keep, rows);
        else
          trunk_keep = std::min(trunk_keep, rows);
      }
    }
  } else if (deferred) {
    const auto common = SnapshotLineage::Common(
        session.snapshot_lineage_, deferred->lineage_,
        {std::min(session.position_, h.position),
         std::min(session.mtp_.position, h.mtp_position),
         std::min(session.blocks_, h.blocks),
         std::min(session.mtp_.blocks, h.mtp_blocks)});
    trunk_keep = common[0];
    draft_keep = common[1];
    trunk_blocks = common[2];
    draft_blocks = common[3];
  }
  trunk_blocks = h.compress_ratio
                     ? std::min(trunk_blocks, trunk_keep / h.compress_ratio)
                     : 0;
  draft_blocks = h.compress_ratio
                     ? std::min(draft_blocks, draft_keep / h.compress_ratio)
                     : 0;
  auto restored_lineage =
      deferred ? std::make_shared<SnapshotLineage>(
                     deferred->lineage_,
                     SnapshotLineage::Rows{h.position, h.mtp_position, h.blocks,
                                           h.mtp_blocks})
               : nullptr;
  if (session.snapshots_) {
    session.snapshots_->Preserve(trunk_keep, draft_keep, trunk_blocks,
                                 draft_blocks);
  }
  // If restoration fails after a partial write, no provenance may survive.
  session.snapshot_lineage_.reset();
  // Every live state region is overwritten below. Retain only scratch that
  // the restored operation can use; this never allocates new rollback rows.
  // Explicit reset and failed restoration still release all scratch.
  const auto remaining = session.max_context_ - h.position;
  session.TrimRollback(std::min({next_drafts, options_.max_speculative - 1,
                                 remaining ? remaining - 1 : 0}));
  // A borrowed restore may reuse its source slot. Keep recorded graphs, but
  // let unrecorded shapes run eagerly once in the restored request before
  // recording them, just as they would in a fresh execution slot.
  std::erase_if(session.warmed_,
                [&](const auto key) { return !session.graphs_.contains(key); });
  std::unique_ptr<gufo::hip::SnapshotTransfer> fork_transfer;
  const auto upload = [&](void* device, const std::uint8_t* source,
                          std::uint64_t bytes, const char* what,
                          hipMemcpyKind kind = hipMemcpyHostToDevice) {
    if (!session.CheckCancellation(error_msg))
      return false;
    if (deferred) {
      if (!fork_transfer)
        fork_transfer = GetSnapshotAllocator()->Transfer();
      fork_transfer->Enqueue(device, source, bytes, kind);
      return true;
    }
    return Check(hipMemcpy(device, source, bytes, hipMemcpyHostToDevice), what,
                 error_msg);
  };

  if (WalkSnapshot(
          h, &session,
          [&](void* device, std::uint64_t offset, std::uint64_t bytes,
              const char* what, std::uint64_t row_bytes, bool draft,
              bool pooled) {
            const auto original_offset = offset;
            const auto original_bytes = bytes;
            if (deferred && row_bytes != 0) {
              auto rows = draft ? draft_keep : trunk_keep;
              if (pooled)
                rows = draft ? draft_blocks : trunk_blocks;
              const auto skip =
                  std::min(bytes, std::uint64_t{rows} * row_bytes);
              device = static_cast<std::uint8_t*>(device) + skip;
              offset += skip;
              bytes -= skip;
            }
            if (deferred && !borrowed && row_bytes != 0) {
              // Fork directly from the source's still-live prefix.
              // Its detached tail is already present in the payload.
              // Hold both registries until the copy completes so a
              // reset or destruction cannot invalidate either side.
              for (const auto& region : deferred->regions_) {
                if (region.host != payload.data() + original_offset)
                  continue;
                const auto skip = offset - original_offset;
                const auto copied =
                    region.live_bytes > skip
                        ? std::min(bytes, region.live_bytes - skip)
                        : 0;
                if (copied != 0) {
                  if (!session.CheckCancellation(error_msg))
                    return false;
                  if (!fork_transfer)
                    fork_transfer = GetSnapshotAllocator()->Transfer();
                  fork_transfer->Enqueue(
                      device,
                      static_cast<const std::uint8_t*>(region.device) + skip,
                      copied, hipMemcpyDeviceToDevice);
                }
                device = static_cast<std::uint8_t*>(device) + copied;
                offset += copied;
                bytes -= copied;
                break;
              }
            }
            if (bytes == 0)
              return true;
            if (deferred && row_bytes != 0) {
              for (const auto& region : deferred->regions_) {
                if (region.host != payload.data() + original_offset ||
                    region.saved.empty())
                  continue;
                const auto skip = offset - original_offset;
                for (const auto& saved : region.saved) {
                  const auto begin = std::max(skip, saved.offset);
                  const auto end =
                      std::min(original_bytes, saved.offset + saved.bytes);
                  if (begin < end) {
                    if (!session.CheckCancellation(error_msg))
                      return false;
                    if (!fork_transfer)
                      fork_transfer = GetSnapshotAllocator()->Transfer();
                    fork_transfer->Enqueue(
                        static_cast<std::uint8_t*>(device) + begin - skip,
                        saved.chunk->device + begin - saved.offset, end - begin,
                        hipMemcpyDeviceToDevice);
                  }
                }
                return true;
              }
            }
            const auto* source = payload.data() + offset;
            auto kind = hipMemcpyHostToDevice;
            if (deferred && deferred->mutable_storage_ &&
                offset >= deferred->mutable_offset_ &&
                offset + bytes <=
                    deferred->mutable_offset_ + deferred->mutable_bytes_) {
              source = deferred->mutable_device_ + offset -
                       deferred->mutable_offset_;
              kind = hipMemcpyDeviceToDevice;
            } else if (deferred && deferred->extra_storage_ && row_bytes == 0) {
              // The destination may split a ring region differently from the
              // source, so copy every overlapping frozen piece.
              auto* target = static_cast<std::uint8_t*>(device);
              for (const auto& extra : deferred->extras_) {
                const auto begin = std::max(offset, extra.offset);
                const auto end =
                    std::min(offset + bytes, extra.offset + extra.bytes);
                if (begin < end &&
                    !upload(target + (begin - offset),
                            extra.device + (begin - extra.offset), end - begin,
                            what, hipMemcpyDeviceToDevice))
                  return false;
              }
              return true;
            }
            return upload(device, source, bytes, what, kind);
          }) == 0) {
    if (fork_transfer)
      fork_transfer->Finish();
    if (snapshot_lock.owns_lock())
      snapshot_lock.unlock();
    session.Reset();
    return false;
  }
  if (fork_transfer)
    fork_transfer->Finish();
  session.RestoreVisionLayout(layout, stream_);
  session.position_ = h.position;
  session.blocks_ = h.blocks;
  session.mtp_.position = h.mtp_position;
  session.mtp_.blocks = h.mtp_blocks;
  session.mtp_.residual_valid = h.mtp_residual_valid != 0;
  session.snapshot_lineage_ = std::move(restored_lineage);
  if (borrowed)
    for (auto& region : deferred->regions_)
      region.live_bytes = region.bytes;
  session.snapshot_position_ = borrowed ? h.position : trunk_keep;
  session.snapshot_mtp_position_ = borrowed ? h.mtp_position : draft_keep;
  session.spec_base_ = h.position;
  session.spec_tokens_ = 0;
  session.ngram_.prev = h.ngram_prev;
  if (info != nullptr) {
    info->position = h.position;
    info->hidden_rows = h.hidden_rows;
  }
  return true;
}

bool Executor::ReadVerificationRows(std::uint32_t row, std::span<float> logits,
                                    std::string* error_msg) const {
  const auto vocab = config().vocab_size;
  if (row >= options_.max_speculative || logits.empty() ||
      logits.size() % vocab != 0 ||
      logits.size() / vocab > options_.max_speculative - row) {
    AssignError(error_msg, "invalid verification row");
    return false;
  }
  return Check(hipMemcpyAsync(logits.data(), VerificationLogits() + row * vocab,
                              logits.size_bytes(), hipMemcpyDeviceToHost,
                              stream_),
               "constrained verification row download", error_msg) &&
         Check(hipStreamSynchronize(stream_), "constrained verification",
               error_msg);
}

bool Executor::GreedyMtpPredictions(std::span<ArgmaxCandidate> predictions,
                                    const sampling::SamplerState& sampler,
                                    std::span<const std::int32_t> drafts,
                                    std::string* error_msg) const {
  const auto rows = predictions.size();
  if (rows == 0 || rows > options_.max_logit_rows || rows > 7 ||
      drafts.size() != rows || s_.mtp_ids == nullptr) {
    AssignError(error_msg, "invalid greedy MTP verification request");
    return false;
  }
  // Proposal selection has finished. Its two ID buffers and argmax scratch
  // can be reused until the next draft head overwrites them.
  const auto vocab = config().vocab_size;
  // Keep the host upload alive until the final stream synchronization. This
  // workspace is shared, never part of a session or its persistent snapshot.
  std::vector<sampling::TokenPenalty> penalties;
  if (sampler.config().penalties_enabled()) {
    penalties.reserve(rows * (sampler.penalties().size() + rows));
    // Drafts may violate the target grammar. Only their conditional penalty
    // history is needed here; FinishDecode checks each winner's grammar.
    auto tentative = sampler.WithoutConstraint();
    GreedyPenaltyRows batch{};
    for (std::size_t row = 0; row < rows; ++row) {
      const auto counts = tentative.penalties();
      penalties.insert(penalties.end(), counts.begin(), counts.end());
      batch.offsets[row + 1] = static_cast<std::uint32_t>(penalties.size());
      if (row + 1 < rows)
        tentative.Accept(static_cast<sampling::TokenId>(drafts[row]));
    }
    if (penalties.size() > verification_penalty_capacity_) {
      const auto capacity =
          std::max(penalties.size(), 2 * verification_penalty_capacity_);
      sampling::TokenPenalty* allocated = nullptr;
      if (!Check(hip::AllocateDevice(&allocated, capacity * sizeof(*allocated)),
                 "verification penalty allocation", error_msg))
        return false;
      (void)hipFree(verification_penalties_);
      verification_penalties_ = allocated;
      verification_penalty_capacity_ = capacity;
    }
    batch.penalties = verification_penalties_;
    if (!penalties.empty() &&
        !Check(hipMemcpyAsync(verification_penalties_, penalties.data(),
                              penalties.size() * sizeof(penalties.front()),
                              hipMemcpyHostToDevice, stream_),
               "verification penalty upload", error_msg))
      return false;
    const auto& config = sampler.config();
    PenalizedArgmax(
        VerificationLogits(), batch, config.repeat_penalty,
        config.frequency_penalty, config.presence_penalty,
        reinterpret_cast<PenaltyArgmaxCandidate*>(s_.mtp_scratch_ids),
        s_.mtp_argmax, rows, vocab, stream_);
  } else {
    gufo::hip::LaunchBatchedGPUArgmax(
        VerificationLogits(), s_.mtp_ids, rows, vocab,
        {reinterpret_cast<float*>(s_.mtp_scratch_ids),
         MtpCandidateWorkspaceSize(vocab)},
        stream_);
    GatherArgmaxCandidates(VerificationLogits(), s_.mtp_ids, s_.mtp_argmax,
                           static_cast<std::uint32_t>(rows), vocab, stream_);
  }
  const bool copied = Check(
      hipMemcpyAsync(predictions.data(), s_.mtp_argmax,
                     predictions.size_bytes(), hipMemcpyDeviceToHost, stream_),
      "greedy MTP predictions download", error_msg);
  // Drain even after a failed download before releasing the upload source.
  const bool completed = Check(hipStreamSynchronize(stream_),
                               "greedy MTP verification", error_msg);
  return copied && completed;
}

bool Executor::CanCompactMtpVerification(
    const sampling::SamplerState& sampler) {
  const auto& config = sampler.config();
  return config.uses_random_sampling() && config.top_k > 0 &&
         std::size_t(config.top_k) <= kMtpCandidates &&
         config.min_keep <= kMtpCandidates &&
         sampler.penalties().size() + 8 <= kCompactPenaltyLimit &&
         !sampler.NeedsConstraintMask();
}

bool Executor::SampledMtpCandidates(
    std::span<std::span<const sampling::LogitCandidate>> output,
    const sampling::SamplerState& sampler, std::span<const std::int32_t> drafts,
    std::string* error_msg) const {
  const auto rows = output.size();
  if (rows == 0 || rows > 7 || rows >= options_.max_speculative ||
      rows != drafts.size() || verification_ids_ == nullptr ||
      !CanCompactMtpVerification(sampler)) {
    AssignError(error_msg, "invalid compact MTP verification request");
    return false;
  }
  auto& penalties = verification_penalty_host_;
  penalties.clear();
  GreedyPenaltyRows batch{};
  auto tentative = sampler.WithoutConstraint();
  for (std::size_t row = 0; row < rows; ++row) {
    const auto counts = tentative.penalties();
    penalties.insert(penalties.end(), counts.begin(), counts.end());
    batch.offsets[row + 1] = penalties.size();
    if (row + 1 < rows)
      tentative.Accept(static_cast<sampling::TokenId>(drafts[row]));
  }
  batch.penalties = verification_penalties_;
  if (!penalties.empty() &&
      !Check(hipMemcpyAsync(verification_penalties_, penalties.data(),
                            penalties.size() * sizeof(penalties[0]),
                            hipMemcpyHostToDevice, stream_),
             "compact verification penalties", error_msg))
    return false;
  VerificationCandidates(VerificationLogits(), batch, verification_ids_,
                         verification_scratch_ids_, verification_candidates_,
                         rows, config().vocab_size, stream_);
  const auto count = rows * kMtpCandidates + penalties.size();
  const bool copied = Check(
      hipMemcpyAsync(verification_candidates_host_, verification_candidates_,
                     count * sizeof(sampling::LogitCandidate),
                     hipMemcpyDeviceToHost, stream_),
      "compact verification candidates", error_msg);
  const bool completed =
      Check(hipStreamSynchronize(stream_), "compact verification", error_msg);
  if (!copied || !completed)
    return false;
  for (std::size_t row = 0; row < rows; ++row)
    output[row] = {
        verification_candidates_host_ + row * kMtpCandidates +
            batch.offsets[row],
        kMtpCandidates + batch.offsets[row + 1] - batch.offsets[row]};
  return true;
}

bool Executor::MtpForward(Session& session,
                          std::span<const std::int32_t> tokens,
                          std::int32_t hidden_row, MtpOutput output,
                          std::string* error_msg,
                          const float* hidden_source) const {
  DropReadyQ8();
  const auto n = static_cast<std::uint32_t>(tokens.size());
  if (session.owner_ != this ||
      std::any_of(tokens.begin(), tokens.end(), [&](auto t) {
        return t < 0 || static_cast<std::uint32_t>(t) >= config().vocab_size;
      })) {
    AssignError(error_msg, "invalid MTP session or token");
    return false;
  }
  if (!session.CheckCancellation(error_msg))
    return false;
  if (!session.mtp_enabled_) {
    AssignError(error_msg, "no MTP block loaded");
    return false;
  }

  if (n == 0 || n > options_.max_batch || (hidden_row < 0 && n != 1) ||
      (hidden_row >= 0 &&
       static_cast<std::uint32_t>(hidden_row) + n >
           (hidden_source ? options_.max_batch : options_.max_speculative))) {
    AssignError(error_msg, "MTP batch outside the kept hidden rows");
    return false;
  }
  if (output.trace != nullptr &&
      !output.trace->Valid(config().hidden_size, config().HcDim())) {
    AssignError(error_msg, "invalid MTP trace destinations");
    return false;
  }
  if ((hidden_row < 0 && !session.mtp_.residual_valid) ||
      (output.kv_only &&
       (hidden_row < 0 || output.token != nullptr ||
        output.candidates != nullptr || output.trace != nullptr))) {
    AssignError(error_msg, "MTP residual requires a full known-hidden forward");
    return false;
  }
  const std::uint32_t pos = session.mtp_.position;
  if (pos + n > session.max_context_) {
    AssignError(error_msg, "MTP context is full");
    return false;
  }
  if (session.continuation_hooks_)
    session.continuation_hooks_->BeforeWrite(
        true, pos, pos + n, session.mtp_.blocks,
        pos + n > config().indexer_top_k ? (pos + n) / config().compress_ratio
                                         : session.mtp_.blocks);
  session.PreserveSnapshots(session.position_, session.mtp_.position);
  ++session.mutation_epoch_;
  session.mtp_.residual_valid = false;
  std::copy(tokens.begin(), tokens.end(), tokens_host_);
  control_host_->position = session.position_;
  control_host_->blocks = session.blocks_;
  control_host_->mtp_position = pos;
  control_host_->hidden_row = hidden_row;
  control_host_->mtp_blocks = session.mtp_.blocks;
  const auto& c = config();
  const bool sparse = pos + n > c.indexer_top_k;
  const auto complete = (pos + n) / c.compress_ratio;
  const auto pool = sparse ? complete - session.mtp_.blocks : 0;
  const auto graph_pool = n / c.compress_ratio + 1;
  const bool graph = output.trace == nullptr && hidden_source == nullptr &&
                     n <= kVecBatch && pool <= graph_pool &&
                     pos + 1 >= session.VisionLayout().PrefixLength();
  // Captured graphs bake in the head; key on the one this draft reads.
  const bool subset = UseDraftSubset(session, output.draft_subset) &&
                      (output.token != nullptr || output.candidates != nullptr);
  const std::uint64_t key =
      static_cast<std::uint64_t>(n) |
      (static_cast<std::uint64_t>(hidden_row < 0) << 32) |
      (std::uint64_t{1} << 40) |
      (std::uint64_t{output.token != nullptr} << 41) |
      (std::uint64_t{output.candidates != nullptr} << 43) |
      (std::uint64_t{sparse} << 44) | (std::uint64_t{output.kv_only} << 45) |
      (std::uint64_t{subset} << 46);
  const auto body = [&] {
    return MtpBody(session, n, pos, output.token != nullptr,
                   output.candidates != nullptr, error_msg,
                   graph ? graph_pool : pool, hidden_source, output.trace,
                   output.kv_only, subset);
  };
  if (!Run(session, key, graph, body, error_msg)) {
    return false;
  }
  if (output.token != nullptr) {
    *output.token = mtp_token_host_[0];
    if (output.confidence != nullptr)
      *output.confidence = std::bit_cast<float>(mtp_token_host_[1]);
  }
  if (output.candidates != nullptr) {
    *output.candidates = *mtp_candidates_host_;
  }
  session.mtp_.position = pos + n;
  session.mtp_.residual_valid = !output.kv_only;
  if (sparse)
    session.mtp_.blocks = complete;
  return true;
}

bool Executor::MtpBody(Session& session, std::uint32_t n, std::uint32_t pos,
                       bool token, bool candidates, std::string* error_msg,
                       std::uint32_t pool_grid, const float* hidden_source,
                       MtpTrace* trace, bool kv_only, bool draft_subset) const {
  const Config& c = config();
  const DeviceLayer& l = model_->mtp();
  const std::uint32_t hc_dim = c.HcDim();
  const std::size_t final_row = static_cast<std::size_t>(n - 1) * hc_dim;
  const auto copy_trace = [&](const float* source,
                              std::span<float> destination) {
    return destination.empty() ||
           Check(hipMemcpyAsync(destination.data(), source,
                                destination.size_bytes(), hipMemcpyDeviceToHost,
                                stream_),
                 "MTP trace download", error_msg);
  };
  if (!Check(hipMemcpyAsync(session.control_, control_host_,
                            sizeof(Session::Control), hipMemcpyHostToDevice,
                            stream_),
             "control upload", error_msg) ||
      !Check(hipMemcpyAsync(s_.tokens, tokens_host_, n * sizeof(std::int32_t),
                            hipMemcpyHostToDevice, stream_),
             "token upload", error_msg)) {
    return false;
  }
  EmbedTokens(model_->token_embd().data, SmallType(model_->token_embd().type),
              s_.tokens, s_.mtp_embd, n, c.hidden_size, 1, stream_);
  // MTP embeds shifted token IDs. Visual information arrives in the trunk
  // hidden stream; image embeddings belong only to the target input.
  RmsNormRows(s_.mtp_embd, l.nextn_enorm.f32(), s_.mtp_embd, n, c.hidden_size,
              1, c.rms_eps, stream_);
  // The hidden input: kept trunk rows from `hidden_row`, or the block's
  // own carried residual.
  const float* hidden = s_.mtp_h;
  if (hidden_source && control_host_->hidden_row >= 0) {
    // Eager catch-up can normalize the trunk rows directly. Graphs use the
    // device-selected source below because their hidden-row index can change
    // on replay. Neither path modifies the trunk residual.
    hidden = hidden_source +
             static_cast<std::size_t>(control_host_->hidden_row) * hc_dim;
  } else {
    MtpHidden(hidden_source ? hidden_source : session.mtp_.target_hidden,
              session.mtp_.h, &session.control_->hidden_row, s_.mtp_h, n,
              hc_dim, stream_);
  }
  // Unlike the HC mixers, this normalization spans the complete HC * H row.
  RmsNormRows(hidden, l.nextn_hnorm.f32(), s_.mtp_h, n, hc_dim, 1, c.rms_eps,
              stream_);
  if (trace && !copy_trace(s_.mtp_h + final_row, trace->normalized_hidden))
    return false;
  // These projections determine persistent draft KV. Use the same row-wise
  // activation quantization and reduction for prompt chunks and decode;
  // changing between F16 GEMM and Q8 GEMV changes sampled replay after reuse.
  if (!DenseBatch(l.nextn_fc_embedding, s_.mtp_embd, s_.mtp_eproj, n,
                  error_msg) ||
      !DenseBatch(l.nextn_fc_hidden, s_.mtp_h, s_.mtp_res, n * c.hc_count,
                  error_msg)) {
    return false;
  }
  AddRowsBroadcast(s_.mtp_eproj, s_.mtp_res, n, c.hidden_size, c.hc_count,
                   stream_);
  if (trace && !copy_trace(s_.mtp_res + final_row, trace->fused))
    return false;
  Session::AttentionState attn;
  attn.rope = session.vision_input_.rope();
  attn.k_cache = session.mtp_.k_cache;
  attn.v_cache = session.mtp_.v_cache;
  attn.index_k = session.mtp_.index_k;
  attn.block_k = session.mtp_.block_k;
  // The draft block's attention runs at its own position.
  // Catch-up exports KV for every row but only carries its final residual.
  // Preserve that row's original query tile; earlier attention results
  // never contribute to the carried state.
  const bool last_only =
      !token && !candidates && n > 32 && control_host_->hidden_row >= 0;
  // Keep the final 128-column tile (and its predecessor for short tails).
  // At least 96 rows retain the wide mixer/projection arithmetic. Attention
  // still writes every KV/indexer row before the scratch view is narrowed.
  // Short catch-up also carries only its final row. Keep two rows so the
  // router and projections retain their multi-row arithmetic; the single
  // row route has a different floating-point reduction.
  const auto skipped =
      control_host_->hidden_row >= 0 && n > 2 && n <= kVecBatch
          ? n - 2
          : (last_only && n >= 224 ? (n - 96) / 128 * 128 : 0U);
  const bool cache_only = kv_only && !l.attn_qkv.empty();
  if (!HcMixBatch(l.hc_attn, s_.mtp_res, false, s_.mixed,
                  cache_only ? nullptr : s_.inject, n, error_msg)) {
    return false;
  }
  if (cache_only) {
    // Known trunk rows replace the predictor residual on the next forward.
    // Only K/V and pooled indexer keys survive this catch-up. Slice the
    // packed Q/gate/K/V weight without copying or changing its arithmetic.
    auto kv = l.attn_qkv;
    const TensorRef layout{.type = kv.type, .cols = kv.cols};
    kv.data = static_cast<std::uint8_t*>(kv.data) +
              std::size_t{2} * c.AttentionQDim() * layout.RowBytes();
    kv.rows = 2 * c.AttentionKvDim();
    if (!DenseBatch(kv, s_.mixed, s_.qg, n, error_msg) ||
        !PrepareAttention(s_.qg, kv.rows, nullptr, l.attn_k_norm.f32(), nullptr,
                          nullptr, attn.k_cache, attn.v_cache, n, 0,
                          c.num_kv_heads, c.head_dim, c.rotary_dim,
                          &session.control_->mtp_position, c.rope_theta,
                          c.rms_eps, stream_, attn.rope, false, yarn_)) {
      AssignError(error_msg, "MTP cache projection failed");
      return false;
    }
    const auto capacity =
        IndexerCapacity(c, options_.max_batch, session.max_context_);
    if (!DenseBatch(l.indexer_k, s_.mixed, s_.ik, n, error_msg))
      return false;
    StoreRows(s_.ik, attn.index_k, n, c.indexer_head_dim,
              &session.control_->mtp_position, capacity, stream_);
    if (pos + n > c.indexer_top_k) {
      PoolIndexerBlocks(
          attn.index_k, l.indexer_k_norm.f32(), attn.block_k,
          &session.control_->mtp_blocks, &session.control_->mtp_position, n,
          pool_grid, c.compress_ratio, c.indexer_head_dim, c.rotary_dim,
          c.rope_theta, c.rms_eps, capacity, stream_, attn.rope, yarn_);
    }
    return true;
  }
  if (!l.attn_qkv.empty()) {
    if (!DenseBatch(l.attn_qkv, s_.mixed, s_.qg, n, error_msg))
      return false;
  } else if (!DenseBatch(l.attn_q, s_.mixed, s_.qg, n, error_msg) ||
             !DenseBatch(l.attn_k, s_.mixed, s_.k, n, error_msg) ||
             !DenseBatch(l.attn_v, s_.mixed, s_.v, n, error_msg)) {
    return false;
  }
  if (!Attention(l, attn, s_.mixed, s_.block_out, n,
                 &session.control_->mtp_position, &session.control_->mtp_blocks,
                 pos, pool_grid, session.max_context_,
                 pos + n > c.indexer_top_k, error_msg, last_only, true,
                 skipped == 0)) {
    return false;
  }
  struct RestoreScratch {
    const Executor* executor;
    Scratch scratch;
    bool changed;
    ~RestoreScratch() {
      if (changed)
        executor->UseScratch(scratch);
    }
  } restore{this, s_, skipped != 0};
  const auto tail_rows = n - skipped;
  const auto tail_last = static_cast<std::size_t>(tail_rows - 1) * hc_dim;
  if (skipped != 0) {
    auto tail = RowScratch(s_, skipped);
    // Keep the producer's inject stride: it may use vectorized partials or
    // a single quantized projection rather than RowScratch's scalar layout.
    tail.inject = s_.inject + static_cast<std::size_t>(skipped) * c.hc_count *
                                  inject_parts_;
    UseScratch(tail);
    if (!Dense(l.attn_out, s_.ctx, s_.block_out, tail_rows, error_msg))
      return false;
  }
  // A trace reads the residual before the mixer.
  Combine(s_.mtp_res, l.hc_ffn.norm.f32(), tail_rows, nullptr,
          trace == nullptr ? &l.hc_ffn : nullptr);
  if (trace && !copy_trace(s_.mtp_res + tail_last, trace->attention))
    return false;
  if (!session.CheckCancellation(error_msg))
    return false;
  if (!HcMix(l.hc_ffn, s_.mtp_res, true, s_.mixed, s_.inject, tail_rows,
             error_msg) ||
      (trace && !copy_trace(s_.mixed + static_cast<std::size_t>(tail_rows - 1) *
                                           c.hidden_size,
                            trace->ffn_input))) {
    return false;
  }
  if (skipped != 0 && tail_rows == 2 &&
      !Check(hipMemcpyAsync(s_.mixed, s_.mixed + c.hidden_size,
                            c.hidden_size * sizeof(float),
                            hipMemcpyDeviceToDevice, stream_),
             "MTP tail padding", error_msg)) {
    return false;
  }
  // The discarded padding row shares the final row's routed experts, so
  // preserving multi-row arithmetic does not reread another expert set.
  if (!Moe(l, s_.mixed, s_.block_out, tail_rows, error_msg, last_only)) {
    return false;
  }
  Combine(s_.mtp_res, nullptr, tail_rows);
  if (trace &&
      !copy_trace(s_.block_out +
                      static_cast<std::size_t>(tail_rows - 1) * c.hidden_size,
                  trace->ffn_output))
    return false;
  if (trace && !copy_trace(s_.mtp_res + tail_last, trace->hidden))
    return false;
  if (trace && !trace->head.empty()) {
    if (!HcMix(l.nextn_head, s_.mtp_res + tail_last, false, s_.mixed, nullptr,
               1, error_msg) ||
        !copy_trace(s_.mixed, trace->head))
      return false;
  }
  const float* last = s_.mtp_res + tail_last;
  if (!Check(hipMemcpyAsync(session.mtp_.h, last, hc_dim * sizeof(float),
                            hipMemcpyDeviceToDevice, stream_),
             "MTP hidden carry", error_msg)) {
    return false;
  }
  return (!token && !candidates) ||
         MtpHead(l.nextn_head, last, token, candidates,
                 draft_subset ? &session : nullptr, error_msg);
}

}  // namespace gufo::models::qwen38_flash_next::rocm
