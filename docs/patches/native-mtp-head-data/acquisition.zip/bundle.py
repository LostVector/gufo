from pathlib import Path
import hashlib,json,zipfile,re
p=Path(__file__).resolve().parent;q=p/'source/docs/patches/native-mtp-head-data';q.mkdir(parents=True,exist_ok=False);entries={}
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(q/'acquisition.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in sorted(p.rglob('*')):
  rel=f.relative_to(p)
  if not f.is_file()or any(x in('source','__pycache__')or x.endswith('runtime')for x in rel.parts):continue
  if f.suffix in('.o','.a','.so','.bin')or f.name in('component','probe','gufo')or f.name.endswith('-private.json'):continue
  data=f.read_bytes();assert len(data)<15*1024**2,rel
  assert not re.search(rb'gh[opusr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),rel
  entries[str(rel)]=sha(data);z.writestr(str(rel),data)
(q/'archive.json').write_text(json.dumps({'archive_sha256':sha((q/'acquisition.zip').read_bytes()),'entries':entries,'excluded':'Binaries, model weights, object/static libraries, large snapshot payloads, private control configs, source review checkout and Python caches.'},indent=2)+'\n')
print(len(entries),'entries', (q/'acquisition.zip').stat().st_size,'bytes')
