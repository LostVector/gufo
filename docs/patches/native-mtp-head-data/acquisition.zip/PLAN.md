# TP2 native MTP optimization

User authorized native MTP optimization after merging fork18. Keep all work
isolated and restore the current MTP service. No driver/kernel/ROCm changes,
whole-table warming, upstream publication or live binary replacement.

1. Pin fork tp2 ff485f17. Reuse its exact-source production artifact from the
   preceding qualified study; record source/build relationship. Build a separate
   bounded source observer. No added HIP synchronizations or GPU work.
2. Run matched control and observer on short/actual2048 greedy and sampled
   workloads, natural EOS, 64K capacity, one slot, chunk2048, target UD-Q4_K_XL
   and shared Q8 MTP. Record actual target widths, draft/catch-up, target forward,
   verification/rollback and host-controller costs on both ranks. Retain timings,
   work differences and transport errors. Observer timings are diagnostic only.
3. Choose one measured bottleneck; prototype a small reversible change. Wider
   native vocabulary-head sharing is only a hypothesis until real widths/costs
   show it is relevant. Do not change arithmetic, state, RNG or dependencies.
4. Before timing: full-logit/component and actual-engine state/replay tests for
   affected shapes. Compare production builds with fixed alternating starts,
   retain all failures/phase flags and actual speculative work. Cover C1/C2 if
   both are affected. Do not infer significance from a small pilot.
5. Advance a gain to predeclared balanced confidence testing only if warranted;
   document results and residual risks. No new PR or deployment automatically.
