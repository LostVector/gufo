from pathlib import Path
import hashlib,importlib.util,json,os,shutil,socket,subprocess,sys
p=Path(__file__).resolve().parent;root=p.parents[2];src=root/'tp-cache-retention/dflash2-flash-next-worktree';tests=src/'tests/functional';sys.path.insert(0,str(tests))
spec=importlib.util.spec_from_file_location('functional_runner',tests/'run.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
from cache_disk_spacing import check_disk_spacing
meta=json.loads((p.parent/'candidate-binary.json').read_text())['candidate'];assert hashlib.sha256(Path(meta['binary']).read_bytes()).hexdigest()==meta['sha256']
wrapper=root/'tp-cache-retention/dflash2-flash-next-port-v1/functional-lookup-ranks-2026-11-05.py';python=root/'first-token-preview/functional-venv/bin/python';assert not(p/'isolated-complete').exists()
for width,kind in [(7,'spacing'),(7,'cancel-persist')]:
 out=p/f'w{width}-isolated-{kind}';out.mkdir(exist_ok=False)
 with socket.socket()as s:s.bind(('127.0.0.1',0));port=str(s.getsockname()[1])
 url='http://127.0.0.1:'+port
 cmd=[str(wrapper),'serve','llm','--model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','--served-model-name','mtp-qual','--speculative','mtp','--mtp-model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf','--draft-tokens',str(width),'--context','65536','--sessions','2','--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off','--host','127.0.0.1','--port',port,'--cache-disk',str(out/'disk'),'--cache-disk-bytes',str(8*1024**3),'--cache-disk-staging-bytes',str(1024**3)]
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(Path(meta['binary']).parents[1]);env['DFLASH_TP_LAUNCH_RECORDS']=str(out/'ranks')
 records=[]
 def run(label,script,extra):
  command=[str(python),str(tests/script),'--url',url,'--model','mtp-qual','--output',str(out/(label+'.json')),*extra];records.append(command)
  with(out/(label+'.log')).open('w')as f:subprocess.run(command,env=env,cwd=src,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
  assert json.loads((out/(label+'.json')).read_text()),label
  print('PASS isolated',width,kind,label,flush=True)
 (out/'protocol.json').write_text(json.dumps({'command':cmd,'binary':meta,'scope':'Unmodified existing HTTP fixtures, isolated disk-spacing ownership. No MIN_STEP/filter/assertion changes. Separate cache ownership avoids known legacy aggregate contamination; assertions unchanged.'},indent=2)+'\n')
 try:
  with runner.server(cmd,out/'server.log',240,environment=env):
   if kind=='spacing':run('spacing','cache_disk_spacing.py',[])
   else:
    for label,extra in [('text-cancel',['--case','content-preserve0-sampled0','--discard-assistant']),('thinking-tool-cancel',['--case','reasoning_content-preserve1-sampled1','--reasoning-effort','high','--tools']),('legacy-tool-cancel',['--case','content-preserve1-sampled0','--tools','--legacy-tool-history'])]:run(label,'continuation.py',['--prefix-repetitions','16',*extra])
    run('persist','cache_persist.py',[])
  with runner.server(cmd,out/'server-restarted.log',240,environment=env):
   if kind=='spacing':run('spacing-disk','cache_disk_spacing.py',['--restore',str(out/'spacing.json')])
   else:
    for label in ('text-cancel','thinking-tool-cancel','legacy-tool-cancel'):run(label+'-disk','continuation.py',['--restore',str(out/(label+'.json'))])
    run('persist-disk','cache_persist.py',['--restore',str(out/'persist.json')])
  if kind=='spacing':
   a=json.loads((out/'spacing.json').read_text())[0];b=json.loads((out/'spacing-disk.json').read_text())[0];result=check_disk_spacing((out/'server.log').read_text(),(out/'server-restarted.log').read_text(),a,b);(out/'spacing-validation.json').write_text(json.dumps(result,indent=2)+'\n')
  (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');(out/'complete').touch()
 finally:
  shutil.rmtree(out/'disk',ignore_errors=True)
  # The peer's cache is fixture-owned and no longer needed after restart checks.
  code='from pathlib import Path;import shutil;p=Path('+repr(str(out/'disk'))+');assert str(p).startswith('+repr(str(p))+');shutil.rmtree(p,ignore_errors=True)'
  import shlex
  subprocess.run(['ssh','-o','BatchMode=yes','rkuo@rk-corsair-ai',shlex.join(['python3','-c',code])],check=False)
(p/'isolated-complete').touch();print('PASS all isolated cache ownership checks',flush=True)
