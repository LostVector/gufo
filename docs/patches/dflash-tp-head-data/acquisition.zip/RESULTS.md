# Qualification result

The proposed TP2 DFlash head-sharing guard preserves covered numerical/state
behavior and produces statistically resolved decode gains on the predeclared
workload. It remains a fork review candidate, not a live service replacement
or a uniform-latency/general-model-quality claim. NativeMTP is restored.

## Fixed confirmation

Forty fresh starts,200requests including40warmups;10independent processpairs
perwidth, balanced randomized BC/CB order, heldout sampledseeds2001..2010.
All output and non-timing usage/work identities match. Greedy and seeded sampled
short/actualpp2048 tasks,1slot,65,536capacity,chunk2048,UD-Q4_K_XL/Q8_0DFlash2,
fixed draftwidth3/7,neutralpenalties/thinkingoff,1GiB RAMcache,promptcacheoff.
No sampler/profiler in timing runs. Pilot data are not pooled.

| Draft / target rows | Decode change | Marginal95% paired-process CI | Holm-adjusted exact p | Whole-client-wall throughput change |
| --- | ---: | --- | ---: | ---: |
|3 /4|+1.836%|[+1.634,+2.044]%|0.015873|+1.452%|
|7 /8|+0.868%|[+0.639,+1.081]%|0.015873|+0.719%|

Decode is the registered primary outcome, clustering allfour tasks within
processpair. Exact two-sided randomization enumerates252balanced assignments;
Holm covers the two widths. Bootstrap20,000draws preserve BC/CB strata. CIs are
marginal/conditional on these tasks/seeds. Wall-throughput is secondary, not
an additional multiplicity-controlled claim. Fourrow all10pair estimates positive;
eightrow9/10positive. Small gains were not rejected by a magnitude threshold.

| Width | Workload | Reference decode tok/s | Candidate | Paired change |
| --- | --- | ---: | ---: | ---: |
|3|short-greedy|63.23|64.32|+1.729%|
|3|short-sampled|65.17|66.43|+1.933%|
|3|pp2048-greedy|57.81|58.96|+1.984%|
|3|pp2048-sampled|51.94|52.83|+1.698%|
|7|short-greedy|62.49|63.01|+0.844%|
|7|short-sampled|64.20|65.03|+1.297%|
|7|pp2048-greedy|54.84|55.33|+0.898%|
|7|pp2048-sampled|53.32|53.55|+0.434%|

All14correlated phase entries across11paired requests remain:6snapshot,4prefill,
3TTFT,1max-inter-token. Largest prefill regression115ms andTTFT110ms in one
eightrow pair. Sixteen starts have recovered transport errors (9reference,
7candidate); none excluded/replaced. These do not erase the registered decode
result, nor do mean gains clear tails or prove candidate-specific error causation.
No adaptive-policy/long-depth speedup or unconditional serving gain is inferred.

## Quality and actual-route proof

Quality probe294records/28complete serialized post-replay state comparisons
PERnode; actualshort/16K/32K, greedy/compact sampled plus short noncompact sampled
with penalties. All complete verification matrices/frontier logits finite and
bit-identical; tokens/RNG(deferred draw)/history/work/positions match.126actual
gather cycles and107sampled rejection cycles PERnode; fallbackrows1/2/3/7 and
changedrows4/8 asserted. Borrowed-object same/cross, serialized and file restores;
borrowed objects were materialized before mutation. Diagnostic extra sync is not
an async-lifetime or throughput claim. The preceding real-weight component
checks32cases/29,798,400logits+guards PERnode.

Uninstrumented HTTP passes both-width stop/state-edge/24.6Khistory/cached replay,
cancellation/resume and disk restart behavior. Original width3 aggregate cache
report remains failed due demonstrable foreign-conversation checkpoint2828
misattribution by the legacy token-range filter. Every individual check passed;
isolated unchanged spacing assertions pass both widths, as do independent
cancellation/persistence restart checks. No assertion/tolerance is relaxed.

Production wire deltas with identical inference work show169–200additional
dataWRs/start atwidth3 and130–160atwidth7 on bothnodes, consistent with extra
head exchanges. This is not a direct per-call kernel trace. Code and all915-file
format gates preserve exact measured production source bytes. No new kernel,
public option, allocation or API contract; existing lossless gather reused.

## Separate tail/error correlation

Four bounded source/counter diagnostic starts, bothhosts, no SDK or addedGPU
waits. Pollmedian~1.055ms,p95~1.07ms, actualmax recorded; sampleruses8–10%ofone
CPUcore and is absent from the confidence study. Its one setup failure incorrectly
treated the live queue-depth gauge as monotonic; raw attempt retained, guardfixed.

Reproduced CRC/badframe/lost/retransmit counterchanges in reference ANDcandidate
fourrow runs, during the actual2,041-token prefill-forward call (~1.45/1.51s),
with detection brackets~1.1–1.3ms. Eightrow diagnostic starts have noerror events.
These observations locate the reproduced detections in shared prefill execution,
not the DFlash vocabulary-head call. They do not establish DMAarrival time,
error cause, or causal attribution for all14untraced flags. No cross-host
timestamp subtraction. Source timings and per-ms queue activity remain raw.

## Decision

Prepare one focused draft PR to our fork with code/source/evidence for review.
Retain both guarded shapes: both primary decode outcomes resolve positively;
no arbitrary small-gain cutoff. Keep the tail/transport and fixed-workload limits
visible. Do not publish/update upstream or change the live nativeMTP service.
The driver errors are a separate remaining reliability/latency investigation,
not grounds to call all source CPU waits avoidable.
