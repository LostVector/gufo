# DFlash2 TP2 vocabulary-head qualification

Parent0733d3f2 and unchanged candidate9a5a9d43 (from the November9 pilot).
ApprovedB6 driver/TX32/RX1ms, existing dual cables, privateROCm7.14.1/gfx1151,
UD-Q4_K_XL target/officialQ8_0 DFlash2. No system/default/upstream change.
NativeMTP trial is paused under the shared model lock and restored after each
owned acquisition. No whole-ngram-table warming or Halogen startup.

## Numerical/state qualification — passed

The quality-only probe uses one resident model with a test-only head-route
toggle. Disabled reproduces the unchanged external-target route; enabled is
exactly the proposed guarded4/8-row route. It captures the ENTIRE target-head
matrix before acceptance and the full committed frontier, checking finite values
and exact SHA256 for every float byte. Added capture synchronization is diagnostic
only; this is not an uninstrumented timing or asynchronous-lifetime proof.

Both nodes pass7cases,294records and28complete post-replay state comparisons EACH.
Actual prefix depths are short,16,384and32,768. Greedy/compact sampled cover all
three depths; noncompact sampled with penalties covers short depth. Candidate
rows4/8 and fallbacks1/2/3/7 actually execute. Each rank records126eligible gathered
cycles and107sampled rejection cycles, so passing fallback/perfect acceptance
cannot masquerade as coverage. Exact cross-node verification/frontier hashes agree.

Comparisons include tokens, RNG including deferred draw, sampler history,
proposal/accept/lookup work, positions and every byte of complete materialized
serialized target/draft/recurrent state after borrowed-object same/cross-session,
serialized cross-session and file-roundtrip restores. Borrowed objects are
materialized before the reference mutation to compare complete byte payloads;
this is not a separate unmaterialized copy-on-write race test. Real HTTP cache
and cancellation qualification below exercises the normal uninstrumented path.

The latest file-roundtrip payload is retained; earlier cases were compared in
process and hashes are retained. No partial-logit digest substitutes for the
full verification-row capture. Baseline equivalence is not original-author
model/acceptance parity. Source/build/archive-member provenance and both raw
rank logs are under state/. The diagnostic modifies only executor.cpp in a copy
of the candidate archive; remaining production/GPU objects stay unchanged.

Recovered transport errors during this quality probe are retained: EVO
retransmit2/lost14/badframe11/CRC11/overrun2; Corsairretransmit6/lost3/badframe3/CRC3.
They did not produce an observed output/state mismatch; no driver reliability
or latency guarantee follows from that fact.

## HTTP behavior — properties passed; aggregate fixture failure retained

Uninstrumented candidate is tested with fixed widths3/7,64Kcapacity,2slots,
chunk2048,1GiB RAMcache. Existing stops/state-edge and long-context suites pass
at both widths. Actual long histories include24,647/24,748/24,767prompt tokens,
with cached replay, sampling, cancellation/resume and structured outputs.

Width3's original combined runner records every individual subcheck passed,
including allthree cancellation roles and disk restores, cache_persist policy,
and disk-spacing growth/restore. Its final aggregate spacing checker FAILS,
and the report remains failed. Legacy logs lack per-checkpoint provenance:
the range-based checker includes a later, different cache-persist conversation's
2,828-token checkpoint among the spacing fixture's2,447/6,278checkpoints.

Isolated spacing grow/restart/branch tests run unchanged in their own caches
at both widths: stored2,447/6,278,13min-step skips, valid shared branch3,043.
Original MIN_STEP2048/filter/assertions are unchanged. Width7 cancellation and
persist fixtures also pass independently, including allthree disk-replayed
cancellation roles. This establishes tested behavior despite the known aggregate
harness attribution error; it does not retroactively turn the failed report green.
functional/DISK-SPACING-FAILURE.md, original report, standalone commands and
isolated validation retain the evidence. Functional recordings retain every
request timing; they do not establish matched cache/cancel timing superiority.

## Fixed confidence study

PROTOCOL.md and confirmation/DESIGN.json were written before acquisition.
40fresh starts,10independent processpairs PERwidth3/7, fivebaseline→candidate
andfivecandidate→baseline orders perwidth, seeded pairgroup randomization.
One64-token warmup plus four128-capped measured cases perstart: short and actual
pp2048, greedy and sampled. Sampled seeds2001..2010 are heldout from the pilot
and matched withinpair. Actual naturalEOS/output counts are strict withinpair,
not forced equal across widths or seeds.1slot,64Kcapacity,chunk2048,1GiB RAMcache,
neutralpenalties/thinkingoff/fixeddraftwidth/no promptcache/no profiler or sampler.

Primary perpair outcome is the mean log decode-rate ratio across four cases,
with processpair as the cluster. Exact two-sided balanced-order randomization
has252assignments perwidth; Holm adjusts the two width hypotheses.20,000paired
bootstrap draws stratified by BC/CB produce marginal95%CIs conditional on these
four tasks/seeds. Whole-client-wall throughput is a separate exploratory outcome.
Sanity checks for zero/constant positive/negative effects are archived.

Every output and non-timing usage field must match. All phase regressions above
BOTH5%and3ms, driver errors and raw results remain, with no sample replacement,
exclusion or optional stopping. No pooling with the earlier pilot. A statistically
resolved small gain remains useful; latency/quality limits stay separate.

## Correlation follow-up

Prepared source/counter diagnostic remains separate from throughput. It captures
actual target/prefill source intervals and node-local errorcounter-change
brackets from a nominal1ms root read-only debugfs sampler, without an SDK,
new GPU waits, driver reload or parameter changes. Actual polling CPU/intervals
are recorded. Counter detection time is not DMAarrival or proof of cause.
No cross-host clock subtraction. A bounded failure to reproduce stays inconclusive.

## Artifacts and reproduction

All workflows require the recorded lab layout and pinned dependencies/models;
use fresh output directories to repeat, preserving failures. state/build.py is
run under dflash-upstream-2026-11-07/build.sh; state/run-locked.sh owns the model
lock. functional/ contains the original aggregate runner and independent
ownership replays. confirmation/run-locked.sh requires both numerical and
functional behavior gates. Analyze only after fixed acquisition completes:

```bash
python3 confirmation/analyze.py
```

Binaries remain isolated. No upstream PR is published or updated. Publication
and adoption decisions retain exact source/binary pins and all qualifications.
