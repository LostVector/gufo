from pathlib import Path
import hashlib,json,os,subprocess
p=Path(__file__).resolve().parent;root=p.parents[2];src=root/'tp-cache-retention/dflash2-flash-next-worktree';old=root/'tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost/head-experiment';binary=json.loads((old/'binary.json').read_text());assert hashlib.sha256(Path(binary['binary']).read_bytes()).hexdigest()==binary['sha256'];assert not(p/'w7-sdk-protocol.json').exists()
wrapper=root/'tp-cache-retention/dflash2-flash-next-port-v1/functional-lookup-ranks-2026-11-05.py'
commands=[]
for width in(7,):
 label='w'+str(width)+'-sdk';cmd=[str(root/'first-token-preview/functional-venv/bin/python'),str(src/'tests/functional/run.py'),'--record-baseline','--output',str(p/label),'--sampling-preset','qwen38','--expected-input-modalities','text','--startup-timeout','240','--request-timeout','240','--suite-timeout','1800']
 for suite in('stops','long-context','state-edges'):cmd+=['--suite',suite]
 cmd+=['--',str(wrapper),'serve','llm','--model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','--served-model-name','dflash-qual','--speculative','dflash2','--dflash-model','/home/rkuo/models/Qwen3.8-Flash-Next-DFlash2-GGUF/Qwen3.8-Flash-Next-DFlash2-Q8_0.gguf','--draft-policy','fixed','--draft-tokens',str(width),'--context','65536','--sessions','2','--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off'];commands.append((label,cmd))
(p/'w7-sdk-protocol.json').write_text(json.dumps({'binary':binary,'commands':commands,'scope':'Candidate-only existing HTTP correctness suites, record-baseline is harness recording mode, not source identity. Both fixedwidths,64Kcapacity,longhistory/cache/restart/cancel. No matched functional timing superiority claim; all raw request timings retained.'},indent=2)+'\n')
for label,cmd in commands:
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(Path(binary['binary']).parents[1]);env['DFLASH_TP_LAUNCH_RECORDS']=str(p/(label+'-ranks'))
 print('START functional',label,flush=True)
 with(p/(label+'-controller.log')).open('w')as f:r=subprocess.run(cmd,env=env,cwd=src,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode)
 report=json.loads((p/label/'report.json').read_text());assert report['status']=='passed',report
 print('PASS functional',label,flush=True)
(p/'w7-sdk-complete').touch()
