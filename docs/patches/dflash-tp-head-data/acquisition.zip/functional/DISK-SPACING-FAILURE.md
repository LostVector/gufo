# Retained aggregate disk-spacing failure

The unmodified existing width3 runner reports failed after all13individual
HTTP subchecks pass. The final aggregate spacing filter sees2447,2828,6278.
2828 is the checkpoint from the separate cache-persist control (prompt2835),
which runs after spacing growth but before server shutdown. The legacy cache
log lacks checkpoint provenance and check_disk_spacing falls back to the broad
token-count range2447..6640; it accidentally includes that other conversation.

Evidence: disk-spacing.json turn prompt counts2454,2745,3036,3327,3618,6285,6576;
cache-persist.json control prompt2835; server.log shows spacing saves2447/6278
and then the later persist control save2828. Individual restart/disk-cancel,
persist and spacing-restore checks pass. Original report remains failed.

Resolution test isolates existing spacing grow/restore scripts in their own
server and private cache, retaining original MIN_STEP2048 and all assertions.
No filter/threshold/tolerance is weakened. Width7 uses the same isolated
spacing fixture; cancellation/persist fixtures keep separate ownership.
This is evidence of harness interference, not a cleared production timing
regression or a retroactively passing aggregate report.
