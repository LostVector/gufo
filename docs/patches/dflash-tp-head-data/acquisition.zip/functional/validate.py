from pathlib import Path
import json
p=Path(__file__).resolve().parent;a=json.loads((p/'w3/report.json').read_text());b=json.loads((p/'w7-sdk/report.json').read_text())
assert a['status']=='failed'and'disk checkpoints closer'in a['error'];assert all(x['status']=='passed'for x in a['suites'].values());assert b['status']=='passed'
for name in('w3-isolated-spacing','w7-isolated-spacing','w7-isolated-cancel-persist'):assert(p/name/'complete').exists()
for name in('w3-isolated-spacing','w7-isolated-spacing'):
 x=json.loads((p/name/'spacing-validation.json').read_text());assert x['stored_tokens']==[2447,6278]and x['min_step_skips']>=5and x['shared_boundary_tokens']
assert(p/'isolated-complete').exists();(p/'behavior-complete').touch();print('PASS recorded behavior coverage; original aggregate failure retained')
