# DFlash TP2 head-sharing qualification

User authorizes full logits/state/rollback/restore, longer-context/cache/cancel,
then fixed balanced confirmation with retained timing flags/transport errors.
Reference0733d3f2; production candidate SHA9a5a9d43 from preceding study, unchanged.
No system/kernel/ROCm/driver/default changes; B6/TX32/RX1ms/existingdualcables.
NativeMTPtrial paused/restored under shared model-matrix flock on every exit.
No upstream publication. Apply repo optimize-kernel workflow.

State diagnostic: same current candidate archive, one executor.cpp object replaced
with test-only route toggle and full head-row capture, ordinary same compiler.
No performance evidence from diagnostic. Before every cycle reset capture; OFF
reproduces0733external route and ON reproduces exactcandidate. Capture includes
every full verification head row (not only selected logits), added sync is
diagnostic only. Check tokens, every committed logit, RNG, proposal/accept/lookup
work, positions and complete materialized snapshot bytes. Short/16K/32K actual
prefixes, greedy/compact sampled; short noncompact sampled penalty mode. Force
exact target row budgets1/2/3/4/7/8 to test candidate and fallbacks, retaining
normal p/q/RNG and lookup. Borrowed same/cross-session, serialized and file
roundtrip; no tolerant comparison or golden replacement. Gateactualgathercounts.

Functional candidate: existing HTTP suites cache,cancel,long-context at64K
capacity, actual mode/draft checks. Use matched reference for timing comparison,
not duplicate broad correctness. NaturalEOS/greedy/seeded sampled/continuations
and cache restart included where existing suite specifies. Keep failures.

Confirmation ONLY after numerical gate: ten independent process pairs PER
width3/7,20starts perwidth, balanced fiveB/C andfiveC/B in fixed seeded random
order. Same four measured cases as preceding short/pp2048 greedy/sampled study,
one64-output warmup/start; cap128 with naturalEOS,1slot/65,536capacity/chunk2048,
1GiB RAMcache, UD-Q4_K_XL/Q8_0DFlash2,fixedwidth, neutralpenalties,no promptcache.
Primary metric perpair: geometric mean of matched decode-rate ratios across
allfour cases, respecting process cluster; both width hypotheses tested two-sided
with exact balanced-order randomization (252assignments), Holm overtwo widths.
Report bootstrap paired-process95%CIs, case-specific descriptive rates and all
per-request phases above BOTH5%and3ms. Tenpairs fixed; no optional stopping or
sample replacement/exclusion for errors/noise. Every choice and non-timingusage
field must match perwidth; actual draft work verified. No profiler/admin sampler
during throughput. Retain before/after errors/boot/link/module/PID metadata.
Only current study is confirmatory; do not pool preceding pilot.

After fixed acquisition, use separate bounded node-local driver-counter sampler
on flagged histories if errors/latency flags persist. Correlate counter-change
brackets with request timing, never subtract host clocks or claim causation
from launch-level deltas. Keep diagnostic overhead separate from confirmation.
A statistically significant small gain remains useful; tail/quality limitations
stay visible and do not become an arbitrary magnitude cutoff.

Confirmation sampledseeds are heldout2001..2010(2000+pair), identicalwithinpair;
greedyseed43 unchanged. Pairgroups acrosswidths shuffled byseed20261109, with
fiveBC/fiveCB perwidth fixed beforeacquisition. DESIGN.json pins all40starts.

Bootstrap resamples wholepairs within BC/CB strata(5+5), preserving designed
orderbalance and allfourcase cluster. No change to hypothesis/count/testfamily.
