First separate counter diagnostic completed its five output/work checks but
its sampler rejected a falling data_wr_live value. That value is an instantaneous
queue gauge, not a cumulative counter. Original source/controller/client logs
remain in failed-sampler0-baseline; the guard now excludes only that gauge from
monotonic assertions. No driver reset or model mismatch occurred. The fixed
unprofiled40start study predates this observer and is unaffected. Corrected
diagnostic remains fourbounded starts; no event-conditioned sample selection.
