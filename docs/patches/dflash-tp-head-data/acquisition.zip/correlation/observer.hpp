#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
namespace dcost {
inline long long now() {
 return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
struct Row {
 const char* stage{};std::uintptr_t owner{};unsigned position{},rows{},emitted{},drafted{},accepted{};
 long long begin{},end{},clock_before{},clock_after{};std::uint64_t sdk{};int status=-1;
 std::atomic<bool> complete{false};
};
struct Recorder {
 const char* path=std::getenv("GUFO_DFLASH_COST_PATH");
 std::array<Row,8192> rows{};std::atomic<unsigned> next{0};
 ~Recorder() {
  if (!path) return;
  auto* f=std::fopen(path,"w");if(!f)return;
  auto n=next.load();std::fprintf(f,"# capacity=8192 total=%u overflow=%u\n",n,n>8192?n-8192:0);
  std::fprintf(f,"stage,owner,position,rows,begin_ns,end_ns,clock_before_ns,sdk_ns,clock_after_ns,status,emitted,drafted,accepted\n");
  for(unsigned i=0;i<n&&i<8192;++i) {
   const auto& r=rows[i];if(!r.complete.load(std::memory_order_acquire))continue;
   std::fprintf(f,"%s,%llu,%u,%u,%lld,%lld,%lld,%llu,%lld,%d,%u,%u,%u\n",r.stage,(unsigned long long)r.owner,r.position,r.rows,r.begin,r.end,r.clock_before,(unsigned long long)r.sdk,r.clock_after,r.status,r.emitted,r.drafted,r.accepted);
  }
  std::fclose(f);
 }
};
inline Recorder recorder;
inline void calibrate(Row&) {}
struct Scope {
 Row* row=nullptr;
 Scope(const char* stage,const void* owner,unsigned pos,unsigned rows) {
  if(!recorder.path)return;
  auto i=recorder.next.fetch_add(1,std::memory_order_relaxed);if(i>=8192)return;
  row=&recorder.rows[i];row->stage=stage;row->owner=reinterpret_cast<std::uintptr_t>(owner);row->position=pos;row->rows=rows;
  calibrate(*row);row->begin=now();
 }
 void work(unsigned drafted,unsigned emitted,unsigned accepted){if(row){row->drafted=drafted;row->emitted=emitted;row->accepted=accepted;}}
 ~Scope(){if(row){row->end=now();row->complete.store(true,std::memory_order_release);}}
};
}
