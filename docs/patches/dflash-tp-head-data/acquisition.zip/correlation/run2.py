from pathlib import Path
import hashlib,json,os,shlex,signal,socket,subprocess,sys,time,urllib.request
p=Path(__file__).resolve().parent;root=p.parents[2];peer='rkuo@rk-corsair-ai';old=root/'tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost';assert not(p/'protocol2.json').exists();meta=json.loads((p/'binaries.json').read_text());cases=json.loads((old/'protocol.json').read_text())['cases']
def call(rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(args)]if rank else args,text=True,timeout=60)
def canon(x):
 if isinstance(x,dict):return{k:canon(v)for k,v in x.items()if not k.endswith('_ms')and not k.endswith('_per_second')}
 if isinstance(x,list):return[canon(v)for v in x]
 return x
for role,m in meta.items():
 assert hashlib.sha256(Path(m['binary']).read_bytes()).hexdigest()==m['sha256'];call(1,['mkdir','-p',str(Path(m['binary']).parent)]);subprocess.run(['rsync','-a',m['binary'],peer+':'+m['binary']],check=True)
call(1,['mkdir','-p',str(p)]);subprocess.run(['rsync','-a',*[str(p/x)for x in('sample.py','run-rank.py','binaries.json')],peer+':'+str(p)+'/'],check=True)
protocol={'sequence':[(r,w)for w in(3,7)for r in('baseline','candidate')],'binaries':meta,'scope':'Bounded source/error-counter diagnostic, NOT throughput/confidence. Node-local source and sampler clocks. No driver change/profiler/extra GPU wait. Original samewidth control output/work strict.'};(p/'protocol2.json').write_text(json.dumps(protocol,indent=2)+'\n')
for role,width in protocol['sequence']:
 label='w'+str(width);out=p/role/label;out.mkdir(parents=True,exist_ok=False)
 for rank in(0,1):
  assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/srcversion']).strip()=='B6C332F34D27E163651EE38';assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/refcnt']).strip()=='0';(out/f'before-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
 with socket.socket()as s:s.bind(('127.0.0.1',0));port=str(s.getsockname()[1])
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(Path(meta[role]['binary']).parents[1]);env['DFLASH_TP_LAUNCH_RECORDS']=str(out/'launch')
 for k in('ROCP_TOOL_ATTACH','LD_PRELOAD','GUFO_DFLASH_COST_PATH'):env.pop(k,None)
 cmd=[sys.executable,str(p/'launcher.py'),'serve','llm','--model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','--served-model-name','dflash-cost','--speculative','dflash2','--dflash-model','/home/rkuo/models/Qwen3.8-Flash-Next-DFlash2-GGUF/Qwen3.8-Flash-Next-DFlash2-Q8_0.gguf','--draft-policy','fixed','--draft-tokens',str(width),'--context','65536','--sessions','1','--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off','--host','127.0.0.1','--port',port]
 print('START diagnostic',role,label,flush=True);workers=[];logs=[];rows=[]
 with(out/'server.log').open('w')as f:
  proc=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+240
   while True:
    assert proc.poll()is None,'server exit'
    try:
     with urllib.request.urlopen('http://127.0.0.1:'+port+'/health',timeout=1)as r:
      if r.status==200:break
    except OSError:pass
    assert time.monotonic()<deadline;time.sleep(.2)
   launch=next((out/'launch').glob('*'))
   for rank in(0,1):
    m=json.loads(call(rank,['cat',str(launch/f'rank{rank}-pid.json')]));args=['sudo','-n','/usr/local/sbin/strix-driver-lab','run',str((p/'sample.py').relative_to(root)),role,str(rank),str(m['pid']),label]
    if rank:args=['ssh','-o','BatchMode=yes',peer,shlex.join(args)]
    log=(out/f'sampler-r{rank}.log').open('w');logs.append(log);workers.append(subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT))
   deadline=time.monotonic()+15
   while True:
    assert all(w.poll()in(None,0)for w in workers),'sampler failed'
    ready=[]
    for rank in(0,1):
     try:ready.append(call(rank,['test','-f',str(out/f'sample-r{rank}/ready')])=='')
     except subprocess.CalledProcessError:ready.append(False)
    if all(ready):break
    assert time.monotonic()<deadline;time.sleep(.1)
   for i,(name,prompt,temp,seed,limit)in enumerate(cases):
    body={'model':'dflash-cost','messages':[{'role':'user','content':prompt}],'max_tokens':limit,'temperature':temp,'top_p':.95,'top_k':20,'seed':seed,'presence_penalty':0,'frequency_penalty':0,'repeat_penalty':1,'cache_prompt':False,'cache_persist':False,'chat_template_kwargs':{'enable_thinking':False}}
    start=time.monotonic_ns();req=urllib.request.Request('http://127.0.0.1:'+port+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=240)as response:reply=json.load(response)
    end=time.monotonic_ns();ref=json.loads((old/'control'/label/f'{i}-{name}-response.json').read_text());assert reply['choices']==ref['choices']and canon(reply['usage'])==canon(ref['usage']),(role,label,name)
    row={'case':name,'warmup':i==0,'begin_ns':start,'end_ns':end,'usage':reply['usage'],'timings':reply['timings']};rows.append(row);(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(out/f'{i}-{name}.json').write_text(json.dumps(reply,indent=2)+'\n')
   for rank in(0,1):call(rank,['touch',str(out/f'sample-r{rank}/stop')])
   for w in workers:assert w.wait(timeout=15)==0
  finally:
   for rank,w in enumerate(workers):
    if w.poll()is None:
     try:call(rank,['touch',str(out/f'sample-r{rank}/stop')]);w.wait(timeout=15)
     except Exception:w.terminate()
   if proc.poll()is None:
    proc.send_signal(signal.SIGINT)
    try:proc.wait(timeout=40)
    except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=20)
   for log in logs:log.close()
 subprocess.run(['rsync','-a',peer+':'+str(out/'sample-r1')+'/',str(out/'sample-r1')+'/'],check=True);subprocess.run(['rsync','-a','--include=*/','--include=*-cost.csv','--exclude=*',peer+':'+str(out/'launch')+'/',str(out/'launch')+'/'],check=True)
 for rank in(0,1):
  assert call(rank,['cat','/sys/module/thunderbolt_ibverbs/refcnt']).strip()=='0';(out/f'after-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']));assert len(list((out/'launch').rglob(f'rank{rank}-pid-cost.csv')))==1
 (out/'complete').touch();print('PASS diagnostic',role,label,flush=True)
(p/'complete').touch()
