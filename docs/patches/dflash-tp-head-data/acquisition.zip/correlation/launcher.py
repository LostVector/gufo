#!/usr/bin/env python3
"""Task-private two-rank launcher for the unmodified functional HTTP harness.

The parent harness owns the HTTP port and cache lifecycle. Each invocation owns
both rank processes and fresh bootstrap/control ports; restart starts both ranks.
"""
from pathlib import Path
import json
import os
import secrets
import shlex
import signal
import socket
import subprocess
import sys
import time

lab = Path(__file__).resolve().parent
peer = 'rkuo@rk-corsair-ai'
out = Path(os.environ['DFLASH_TP_LAUNCH_RECORDS']) / secrets.token_hex(8)
out.mkdir(parents=True, exist_ok=False)
binary = Path(os.environ['DFLASH_TP_RUNTIME']) / 'bin/gufo'
launcher = lab / 'run-rank.py'
args = sys.argv[1:]
assert args[0] == 'serve' and 'llm' in args
assert not any(flag in args for flag in ('--tp-rank', '--tp-control-token'))

def remote(command, **kwargs):
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                           peer, shlex.join(command)], check=True, **kwargs)

held = [socket.socket(), socket.socket()]
for sock in held:
    sock.bind(('0.0.0.0', 0))
ports = [str(sock.getsockname()[1]) for sock in held]
for sock in held:
    sock.close()
common = args + ['--tp-world-size', '2', '--tp-bootstrap-host', '192.168.64.125',
                 '--tp-bootstrap-port', ports[0], '--tp-control-port', ports[1],
                 '--tp-control-token', secrets.token_hex(32),
                 '--tp-rdma-device', 'usb4_rdma0']
remote(['mkdir', '-p', str(out)])
processes = []
stopping = False

def stop(signum, frame):
    global stopping
    stopping = True
    # Forward shutdown to the actual head, not the SSH transport.
    if processes and processes[0].poll() is None:
        processes[0].send_signal(signal.SIGINT)

for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, stop)

cleanup = '''from pathlib import Path
import json,os,signal,sys,time
p=Path(sys.argv[1])
if not p.exists():raise SystemExit(0)
m=json.loads(p.read_text());proc=Path('/proc')/str(m['pid'])
def same():
 return proc.exists() and (proc/'exe').resolve()==Path(m['binary']) and (proc/'stat').read_text().rsplit(')',1)[1].split()[19]==m['start_ticks']
if same():
 os.kill(m['pid'],signal.SIGTERM)
 for i in range(80):
  if not same():break
  time.sleep(.1)
 else:
  if same():os.kill(m['pid'],signal.SIGKILL)
'''
try:
    for rank in (0, 1):
        config = out / f'rank{rank}-private.json'
        config.write_text(json.dumps(dict(binary=str(binary), args=(common if rank == 0 else [v if i != common.index('--tp-rdma-device') + 1 else 'usb4_rdma5' for i,v in enumerate(common)]) + ['--tp-rank', str(rank)])))
        config.chmod(0o600)
        command = ['python3', str(launcher), str(config), str(out / f'rank{rank}-pid.json')]
        if rank:
            subprocess.run(['rsync', '-a', '--chmod=F600', str(config), peer + ':' + str(config)], check=True)
            command = ['ssh', '-o', 'BatchMode=yes', peer, shlex.join(command)]
        log = None if rank == 0 else (out / 'rank1.log').open('w')
        processes.append(subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT))
        if log:
            log.close()
    while processes[0].poll() is None:
        if processes[1].poll() is not None and not stopping:
            raise RuntimeError('TP worker exited unexpectedly; see ' + str(out))
        time.sleep(.1)
    if not stopping and processes[0].returncode != 0:
        raise RuntimeError('TP head failed: ' + str(processes[0].returncode))
finally:
    subprocess.run(['python3', '-c', cleanup, str(out / 'rank0-pid.json')], check=True, timeout=12)
    remote(['python3', '-c', cleanup, str(out / 'rank1-pid.json')], timeout=15)
    for process in processes:
        process.wait(timeout=5)
    (out / 'exits.json').write_text(json.dumps([p.returncode for p in processes]) + '\n')
    remote(['cat', str(out / 'rank1-pid.json')], stdout=(out / 'rank1-pid.json').open('w'))
    for rank in (0, 1):
        (out / f'rank{rank}-private.json').unlink(missing_ok=True)
    remote(['rm', '-f', str(out / 'rank1-private.json')])
