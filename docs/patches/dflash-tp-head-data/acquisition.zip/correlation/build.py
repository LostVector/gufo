from pathlib import Path
import hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent;src=p.parents[1]/'dflash2-flash-next-worktree';names=['src/models/qwen38_flash_next/engine.cpp','src/models/qwen38_flash_next/kernels/rocm/executor.cpp'];original=subprocess.check_output(['git','branch','--show-current'],cwd=src,text=True).strip();assert original=='review/flash-next-dflash2';assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True).strip();assert not(p/'binaries.json').exists();records={}
def run(args,log=None):subprocess.run(args,cwd=src,check=True,stdout=log,stderr=subprocess.STDOUT if log else None)
try:
 run(['git','switch','evidence/hc-combined-20261109-combined'])
 for role in('baseline','candidate'):
  try:
   for name,source in zip(names,[p/'engine.cpp',p/(role+'-executor.cpp')]):shutil.copyfile(source,src/name);(src/name).touch()
   with(p/(role+'-build.log')).open('w')as log:
    run(['cmake','--preset','release','-DGUFO_ENABLE_TP2_RDMA=ON','-DGUFO_BUILD_TOOLS=OFF','-DGUFO_REVISION=0733-correlation-'+role],log);run(['cmake','--build','--preset','release','--parallel','4','--target','gufo'],log)
   text=(p/(role+'-build.log')).read_text()
   for name in names:assert name+'.o' in text,(role,name)
   binary=p/(role+'-runtime')/'bin/gufo';binary.parent.mkdir(parents=True,exist_ok=False);shutil.copyfile(src/'build/release/gufo',binary);binary.chmod(0o755)
   records[role]={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'parent':'0733d3f2','source_sha256':{n:hashlib.sha256((src/n).read_bytes()).hexdigest()for n in names},'header_sha256':hashlib.sha256((p/'observer.hpp').read_bytes()).hexdigest(),'scope':'Host timestamps only, no SDK/profiler/extraGPU waits. Required error-counter correlation; not throughput evidence.'};(p/'binaries.json').write_text(json.dumps(records,indent=2)+'\n')
  finally:run(['git','restore','--',*names])
finally:run(['git','switch',original])
print('Built source/counter correlation artifacts',flush=True)
