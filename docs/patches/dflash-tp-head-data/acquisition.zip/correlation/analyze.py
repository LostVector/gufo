from pathlib import Path
import csv,json,statistics,collections
p=Path(__file__).resolve().parent;assert(p/'complete').exists();reports=[]
for role in('baseline','candidate'):
 for label in('w3','w7'):
  out=p/role/label;requests=json.loads((out/'rows.json').read_text())
  for rank in(0,1):
   f=list((out/'launch').rglob(f'rank{rank}-pid-cost.csv'));assert len(f)==1
   lines=f[0].read_text().splitlines();assert 'overflow=0'in lines[0]
   source=[{k:(v if k=='stage'else int(v))for k,v in r.items()}for r in csv.DictReader(x for x in lines if not x.startswith('#'))]
   sample=json.loads((out/f'sample-r{rank}/result.json').read_text());events=[]
   for event in sample['events']:
    a,b=event['earliest_ns'],event['detected_by_ns'];hits=[r for r in source if r['begin_ns']<b and r['end_ns']>a]
    concrete=[r for r in hits if r['stage']not in('cycle','verify','forward')]
    local=[]
    if rank==0:local=[r['case']for r in requests if r['begin_ns']<b and r['end_ns']>a]
    events.append({**event,'possible_source_stages':sorted(set(r['stage']for r in concrete)),'matching_source_intervals':[{'stage':r['stage'],'position':r['position'],'rows':r['rows'],'begin_ns':r['begin_ns'],'end_ns':r['end_ns'],'wall_ms':(r['end_ns']-r['begin_ns'])/1e6}for r in concrete],'local_client_cases':local,'case_scope':'Onlyrank0 has same-host client timing; rank1 deliberately unassigned.'})
   totals={k:sample['final'][k]-v for k,v in sample['initial'].items()if sample['final'][k]!=v};stages=collections.Counter(s for e in events for s in e['possible_source_stages'])
   prefill=[{'position':r['position'],'rows':r['rows'],'wall_ms':(r['end_ns']-r['begin_ns'])/1e6,'overlapping_error_brackets':sum(e['earliest_ns']<r['end_ns']and e['detected_by_ns']>r['begin_ns']for e in events)}for r in source if r['stage']=='prefill-forward']
   row={'role':role,'width':int(label[1:]),'rank':rank,'source_events':len(source),'source_overflow':0,'polls':sample['polls'],'one_CPU_percent':sample['one_CPU_percent'],'poll_interval_median_us':sample['poll_interval_median_us'],'poll_interval_p95_us':sample['poll_interval_p95_us'],'poll_interval_max_us':sample['poll_interval_max_us'],'read_median_us':sample['read_median_us'],'counter_deltas':totals,'error_brackets':len(events),'stage_bracket_overlaps':dict(stages),'events':events,'prefill_intervals':prefill};reports.append(row)
   print(role,label,rank,'brackets',len(events),'CPU%',round(row['one_CPU_percent'],2),'stages',dict(stages))
report={'scope':'Separate source/counter diagnostic; no throughput/confidence pooling, extra waits or profiler. Error detection brackets are not DMA-arrival/command completion, phase overlap not proof of cause; multiple counters/stages can refer to one event. No cross-host clock subtraction. Polling/CPU overhead measured, absence of events stays bounded/inconclusive.','reports':reports}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
