from pathlib import Path
import hashlib,json,os,statistics,sys,time
assert os.geteuid()==0
p=Path(__file__).resolve().parent;role,rank,pid,label=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4];assert role in('baseline','candidate')and rank in(0,1)and pid>1 and label in('w3','w7')
meta=json.loads((p/'binaries.json').read_text())[role];binary=Path(meta['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==meta['sha256'];proc=Path('/proc')/str(pid);assert proc.exists()and(proc/'exe').resolve()==binary
assert Path('/sys/module/thunderbolt_ibverbs/srcversion').read_text().strip()=='B6C332F34D27E163651EE38'
out=p/role/label/f'sample-r{rank}';out.mkdir(exist_ok=False,parents=True);owner=Path('/home/rkuo').stat();os.chown(out,owner.st_uid,owner.st_gid);stop=out/'stop';ready=out/'ready';source=Path('/sys/kernel/debug/thunderbolt_ibverbs/summary')
keys={'data_wr_retransmit','data_wr_timeout','data_wr_retry_exhausted','data_rx_lost','data_rx_bad_frame','data_rx_crc_error','data_rx_overrun','data_rx_raw_poisoned','data_tx_errors','data_wr_copy_error','data_rx_repost_failed'}
error_keys=set(keys)
activity_keys={'data_tx_completed','data_tx_posted','data_wr_live','data_tx_credit_stalls'}
keys|=activity_keys
def read():
 a=time.monotonic_ns();text=source.read_text();values={}
 for line in text.splitlines():
  k,sep,v=line.partition(': ')
  if sep and k in keys:values[k]=int(v)
 b=time.monotonic_ns();return a,b,values
start=time.monotonic_ns();cpu=time.process_time_ns();previous_a,previous_b,base=read();last=base;events=[];activity=[];intervals=[];reads=[];polls=0;ready.write_text(str(start)+'\n');os.chown(ready,owner.st_uid,owner.st_gid);deadline=start+45_000_000_000
while time.monotonic_ns()<deadline and not stop.exists():
 target=time.monotonic_ns()+1_000_000;a,b,value=read();assert value.keys()==last.keys();assert all(value[k]>=last[k]for k in keys if k!='data_wr_live'),'counter reset'
 delta={k:value[k]-last[k]for k in error_keys if value[k]!=last[k]}
 activity.append({'begin_ns':a,'end_ns':b,**{k:value[k]for k in activity_keys}})
 if delta:events.append({'earliest_ns':previous_a,'detected_by_ns':b,'read_begin_ns':a,'read_end_ns':b,'delta':delta,'absolute':value})
 intervals.append(a-previous_a);reads.append(b-a);polls+=1;previous_a,previous_b,last=a,b,value
 delay=(target-time.monotonic_ns())/1e9
 if delay>0:time.sleep(delay)
end=time.monotonic_ns();used=time.process_time_ns()-cpu
result={'role':role,'rank':rank,'pid':pid,'begin_ns':start,'end_ns':end,'polls':polls,'CPU_ms':used/1e6,'one_CPU_percent':100*used/(end-start),'poll_interval_median_us':statistics.median(intervals)/1000,'poll_interval_p95_us':sorted(intervals)[int(.95*(len(intervals)-1))]/1000,'poll_interval_max_us':max(intervals)/1000,'read_median_us':statistics.median(reads)/1000,'initial':base,'final':last,'events':events,'activity':activity,'scope':'Read-only driver counters; event detection bracket, not DMAarrival or proven cause. Nominal1ms, actualpollintervals recorded. Same-host monotonic clocks only. Diagnostic not throughput/confidence.'}
f=out/'result.json';f.write_text(json.dumps(result,indent=2)+'\n');os.chown(f,owner.st_uid,owner.st_gid);os.chmod(f,0o644)
print('Sampler complete',rank,'events',len(events),'CPU%',result['one_CPU_percent'],flush=True)
