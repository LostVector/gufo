# Separate error/phase correlation

Execute after uninstrumented fixedstudy. Two diagnosticroles for each width3/7
(fourstarts total), same fourcase history, noGPUprofiler. Ordinary CMake builds
capture source scopes in bounded at-exit rings, including actual prefill Forward.
No extra GPU sync/math/policy changes. Rootfastsampler reads existing debugfs
summary at nominal1ms afterhealth, recording errorcounterchanges with read/
detectionbrackets, polltiming andCPUusage. No driver/configuration change.
Every request/rawtiming retained; observer not used for speed/confidence.
Counterdetect time is notDMA arrival or proof of cause. No cross-host clock
subtraction. Retain a bounded inconclusive result if no event reproduces.
