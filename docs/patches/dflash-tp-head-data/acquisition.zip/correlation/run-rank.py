from pathlib import Path
import json,os,sys
root=Path('/home/rkuo/strix-dispatch-investigation');config=json.loads(Path(sys.argv[1]).read_text());meta=Path(sys.argv[2])
env=os.environ.copy();
env['GUFO_DFLASH_COST_PATH']=str(meta.with_name(meta.stem+'-cost.csv'))
env.pop('ROCP_TOOL_ATTACH',None)
env['LD_LIBRARY_PATH']=':'.join(map(str,[Path(config['binary']).parent.parent/'lib',root/'tp-cache-retention/fork-integration-v1/runtime/lib',root/'native-rdma/runtime/lib',root/'dependencies/gufo-dev/usr/lib/x86_64-linux-gnu',Path('/home/rkuo/.local/opt/rocm-7.14.1/lib')]))
env['RDMAV_DRIVERS']=str(root/'native-rdma/runtime/lib/libusb4_rdma')
meta.write_text(json.dumps(dict(pid=os.getpid(),start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],binary=config['binary']))+'\n')
os.execve(config['binary'],[config['binary'],*config['args']],env)
