from pathlib import Path
import hashlib,json,os,shlex,signal,socket,subprocess,sys,time,urllib.request
p=Path(__file__).resolve().parent;lab=p;root=p.parents[2];peer='rkuo@rk-corsair-ai'
assert not (p/'protocol.json').exists()
meta=json.loads((p/'binary.json').read_text());prod=json.loads(Path('/home/rkuo/strix-dispatch-investigation/tp-cache-retention/hc-combined-dflash-cost-2026-11-09/binaries.json').read_text())['combined']
design=json.loads((p/'DESIGN.json').read_text())
sequence=[(arm,label,width,prod if arm=='baseline' else meta)for arm,label,width in design['sequence']]
target='/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf'
draft='/home/rkuo/models/Qwen3.8-Flash-Next-DFlash2-GGUF/Qwen3.8-Flash-Next-DFlash2-Q8_0.gguf'
python='Implement a Python asynchronous work queue with bounded concurrency, fair scheduling and cancellation. Provide code and explain the invariants.'
pp=json.loads((root/'prefill-scaling/results/prompts.json').read_text())['2048']
cases=[('warmup',python,0.,43,64),('short-greedy',python,0.,43,128),('short-sampled',python,1.,1001,128),('pp2048-greedy',pp,0.,43,128),('pp2048-sampled',pp,1.,1001,128)]
def remote(args,**kw):return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(args)],check=True,**kw)
def call(rank,args):return subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(args)] if rank else args,text=True,timeout=60)
def inventory(tag):
 code="from pathlib import Path;import json,platform\ndef read(p):\n try:return p.read_text().strip()\n except OSError:return None\nr=Path('/sys/module/thunderbolt_ibverbs');print(json.dumps({'host':platform.node(),'boot':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'cmdline':Path('/proc/cmdline').read_text().strip(),'module':(r/'srcversion').read_text().strip(),'refcnt':(r/'refcnt').read_text().strip(),'parameters':{f.name:read(f) for f in (r/'parameters').glob('*')},'links':{str(f):f.read_text().strip() for n in ('rx_speed','tx_speed','rx_lanes','tx_lanes') for f in Path('/sys/bus/thunderbolt/devices').glob('*/'+n)}}))"
 rows=[]
 for rank in (0,1):
  d=json.loads(call(rank,['python3','-c',code]));assert d['module']=='B6C332F34D27E163651EE38' and d['refcnt']=='0',d
  (p/f'{tag}-inventory-r{rank}.json').write_text(json.dumps(d,indent=2)+'\n');rows.append(d)
  (p/f'{tag}-snapshot-r{rank}.txt').write_text(call(rank,['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']))
 return rows
for d in [meta,prod]:
 binary=Path(d['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==d['sha256'];remote(['mkdir','-p',str(binary.parent)]);subprocess.run(['rsync','-a',str(binary),peer+':'+str(binary)],check=True);assert call(1,['sha256sum',str(binary)]).split()[0]==d['sha256']
remote(['mkdir','-p',str(p)])
assert call(1,['test','-s',draft])==''
def canonical_usage(value):
 if isinstance(value,dict):return {k:canonical_usage(v) for k,v in value.items() if not k.endswith('_ms') and not k.endswith('_per_second')}
 if isinstance(value,list):return [canonical_usage(x) for x in value]
 return value
initial=inventory('initial');identities={};allrows=[]
protocol={'sequence':[(a,b,c,d['sha256']) for a,b,c,d in sequence],'parent':'0733d3f2','cases':cases,'capacity':65536,'sessions':1,'prefill_chunk':2048,'mode':'DFlash2 fixed widths3/7, actual target rows checked in source; neutral penalties; sampled topk20/topp.95; thinkingoff; no promptcache','scope':'Fixed predeclared40start balanced study,10independentpairs perwidth with fresh sampledseeds2001..2010. See DESIGN.json; exact choices/all nontimingusage; retain every phaseflag/error. No defaultadoption.'}
(p/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
for arm,label,width,entry in sequence:
 out=p/arm/label;out.mkdir(parents=True,exist_ok=False);start=time.monotonic();inventory(arm+'-'+label+'-before')
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 cmd=[sys.executable,'/home/rkuo/strix-dispatch-investigation/tp-cache-retention/hc-combined-dflash-cost-2026-11-09/dflash-cost/launcher.py','serve','llm','--model',target,'--served-model-name','dflash-cost','--speculative','dflash2','--dflash-model',draft,'--draft-policy','fixed','--draft-tokens',str(width),'--context','65536','--sessions','1','--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off','--host','127.0.0.1','--port',str(port)]
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(Path(entry['binary']).parents[1]);env['DFLASH_TP_LAUNCH_RECORDS']=str(out/'launch')
 for k in ('LD_PRELOAD','ROCP_TOOL_ATTACH','GUFO_TP_TRACE_PREFIX','GUFO_DFLASH_COST_PATH'):env.pop(k,None)
 (out/'launch.json').write_text(json.dumps({'command':cmd,'binary_sha256':entry['sha256'],'runtime':env['DFLASH_TP_RUNTIME']},indent=2)+'\n')
 print('START',arm,label,flush=True);workers=[];workerlogs=[];rows=[]
 with (out/'server.log').open('w') as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+240
   while True:
    if proc.poll() is not None:raise RuntimeError('launcher exit '+str(proc.returncode))
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as r:
      if r.status==200:break
    except OSError:pass
    assert time.monotonic()<deadline,'startup deadline';time.sleep(.2)
   if arm=='profile':
    records=list((out/'launch').glob('*'));assert len(records)==1
    for rank in (0,1):
     (out/f'trace-r{rank}').mkdir();remote(['mkdir','-p',str(out/f'trace-r{rank}')])
     # The local launcher records the peer PID only during shutdown; read it over SSH now.
     m=json.loads(call(rank,['cat',str(records[0]/f'rank{rank}-pid.json')]))
     assert m['binary']==entry['binary']
     args=['sudo','-n','/usr/local/sbin/strix-driver-lab','run',str((p/'collect.py').relative_to(root)),str(rank),str(m['pid']),label]
     if rank:args=['ssh','-o','BatchMode=yes',peer,shlex.join(args)]
     wl=(out/f'collector-r{rank}.log').open('w');workerlogs.append(wl);workers.append(subprocess.Popen(args,stdout=wl,stderr=subprocess.STDOUT))
     call(rank,['touch',str(out/f'trace-r{rank}/gpu.start')])
    deadline=time.monotonic()+45
    while True:
     if any(w.poll() is not None and w.returncode!=0 for w in workers):raise RuntimeError('collector failed; inspect logs')
     ready=[]
     for rank in (0,1):
      try:ready.append(bool(call(rank,['test','-f',str(out/f'trace-r{rank}/gpu.ready')])==''))
      except subprocess.CalledProcessError:ready.append(False)
     if all(ready):break
     assert time.monotonic()<deadline,'profiler ready deadline';time.sleep(.2)
   for i,(name,prompt,temp,seed,limit) in enumerate(cases):
    seed=(2000+int(label.split('-p')[1])) if temp else seed
    body={'model':'dflash-cost','messages':[{'role':'user','content':prompt}],'max_tokens':limit,'temperature':temp,'top_p':.95,'top_k':20,'seed':seed,'presence_penalty':0,'frequency_penalty':0,'repeat_penalty':1,'cache_prompt':False,'cache_persist':False,'chat_template_kwargs':{'enable_thinking':False}}
    (out/f'{i}-{name}-request.json').write_text(json.dumps(body,indent=2)+'\n');begin=time.monotonic_ns()
    req=urllib.request.Request(f'http://127.0.0.1:{port}/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=240) as response:reply=json.load(response)
    end=time.monotonic_ns();(out/f'{i}-{name}-response.json').write_text(json.dumps(reply,indent=2)+'\n')
    u=reply['usage'];assert u['cached_tokens']==0 and u['draft_tokens']>0,u
    identity={'name':name,'choices':reply['choices'],'usage':canonical_usage(u)}
    # Timing/executor metadata are outside usage; retain every choice/work identity.
    key=(label,name)
    if key not in identities:identities[key]=identity
    else:assert identity==identities[key],(arm,label,name,'source observer changes output/work')
    row={'arm':arm,'width':width,'case':name,'warmup':i==0,'begin_ns':begin,'end_ns':end,'usage':u,'timings':reply['timings'],'reply_sha256':hashlib.sha256(json.dumps(reply['choices'],sort_keys=True).encode()).hexdigest()};rows.append(row);allrows.append(row)
    (out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(p/'rows.json').write_text(json.dumps(allrows,indent=2)+'\n');print(arm,label,name,u['completion_tokens'],round(reply['timings']['predicted_per_second'],2),flush=True)
   for w in workers:
    assert w.wait(timeout=70)==0,'profiler exit failure'
  finally:
   for w in workers:
    if w.poll() is None:
     # Collector handles its SDK process under SIGINT; target remains owned by launcher.
     w.send_signal(signal.SIGINT)
     try:w.wait(timeout=20)
     except subprocess.TimeoutExpired:w.terminate();w.wait(timeout=10)
   if proc.poll() is None:
    proc.send_signal(signal.SIGINT)
    try:proc.wait(timeout=40)
    except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=20)
   for f in workerlogs:f.close()
 if arm=='profile':
  subprocess.run(['rsync','-a',peer+':'+str(out/f'trace-r1')+'/',str(out/f'trace-r1')+'/'],check=True)
  subprocess.run(['rsync','-a','--include=*/','--include=*-cost.csv','--exclude=*',peer+':'+str(out/'launch')+'/',str(out/'launch')+'/'],check=True)
 if arm=='profile':
  exits=json.loads(next((out/'launch').rglob('exits.json')).read_text())
  assert exits[0]==0,('profile head shutdown failed',exits)
  for rank in (0,1):
   fs=list((out/'launch').rglob(f'rank{rank}-pid-cost.csv'));assert len(fs)==1,('missing source ring',rank)
   assert 'overflow=0' in fs[0].read_text().splitlines()[0]
 inv=inventory(arm+'-'+label+'-after');assert all(all(a[k]==b[k] for k in ('boot','cmdline','module','parameters','links')) for a,b in zip(initial,inv))
 (out/'complete').touch();print('PASS',arm,label,round(time.monotonic()-start,2),'seconds',flush=True)
(p/'complete').touch();inventory('final');print('DFLASH HEAD FIXED CONFIRMATION COMPLETE',flush=True)
