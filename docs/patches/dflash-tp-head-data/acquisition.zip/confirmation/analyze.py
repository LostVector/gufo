from pathlib import Path
import collections,itertools,json,math,random,re,statistics,csv
p=Path(__file__).resolve().parent;assert(p/'complete').exists();design=json.loads((p/'DESIGN.json').read_text());data={};errors={};flags=[];pairs=[];casepairs=[]
def canon(x):
 if isinstance(x,dict):return {k:canon(v)for k,v in x.items()if not k.endswith('_ms')and not k.endswith('_per_second')}
 if isinstance(x,list):return [canon(v)for v in x]
 return x
for arm,label,width in design['sequence']:
 rows=json.loads((p/arm/label/'rows.json').read_text());assert len(rows)==5;data[arm,label]=rows
 for rank in(0,1):
  def counters(tag):return {k:int(v)for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'{arm}-{label}-{tag}-snapshot-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert a.keys()==b.keys()and len(a)>100
  diff={k:b[k]-v for k,v in a.items()if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors.setdefault(arm+'-'+label,{})[str(rank)]=diff
for width in(3,7):
 for pair in range(1,11):
  label=f'w{width}-p{pair:02}';a=data['baseline',label];b=data['candidate',label];d=[];wall=[]
  for x,y in zip(a,b):
   assert x['case']==y['case'] and x['reply_sha256']==y['reply_sha256']and canon(x['usage'])==canon(y['usage']),(label,x['case'],'output/work identity')
   if x['warmup']:continue
   ratio=y['timings']['predicted_per_second']/x['timings']['predicted_per_second'];d.append(math.log(ratio))
   bw=(x['end_ns']-x['begin_ns'])/1e6;cw=(y['end_ns']-y['begin_ns'])/1e6;wall.append(math.log(bw/cw))
   casepairs.append({'width':width,'pair':pair,'case':x['case'],'baseline_tps':x['timings']['predicted_per_second'],'candidate_tps':y['timings']['predicted_per_second'],'log_ratio':math.log(ratio),'baseline_wall_ms':bw,'candidate_wall_ms':cw})
   for k in('queue_ms','shared_prefix_wait_ms','prefill_ms','decode_ms','ttft_ms','mean_inter_token_ms','max_inter_token_ms','cache_snapshot_ms'):
    aa=x['usage']['gufo'].get(k);bb=y['usage']['gufo'].get(k)
    if aa is not None and bb is not None and bb-aa>max(3,aa*.05):flags.append({'width':width,'pair':pair,'case':x['case'],'metric':k,'baseline_ms':aa,'candidate_ms':bb,'delta_ms':bb-aa,'baseline_transport_errors':('baseline-'+label)in errors,'candidate_transport_errors':('candidate-'+label)in errors})
   if cw-bw>max(3,bw*.05):flags.append({'width':width,'pair':pair,'case':x['case'],'metric':'client_wall_ms','baseline_ms':bw,'candidate_ms':cw,'delta_ms':cw-bw,'baseline_transport_errors':('baseline-'+label)in errors,'candidate_transport_errors':('candidate-'+label)in errors})
  assert len(d)==4
  pairs.append({'width':width,'pair':pair,'order':design['orders'][str(width)][pair-1],'mean_log_decode_ratio':statistics.mean(d),'mean_log_wall_throughput_ratio':statistics.mean(wall)})
def quantile(x,q):
 x=sorted(x);i=(len(x)-1)*q;lo=int(i);f=i-lo;return x[lo]*(1-f)+x[min(lo+1,len(x)-1)]*f
results=[]
for width in(3,7):
 rows=[r for r in pairs if r['width']==width];logs=[r['mean_log_decode_ratio']for r in rows];obs=statistics.mean(logs)
 signs=[1 if r['order']=='BC'else-1 for r in rows];chronological=[sign*x for sign,x in zip(signs,logs)];null=[]
 for bc in itertools.combinations(range(10),5):
  selected=set(bc);null.append(statistics.mean(x*(1 if i in selected else-1)for i,x in enumerate(chronological)))
 exact=sum(abs(x)>=abs(obs)-1e-15 for x in null)/len(null)
 rng=random.Random(20261109+width);strata=[[r for r in rows if r['order']==order]for order in('BC','CB')];boot=[];wallboot=[]
 for _ in range(20000):
  sample=[rng.choice(s)for s in strata for __ in range(5)];boot.append(statistics.mean(r['mean_log_decode_ratio']for r in sample));wallboot.append(statistics.mean(r['mean_log_wall_throughput_ratio']for r in sample))
 transform=lambda x:100*math.expm1(x)
 cases=[]
 for case in('short-greedy','short-sampled','pp2048-greedy','pp2048-sampled'):
  r=[x for x in casepairs if x['width']==width and x['case']==case];cases.append({'case':case,'baseline_tps_geomean':statistics.geometric_mean(x['baseline_tps']for x in r),'candidate_tps_geomean':statistics.geometric_mean(x['candidate_tps']for x in r),'paired_change_percent':transform(statistics.mean(x['log_ratio']for x in r))})
 results.append({'width':width,'target_rows':width+1,'process_pairs':10,'decode_change_percent':transform(obs),'marginal95CI_percent':[transform(quantile(boot,q))for q in(.025,.975)],'exact_balanced_order_two_sided_p':exact,'randomization_assignments':len(null),'wall_throughput_change_percent':transform(statistics.mean(r['mean_log_wall_throughput_ratio']for r in rows)),'wall_marginal95CI_percent':[transform(quantile(wallboot,q))for q in(.025,.975)],'positive_decode_pairs':sum(x>0 for x in logs),'cases':cases})
ordered=sorted(results,key=lambda r:r['exact_balanced_order_two_sided_p']);last=0
for i,r in enumerate(ordered):last=max(last,min(1,(len(results)-i)*r['exact_balanced_order_two_sided_p']));r['Holm_adjusted_p']=last;r['resolved_positive_decode_gain']=last<.05 and r['marginal95CI_percent'][0]>0
report={'scope':'Fixed40starts/200requests including40warmups,10independentprocesspairs perwidth; no pooling/pair exclusion. Decode-rate primary, fourcases clustered withinpair. Bootstrap BC/CBstratified20k, exact balanced252order assignments, Holm overtwo widths. CIs marginal andconditionalonfixedtasks/seeds; phaseflags/errors remain separate adoption limits. Wall-throughput outcome exploratory.','requests':sum(len(r)for r in data.values()),'all_output_work_identities_match':True,'results':results,'pairs':pairs,'casepairs':casepairs,'phase_flags':flags,'transport_errors':errors}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
with(p/'phase-flags.csv').open('w')as f:
 if flags:w=csv.DictWriter(f,fieldnames=list(flags[0]));w.writeheader();w.writerows(flags)
print(json.dumps({'requests':report['requests'],'results':results,'phase_flags':len(flags),'error_launches':len(errors)},indent=2))
