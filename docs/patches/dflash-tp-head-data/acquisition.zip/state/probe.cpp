#include "src/core/crypto/sha256.hpp"
#include "src/models/qwen38_flash_next/engine.hpp"
#include "src/models/qwen38_flash_next/kernels/rocm/verbs.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <vector>
namespace q=gufo::models::qwen38_flash_next;
namespace gufo::models::qwen38_flash_next::rocm {
void DFlashHeadProbeReset(bool);
const std::vector<std::vector<float>>& DFlashHeadProbeValues();
const std::vector<std::uint32_t>& DFlashHeadProbeRows();
const std::vector<unsigned>& DFlashHeadProbeGathered();
}
void Need(bool ok,const std::string& s){if(!ok)throw std::runtime_error(s);}
template<class T>std::string Hash(std::span<const T> x){return gufo::crypto::Sha256Hex({reinterpret_cast<const std::uint8_t*>(x.data()),x.size_bytes()});}
struct Record {
 std::vector<std::int32_t> tokens,history;
 std::vector<std::uint32_t> rows;
 std::vector<std::string> verification;
 std::string logits;
 std::uint32_t position;
 std::uint64_t rng,drafted,accepted,lookup,lookup_accepted;
 std::optional<std::int32_t> pending;
 bool stop;
 bool operator==(const Record&)const=default;
};
int main(int argc,char**argv){
 std::shared_ptr<q::rocm::Communicator> comm;
 try{
  Need(argc==8,"rank host device target draft output port");unsigned rank=std::stoul(argv[1]);Need(rank<2,"rank");
  q::rocm::IbrverbsConfig cfg;cfg.rank=rank;cfg.bootstrap_host=argv[2];cfg.rdma_device=argv[3];cfg.bootstrap_port=std::stoul(argv[7]);
  std::string error;comm=q::rocm::CreateIbrverbsCommunicator(cfg,&error);Need(bool(comm)&&comm->SupportsTargetHeadGather(),error);
  q::ModelOptions opt;opt.tp_world_size=2;opt.tp_rank=rank;opt.communicator=comm;opt.max_context=65536;opt.decode_concurrency=2;opt.max_draft_tokens=7;opt.dflash_model_path=argv[5];
  auto model=q::Model::Load(argv[4],opt,&error);Need(bool(model),error);auto draft=model->LoadDFlashDraft(argv[5],&error);Need(bool(draft),error);
  auto a=model->CreateSession(gufo::core::SessionMode::kAutoregressive,65536,&error,draft);Need(bool(a)&&a->DFlashEnabled(),error);
  auto b=model->CreateSession(gufo::core::SessionMode::kAutoregressive,65536,&error,draft);Need(bool(b)&&b->DFlashEnabled(),error);
  auto suffix=model->Tokenize("Implement a robust timestamp parser. Explain edge cases and provide Python code.\n");
  auto pattern=model->Tokenize("Independent requests preserve their own recurrent state and sampling history. ");Need(!suffix.empty()&&!pattern.empty(),"prompt tokens");
  std::ofstream out(argv[6]);Need(bool(out),"output");Need(comm->BeginOperation(110909,&error),error);
  unsigned records=0,state_pairs=0,eligible=0,sampled_rejections=0,cases=0;
  for(unsigned depth:{0U,16384U,32768U})for(unsigned mode=0;mode<(depth?2U:3U);++mode){
   std::cout<<"START depth="<<depth<<" mode="<<mode<<std::endl;
   auto prefix=suffix;if(depth){prefix.resize(depth-suffix.size());for(unsigned i=0;i<prefix.size();++i)prefix[i]=pattern[i%pattern.size()];prefix.insert(prefix.end(),suffix.begin(),suffix.end());Need(prefix.size()==depth,"actual requested depth");}
   a->Reset();b->Reset();q::rocm::DFlashHeadProbeReset(false);Need(a->Sync(prefix,&error),error);
   gufo::sampling::SamplingConfig config;config.temperature=mode?.8F:0.F;config.top_k=mode==2?0:20;config.top_p=.95F;config.seed=1009+mode;if(mode==2){config.repeat_penalty=1.1F;config.presence_penalty=.1F;}
   gufo::sampling::SamplerState random(config);
   auto Run=[&](q::Session& session,gufo::sampling::SamplerState& rng,bool enabled,const std::string& phase,unsigned count){
    std::vector<Record> result;const std::array<unsigned,8> budgets{4,8,1,2,3,7,4,8};
    for(unsigned step=0;step<count;++step){
     const auto budget=budgets[step%budgets.size()];q::rocm::DFlashHeadProbeReset(enabled);auto before=session.Statistics();q::Session::DecodeResult decoded;
     Need(session.DecodeDFlashStep(budget,rng,&decoded,&error,false,budget-1),error);Need(!decoded.tokens.empty(),"no progress");
     const auto& values=q::rocm::DFlashHeadProbeValues();const auto& rows=q::rocm::DFlashHeadProbeRows();const auto& gathered=q::rocm::DFlashHeadProbeGathered();Need(!values.empty()&&values.size()==rows.size()&&rows.size()==gathered.size(),"actual head captures");
     Record r;r.rows=rows;bool exercised=false;
     for(unsigned i=0;i<values.size();++i){Need(values[i].size()==std::size_t{rows[i]}*248320&&std::all_of(values[i].begin(),values[i].end(),[](float x){return std::isfinite(x);}),"full finite verification matrix");r.verification.push_back(Hash<float>(values[i]));bool expected=enabled&&(rows[i]==4||rows[i]==8);Need(bool(gathered[i])==expected,"actual candidate/fallback route");exercised|=gathered[i];}
     Need(std::find(rows.begin(),rows.end(),budget)!=rows.end(),"requested target shape not exercised");eligible+=exercised;
     auto after=session.Statistics();r.tokens=decoded.tokens;r.logits=Hash<float>(session.Logits());r.position=session.Position();r.rng=rng.rng_state();r.pending=rng.SaveDrawState().pending;r.history={rng.history().begin(),rng.history().end()};r.drafted=after.drafted-before.drafted;r.accepted=after.accepted-before.accepted;r.lookup=after.lookup-before.lookup;r.lookup_accepted=after.lookup_accepted-before.lookup_accepted;r.stop=decoded.stop;
     Need(session.Logits().size()==248320&&std::all_of(session.Logits().begin(),session.Logits().end(),[](float x){return std::isfinite(x);}),"full finite committed logits");if(mode&&r.drafted>r.accepted)++sampled_rejections;
     out<<"{\"depth\":"<<depth<<",\"mode\":"<<mode<<",\"phase\":\""<<phase<<"\",\"step\":"<<step<<",\"budget\":"<<budget<<",\"position\":"<<r.position<<",\"drafted\":"<<r.drafted<<",\"accepted\":"<<r.accepted<<",\"lookup\":"<<r.lookup<<",\"rng\":"<<r.rng<<",\"logits_sha256\":\""<<r.logits<<"\",\"verification_sha256\":[";
     for(unsigned i=0;i<r.verification.size();++i){if(i)out<<',';out<<'"'<<r.verification[i]<<'"';}out<<"],\"rows\":[";for(unsigned i=0;i<rows.size();++i){if(i)out<<',';out<<rows[i];}out<<"],\"gathered\":"<<unsigned(exercised)<<"}\n";out.flush();++records;result.push_back(std::move(r));
    }return result;
   };
   Run(*a,random,true,"warm",2);
   auto saved=a->SaveSnapshot(&error,q::Session::SnapshotMode::kBorrowed);Need(bool(saved),error);auto bytes=saved->bytes();std::vector<std::uint8_t> payload(bytes.begin(),bytes.end());Need(payload.size()==saved->SizeBytes(),"complete base snapshot");auto base_rng=random;
   auto expected=Run(*a,random,false,"reference",8);auto reference=a->SaveSnapshot(&error,q::Session::SnapshotMode::kMaterialized);Need(bool(reference),error);
   const std::string file=std::string(argv[6])+".snapshot.bin";
   {std::ofstream f(file,std::ios::binary);f.write(reinterpret_cast<const char*>(payload.data()),payload.size());Need(bool(f),"snapshot file write");}
   for(const std::string phase:{"borrowed-same","borrowed-cross","serialized-cross","file-cross"}){
    auto& session=phase=="borrowed-same"?*a:*b;
    if(phase=="borrowed-same"||phase=="borrowed-cross")Need(session.RestoreSnapshot(*saved,&error),error);
    else if(phase=="serialized-cross")Need(session.RestoreSnapshot(payload,&error),error);
    else {std::ifstream f(file,std::ios::binary);std::vector<std::uint8_t> disk((std::istreambuf_iterator<char>(f)),{});Need(disk==payload,"file snapshot bytes");Need(session.RestoreSnapshot(disk,&error),error);}
    auto state=base_rng;Need(Run(session,state,true,phase,8)==expected,"full logits/tokens/RNG/history/work replay: "+phase);
    auto end=session.SaveSnapshot(&error,q::Session::SnapshotMode::kMaterialized);Need(bool(end),error);auto x=reference->bytes(),y=end->bytes();Need(x.size()==y.size()&&std::equal(x.begin(),x.end(),y.begin()),"complete post-replay target/draft/recurrence state: "+phase);
    std::cout<<"STATE depth="<<depth<<" mode="<<mode<<" phase="<<phase<<" bytes="<<y.size()<<" sha256="<<Hash<std::uint8_t>(y)<<std::endl;++state_pairs;
   }
   ++cases;std::cout<<"PASS depth="<<depth<<" mode="<<mode<<std::endl;
  }
  Need(cases==7&&records==294&&state_pairs==28&&eligible>=126&&sampled_rejections>0,"exact required coverage");Need(comm->EndOperation(110909,&error),error);
  std::cout<<"PASS cases="<<cases<<" records="<<records<<" full_state_pairs="<<state_pairs<<" eligible_cycles="<<eligible<<" sampled_rejections="<<sampled_rejections<<std::endl;return 0;
 }catch(const std::exception& e){if(comm)comm->Abort(e.what());std::cerr<<e.what()<<std::endl;return 1;}
}
