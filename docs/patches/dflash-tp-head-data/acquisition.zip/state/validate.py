from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent;a=[json.loads(x)for x in(p/'rank0.jsonl').read_text().splitlines()];b=[json.loads(x)for x in(p/'rank1.jsonl').read_text().splitlines()];assert a==b and len(a)==294
m=json.loads((p/'build.json').read_text())
for name,h in m['source_sha256'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h
for rank in(0,1):
 text=(p/f'rank{rank}.log').read_text();assert 'PASS cases=7 records=294 full_state_pairs=28' in text;assert len(re.findall(r'^STATE ',text,re.M))==28
print('PASS recorded full-state/source coverage; no new GPU proof')
