from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess
p=Path(__file__).resolve().parent;root=p.parents[2];src=root/'tp-cache-retention/dflash2-flash-next-worktree';build=src/'build/release'
assert not (p/'build.json').exists();entries=json.loads((build/'compile_commands.json').read_text())
def compile(suffix,source,dest):
 e=next(x for x in entries if x['file'].endswith(suffix));cmd=shlex.split(e['command']);cmd[-1]=str(source);cmd[cmd.index('-o')+1]=str(dest);return cmd
executor=compile('/src/models/qwen38_flash_next/kernels/rocm/executor.cpp',p/'executor-diagnostic.cpp',p/'executor.cpp.o');main=compile('/src/cli/main.cpp',p/'probe.cpp',p/'probe.o')
archive=build/'extensions/build/qwen38_flash_next/build/libgufo_qwen38_flash_next_hip.a';copy=p/archive.name;shutil.copyfile(archive,copy)
cmd=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','gufo'],text=True).splitlines()[-1]);assert cmd[:2]==[':','&&']and cmd[-2:]==['&&',':'];link=cmd[2:-2]
i=next(i for i,x in enumerate(link)if x.endswith('/src/cli/main.cpp.o'));link[i]=str(p/'probe.o');rel=str(archive.relative_to(build));assert rel in link;link=[str(copy)if x==rel else x for x in link];link[link.index('-o')+1]=str(p/'probe')
if '-Xlinker'in link:
 i=link.index('-Xlinker');assert link[i+1].startswith('--dependency-file=');del link[i:i+2]
commands=[executor,['ar','r',str(copy),str(p/'executor.cpp.o')],main,link]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
meta={'cwd':str(build),'commands':commands,'parent_candidate':'9a5a9d43becbb0dd9aaf8930477e647b010efd169650da1318db02dfd776942c','archive_parent_sha256':sha(archive),'source_sha256':{n:sha(p/n)for n in ('probe.cpp','executor-diagnostic.cpp')},'scope':'Quality-only route toggle; OFF=0733external path, ON=exact isolated guard; full verification rows captured with diagnostic synchronization. No performance qualification from this binary. Runtime Need assertions always enabled.'}
(p/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
with(p/'build.log').open('w')as log:
 for c in commands:subprocess.run(c,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
changed=[n for n in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()if subprocess.check_output(['ar','p',str(archive),n])!=subprocess.check_output(['ar','p',str(copy),n])];assert changed==['executor.cpp.o'],changed
meta.update(binary_sha256=sha(p/'probe'),changed_archive_members=changed);(p/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('Built quality-only full-row/state probe',flush=True)
