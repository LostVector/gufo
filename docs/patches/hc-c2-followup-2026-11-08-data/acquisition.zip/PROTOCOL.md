# Current-base HC C2 diagnostic follow-up — November 8, 2026

User request: merge fork PR16, gather more evidence for fork PR14/15. PR16 merged
as59855a97 after facade fix39705db3/CPU tests/format/API/strict boundaries.
No upstream publication or merge of14/15 is authorized by this acquisition.

Three separate CMake release-preset RDMA binaries: merged59855a97 baseline,
baseline+PR14productionf5e9290c, baseline+PR15production74f385dc. Same compiler,
flags, headers and GPU operators; each candidate changes only batch.cpp relative
to base. Freeze each linked executable and record source/command/binary hashes.
No composition of the two optimizations. No system/driver/ROCm/boot changes.

Keep driverB6C332F34D27E163651EE38 on both hosts; preserve existing links and
selected device0EVO/device5Corsair. Observe/read counters only before/after each
launch, not during measurement. Keep disk-backed PLE, no whole-table warming or
admin sampler. GPU work waits until all builds finish and the user MTP trial is
paused under the shared model-matrix lock; restore it on exit.

This is a bounded diagnostic acquisition, not a new confidence-extension study.
Do not pool with old81C6-driver records. Fixed order:

1. baseline,2sessions (PR14 comparison)
2. PR14,2sessions
3. PR15,8sessions (PR15 comparison)
4. baseline,8sessions
5. PR14,2sessions
6. baseline,2sessions
7. baseline,8sessions
8. PR15,8sessions

Common: UD-Q4_K_XL, shared-Q8_0 nativeMTP, capacity65536,chunk2048,1GiB RAM cache,
greedy/thinkingoff,cache_promptfalse,no profiler. Each launch records one short
8-token warmup, a C2 natural warmup128/actor, a C1 pp2048/tg128 control, then four
natural C2 waves (128/actor) and four coding C2 waves (256/actor), followed by a
C1 pp2048/tg128 control. Both actors synchronize at a gate; actor1 starts10ms
later to retain admission order. Store all SSE content-arrival timestamps,
full response text/hash, prompt/prefill/cache/work counters and request latencies.
Warmups remain stored and are excluded only as declared here.

Per-comparison identity includes prompt/output/prefill/cache/completion counts.
Adaptive proposal/acceptance/round counts are reported separately; never force
production plans or equate whole-request work with per-cycle work. Retain all
paired phase differences above BOTH5% and3ms, including first-followup gap,
second-content arrival and steady-generation metrics. No magnitude adoption cutoff.

The old flags were intermittent. Absence in this fixed run cannot prove they
are eliminated; a gain estimate from only two process pairs cannot establish
significance. If long first-followup gaps (>80ms) or paired C2 latency flags
recur, collect a separate bounded source-timestamp diagnostic on the affected
histories. Keep observer results separate from untraced serving measurements.
Focus on snapshot submission/worker completion/future consumption and decode
scheduling, rather than another throughput-only rerun. Do not repeat until green.
