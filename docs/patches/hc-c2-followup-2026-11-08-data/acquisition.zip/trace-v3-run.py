from pathlib import Path
import hashlib,json,os,re,shlex,signal,socket,subprocess,sys,time,urllib.request
mainlab=Path(__file__).resolve().parent;lab=mainlab/'trace-v3-acquisition';lab.mkdir(exist_ok=False);root=mainlab.parents[1];peer='rkuo@rk-corsair-ai'
launcher=mainlab/'trace-launcher.py'
assert len(json.loads((mainlab/'trace-v3-binaries.json').read_text()))==3;assert not(lab/'protocol.json').exists()
meta=json.loads((mainlab/'trace-v3-binaries.json').read_text());meta={k:{**v,'revision':v['parent_revision']} for k,v in meta.items()};protocol={'base':meta['baseline']['revision'],'binaries':meta,'settings':{'model':'UD-Q4_K_XL','mtp':'sharedQ8_0','context_capacity':65536,'chunk':2048,'cache_ram_bytes':1073741824,'temperature':0,'thinking':'off'},'design_sha256':hashlib.sha256((mainlab/'PROTOCOL.md').read_bytes()).hexdigest(),'requests_sha256':hashlib.sha256((mainlab/'requests.py').read_bytes()).hexdigest(),'sequence':[['p14-b','baseline',2],['p14-c','pr14',2],['p15-c','pr15',8],['p15-b','baseline',8]],'scope':'Source observer only; triggered by predeclared long-gap/phase flags in fixed untraced acquisition. Four bounded starts, no throughput/gain pooling or statistical claim. Ring events use same-host monotonic clocks; no cross-host clock subtraction.'}
(lab/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
def remote(args,**kwargs):return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(args)],check=True,**kwargs)
def inventory(label):
 code="""from pathlib import Path
import json,platform
r=Path('/sys/module/thunderbolt_ibverbs')
def read(p):
 try:return Path(p).read_text().strip()
 except OSError:return None
print(json.dumps({'host':platform.node(),'kernel':platform.release(),'boot_id':read('/proc/sys/kernel/random/boot_id'),'cmdline':read('/proc/cmdline'),'srcversion':read(r/'srcversion'),'refcnt':read(r/'refcnt'),'parameters':{p.name:read(p) for p in (r/'parameters').glob('*')},'devices':[p.name for p in Path('/sys/class/infiniband').glob('*')],'links':{str(p):read(p) for name in ('rx_speed','tx_speed','rx_lanes','tx_lanes') for p in Path('/sys/bus/thunderbolt/devices').glob('*/'+name)}}))"""
 rows=[]
 for rank in (0,1):
  cmd=['python3','-c',code]
  if rank:cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',peer,shlex.join(cmd)]
  value=json.loads(subprocess.check_output(cmd,text=True,timeout=30));rows.append(value);(lab/f'{label}-inventory-r{rank}.json').write_text(json.dumps(value,indent=2)+'\n')
  assert value['srcversion']=='B6C332F34D27E163651EE38',value
  assert value['refcnt']=='0',value
 return rows
def snapshot(label):
 for rank in (0,1):
  cmd=['sudo','-n','/usr/local/sbin/strix-rdma-helper','snapshot']
  if rank:cmd=['ssh','-o','BatchMode=yes',peer,shlex.join(cmd)]
  (lab/f'{label}-snapshot-r{rank}.txt').write_text(subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT,timeout=30))
def stop(p):
 if p.poll() is None:
  p.send_signal(signal.SIGINT)
  try:p.wait(timeout=40)
  except subprocess.TimeoutExpired:
   p.terminate()
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:p.kill();p.wait()
for role,m in meta.items():
 binary=Path(m['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==m['sha256'];remote(['mkdir','-p',str(binary.parent)]);subprocess.run(['rsync','-a',str(binary),peer+':'+str(binary)],check=True)
 check=subprocess.check_output(['ssh',peer,'sha256sum',str(binary)],text=True).split()[0];assert check==m['sha256']
remote(['mkdir','-p',str(mainlab)]);subprocess.run(['rsync','-a',str(mainlab/'run-rank.py'),peer+':'+str(mainlab/'run-rank.py')],check=True)
initial=inventory('initial');snapshot('initial');reference={};completed=[]
for label,role,capacity in protocol['sequence']:
 start=time.monotonic();inventory(label+'-before');snapshot(label+'-before')
 with socket.socket() as reserve:reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
 command=[sys.executable,str(launcher),'serve','llm','--model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-00001-of-00004.gguf','--served-model-name','hc-c2-test','--host','127.0.0.1','--port',str(port),'--context','65536','--sessions',str(capacity),'--prefill-chunk','2048','--cache-ram-bytes','1073741824','--think','off','--speculative','mtp','--mtp-model','/home/rkuo/models/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf','--draft-tokens','7']
 env=os.environ.copy();env['DFLASH_TP_RUNTIME']=str(mainlab/'runtime'/('trace-v3-'+role));env['DFLASH_TP_LAUNCH_RECORDS']=str(lab/'launch'/label);Path(env['DFLASH_TP_LAUNCH_RECORDS']).mkdir(parents=True)
 for key in ('LD_PRELOAD','ROCP_TOOL_ATTACH','GUFO_TP_TRACE_PREFIX'):env.pop(key,None)
 (lab/f'{label}-launch.json').write_text(json.dumps({'command':command,'runtime':env['DFLASH_TP_RUNTIME'],'role':role,'sessions':capacity},indent=2)+'\n')
 print('START',label,role,'slots',capacity,flush=True)
 with (lab/f'{label}-server.log').open('w') as log:
  process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+240
   while True:
    if process.poll() is not None:raise RuntimeError(f'{label} launcher exited: {process.returncode}')
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as response:
      if response.status==200:break
    except OSError:pass
    if time.monotonic()>deadline:raise TimeoutError(label+' readiness')
    time.sleep(.2)
   with (lab/f'{label}-client.log').open('w') as client:
    subprocess.run([sys.executable,str(mainlab/'requests.py'),f'http://127.0.0.1:{port}',str(lab/f'{label}.jsonl')],stdout=client,stderr=subprocess.STDOUT,check=True,timeout=600)
  finally:stop(process)
 subprocess.run(['rsync','-a','--include=*/','--include=*-trace.csv','--exclude=*',peer+':'+str(lab/'launch'/label)+'/',str(lab/'launch'/label)+'/'],check=True)
 snapshot(label+'-after');inv=inventory(label+'-after');assert all(all(a[k]==b[k] for k in ('boot_id','cmdline','srcversion','parameters','links')) for a,b in zip(initial,inv))
 rows=[json.loads(x) for x in (lab/f'{label}.jsonl').read_text().splitlines()];assert len(rows)==21,len(rows)
 identity=[{k:r[k] for k in ('case','rep','actor','width','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256')} for r in rows]
 key='pr14' if label.startswith('p14') else 'pr15'
 if key not in reference:reference[key]=identity
 else:assert reference[key]==identity,(label,'output/prompt/cache work mismatch')
 assert all(r['draft_tokens']>0 for r in rows if r['case'] in ('natural-c2','coding-c2'))
 completed.append({'label':label,'role':role,'sessions':capacity,'seconds':time.monotonic()-start,'requests':len(rows)});(lab/'completed.json').write_text(json.dumps(completed,indent=2)+'\n');print('PASS',label,round(completed[-1]['seconds'],2),'seconds',flush=True)
(lab/'complete').touch();snapshot('final');inventory('final');print('ACQUISITION COMPLETE',flush=True)
