from pathlib import Path
import hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent;src=p.parent/'dflash2-flash-next-worktree';meta=json.loads((p/'binaries.json').read_text());paths=['src/cli/serve/text_generation_scheduler.cpp','src/cli/serve/text_model_runner.cpp','src/models/qwen38_flash_next/kernels/rocm/batch.cpp'];out={}
def run(args,log=None):return subprocess.run(args,cwd=src,check=True,stdout=log,stderr=subprocess.STDOUT if log else None)
original=subprocess.check_output(['git','branch','--show-current'],cwd=src,text=True).strip()
assert original=='review/flash-next-dflash2' and not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True).strip()
try:
 for role,m in meta.items():
  run(['git','switch','evidence/hc-c2-20261108-'+role])
  try:
   for name in paths:shutil.copy2(p/'trace-source'/role/name,src/name)
   with (p/f'trace-build-{role}.log').open('w') as log:
    run(['cmake','--preset','release','-DGUFO_ENABLE_TP2_RDMA=ON','-DGUFO_BUILD_TOOLS=OFF','-DGUFO_REVISION='+m['revision']+'-hcdiag'],log)
    run(['cmake','--build','--preset','release','--parallel','4','--target','gufo'],log)
   binary=p/'runtime'/('trace-'+role)/'bin/gufo';binary.parent.mkdir(parents=True,exist_ok=False);shutil.copy2(src/'build/release/gufo',binary)
   out[role]={'parent_revision':m['revision'],'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'observer_sha256':hashlib.sha256((p/'observer.hpp').read_bytes()).hexdigest(),'instrumented_sources':{n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in paths},'scope':'Diagnostic observer; not used for throughput or gain estimates. Only host source timestamps and aggregate HC producer/fusion counts; rings flushed at orderly process exit.'}
   (p/'trace-binaries.json').write_text(json.dumps(out,indent=2)+'\n');print('FROZEN TRACE',role,out[role]['sha256'],flush=True)
  finally:run(['git','restore','--',*paths])
finally:run(['git','switch',original])
