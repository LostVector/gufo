# Fork PR16 merge

Merged into LostVector/gufo:tp2 as
`59855a97a52cb678d66ce3edc3964ceaac6b974e`
on 2026-11-08T17:59:41Z.

The final feature-head fix `39705db3` imports DraftBackend through the public
`<gufo/ext/draft_backend.hpp>` extension surface instead of the core-private
header. CPU donor/lookup checks, formatting, extension API, strict model/core
boundary and family graph checks passed before the merge. This is a fork-only
merge; no upstream publication or default trial binary replacement occurred.

https://github.com/LostVector/gufo/pull/16
