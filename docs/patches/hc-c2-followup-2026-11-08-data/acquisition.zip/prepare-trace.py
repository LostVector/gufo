from pathlib import Path
import hashlib,json,re,subprocess
lab=Path(__file__).resolve().parent;src=lab.parent/'dflash2-flash-next-worktree';meta=json.loads((lab/'binaries.json').read_text())
paths=['src/cli/serve/text_generation_scheduler.cpp','src/cli/serve/text_model_runner.cpp','src/models/qwen38_flash_next/kernels/rocm/batch.cpp']
def replace(s,a,b):assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
for role,m in meta.items():
 out=lab/'trace-source'/role;out.mkdir(parents=True,exist_ok=True)
 texts={p:subprocess.check_output(['git','show',m['revision']+':'+p],cwd=src,text=True) for p in paths}
 s=texts[paths[0]]
 s=replace(s,'struct ScheduledRequest {','struct ScheduledRequest {\n  mutable std::size_t hc_diag_seen_snapshot = ~std::size_t{0};')
 for anchor,name in [('''  void StepPrefill(const std::shared_ptr<ScheduledRequest>& request,
                   bool decoder_runnable, bool peer_waiting = false) {''','prefill'),('''  [[nodiscard]] bool PublishSelection(
      const std::shared_ptr<ScheduledRequest>& request,
      const TextDecodeSelection& selection) {''','publish'),('''  bool PrepareFirstSnapshot(const std::shared_ptr<ScheduledRequest>& request) {''','first-snapshot')]:s=replace(s,anchor,anchor+'\n    hc_diag::RequestScope diag("'+name+'", *request);')
 anchor='''      const auto preview = request->runner_request.PreviewFirstToken();''';s=replace(s,anchor,'      hc_diag::request("preview-before", *request);\n'+anchor+'\n      hc_diag::request("preview-return", *request);')
 anchor='''      steps = runner_pool->DecodeBatch(runner_requests, max_tokens, plan);''';s=replace(s,anchor,'''      for (const auto& diag_item : prepared)
        hc_diag::request("decode-batch-before", *diag_item.request);
'''+anchor+'''
      for (const auto& diag_item : prepared)
        hc_diag::request("decode-batch-after", *diag_item.request);''')
 regex=r'(?m)^([ \t]*)(pending|ready|request)->runner_request.PrepareBatchExecution\(\);$'
 def wrapped(m):
  i,v=m.groups();return i+'{ hc_diag::RequestScope diag("prepare-runner", *'+v+');\n'+i+'  '+v+'->runner_request.PrepareBatchExecution(); }'
 s,n=re.subn(regex,wrapped,s);assert n>=2,n
 anchor='''      const auto step = request->runner_request.DecodeStep(remaining);'''
 s=replace(s,anchor,'''      hc_diag::request("decode-single-before", *request);
'''+anchor+'''
      hc_diag::request("decode-single-after", *request);
      if (request->result.tokens.size() < 8)
        hc_diag::emit("decode-single-work", &request->runner_request, request.get(), request->id,
                      step.draft_rounds, step.draft_tokens, step.draft_accepted_tokens);''')
 texts[paths[0]]=s
 s=texts[paths[1]]
 s=replace(s,'struct TextRunnerPool::Request::Impl {','struct TextRunnerPool::Request::Impl {\n  mutable int hc_diag_pending_state = -1;\n  const void* hc_diag_link = nullptr;')
 anchor='''    snapshot_start = std::chrono::steady_clock::now();''';s=replace(s,anchor,anchor+'\n    hc_diag_pending_state = -1;\n    hc_diag::emit("snapshot-enqueue", this, state, snapshot_tokens.size(), wait);')
 anchor='''                      reservation = std::move(reservation)]() mutable {''';s=replace(s,anchor,anchor+'\n                       hc_diag::Scope diag("snapshot-worker", this, state, snapshot_tokens.size());')
 anchor='''  void FinishPromptSnapshot() noexcept {''';s=replace(s,anchor,anchor+'\n    hc_diag::Scope diag("snapshot-get", this, nullptr, snapshot_tokens.size());')
 anchor='''bool TextRunnerPool::Request::PreparePromptSnapshot() {''';s=replace(s,anchor,anchor+'\n  if (impl_ && impl_->hc_diag_link != this) {\n    hc_diag::emit("request-link", this, impl_.get());\n    impl_->hc_diag_link = this;\n  }')
 anchor='''bool TextRunnerPool::Request::SnapshotPending() const {
  return impl_ && impl_->snapshot_future.valid() &&
         impl_->snapshot_future.wait_for(std::chrono::seconds(0)) !=
             std::future_status::ready;
}''';s=replace(s,anchor,'''bool TextRunnerPool::Request::SnapshotPending() const {
  const bool pending = impl_ && impl_->snapshot_future.valid() &&
         impl_->snapshot_future.wait_for(std::chrono::seconds(0)) !=
             std::future_status::ready;
  if (impl_ && impl_->snapshot_future.valid() && impl_->hc_diag_pending_state != int(pending)) {
    impl_->hc_diag_pending_state = pending;
    hc_diag::emit("snapshot-poll", this, impl_.get(), 0, pending);
  }
  return pending;
}''');texts[paths[1]]=s
 s=texts[paths[2]];a=s.index('bool Executor::HcMixBatch(');i=s.index('  const auto& c = config();',a);s=s[:i]+'  hc_diag::count(0, rows);\n'+s[i:]
 if role=='pr14':
  anchor='''  if (q8)
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};''';s=replace(s,anchor,'''  if (q8) {
    hc_diag::count(1, rows);
    mixed_q8_ready_ = {mixed, s_.mixed_q8_1, rows, c.hidden_size};
  }''')
 if role=='pr15':
  anchor='''          !defer_residual_ && !moe_pending_) {
        DropReadyQ8();''';s=replace(s,anchor,'''          !defer_residual_ && !moe_pending_) {
        hc_diag::count(2, rows);
        DropReadyQ8();''')
 texts[paths[2]]=s
 for path,text in texts.items():
  p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('#include "'+str(lab/'observer.hpp')+'"\n'+text)
(out.parent/'prepared.json').write_text(json.dumps({'observer_sha256':hashlib.sha256((lab/'observer.hpp').read_bytes()).hexdigest(),'roles':list(meta),'scope':'Private bounded source observer; clocks local per host; ring flush only at process exit; no gain measurements from observer binaries.'},indent=2)+'\n')
print('Prepared observer sources for all three roles')
