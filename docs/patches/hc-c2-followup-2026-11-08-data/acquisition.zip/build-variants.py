from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess
lab=Path(__file__).resolve().parent;src=lab.parent/'dflash2-flash-next-worktree';build=src/'build/release'
base='59855a97a52cb678d66ce3edc3964ceaac6b974e';sdk=Path('/home/rkuo/.local/opt/rocm-7.14.1');deps=Path('/home/rkuo/strix-dispatch-investigation/dependencies/gufo-dev')
def run(cmd,log=None):return subprocess.run(cmd,cwd=src,check=True,stdout=log,stderr=subprocess.STDOUT if log else None)
def git(*args):return subprocess.check_output(['git',*args],cwd=src,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(4<<20):h.update(b)
 return h.hexdigest()
assert not git('status','--porcelain');assert not(lab/'binaries.json').exists();original=git('branch','--show-current');assert original=='review/flash-next-dflash2'
roles=[('baseline',None),('pr14','f5e9290cabf48dfeca521847dd60f3692b3c2927'),('pr15','74f385dc46e68e06be8975c6ab41682d7591add4')];records={}
try:
 for role,patch in roles:
  run(['git','switch','-c','evidence/hc-c2-20261108-'+role,base])
  if patch:run(['git','-c','user.name=Richard Kuo','-c','user.email=7145755+LostVector@users.noreply.github.com','cherry-pick',patch])
  revision=git('rev-parse','HEAD');config=['cmake','--preset','release','-DGUFO_ENABLE_TP2_RDMA=ON','-DGUFO_BUILD_TOOLS=OFF','-DGUFO_REVISION='+revision,'-DCMAKE_C_COMPILER='+str(sdk/'bin/amdclang'),'-DCMAKE_CXX_COMPILER='+str(sdk/'bin/amdclang++'),'-DCMAKE_HIP_COMPILER='+str(sdk/'lib/llvm/bin/clang++'),'-DCMAKE_HIP_ARCHITECTURES=gfx1151','-DCMAKE_PREFIX_PATH='+str(sdk)+';'+str(deps/'usr'),'-DPKG_CONFIG_EXECUTABLE='+str(deps/'usr/bin/pkgconf'),'-DPython3_EXECUTABLE=/home/rkuo/strix-dispatch-investigation/.venv/bin/python']
  with (lab/f'build-{role}.log').open('w') as log:run(config,log);run(['cmake','--build','--preset','release','--parallel','4','--target','gufo'],log)
  binary=lab/'runtime'/role/'bin/gufo';binary.parent.mkdir(parents=True);shutil.copy2(build/'gufo',binary)
  commands=json.loads((build/'compile_commands.json').read_text());(lab/f'compile-{role}.json').write_text(json.dumps(commands,indent=2)+'\n')
  (lab/f'source-{role}.patch').write_text(git('diff',base,revision)+'\n')
  records[role]={'revision':revision,'binary':str(binary),'sha256':sha(binary),'base':base,'patch':patch,'batch_sha256':sha(src/'src/models/qwen38_flash_next/kernels/rocm/batch.cpp'),'build_type':'RelWithDebInfo','testing':False,'rdma':True,'configuration_command':config,'compile_units':len(commands)}
  (lab/'binaries.json').write_text(json.dumps(records,indent=2)+'\n');print('FROZEN',role,revision,records[role]['sha256'],flush=True)
 (lab/'build-complete').touch()
finally:run(['git','switch',original])
