from pathlib import Path
import collections,csv,json,re,statistics
p=Path(__file__).resolve().parent;q=p/'trace-v2-acquisition'
def fnv(s):
 h=14695981039346656037
 for c in s.encode():h=((h^c)*1099511628211)&((1<<64)-1)
 return h
def merge(intervals):
 out=[]
 for a,b in sorted(intervals):
  if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
  else:out.append([a,b])
 return out
def overlap(a,b,intervals):return sum(max(0,min(b,y)-max(a,x)) for x,y in merge(intervals))
allrows=[];scopes=[];meta={}
for label,role,slots in json.loads((q/'protocol.json').read_text())['sequence']:
 if not(q/f'{label}.jsonl').exists():continue
 files=list((q/'launch'/label).rglob('rank0-pid-trace.csv'))
 if not files:continue
 assert len(files)==1
 lines=files[0].read_text().splitlines();assert 'overflow=0' in lines[0],lines[0]
 events=[{k:(v if k=='stage' else int(v)) for k,v in r.items()} for r in csv.DictReader(s for s in lines if not s.startswith('#'))];events.sort(key=lambda r:r['ns']);meta[label]={'events':len(events),'header':lines[0],'counters':[s for s in lines if s.startswith('# counters')]}
 spans=[];stack=collections.defaultdict(list)
 for e in events:
  if e['stage'] not in ('snapshot-worker','snapshot-get','prefill','publish','prepare-runner','first-snapshot'):continue
  key=(e['tid'],e['stage'],e['owner'],e['key'])
  if e['a']==1:stack[key].append(e)
  elif e['a']==2:
   assert stack[key],e
   a=stack[key].pop();spans.append({'stage':e['stage'],'owner':e['owner'],'key':e['key'],'start':a['ns'],'end':e['ns'],'before_tokens':a['b'],'after_tokens':e['b'],'client_hash':e['c']})
 assert not any(stack.values())
 dstart={};decode=[]
 for e in events:
  key=(e['owner'],e['key'])
  if e['stage'] in ('decode-batch-before','decode-single-before'):dstart[key]=e['ns']
  elif e['stage'] in ('decode-batch-after','decode-single-after'):
   assert key in dstart;decode.append({'owner':e['owner'],'key':e['key'],'start':dstart.pop(key),'end':e['ns']})
 assert not dstart
 dispatch=[(x['start'],x['end']) for x in spans if x['stage']=='prefill']+[(x['start'],x['end']) for x in decode]
 clients=[json.loads(x) for x in (q/f'{label}.jsonl').read_text().splitlines()]
 measured=sorted((x for x in clients if x['case']!='warmup-short'),key=lambda x:x['started_at'])
 ids=sorted(set(x['key'] for x in spans if x['stage']=='publish'))
 assert len(ids)==len(measured),(label,len(ids),len(measured))
 # Server uses peer identity, not X-Client-ID. Join serialized waves by monotonically
 # increasing request ID and staggered admission; verify every join against time bounds.
 mapping={(x['case'],x['rep'],x['actor']):rid for x,rid in zip(measured,ids)}
 for client in clients:
  if client['case']=='warmup-short':continue
  start=int(client['started_at']*1e9);end=int(client['finished_at']*1e9);ch=fnv(f"hc-{client['case']}-{client['actor']}")
  pubs=[x for x in spans if x['stage']=='publish' and x['key']==mapping[(client['case'],client['rep'],client['actor'])] and start<=x['start']<=end];assert pubs,(label,client['case'],client['rep'],client['actor'])
  first=min(x['end'] for x in pubs if x['after_tokens']>=1);second=min(x['end'] for x in pubs if x['after_tokens']>=2);rid=pubs[0]['key'];owner=pubs[0]['owner']
  links=[e for e in events if e['stage']=='request-link' and e['owner']==owner and start<=e['ns']<=end];assert links
  impl=links[0]['object'];jobs=[e for e in events if e['stage']=='snapshot-enqueue' and e['owner']==impl and start<=e['ns']<=second];assert jobs
  job=max(jobs,key=lambda e:(e['key'],e['ns']));workers=[x for x in spans if x['stage']=='snapshot-worker' and x['owner']==impl and x['key']==job['key'] and job['ns']<=x['start']<=second];gets=[x for x in spans if x['stage']=='snapshot-get' and x['owner']==impl and x['key']==job['key'] and job['ns']<=x['start']<=second]
  assert workers and gets,(label,rid,impl,job)
  worker=workers[0];get=gets[0];own=[x for x in decode if x['key']==rid and first<=x['start']<second];a=worker['end'];b=get['start']
  record={'launch':label,'role':role,'sessions':slots,'case':client['case'],'rep':client['rep'],'actor':client['actor'],'warmup':client['warmup'],'source_request_id':rid,'client_first_followup_ms':client['first_followup_ms'],'publication_gap_ms':(second-first)/1e6,'worker_queue_ms':(worker['start']-job['ns'])/1e6,'snapshot_worker_ms':(worker['end']-worker['start'])/1e6,'worker_end_to_get_ms':(b-a)/1e6,'future_get_ms':(get['end']-get['start'])/1e6,'wait_overlap_inference_wall_ms':overlap(a,b,dispatch)/1e6 if b>=a else 0,'own_decode_calls_before_second_publication':len(own),'own_decode_wall_ms':sum(x['end']-x['start'] for x in own)/1e6,'publication_gap_overlap_inference_wall_ms':overlap(first,second,dispatch)/1e6,'early_single_decode_work':[{'draft_rounds':e['a'],'draft_tokens':e['b'],'accepted':e['c']} for e in events if e['stage']=='decode-single-work' and e['key']==rid and first<=e['ns']<=second]}
  allrows.append(record)
scopes={'scope':'Same-host EVO source spans and local client content-arrival times only. No cross-node timestamp subtraction. Model dispatch/completion wall spans include GPU/RDMA/sync/CPU work, not pure GPU compute. Observer data not used for throughput/gain estimates.','records':allrows,'events':meta}
(p/'trace-v2-analysis.json').write_text(json.dumps(scopes,indent=2)+'\n')
print('source joined requests',len(allrows))
for role in ('baseline','pr14','pr15'):
 for actor in (0,1):
  rows=[r for r in allrows if r['role']==role and r['actor']==actor and r['case']=='natural-c2']
  if rows:print(role,actor,{k:round(statistics.median(x[k] for x in rows),3) for k in ('publication_gap_ms','snapshot_worker_ms','worker_end_to_get_ms','wait_overlap_inference_wall_ms','own_decode_calls_before_second_publication','own_decode_wall_ms','publication_gap_overlap_inference_wall_ms')})
