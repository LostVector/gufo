from pathlib import Path
import concurrent.futures,hashlib,json,sys,threading,time
lab=Path(__file__).resolve().parent
src=lab.parent/'dflash2-flash-next-worktree'
sys.path.insert(0,str(src/'tools'))
from gufo import serving_bench as bench
original_int=bench._required_integer;original_sse=bench._sse_data;local=threading.local()
def integer(metrics,key):
 if key=='prefill_tokens':local.metrics=dict(metrics)
 return original_int(metrics,key)
def sse(response):
 for event in original_sse(response):
  if event!='[DONE]':
   p=json.loads(event);choices=p.get('choices')
   if isinstance(choices,list) and choices:
    d=choices[0].get('delta',{});content=d.get('content')
    if content or d.get('tool_calls'):local.events.append({'ns':time.perf_counter_ns(),'content_bytes':len(content.encode()) if isinstance(content,str) else 0,'content':content})
  yield event
bench._required_integer=integer;bench._sse_data=sse
class Gate:
 def __init__(self,actor,event):self.actor=actor;self.event=event
 def wait(self):
  if self.actor==0:self.event.set()
  else:self.event.wait();time.sleep(.01)
base=sys.argv[1];destination=Path(sys.argv[2]);rows=[]
natural=['Write a detailed numbered list of thirty practical ways to debug a slow distributed inference server. Explain each item.\nRequest variant '+str(i)+'.' for i in range(2)]
coding=['Implement a Python asynchronous work queue with bounded concurrency, fair scheduling and cancellation. Provide code and explain the invariants.','Implement a C++ bounded concurrent queue. Explain safe producer and consumer shutdown and provide code.']
pp=json.loads(Path('/home/rkuo/strix-dispatch-investigation/prefill-scaling/results/prompts.json').read_text())['2048']
def request(case,text,actor=0,width=1,tokens=128,rep=0,gate=None):
 local.metrics=None;local.events=[]
 obs=bench.run_request(base_url=base,model='hc-c2-test',prompt=text,max_tokens=tokens,temperature=0,timeout_seconds=300,client_id=f'hc-{case}-{actor}',concurrency=width,repetition=rep,request_index=actor,start_gate=gate,cache_prompt=False,extra_body={'chat_template_kwargs':{'enable_thinking':False}},endpoint_profile='gufo')
 events=local.events;row={'case':case,'rep':rep,'actor':actor,'width':width,'warmup':case.startswith('warmup'),'prompt_sha256':hashlib.sha256(text.encode()).hexdigest(),'started_at':obs.started_at,'finished_at':obs.finished_at,'events':events,'raw_gufo':local.metrics,**obs.public()}
 row['first_followup_ms']=(events[1]['ns']-events[0]['ns'])/1e6 if len(events)>1 else None
 row['second_content_ms']=(events[1]['ns']/1e9-obs.started_at)*1000 if len(events)>1 else None
 assert row['prefill_tokens']==row['prompt_tokens'] and row['cached_prompt_tokens']==0,row
 return row
with destination.open('x') as f:
 def save(r):rows.append(r);f.write(json.dumps(r)+'\n');f.flush()
 def wave(case,texts,tokens,rep):
  gate=threading.Event()
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   jobs=[pool.submit(request,case,text,actor,2,tokens,rep,Gate(actor,gate)) for actor,text in enumerate(texts)]
   got=[j.result() for j in jobs]
  for row in got:save(row)
  print(case,rep,[(r['actor'],r['completion_tokens'],r['first_followup_ms'],r['raw_gufo'].get('resident_requests_at_admission')) for r in got],flush=True)
 save(request('warmup-short','Explain tensor parallel inference briefly.',tokens=8))
 wave('warmup-c2',natural,128,0)
 save(request('c1-before',pp,rep=1))
 for rep in range(4):wave('natural-c2',natural,128,rep)
 for rep in range(4):wave('coding-c2',coding,256,rep)
 save(request('c1-after',pp,rep=2))
print('COMPLETE',len(rows),'requests',flush=True)
