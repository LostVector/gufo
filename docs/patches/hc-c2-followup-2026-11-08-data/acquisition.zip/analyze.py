from pathlib import Path
import csv,json,math,re,statistics
p=Path(__file__).resolve().parent;assert(p/'complete').exists()
protocol=json.loads((p/'protocol.json').read_text());data={name:[json.loads(x) for x in (p/f'{name}.jsonl').read_text().splitlines()] for name,_,_ in protocol['sequence']}
errors={};baseline_same={}
for label,_,_ in protocol['sequence']:
 for rank in (0,1):
  def counters(tag):return {k:int(v) for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(p/f'{label}-{tag}-snapshot-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  a,b=counters('before'),counters('after');assert len(a)>100 and a.keys()==b.keys()
  diff={k:b[k]-v for k,v in a.items() if b[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  if diff:errors.setdefault(label,{})[str(rank)]=diff
fields=['wall_ms','queue_ms','prefill_ms','decode_ms','client_ttft_ms','server_ttft_ms','first_followup_ms','second_content_ms','server_max_inter_token_ms']
flags=[];work=[];pairs=[];wave=[]
identity=['case','rep','actor','width','prompt_sha256','prompt_tokens','prefill_tokens','cached_prompt_tokens','completion_tokens','completion_sha256']
for pr in ['14','15']:
 for pair in [1,2]:
  b=f'p{pr}-b{pair}';c=f'p{pr}-c{pair}';bb=data[b];cc=data[c];assert len(bb)==len(cc)==21
  for x,y in zip(bb,cc):
   assert all(x[k]==y[k] for k in identity),(pr,pair,x['case'],x['rep'],x['actor'])
   if x['warmup']:continue
   for key in fields:
    a,v=x.get(key),y.get(key)
    if a is not None and v is not None and v-a>max(3,a*.05):flags.append({'pr':pr,'pair':pair,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'metric':key,'baseline':a,'candidate':v,'delta_ms':v-a,'transport_errors_in_candidate':c in errors})
   for key in ['draft_tokens','draft_accepted_tokens']:
    if x[key]!=y[key]:work.append({'pr':pr,'pair':pair,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'field':key,'baseline':x[key],'candidate':y[key]})
   for key in ['draft_rounds']:
    if x['raw_gufo'].get(key)!=y['raw_gufo'].get(key):work.append({'pr':pr,'pair':pair,'case':x['case'],'rep':x['rep'],'actor':x['actor'],'field':key,'baseline':x['raw_gufo'].get(key),'candidate':y['raw_gufo'].get(key)})
  for case in ['natural-c2','coding-c2']:
   br=[];cr=[]
   for rep in range(4):
    arm=[]
    for d in (bb,cc):
     r=[x for x in d if x['case']==case and x['rep']==rep];assert len(r)==2
     arm.append(sum(x['completion_tokens'] for x in r)/(max(x['finished_at'] for x in r)-min(x['started_at'] for x in r)))
    br.append(arm[0]);cr.append(arm[1]);wave.append({'pr':pr,'pair':pair,'case':case,'rep':rep,'baseline_tps':arm[0],'candidate_tps':arm[1],'change_percent':100*(arm[1]/arm[0]-1),'candidate_transport_errors':c in errors})
   pairs.append({'pr':pr,'pair':pair,'case':case,'baseline_wave_tps':statistics.geometric_mean(br),'candidate_wave_tps':statistics.geometric_mean(cr),'geometric_paired_change_percent':100*(statistics.geometric_mean(v/a for a,v in zip(br,cr))-1)})
summary={'scope':'Current-base bounded diagnostic; two process pairs per optimization, four waves per workload per start. Waves within a process are not independent process repetitions. No pooling with prior studies.','base':protocol['base'],'starts':8,'requests':sum(map(len,data.values())),'all_output_prompt_cache_identities_match':True,'transport_errors':errors,'phase_gate':'candidate-baseline > max(3ms,5% baseline), unchanged; correlated fields are not independent faults','flags':flags,'adaptive_work_differences':work,'paired_descriptive_results':pairs,'waves':wave,'source_trace_required_by_protocol':any(x['first_followup_ms'] and x['first_followup_ms']>80 for d in data.values() for x in d if not x['warmup']) or bool(flags),'limits':['Transport errors make affected launches confounded; no sample excluded or replaced.','Only two process pairs per optimization; no significance, equivalence or superiority conclusion.','Client content-arrival events are publication chunks, not individual GPU token completions.']}
(p/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
with(p/'phase-flags.csv').open('w')as f:
 if flags:w=csv.DictWriter(f,fieldnames=list(flags[0]));w.writeheader();w.writerows(flags)
print(json.dumps({'starts':summary['starts'],'requests':summary['requests'],'error_launches':list(errors),'phase_flags':len(flags),'work_changes':len(work),'pairs':pairs,'source_trace_required':summary['source_trace_required_by_protocol']},indent=2))
