# Observer build validity

The first observer acquisition is retained but candidate traces are invalid for
role attribution: `copy2` preserved old source mtimes, so incremental CMake did
not recompile the three copied source files for candidate roles. Baseline source
spans remain diagnostic only; no candidate comparisons or path counts can be
claimed from this observer. The v2 build has the same issue and was not run.
The production untraced acquisition is unaffected: git checkout updated source
mtimes and its logs explicitly show each changed batch.cpp compilation.

The v3 observer builder uses copyfile plus touch and asserts the build log contains
every one of the three changed translation units for every role. All old files
are retained. Source copies and compiler events are audited independently of the
binary revision string.
