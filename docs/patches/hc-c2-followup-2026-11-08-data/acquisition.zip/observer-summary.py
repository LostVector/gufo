from pathlib import Path
import csv,json,re,statistics
p=Path(__file__).resolve().parent;q=p/'trace-v3-acquisition'
a=json.loads((p/'trace-v3-analysis.json').read_text());out={}
for label,role,slots in json.loads((q/'protocol.json').read_text())['sequence']:
 m={'role':role,'sessions':slots,'errors':{},'hc_counts':{}}
 for rank in (0,1):
  def counters(tag):return {k:int(v) for k,v in re.findall(r'^((?:data|dmabuf)_\w+): (\d+)$',(q/f'{label}-{tag}-snapshot-r{rank}.txt').read_text().split('\nFILE ',1)[0],re.M)}
  before,after=counters('before'),counters('after');assert len(before)>100 and before.keys()==after.keys()
  m['errors'][rank]={k:after[k]-v for k,v in before.items() if after[k]!=v and re.search('error|retransmit|retry_exhausted|timeout|lost|drop|fail|bad_frame|bad_header|poison|overrun',k)}
  f=list((q/'launch'/label).rglob(f'rank{rank}-pid-trace.csv'));assert len(f)==1
  text=f[0].read_text();assert 'overflow=0' in text.splitlines()[0]
  counts=[dict(zip(('rows','batch','ready_producer','fused'),map(int,t))) for t in re.findall(r'# counters rows=(\d+) batch=(\d+) ready_producer=(\d+) fused=(\d+)',text)]
  m['hc_counts'][rank]={'by_rows':counts,'totals':{k:sum(x[k] for x in counts) for k in ('batch','ready_producer','fused')}}
 m['natural_actors']={}
 for actor in (0,1):
  r=[x for x in a['records'] if x['launch']==label and x['case']=='natural-c2' and x['actor']==actor]
  m['natural_actors'][actor]={k:statistics.median(x[k] for x in r) for k in ('publication_gap_ms','snapshot_worker_ms','worker_end_to_get_ms','future_get_ms','wait_overlap_inference_wall_ms','own_decode_calls_before_second_publication','own_decode_wall_ms','publication_gap_overlap_inference_wall_ms')}
  m['natural_actors'][actor]['early_work']=[x['early_single_decode_work'] for x in r]
 out[label]=m
(p/'observer-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for label,m in out.items():print(label,json.dumps({k:v for k,v in m.items() if k!='hc_counts'}),{r:c['totals'] for r,c in m['hc_counts'].items()})
