#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string_view>
#include <sys/syscall.h>
#include <unistd.h>
namespace hc_diag {
constexpr std::size_t capacity=65536;
struct alignas(64) Record { std::uint64_t ns{},tid{};const char* stage{};std::uintptr_t owner{},object{};std::uint64_t key{},a{},b{},c{};std::atomic<bool> ready{false};};
struct Recorder {
 const char* path=std::getenv("HC_C2_TRACE_PATH");
 std::atomic<std::size_t> next{0};std::array<Record,capacity> rows{};
 std::array<std::atomic<std::uint64_t>,66> batch{},ready{},fused{};
 ~Recorder(){
  if(!path)return;
  auto* f=std::fopen(path,"w");if(!f)return;
  const auto total=next.load();std::fprintf(f,"# capacity=%zu total=%zu overflow=%zu\n",capacity,total,total>capacity?total-capacity:0);
  std::fprintf(f,"ns,tid,stage,owner,object,key,a,b,c\n");
  for(std::size_t i=0;i<std::min(total,capacity);++i){const auto&r=rows[i];if(!r.ready.load(std::memory_order_acquire))continue;std::fprintf(f,"%llu,%llu,%s,%llu,%llu,%llu,%llu,%llu,%llu\n",(unsigned long long)r.ns,(unsigned long long)r.tid,r.stage,(unsigned long long)r.owner,(unsigned long long)r.object,(unsigned long long)r.key,(unsigned long long)r.a,(unsigned long long)r.b,(unsigned long long)r.c);}
  for(std::size_t n=0;n<66;++n)if(batch[n]||ready[n]||fused[n])std::fprintf(f,"# counters rows=%zu batch=%llu ready_producer=%llu fused=%llu\n",n,(unsigned long long)batch[n].load(),(unsigned long long)ready[n].load(),(unsigned long long)fused[n].load());
  std::fclose(f);
 }
};
inline Recorder recorder;
inline std::uint64_t now(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
inline std::uint64_t hash(std::string_view s){std::uint64_t h=14695981039346656037ULL;for(unsigned char c:s){h^=c;h*=1099511628211ULL;}return h;}
inline void emit(const char* stage,const void* owner,const void* object,std::uint64_t key=0,std::uint64_t a=0,std::uint64_t b=0,std::uint64_t c=0){
 if(!recorder.path)return;auto i=recorder.next.fetch_add(1,std::memory_order_relaxed);if(i>=capacity)return;
 thread_local const auto tid=static_cast<std::uint64_t>(::syscall(SYS_gettid));auto&r=recorder.rows[i];r.ns=now();r.tid=tid;r.stage=stage;r.owner=reinterpret_cast<std::uintptr_t>(owner);r.object=reinterpret_cast<std::uintptr_t>(object);r.key=key;r.a=a;r.b=b;r.c=c;r.ready.store(true,std::memory_order_release);
}
inline void count(unsigned kind,std::size_t rows){if(!recorder.path)return;auto&v=kind==0?recorder.batch:kind==1?recorder.ready:recorder.fused;v[std::min<std::size_t>(65,rows)].fetch_add(1,std::memory_order_relaxed);}
struct Scope {const char* stage;const void* owner;const void* object;std::uint64_t key;Scope(const char*s,const void*o,const void*p,std::uint64_t k=0):stage(s),owner(o),object(p),key(k){emit(stage,owner,object,key,1);}~Scope(){emit(stage,owner,object,key,2);}};
template<class R>struct RequestScope {const char*stage;const R&r;bool enabled;RequestScope(const char*s,const R&q):stage(s),r(q),enabled(recorder.path&&q.token_limit>=128&&q.result.tokens.size()<8){if(enabled&&stage[0]=='f'){if(r.hc_diag_seen_snapshot==r.result.tokens.size())enabled=false;else r.hc_diag_seen_snapshot=r.result.tokens.size();}if(enabled)emit(stage,&r.runner_request,&r,r.id,1,r.result.tokens.size(),hash(r.client_id));}~RequestScope(){if(enabled)emit(stage,&r.runner_request,&r,r.id,2,r.result.tokens.size(),hash(r.client_id));}};
template<class R>void request(const char*stage,const R&r){if(recorder.path&&r.token_limit>=128&&r.result.tokens.size()<8)emit(stage,&r.runner_request,&r,r.id,0,r.result.tokens.size(),hash(r.client_id));}
} // namespace hc_diag
