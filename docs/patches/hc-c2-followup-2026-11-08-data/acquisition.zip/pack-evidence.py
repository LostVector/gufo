from pathlib import Path
import hashlib,json,zipfile
p=Path(__file__).resolve().parent
assert (p/'complete').exists() and (p/'trace-v3-acquisition/complete').exists()
files=[]
for f in sorted(p.rglob('*')):
 if not f.is_file():continue
 r=f.relative_to(p)
 if any(x in r.parts for x in ('runtime','__pycache__','.git')):continue
 if f.name in ('acquisition.zip','archive.json'):continue
 assert f.suffix not in ('.ko','.o','.a','.so')
 assert not any(x in f.name.lower() for x in ('control.json','token.json','.pem','id_ed25519'))
 files.append(f)
with zipfile.ZipFile(p/'acquisition.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,str(f.relative_to(p)))
metadata={'sha256':hashlib.sha256((p/'acquisition.zip').read_bytes()).hexdigest(),'entries':{str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'scope':'Raw production and distinct observer acquisitions, sources, build logs and analyses. V1 candidate observers invalid, v2 not executed: see TRACE-LIMITATIONS.md. No binaries, model weights or control tokens.'}
(p/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(len(files),'entries', (p/'acquisition.zip').stat().st_size,'bytes')
