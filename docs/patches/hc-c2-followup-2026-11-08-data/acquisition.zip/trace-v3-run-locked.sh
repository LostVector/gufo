#!/usr/bin/env bash
set -euo pipefail
lab=/home/rkuo/strix-dispatch-investigation/tp-cache-retention/hc-c2-followup-2026-11-08
was_active=0
if systemctl --user is-active --quiet gufo-flash-next-trial.service; then was_active=1; fi
exec 9>/home/rkuo/strix-dispatch-investigation/overnight/results/model-matrix.lock
restore() {
 code=$?
 trap - EXIT INT TERM
 flock -u 9 || true
 if ((was_active)); then
  if ! bash /home/rkuo/start-flash-next.sh mtp > "$lab/trace-v3-restore-trial.log" 2>&1; then
   echo 'MTP restoration failed; inspect restore-trial.log' >&2
   exit 1
  fi
  echo 'Native MTP trial restored.'
 fi
 exit "$code"
}
trap restore EXIT
trap 'exit 130' INT TERM
if ((was_active)); then bash /home/rkuo/stop-flash-next.sh > "$lab/trace-v3-pause-trial.log" 2>&1; fi
flock -w 60 9
bash /home/rkuo/strix-dispatch-investigation/dflash-upstream-2026-11-07/build.sh python3 "$lab/trace-v3-run.py"
